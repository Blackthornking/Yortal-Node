# YORTAL v0.33 — overlapped pipeline

The range scheduler is gone. `crates/state/src/pipeline/` and
`crates/ycash-android-node/src/pipeline_sync.rs` were deleted, not renamed:
there is no AdaptiveController, RangeScheduler, RangeId, RangeLease,
ValidatedRange or `plan_parallel_ranges` left anywhere in the tree, and no
config key can re-enable them.

## Shape

```
peers (n)                verifier pool (m)          ordered gate (1)       writer (1)
≤48 in flight, each  →   semantic verification  →   prospective tree   →   one
slot refilled on         (context-free, out of      + chain selection      WriteBatch
arrival                  order, every core)         + contextual rules
```

Left of the gate: parallel, unordered, cancellable. Right of the gate:
single-threaded, strictly ancestry-ordered. That line is the entire design.

## Why this is faster than what it replaces

**No head-of-line blocking.** A range made the slowest block in a group of 100
hold up the other 99, and a stalled peer stalled a whole height window until a
hedge timer fired. Requests are now per block: 48 outstanding per peer, and the
slot is refilled the moment one arrives. One slow block costs one slot.

**No idle peers.** Ranges were claimed exclusively, so a peer with nothing to
claim sat idle. Any peer can now be given any unclaimed hash.

**Bulk context, once.** Header hashes, cumulative work and median-time-past for
a whole assignment window are read in three range queries at request time, so
verifier threads never touch the database and never queue behind the writer.

**Commit when ready, not when a range completes.** The gate drains everything
already queued, then publishes the longest contiguous run of children it has, up
to 48, in one `prepare_commit_batch` and one WriteBatch. Contextual rules still
run per block in height order inside that call, so a run of 48 and 48 runs of
one produce identical state. There is no linger timer: draining what has already
arrived gets the batching without adding latency, and keeps the canonical UTXO
cache hot across publications.

**Forks cost nothing.** Candidates are indexed by hash, parent and height, so an
out-of-order child is retained rather than dropped and re-fetched, and competing
blocks at one height stay distinguishable until chain selection.

## Why it cannot change consensus

Every rule runs where it already ran. Semantic verification calls the same
`validate_for_commit_batched_with_parsed`; contextual validation calls the same
`prepare_commit_batch`; publication calls the same `apply_prepared_commit`. No
consensus file was touched by this change.

The numbers are transport only. 48 blocks per peer, 192 in flight, 192
prospective, 48 blocks per WriteBatch, m verifier threads: each is a window or a
buffer, none is a consensus object. `SyncConfig::from_env` lets all of them
change at runtime, which is exactly how the 16/48/64 equivalence test is run.

Height-gated rules stay height-gated: each block carries its own `Context` built
from its own height, never from its position in a queue or batch.

## Deliberately not done

**Overlapping contextual preparation with the RocksDB write.** This is the next
real win — preparing block N+1 while N's WriteBatch is in flight — and it is
sound only with an in-memory overlay for Sapling anchors, nullifiers and Sprout
state, not just the UTXO cache that exists today. Without that overlay, a
transaction anchored in block N would be validated against a database that has
not yet seen N. The plans describe this as the working-state overlay; it belongs
in `chainstate.rs` and needs its own review and tests, so it was left out rather
than approximated. The structure here is ready for it: the gate is already the
only ordered component, and `BlockWriteWorker` is already the only writer.

**Desktop peer transport.** `crates/node/src/sync.rs` was removed with the range
scheduler. The engine lives in the node library and the Android coordinator
drives it; a headless driver can be rebuilt on the same API.

## Status

Written without a compiler available. Expect a CI pass to shake out type errors,
particularly around `ycash_node` module paths in the Android crate and the
telemetry field names in `runtime.rs`.

## Script verification

Transparent script checks were the largest single cost in a commit, and two
things were wrong with how they ran.

**Fixed now: the permit gate.** Every input inside the parallel loop took a
process-wide `Mutex` to acquire a `ScriptPermit`, and then took the same mutex
again to read the active count for telemetry. With cores-1 workers all queueing
on one lock for every input, the inside of the parallel section was serialised
against itself. The gate existed because the old pipeline had several components
driving the pool at once; the ordered state gate now guarantees exactly one
thread ever does, and the pool's own thread count already bounds the width. The
permit, its condvar and `SCRIPT_GATE` are gone.

**Still to do: the granularity.** Parallelism is per transaction, over
`tx.vin`. Most Zcash transactions have one or two inputs, and
`script_parallel_threshold` sends a single-input transaction down a fully serial
path, so the pool is idle for most of a block while each small transaction pays
a Rayon scatter.

The fix is to batch script checks per *block* rather than per transaction:

1. `BlockConnector` gains a lifetime `'b` and a
   `Vec<PendingScriptCheck<'b>>` holding `{ tx, precomputed, txid, tx_index,
   input_index, amount, script_pubkey }`. The prevout script is copied because
   the coin may be spent later in the same batch; everything else is borrowed
   from `BlockCommit::parsed_txs`, which outlives the connection.
2. `connect_tx` queues one entry per input instead of verifying inline. Every
   other check — sigops, BIP30, value, nullifiers, anchors — stays exactly where
   it is, sequential and in order.
3. At the end of each block, one `pool.install(|| checks.par_iter()...)` runs
   every check in the block in a single scatter: thousands of jobs instead of
   hundreds of scatters of one or two.
4. Failure reporting stays deterministic by selecting the failing check with
   the lowest `(tx_index, input_index)`.

This is exactly what Bitcoin Core's `CCheckQueue` does, and it is consensus-safe
for the same reason: script verification is a pure function of the scriptSig,
the prevout script, the sighash data, the flags and the height. It mutates
nothing, so when it runs is free; that every check runs before the block is
accepted is what matters. Flushing per block rather than per batch keeps the
copied prevout scripts bounded.

### Block-level batching: implemented

`connect_tx` now queues one `PendingScriptCheck` per transparent input instead
of verifying inline, and `BlockConnector::verify_pending_scripts` runs the whole
block's checks in a single `pool.install(|| checks.par_iter() ...)` before the
block is accepted. A block with a few thousand inputs is now one scatter rather
than one scatter per transaction.

Details that matter:

* `BlockConnector` gained a lifetime `'b`; queued checks borrow the block's
  parsed transactions and precomputed signature-hash data. For callers that do
  not supply `parsed_txs`, `prepare_commit_batch` now parses the whole block up
  front at block scope, so those borrows stay valid until the flush.
* The prevout script is copied into the queue, because the coin it came from may
  be spent by a later transaction in the same batch.
* Failure selection is deterministic: of all failing checks, the one with the
  lowest `(tx_index, input_index)` is reported — the same check the old
  per-transaction path reported first.
* Every stateful rule — sigops, BIP30, value balance, nullifiers, anchors, coin
  connection — still runs inline, sequentially, in transaction order. Only the
  pure script checks moved.

## Groth16: our own verifier

`crates/ycash-crypto/src/groth16.rs` is a verify-only Groth16 implementation
over BLS12-381, written rather than taken from bellman.

A node never proves. bellman's R1CS synthesis, gadget library, evaluation
domains, proving-key query vectors and proving-side multiexp are all weight the
node links and never calls. What remains once proving is gone is small enough to
own: proof and verifying-key decoding, the pairing equation, and the batch.

**Field arithmetic is deliberately not reimplemented.** Fp/Fp2 for BLS12-381 is
where both the speed and the correctness risk live, and it wants audited
assembly. This module owns the protocol layer and calls the curve crate
underneath, so the backend can move to blst's aarch64 assembly later without
touching consensus logic.

### What it does that bellman cannot

bellman's API is per proof, so each `L_i = IC_0 + Σ_j x_ij·IC_{j+1}` is built
separately and then combined: N·(k+1) scalar multiplications. Expanding the sum
instead:

```
Σ_i r_i·L_i = (Σ_i r_i)·IC_0 + Σ_j (Σ_i r_i·x_ij)·IC_{j+1}
```

The IC points are fixed in the verifying key, so the whole batch costs k+1
group multiplications no matter how many proofs it holds — for a Sapling spend,
8 instead of 8N. What replaces them is scalar-field accumulation, orders of
magnitude cheaper. This is exact algebra: the group element fed to the pairing
is identical, so the equation and its ~2^-128 bound are unchanged.

Σ r_i·C_i remains a genuine variable-base MSM and uses bucketed Pippenger.
Fixed-base windowed tables for the IC points were considered and left out: once
regrouping has reduced that work to 8 multiplications per batch, tables would
buy a negligible constant at the cost of ~1.3 MB resident on a phone.

### Safety properties

* A batch failure is a hint, never a verdict. `Batch::verify` returns one
  verdict for the set; `verify_individually` resolves it. The single-proof path
  is the reference implementation, not legacy code.
* Randomisers are 128-bit, fresh per batch, from `OsRng`, and never derived from
  chain data — a peer able to influence them could craft proofs that cancel.
* Decoding performs on-curve and prime-order subgroup checks on every point,
  including the verifying key's. Skipping a subgroup check accepts proofs that
  ycashd rejects: a silent chain split.

### Not yet swapped in

`batch.rs` and the `rustzcash.rs` FFI still use `bellman::groth16::{Proof,
VerifyingKey}`, so bellman remains a dependency. Moving them over is mechanical
(the types and encodings match) but it is the change that must not be made on
faith: run both verifiers side by side across every shielded transaction in the
chain and assert identical per-proof verdicts before this module decides
anything canonical.

### Free win while you are there

`VerifyingKey::read` parses the VK as a prefix and stops. `Parameters::read`
continues into the proving-key query vectors — `sapling-spend.params` is ~47 MB,
of which a node uses a few hundred bytes. `rustzcash.rs` currently holds
`SAPLING_SPEND_PARAMS` and `SAPLING_OUTPUT_PARAMS` as full `Parameters`; on a
phone that is the largest single memory saving available here.

## Proof batching across blocks

A verifier thread now takes one block, then whatever else is already queued, up
to `MAX_BLOCKS_PER_PROOF_BATCH` (8), and folds every Sapling proof in the group
into one batch: one final exponentiation for the group instead of one per block.
It never waits for more blocks, so latency at the chain tip is unchanged, and
threads still verify different groups in parallel.

On batch rejection every block in the group is re-verified individually, each
with its own batch, so the failure lands on the block that owns it and no valid
block is rejected by association.

## Groth16: what was already better, and what changed

Reading `batch.rs` closely, two things in it are better than a naive port of
bellman's verifier, and both were already there:

**The public-input commitments are regrouped.** `verify_items` accumulates
`Σ_i r_i·x_ij` per input index in `ic_coeff`, in the scalar field, then
multiplies each fixed IC base once. It does not build a per-proof `L_i` and
combine. So the batch costs k+1 group multiplications regardless of how many
proofs it holds — 8 for a Sapling spend batch, not 8N. Exact algebra, identical
group element, unchanged soundness bound. bellman's per-proof API cannot express
this, which is the substantive sense in which this verifier beats it.

**A batch of one is an exact single-proof check.** `r = 1` when there is one
item, so the fallback path spends no randomness and is the plain Groth16
equation. And `verify_set` bisects a failing batch down to the exact failing
tags rather than re-checking everything, which turns an O(N) isolation into
O(f·log N) for f failures.

### What changed now

* `batch.rs` no longer uses bellman. Proof and verifying-key decoding come from
  `crate::groth16`, with the same on-curve and prime-order subgroup checks. The
  batch equation itself was not touched — it was already right.
* The verifying keys are read from the *prefix* of the parameter files by
  `groth16::read_verifying_key_file`, into `SAPLING_SPEND_VERIFYING_KEY` and
  `SAPLING_OUTPUT_VERIFYING_KEY`. `spend_key()` and `output_key()` no longer
  reach into the loaded `Parameters` for `params.vk`.

The measurements that motivated it:

| file | total | verifying key | share |
|---|---|---|---|
| sapling-spend.params | 47,958,396 B | 1,636 B | 0.0034% |
| sapling-output.params | 3,592,860 B | 1,444 B | 0.0402% |

### What still links bellman

`rustzcash.rs` uses `bellman::groth16::{Parameters, PreparedVerifyingKey,
Proof}` for the librustzcash FFI and the prover entry points, and `verify.rs`
uses `zcash_proofs::sapling::SaplingVerificationContext` as the single-proof
reference path — `zcash_proofs` depends on bellman regardless. Dropping the
dependency entirely therefore means replacing that reference path and deciding
the fate of the prover FFI. Neither buys throughput, and both are
consensus-critical, so they are a separate piece of work.

The step that does pay, and is now unblocked: once nothing reads
`SAPLING_SPEND_PARAMS` / `SAPLING_OUTPUT_PARAMS`, stop calling
`load_parameters` for them. That removes ~51 MB of download and resident memory
on the device. Check the prover FFI entry points first — they are the remaining
readers.
