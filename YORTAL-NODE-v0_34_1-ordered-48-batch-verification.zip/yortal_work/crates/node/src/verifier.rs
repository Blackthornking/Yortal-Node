//! Semantic (context-free) verification.
//!
//! These are the consensus checks whose result does not depend on mutable
//! canonical state: block and transaction structure, proof-of-work, Merkle
//! roots, Sapling Groth16 proofs, signature and script precomputation. They are
//! deterministic per block, so they can run on every core and complete out of
//! order without affecting what the chain accepts.
//!
//! Semantic readiness is not canonical readiness. A block that passes here has
//! only earned a place in the prospective set; the ordered state gate still
//! runs every contextual rule before anything becomes canonical.

use std::sync::atomic::Ordering;
use std::sync::mpsc::{sync_channel, Receiver, SyncSender};
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

use anyhow::{anyhow, bail, Result};
use ycash_chain::txid;
use ycash_consensus::{validate_for_commit_batched_with_parsed, Context, ProofBatch};
use ycash_state::prospective::SemanticBlock;
use ycash_state::state_service::{StateServiceHandle, SyncMetrics};
use ycash_state::BlockCommit;

use crate::downloader::{BlockRequest, InFlightRegistry};

/// Optional assume-valid checkpoint, carried over unchanged. Full verification
/// is the default; this is used only when YCASH_ASSUME_VALID=1 and the verified
/// header at the checkpoint height matches.
pub const ASSUME_VALID_HEIGHT: u64 = 2_250_000;
pub const ASSUME_VALID_HASH_DISPLAY: &str =
    "000003f98b7497fdcd8a6b6d10a93a887c5d47127e24a9dc3a40cb65754d21e7";

/// Blocks a verifier thread folds into one Groth16 batch.
///
/// The batch identity costs one final exponentiation regardless of how many
/// proofs it holds, so a bigger batch amortises it better. One block per batch
/// wastes that on blocks with few shielded transactions. Grouping is bounded
/// rather than unlimited because a worker only groups what has *already*
/// arrived: it never waits for more blocks, so latency at the chain tip is
/// unchanged.
///
/// This is a scheduling constant. It changes how proofs are grouped for
/// verification, never which proofs must verify.
pub const MAX_BLOCKS_PER_PROOF_BATCH: usize = 8;

/// A downloaded block with the header context its verification needs.
pub struct RawBlock {
    pub request: BlockRequest,
    pub raw: Vec<u8>,
    /// Peer that supplied the block. Diagnostic provenance only.
    pub source_peer: String,
}

/// Result of one verifier attempt with enough provenance to close the block
/// lifecycle exactly once.
pub struct VerifyOutcome {
    pub height: u64,
    pub hash: [u8; 32],
    pub source_peer: String,
    pub result: Result<SemanticBlock>,
}

/// The prev-hash field of a block header, read straight from the wire bytes.
///
/// Header layout: version(4) | prev(32) | merkle(32) | final Sapling root(32) |
/// time(4) | bits(4) | nonce(32) | solution.
pub fn header_prev(raw: &[u8]) -> Result<[u8; 32]> {
    if raw.len() < 36 {
        bail!("block is too short to contain a header");
    }
    let mut prev = [0u8; 32];
    prev.copy_from_slice(&raw[4..36]);
    Ok(prev)
}

/// Run every context-free consensus check for one block.
///
/// This is the same entry point the previous pipeline used, called with the
/// same arguments for the same block; only the surrounding scheduling changed.
pub fn semantic_verify(block: RawBlock, assume_valid: bool) -> Result<SemanticBlock> {
    let RawBlock { request, raw, .. } = block;
    let height = request.height;
    let ctx = Context {
        height,
        prev_height: height.saturating_sub(1),
        median_time_past: request.median_time_past,
    };
    let assume_valid = assume_valid && height <= ASSUME_VALID_HEIGHT;

    // Sapling proofs in one block share a batch: one multi-Miller loop per
    // verifying key rather than one pairing check per proof. A rejection is
    // re-checked by the single-proof verifier, whose result is final.
    let mut proofs = ProofBatch::new();
    let (validated, parsed_txs) = validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, &mut proofs)
        .map_err(|e| anyhow!("block {height}: {e:?}"))?;
    if proofs.proofs() > 0 {
        if let Err((h, e)) = proofs.finish() {
            bail!("block {h}: {e:?}");
        }
    }
    if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
        bail!("block {height}: consensus decoder returned inconsistent transaction data");
    }

    let prev = header_prev(&raw)?;
    let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
    let precomputed_txs: Vec<ycash_script::PrecomputedTxData> =
        parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();

    Ok(SemanticBlock::from_commit(BlockCommit {
        height,
        hash: request.hash,
        prev,
        work: request.work,
        raw,
        txs,
        parsed_txs,
        precomputed_txs,
        proofs_verified: true,
    }))
}

/// Verify a group of blocks, folding every Sapling proof in the group into one
/// batch.
///
/// On batch rejection each block is re-verified on its own. The batch says only
/// that something in the set is bad, never which block, so a batch verdict is
/// never reported as a per-block result.
pub fn verify_group(blocks: Vec<RawBlock>, assume_valid: bool) -> Vec<VerifyOutcome> {
    if blocks.len() == 1 {
        let mut blocks = blocks;
        let block = blocks.remove(0);
        let height = block.request.height;
        let hash = block.request.hash;
        let source_peer = block.source_peer.clone();
        return vec![VerifyOutcome { height, hash, source_peer, result: semantic_verify(block, assume_valid) }];
    }

    let mut batch = ProofBatch::new();
    let mut staged: Vec<Result<SemanticBlock>> = Vec::with_capacity(blocks.len());
    let mut retained: Vec<RawBlock> = Vec::with_capacity(blocks.len());
    for block in blocks {
        let raw_for_retry = RawBlock {
            request: block.request.clone(),
            raw: block.raw.clone(),
            source_peer: block.source_peer.clone(),
        };
        retained.push(raw_for_retry);
        staged.push(verify_into_batch(block, assume_valid, &mut batch));
    }

    if batch.proofs() > 0 {
        if let Err((height, e)) = batch.finish() {
            // Isolate: re-verify every block in the group individually. The
            // lifecycle remains owned throughout this retry; no transport
            // request can be issued for any member while isolation runs.
            eprintln!("[VERIFY] proof batch rejected at height {height} ({e:?}); isolating {} blocks", retained.len());
            return retained
                .into_iter()
                .map(|raw| {
                    let height = raw.request.height;
                    let hash = raw.request.hash;
                    let source_peer = raw.source_peer.clone();
                    VerifyOutcome { height, hash, source_peer, result: semantic_verify(raw, assume_valid) }
                })
                .collect();
        }
    }

    retained
        .into_iter()
        .zip(staged)
        .map(|(raw, result)| VerifyOutcome {
            height: raw.request.height,
            hash: raw.request.hash,
            source_peer: raw.source_peer,
            result,
        })
        .collect()
}

/// Every context-free check for one block except the Groth16 pairing, which is
/// queued into the caller's batch.
fn verify_into_batch(block: RawBlock, assume_valid: bool, batch: &mut ProofBatch) -> Result<SemanticBlock> {
    let RawBlock { request, raw, .. } = block;
    let height = request.height;
    let ctx = Context {
        height,
        prev_height: height.saturating_sub(1),
        median_time_past: request.median_time_past,
    };
    let assume_valid = assume_valid && height <= ASSUME_VALID_HEIGHT;
    let (validated, parsed_txs) = validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, batch)
        .map_err(|e| anyhow!("block {height}: {e:?}"))?;
    if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
        bail!("block {height}: consensus decoder returned inconsistent transaction data");
    }
    let prev = header_prev(&raw)?;
    let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
    let precomputed_txs: Vec<ycash_script::PrecomputedTxData> =
        parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();
    Ok(SemanticBlock::from_commit(BlockCommit {
        height,
        hash: request.hash,
        prev,
        work: request.work,
        raw,
        txs,
        parsed_txs,
        precomputed_txs,
        proofs_verified: true,
    }))
}

/// One consensus verification batch. The downloader may receive these blocks
/// out of network order, but the batch is reassembled into strict height/parent
/// order before any verifier sees it.
pub const VERIFICATION_BATCH_SIZE: usize = 48;

struct VerifierTask {
    batch_id: u64,
    items: Vec<(usize, RawBlock)>,
}

struct VerifierResult {
    batch_id: u64,
    results: Vec<(usize, VerifyOutcome)>,
}

/// Partition 48 ordered positions into contiguous numbered verifier ranges.
/// The first `remainder` verifiers receive one extra block, so every position
/// appears exactly once and verifier order is deterministic.
fn partition_batch(batch_len: usize, verifiers: usize) -> Vec<std::ops::Range<usize>> {
    let n = verifiers.max(1).min(batch_len.max(1));
    let base = batch_len / n;
    let remainder = batch_len % n;
    let mut ranges = Vec::with_capacity(n);
    let mut start = 0;
    for id in 0..n {
        let len = base + usize::from(id < remainder);
        let end = start + len;
        ranges.push(start..end);
        start = end;
    }
    ranges
}

/// Validate that a collected network batch is exactly one contiguous ancestry
/// chain. This is a scheduling gate only: contextual consensus validity is still
/// performed later by the ordered state service.
fn normalize_batch(mut batch: Vec<RawBlock>) -> std::result::Result<Vec<RawBlock>, (Vec<RawBlock>, anyhow::Error)> {
    if batch.is_empty() {
        return Err((batch, anyhow!("empty verification batch")));
    }
    batch.sort_by_key(|b| b.request.height);
    for i in 1..batch.len() {
        let previous_height = batch[i - 1].request.height;
        let current_height = batch[i].request.height;
        let previous_hash = batch[i - 1].request.hash;
        if current_height != previous_height.saturating_add(1) {
            return Err((batch, anyhow!(
                "verification batch is not contiguous: {} followed by {}",
                previous_height, current_height
            )));
        }
        let prev = match header_prev(&batch[i].raw) {
            Ok(prev) => prev,
            Err(e) => return Err((batch, e)),
        };
        if prev != previous_hash {
            return Err((batch, anyhow!(
                "verification batch parent mismatch at height {}",
                current_height
            )));
        }
    }
    Ok(batch)
}

/// Fixed numbered verifier pool feeding the ordered state gate.
///
/// The pool is deliberately two-level:
///
/// 1. A single batch assembler collects all available claims for one 48-block
///    verification window and orders them by height/parent.
/// 2. The ordered window is split into contiguous numbered verifier sub-batches.
///    Each verifier processes its own sub-batch sequentially.
/// 3. Results are gathered by batch/position and are not released to canonical
///    state until every verifier has returned. The complete batch is then handed
///    to the state service as one ordered unit.
#[derive(Clone)]
pub struct VerifierPool {
    tx: SyncSender<RawBlock>,
    metrics: Arc<SyncMetrics>,
}

impl VerifierPool {
    pub fn spawn(
        workers: usize,
        queue_depth: usize,
        state: StateServiceHandle,
        metrics: Arc<SyncMetrics>,
        registry: Arc<InFlightRegistry>,
        assume_valid: bool,
    ) -> Result<Self> {
        let workers = workers.max(1).min(VERIFICATION_BATCH_SIZE);
        let (tx, rx) = sync_channel::<RawBlock>(queue_depth.max(VERIFICATION_BATCH_SIZE));
        let (result_tx, result_rx) = sync_channel::<VerifierResult>(workers.saturating_mul(2).max(1));
        let mut task_txs = Vec::with_capacity(workers);

        metrics.verifier_workers.store(workers as u64, Ordering::Relaxed);

        for id in 0..workers {
            let (task_tx, task_rx) = sync_channel::<VerifierTask>(1);
            task_txs.push(task_tx);
            let result_tx = result_tx.clone();
            thread::Builder::new()
                .name(format!("yortal-verify-{id}"))
                .spawn(move || {
                    while let Ok(task) = task_rx.recv() {
                        let VerifierTask { batch_id, items } = task;
                        let mut results = Vec::with_capacity(items.len());
                        // The verifier owns a contiguous sub-batch and processes
                        // it strictly in position order. Proof pairing is still
                        // capped by MAX_BLOCKS_PER_PROOF_BATCH so the new 48-block
                        // scheduling layer does not accidentally enlarge the
                        // cryptographic proof batch.
                        for chunk in items.chunks(MAX_BLOCKS_PER_PROOF_BATCH) {
                            let positions: Vec<usize> = chunk.iter().map(|(position, _)| *position).collect();
                            let blocks: Vec<RawBlock> = chunk
                                .iter()
                                .map(|(_, block)| RawBlock {
                                    request: block.request.clone(),
                                    raw: block.raw.clone(),
                                    source_peer: block.source_peer.clone(),
                                })
                                .collect();
                            let outcomes = verify_group(blocks, assume_valid);
                            results.extend(positions.into_iter().zip(outcomes));
                        }
                        if result_tx.send(VerifierResult { batch_id, results }).is_err() {
                            return;
                        }
                    }
                })
                .map_err(|e| anyhow!("failed to start verifier thread {id}: {e}"))?;
        }
        drop(result_tx);

        let assembler_state = state.clone();
        let assembler_metrics = Arc::clone(&metrics);
        let assembler_registry = Arc::clone(&registry);
        thread::Builder::new()
            .name("yortal-verify-batch-coordinator".into())
            .spawn(move || {
                let mut batch_id = 0u64;
                while let Ok(first) = rx.recv() {
                    let mut batch = Vec::with_capacity(VERIFICATION_BATCH_SIZE);
                    batch.push(first);

                    // Normal sync is deliberately strict: gather the complete
                    // 48-block window before dispatching. A batch is never split
                    // because one block arrived earlier than another. Only the
                    // final chain tip may flush a smaller tail, and only when no
                    // other lifecycle claim exists and the header tip is already
                    // covered by this tail.
                    while batch.len() < VERIFICATION_BATCH_SIZE {
                        match rx.recv_timeout(Duration::from_millis(100)) {
                            Ok(next) => batch.push(next),
                            Err(std::sync::mpsc::RecvTimeoutError::Timeout) => {
                                let max_height = batch.iter().map(|b| b.request.height).max().unwrap_or(0);
                                let header_height = assembler_metrics.highest_header_height.load(Ordering::Relaxed);
                                let claimed = assembler_registry.len();
                                if header_height <= max_height && claimed == batch.len() {
                                    break;
                                }
                            }
                            Err(std::sync::mpsc::RecvTimeoutError::Disconnected) => return,
                        }
                    }

                    match normalize_batch(batch) {
                        Ok(ordered) => {
                            if let Err(e) = dispatch_and_publish(
                                batch_id,
                                ordered,
                                &task_txs,
                                &result_rx,
                                assembler_state.clone(),
                                assembler_metrics.clone(),
                                assembler_registry.clone(),
                            ) {
                                eprintln!("[VERIFY-BATCH] batch {batch_id} failed: {e}");
                            }
                            batch_id = batch_id.saturating_add(1);
                        }
                        Err((bad_batch, e)) => {
                            eprintln!("[VERIFY-BATCH] rejected malformed 48-block batch: {e}");
                            for block in bad_batch {
                                assembler_registry.release(&block.request.hash);
                            }
                            batch_id = batch_id.saturating_add(1);
                        }
                    }
                }
            })
            .map_err(|e| anyhow!("failed to start verifier batch coordinator: {e}"))?;

        Ok(Self { tx, metrics })
    }

    /// Hand a downloaded block to the 48-block assembler. The assembler is the
    /// only component allowed to turn individual network arrivals into a
    /// canonical verification batch.
    pub fn submit(&self, block: RawBlock) -> Result<()> {
        self.metrics.semantic_queue.fetch_add(1, Ordering::Relaxed);
        self.tx.send(block).map_err(|_| anyhow!("verifier batch coordinator stopped"))
    }

    /// Non-blocking variant for callers that must keep servicing a socket.
    pub fn try_submit(&self, block: RawBlock) -> std::result::Result<(), RawBlock> {
        self.metrics.semantic_queue.fetch_add(1, Ordering::Relaxed);
        match self.tx.try_send(block) {
            Ok(()) => Ok(()),
            Err(e) => {
                self.metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
                Err(match e {
                    std::sync::mpsc::TrySendError::Full(b) => b,
                    std::sync::mpsc::TrySendError::Disconnected(b) => b,
                })
            }
        }
    }
}

/// Dispatch one complete ordered verification batch to numbered workers and
/// wait for all sub-batches before publishing anything downstream.
fn dispatch_and_publish(
    batch_id: u64,
    ordered: Vec<RawBlock>,
    task_txs: &[SyncSender<VerifierTask>],
    result_rx: &Receiver<VerifierResult>,
    state: StateServiceHandle,
    metrics: Arc<SyncMetrics>,
    registry: Arc<InFlightRegistry>,
) -> Result<()> {
    metrics.semantic_queue.fetch_sub(ordered.len() as u64, Ordering::Relaxed);
    metrics.semantic_batches.fetch_add(1, Ordering::Relaxed);
    metrics.last_semantic_batch_blocks.store(ordered.len() as u64, Ordering::Relaxed);

    let ranges = partition_batch(ordered.len(), task_txs.len());
    for (id, range) in ranges.iter().enumerate() {
        let items = range
            .clone()
            .map(|position| (position, RawBlock {
                request: ordered[position].request.clone(),
                raw: ordered[position].raw.clone(),
                source_peer: ordered[position].source_peer.clone(),
            }))
            .collect();
        if task_txs[id].send(VerifierTask { batch_id, items }).is_err() {
            for block in &ordered {
                registry.release(&block.request.hash);
            }
            return Err(anyhow!("verifier {id} task channel disconnected"));
        }
    }

    let mut assembled: Vec<Option<VerifyOutcome>> = (0..ordered.len()).map(|_| None).collect();
    let mut received_workers = 0usize;
    let started = Instant::now();
    let mut failures = Vec::new();

    while received_workers < ranges.len() {
        let response = match result_rx.recv() {
            Ok(response) => response,
            Err(_) => {
                for block in &ordered {
                    registry.release(&block.request.hash);
                }
                return Err(anyhow!("all verifier result channels disconnected"));
            }
        };
        if response.batch_id != batch_id {
            for block in &ordered {
                registry.release(&block.request.hash);
            }
            bail!("verifier result batch mismatch: expected {batch_id}, got {}", response.batch_id);
        }
        received_workers += 1;
        for (position, outcome) in response.results {
            if position >= assembled.len() || assembled[position].is_some() {
                bail!("duplicate/out-of-range verification result at position {position}");
            }
            if outcome.result.is_err() {
                failures.push(position);
            }
            assembled[position] = Some(outcome);
        }
    }

    let verify_elapsed_us = started.elapsed().as_micros() as u64;
    metrics.semantic_verify_us.store(verify_elapsed_us, Ordering::Relaxed);
    metrics.semantic_verify_total_us.fetch_add(verify_elapsed_us, Ordering::Relaxed);

    if !failures.is_empty() {
        metrics.semantic_batch_failures.fetch_add(1, Ordering::Relaxed);
        // A semantic batch is atomic at the lifecycle level. If any member is
        // invalid, none is handed to the ordered state gate. All claims are
        // released together so the entire window can be fetched again cleanly.
        for block in &ordered {
            registry.release(&block.request.hash);
        }
        metrics.invalid_blocks.fetch_add(failures.len() as u64, Ordering::Relaxed);
        for position in failures {
            if let Some(outcome) = &assembled[position] {
                eprintln!("[VERIFY-BATCH] batch {batch_id} rejected at position {} / height {}: {:?}", position, outcome.height, outcome.result.as_ref().err());
            }
        }
        return Ok(());
    }

    let mut verified = Vec::with_capacity(ordered.len());
    for (position, outcome) in assembled.into_iter().enumerate() {
        let Some(outcome) = outcome else {
            bail!("verification batch {batch_id} missing position {position}");
        };
        let VerifyOutcome { height, hash, source_peer, result } = outcome;
        let verified_block = result.map_err(|e| anyhow!("unexpected failed result at position {position}, height {height}: {e}"))?;
        if !registry.mark_verified(&hash) {
            for block in &ordered {
                registry.release(&block.request.hash);
            }
            bail!("lifecycle transition failed for batch {batch_id} position {position} height {height}");
        }
        metrics.semantic_verified_blocks.fetch_add(1, Ordering::Relaxed);
        metrics.raise_semantic_height(height);
        if metrics.canonical_height.load(Ordering::Relaxed).saturating_add(1) == height {
            metrics.trace_head(
                source_peer,
                "VERIFIED_BATCH",
                height,
                Some(hash),
                format!("batch {batch_id} position {position} verified; retained until entire batch is ready"),
            );
        }
        verified.push(verified_block);
    }

    // Every verifier result is now present and was reassembled by original
    // position. Move the lifecycle claims to QUEUED before handing the complete
    // batch across the state boundary; otherwise a very fast state thread could
    // commit/release the batch before the producer marks it queued.
    for block in &ordered {
        if !registry.mark_queued(&block.request.hash) {
            for rollback in &ordered {
                registry.release(&rollback.request.hash);
            }
            bail!("lifecycle transition to queued failed for batch {batch_id}");
        }
    }
    state.offer_batch(verified).map_err(|e| {
        for block in &ordered {
            registry.release(&block.request.hash);
        }
        e
    })?;
    Ok(())
}

/// Default verifier width: leave one core for the ordered state engine and one
/// for the Android UI thread, and never drop below one worker.
pub fn default_verifier_workers() -> usize {
    std::thread::available_parallelism()
        .map(|n| n.get().saturating_sub(2).max(1))
        .unwrap_or(1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn verifier_partition_covers_48_positions_in_order() {
        let ranges = partition_batch(48, 6);
        assert_eq!(ranges, vec![0..8, 8..16, 16..24, 24..32, 32..40, 40..48]);
        let covered: Vec<usize> = ranges.into_iter().flat_map(|r| r.collect::<Vec<_>>()).collect();
        assert_eq!(covered, (0..48).collect::<Vec<_>>());
    }

    #[test]
    fn verifier_partition_handles_non_divisible_worker_counts() {
        let ranges = partition_batch(48, 5);
        assert_eq!(ranges.iter().map(|r| r.len()).collect::<Vec<_>>(), vec![10, 10, 10, 9, 9]);
        assert_eq!(ranges.first().unwrap().start, 0);
        assert_eq!(ranges.last().unwrap().end, 48);
    }

    fn test_raw_block(height: u64, hash: u8, prev: u8) -> RawBlock {
        let mut raw = vec![0u8; 140];
        raw[4..36].copy_from_slice(&[prev; 32]);
        RawBlock {
            request: BlockRequest {
                height,
                hash: [hash; 32],
                work: [0u8; 32],
                median_time_past: 0,
            },
            raw,
            source_peer: "test".into(),
        }
    }

    #[test]
    fn normalize_batch_restores_height_order_and_checks_parent_links() {
        let input = vec![
            test_raw_block(3, 3, 2),
            test_raw_block(1, 1, 0),
            test_raw_block(2, 2, 1),
        ];
        let ordered = normalize_batch(input).unwrap();
        assert_eq!(ordered.iter().map(|b| b.request.height).collect::<Vec<_>>(), vec![1, 2, 3]);
    }

    #[test]
    fn normalize_batch_rejects_a_height_gap_and_returns_claims_for_release() {
        let input = vec![
            test_raw_block(1, 1, 0),
            test_raw_block(3, 3, 2),
        ];
        let err = normalize_batch(input).unwrap_err();
        assert_eq!(err.0.len(), 2);
    }

    #[test]
    fn header_prev_is_read_from_the_wire_bytes() {
        let mut raw = vec![0u8; 140];
        raw[4..36].copy_from_slice(&[9u8; 32]);
        assert_eq!(header_prev(&raw).unwrap(), [9u8; 32]);
        assert!(header_prev(&[0u8; 8]).is_err());
    }
}
