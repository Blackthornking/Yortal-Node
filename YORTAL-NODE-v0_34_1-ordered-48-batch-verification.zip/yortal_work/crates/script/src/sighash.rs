//! Transaction signature hashing, mirroring ycashd 4.5.0
//! `script/interpreter.cpp::SignatureHash`:
//! * pre-Overwinter (v1/v2): legacy double-SHA256 of the modified tx
//! * Overwinter (v3, ZIP 143) and Sapling (v4, ZIP 243): BLAKE2b with the
//!   consensus branch id in the personalisation.

use blake2b_simd::Params;
use sha2::{Digest, Sha256};
use ycash_chain::{write_compact_size, ParsedTransaction, TransparentOutput};

pub const SIGHASH_ALL: u32 = 1;
pub const SIGHASH_NONE: u32 = 2;
pub const SIGHASH_SINGLE: u32 = 3;
pub const SIGHASH_ANYONECANPAY: u32 = 0x80;

pub const SAPLING_VERSION_GROUP_ID: u32 = 0x892f_2085;

fn blake2b_personal(personal: &[u8; 16], data: &[u8]) -> [u8; 32] {
    let h = Params::new().hash_length(32).personal(personal).hash(data);
    let mut out = [0u8; 32];
    out.copy_from_slice(h.as_bytes());
    out
}

fn personal(s: &[u8]) -> [u8; 16] {
    let mut p = [0u8; 16];
    p[..s.len()].copy_from_slice(s);
    p
}

fn ser_output(o: &TransparentOutput, out: &mut Vec<u8>) {
    out.extend_from_slice(&o.value.to_le_bytes());
    write_compact_size(o.script_pubkey.len() as u64, out);
    out.extend_from_slice(&o.script_pubkey);
}

/// `PrecomputedTransactionData`: the per-transaction ZIP 143/243 sub-hashes,
/// so a tx with many inputs doesn't rehash its outputs once per input.
#[derive(Clone, Debug)]
pub struct PrecomputedTxData {
    prevouts: [u8; 32],
    sequence: [u8; 32],
    outputs: [u8; 32],
    joinsplits: [u8; 32],
    shielded_spends: [u8; 32],
    shielded_outputs: [u8; 32],
}

impl PrecomputedTxData {
    pub fn new(tx: &ParsedTransaction) -> Self {
        let mut prevouts = Vec::with_capacity(tx.vin.len() * 36);
        let mut sequence = Vec::with_capacity(tx.vin.len() * 4);
        for i in &tx.vin {
            prevouts.extend_from_slice(&i.prev_txid);
            prevouts.extend_from_slice(&i.prev_index.to_le_bytes());
            sequence.extend_from_slice(&i.sequence.to_le_bytes());
        }
        let mut outputs = Vec::new();
        for o in &tx.vout {
            ser_output(o, &mut outputs);
        }
        let mut js = Vec::new();
        for j in &tx.joinsplits {
            js.extend_from_slice(&j.raw);
        }
        // GetJoinSplitsHash always appends joinSplitPubKey (zero if absent).
        js.extend_from_slice(&tx.joinsplit_pubkey.unwrap_or([0u8; 32]));
        let mut spends = Vec::with_capacity(tx.sapling_spends.len() * 320);
        for s in &tx.sapling_spends {
            spends.extend_from_slice(&s.cv);
            spends.extend_from_slice(&s.anchor);
            spends.extend_from_slice(&s.nullifier);
            spends.extend_from_slice(&s.rk);
            spends.extend_from_slice(&s.zkproof);
        }
        let mut souts = Vec::with_capacity(tx.sapling_outputs.len() * 948);
        for o in &tx.sapling_outputs {
            souts.extend_from_slice(&o.cv);
            souts.extend_from_slice(&o.cmu);
            souts.extend_from_slice(&o.ephemeral_key);
            souts.extend_from_slice(&o.enc_ciphertext);
            souts.extend_from_slice(&o.out_ciphertext);
            souts.extend_from_slice(&o.zkproof);
        }
        Self {
            prevouts: blake2b_personal(&personal(b"ZcashPrevoutHash"), &prevouts),
            sequence: blake2b_personal(&personal(b"ZcashSequencHash"), &sequence),
            outputs: blake2b_personal(&personal(b"ZcashOutputsHash"), &outputs),
            joinsplits: blake2b_personal(&personal(b"ZcashJSplitsHash"), &js),
            shielded_spends: blake2b_personal(&personal(b"ZcashSSpendsHash"), &spends),
            shielded_outputs: blake2b_personal(&personal(b"ZcashSOutputHash"), &souts),
        }
    }
}

/// `SignatureHash(scriptCode, tx, nIn, nHashType, amount, consensusBranchId)`.
///
/// `n_in == None` is `NOT_AN_INPUT` (the joinSplitSig / Sapling binding hash).
/// Returns `None` exactly where ycashd throws `logic_error` (input index out
/// of range, legacy SIGHASH_SINGLE without a matching output); the caller
/// treats that as a failed signature check.
pub fn signature_hash(
    tx: &ParsedTransaction,
    script_code: &[u8],
    n_in: Option<usize>,
    hash_type: u32,
    amount: i64,
    consensus_branch_id: u32,
    cache: Option<&PrecomputedTxData>,
) -> Option<[u8; 32]> {
    if let Some(n) = n_in {
        if n >= tx.vin.len() {
            return None;
        }
    }
    let base = hash_type & 0x1f;
    let anyone_can_pay = hash_type & SIGHASH_ANYONECANPAY != 0;

    if tx.overwintered {
        let owned;
        let c = match cache {
            Some(c) => c,
            None => {
                owned = PrecomputedTxData::new(tx);
                &owned
            }
        };
        let zero = [0u8; 32];
        let sapling = tx.version_group_id == Some(SAPLING_VERSION_GROUP_ID);

        let hash_prevouts = if !anyone_can_pay { c.prevouts } else { zero };
        let hash_sequence = if !anyone_can_pay && base != SIGHASH_SINGLE && base != SIGHASH_NONE { c.sequence } else { zero };
        let hash_outputs = if base != SIGHASH_SINGLE && base != SIGHASH_NONE {
            c.outputs
        } else if base == SIGHASH_SINGLE && n_in.map(|n| n < tx.vout.len()).unwrap_or(false) {
            let mut o = Vec::new();
            ser_output(&tx.vout[n_in.unwrap()], &mut o);
            blake2b_personal(&personal(b"ZcashOutputsHash"), &o)
        } else {
            zero
        };
        let hash_joinsplits = if !tx.joinsplits.is_empty() { c.joinsplits } else { zero };
        let hash_spends = if !tx.sapling_spends.is_empty() { c.shielded_spends } else { zero };
        let hash_souts = if !tx.sapling_outputs.is_empty() { c.shielded_outputs } else { zero };

        let mut p = [0u8; 16];
        p[..12].copy_from_slice(b"ZcashSigHash");
        p[12..].copy_from_slice(&consensus_branch_id.to_le_bytes());

        let mut d = Vec::with_capacity(320);
        d.extend_from_slice(&(tx.version | 0x8000_0000).to_le_bytes());
        d.extend_from_slice(&tx.version_group_id.unwrap_or(0).to_le_bytes());
        d.extend_from_slice(&hash_prevouts);
        d.extend_from_slice(&hash_sequence);
        d.extend_from_slice(&hash_outputs);
        d.extend_from_slice(&hash_joinsplits);
        if sapling {
            d.extend_from_slice(&hash_spends);
            d.extend_from_slice(&hash_souts);
        }
        d.extend_from_slice(&tx.lock_time.to_le_bytes());
        d.extend_from_slice(&tx.expiry_height.unwrap_or(0).to_le_bytes());
        if sapling {
            d.extend_from_slice(&tx.value_balance.to_le_bytes());
        }
        d.extend_from_slice(&hash_type.to_le_bytes());
        if let Some(n) = n_in {
            let i = &tx.vin[n];
            d.extend_from_slice(&i.prev_txid);
            d.extend_from_slice(&i.prev_index.to_le_bytes());
            write_compact_size(script_code.len() as u64, &mut d);
            d.extend_from_slice(script_code);
            d.extend_from_slice(&amount.to_le_bytes());
            d.extend_from_slice(&i.sequence.to_le_bytes());
        }
        return Some(blake2b_personal(&p, &d));
    }

    // ---- legacy (Sprout-era) signature hash ----
    if base == SIGHASH_SINGLE {
        match n_in {
            Some(n) if n < tx.vout.len() => {}
            _ => return None,
        }
    }
    let hash_single = base == SIGHASH_SINGLE;
    let hash_none = base == SIGHASH_NONE;

    let mut d = Vec::with_capacity(tx.raw.len() + 64);
    d.extend_from_slice(&tx.version.to_le_bytes());

    let n_inputs = if anyone_can_pay { 1 } else { tx.vin.len() };
    write_compact_size(n_inputs as u64, &mut d);
    for idx in 0..n_inputs {
        let input_index = if anyone_can_pay {
            match n_in {
                Some(n) => n,
                None => return None,
            }
        } else {
            idx
        };
        let input = &tx.vin[input_index];
        d.extend_from_slice(&input.prev_txid);
        d.extend_from_slice(&input.prev_index.to_le_bytes());
        let is_signed_input = Some(input_index) == n_in;
        if !is_signed_input {
            write_compact_size(0, &mut d);
        } else {
            write_compact_size(script_code.len() as u64, &mut d);
            d.extend_from_slice(script_code);
        }
        if !is_signed_input && (hash_single || hash_none) {
            d.extend_from_slice(&0u32.to_le_bytes());
        } else {
            d.extend_from_slice(&input.sequence.to_le_bytes());
        }
    }

    let n_outputs = if hash_none {
        0
    } else if hash_single {
        n_in.unwrap() + 1
    } else {
        tx.vout.len()
    };
    write_compact_size(n_outputs as u64, &mut d);
    for o in 0..n_outputs {
        if hash_single && Some(o) != n_in {
            // CTxOut() is SetNull(): nValue = -1, empty script.
            d.extend_from_slice(&(-1i64).to_le_bytes());
            write_compact_size(0, &mut d);
        } else {
            ser_output(&tx.vout[o], &mut d);
        }
    }
    d.extend_from_slice(&tx.lock_time.to_le_bytes());

    if tx.version >= 2 {
        write_compact_size(tx.joinsplits.len() as u64, &mut d);
        for js in &tx.joinsplits {
            d.extend_from_slice(&js.raw);
        }
        if !tx.joinsplits.is_empty() {
            d.extend_from_slice(&tx.joinsplit_pubkey.unwrap_or([0u8; 32]));
            d.extend_from_slice(&[0u8; 64]);
        }
    }
    d.extend_from_slice(&hash_type.to_le_bytes());

    let first = Sha256::digest(&d);
    let second = Sha256::digest(first);
    let mut out = [0u8; 32];
    out.copy_from_slice(&second);
    Some(out)
}
