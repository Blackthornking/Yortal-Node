//! Prospective block set: semantically verified blocks waiting for the state
//! context that makes contextual validation possible.
//!
//! This is a candidate *tree*, not a height range. A block is identified by its
//! hash, never by its height: competing blocks at one height stay
//! distinguishable until chain selection runs, and a child that arrives before
//! its parent is retained rather than dropped.
//!
//! Nothing here decides validity. Membership means "semantically verified and
//! waiting"; only [`crate::state_service`] and the consensus layer decide what
//! becomes canonical.

use std::collections::{BTreeMap, HashMap};

use crate::BlockCommit;

/// A block that has passed semantic (context-free) verification and is waiting
/// for its parent's state.
#[derive(Clone, Debug)]
pub struct SemanticBlock {
    pub hash: [u8; 32],
    pub prev: [u8; 32],
    pub height: u64,
    /// Everything the contextual/commit stage needs, already parsed once.
    pub commit: BlockCommit,
}

impl SemanticBlock {
    pub fn from_commit(commit: BlockCommit) -> Self {
        Self { hash: commit.hash, prev: commit.prev, height: commit.height, commit }
    }

    /// Cumulative chain work at this block, as carried by its header.
    pub fn work(&self) -> [u8; 32] {
        self.commit.work
    }
}

/// Fork-aware store, bounded for Android memory safety.
///
/// The bound is a resource limit, never a consensus rule: a block is dropped
/// only to protect memory, it is never rejected as invalid, and a dropped hash
/// can be requested again.
pub struct ProspectiveBlockSet {
    blocks_by_hash: HashMap<[u8; 32], SemanticBlock>,
    children_by_parent: HashMap<[u8; 32], Vec<[u8; 32]>>,
    hashes_by_height: BTreeMap<u64, Vec<[u8; 32]>>,
    capacity: usize,
    evicted: u64,
    /// Hashes dropped for capacity, waiting to be reported to the downloader so
    /// their claims are freed and they can be fetched again.
    evicted_hashes: Vec<[u8; 32]>,
}

impl ProspectiveBlockSet {
    pub fn new(capacity: usize) -> Self {
        Self {
            blocks_by_hash: HashMap::new(),
            children_by_parent: HashMap::new(),
            hashes_by_height: BTreeMap::new(),
            capacity: capacity.max(1),
            evicted: 0,
            evicted_hashes: Vec::new(),
        }
    }

    pub fn len(&self) -> usize {
        self.blocks_by_hash.len()
    }

    pub fn is_empty(&self) -> bool {
        self.blocks_by_hash.is_empty()
    }

    pub fn capacity(&self) -> usize {
        self.capacity
    }

    pub fn evicted(&self) -> u64 {
        self.evicted
    }

    /// Hashes dropped since the last call. The caller must free their download
    /// claims: a block evicted for memory is not invalid, and if its claim is
    /// left outstanding it can never be fetched again — which is how a missing
    /// parent becomes a permanent stall.
    pub fn drain_evicted(&mut self) -> Vec<[u8; 32]> {
        std::mem::take(&mut self.evicted_hashes)
    }

    pub fn contains(&self, hash: &[u8; 32]) -> bool {
        self.blocks_by_hash.contains_key(hash)
    }

    pub fn get(&self, hash: &[u8; 32]) -> Option<&SemanticBlock> {
        self.blocks_by_hash.get(hash)
    }

    /// Insert a candidate. Returns false when the same hash is already held, so
    /// the same block is never processed twice.
    pub fn insert(&mut self, block: SemanticBlock) -> bool {
        if self.blocks_by_hash.contains_key(&block.hash) {
            return false;
        }
        let (hash, prev, height) = (block.hash, block.prev, block.height);
        self.blocks_by_hash.insert(hash, block);
        self.children_by_parent.entry(prev).or_default().push(hash);
        self.hashes_by_height.entry(height).or_default().push(hash);
        self.enforce_capacity(height);
        true
    }

    /// Candidate children of `parent`, in insertion order.
    pub fn children_of(&self, parent: &[u8; 32]) -> Vec<[u8; 32]> {
        self.children_by_parent.get(parent).cloned().unwrap_or_default()
    }

    /// Candidates at one height. Several is normal: that is a fork.
    pub fn hashes_at_height(&self, height: u64) -> Vec<[u8; 32]> {
        self.hashes_by_height.get(&height).cloned().unwrap_or_default()
    }

    /// Highest height currently held, for diagnostics.
    pub fn highest_height(&self) -> Option<u64> {
        self.hashes_by_height.keys().next_back().copied()
    }

    /// Remove and return a candidate, e.g. once it has been committed.
    pub fn take(&mut self, hash: &[u8; 32]) -> Option<SemanticBlock> {
        let block = self.blocks_by_hash.remove(hash)?;
        self.unindex(&block);
        Some(block)
    }

    /// Drop candidates at or below `height`. Used once a height is buried
    /// deeper than the reorg window, where a competing branch can no longer be
    /// selected.
    pub fn prune_to_hashes(&mut self, height: u64) -> Vec<[u8; 32]> {
        let stale: Vec<[u8; 32]> = self
            .hashes_by_height
            .range(..=height)
            .flat_map(|(_, hashes)| hashes.iter().copied())
            .collect();
        let mut removed = Vec::new();
        for hash in stale {
            if self.take(&hash).is_some() {
                removed.push(hash);
            }
        }
        removed
    }

    pub fn prune_to(&mut self, height: u64) -> usize {
        self.prune_to_hashes(height).len()
    }

    fn unindex(&mut self, block: &SemanticBlock) {
        if let Some(children) = self.children_by_parent.get_mut(&block.prev) {
            children.retain(|h| *h != block.hash);
            if children.is_empty() {
                self.children_by_parent.remove(&block.prev);
            }
        }
        if let Some(at_height) = self.hashes_by_height.get_mut(&block.height) {
            at_height.retain(|h| *h != block.hash);
            if at_height.is_empty() {
                self.hashes_by_height.remove(&block.height);
            }
        }
    }

    /// Memory safety only. The furthest-ahead candidate is evicted first: it is
    /// the one whose parent state is least likely to arrive soon, and it can be
    /// downloaded again at any time.
    fn enforce_capacity(&mut self, just_inserted: u64) {
        while self.blocks_by_hash.len() > self.capacity {
            let Some((&highest, hashes)) = self.hashes_by_height.iter().next_back() else { break };
            let Some(&victim) = hashes.last() else { break };
            if highest == just_inserted && self.blocks_by_hash.len() == 1 {
                break;
            }
            if self.take(&victim).is_some() {
                self.evicted = self.evicted.saturating_add(1);
                self.evicted_hashes.push(victim);
            } else {
                break;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn block(hash: u8, prev: u8, height: u64) -> SemanticBlock {
        SemanticBlock {
            hash: [hash; 32],
            prev: [prev; 32],
            height,
            commit: BlockCommit {
                height,
                hash: [hash; 32],
                prev: [prev; 32],
                work: [0u8; 32],
                raw: Vec::new(),
                txs: Vec::new(),
                parsed_txs: Vec::new(),
                precomputed_txs: Vec::new(),
                proofs_verified: true,
            },
        }
    }

    #[test]
    fn the_same_block_is_never_held_twice() {
        let mut set = ProspectiveBlockSet::new(16);
        assert!(set.insert(block(1, 0, 1)));
        assert!(!set.insert(block(1, 0, 1)));
        assert_eq!(set.len(), 1);
    }

    #[test]
    fn competing_blocks_at_one_height_stay_distinguishable() {
        let mut set = ProspectiveBlockSet::new(16);
        set.insert(block(0xA, 0x0B, 5));
        set.insert(block(0xB, 0x0B, 5));
        assert_eq!(set.hashes_at_height(5).len(), 2);
        assert_eq!(set.children_of(&[0x0B; 32]).len(), 2);
    }

    #[test]
    fn a_child_arriving_before_its_parent_is_retained() {
        let mut set = ProspectiveBlockSet::new(16);
        set.insert(block(2, 1, 11));
        assert!(set.children_of(&[1; 32]).contains(&[2; 32]));
        set.insert(block(1, 0, 10));
        // The parent is now present and its child is still waiting on it.
        assert!(set.contains(&[1; 32]));
        assert!(set.children_of(&[1; 32]).contains(&[2; 32]));
    }

    #[test]
    fn capacity_evicts_the_furthest_ahead_candidate() {
        let mut set = ProspectiveBlockSet::new(2);
        set.insert(block(1, 0, 1));
        set.insert(block(2, 1, 2));
        set.insert(block(3, 2, 3));
        assert_eq!(set.len(), 2);
        assert!(set.contains(&[1; 32]));
        assert!(!set.contains(&[3; 32]));
        assert_eq!(set.evicted(), 1);
    }

    #[test]
    fn pruning_drops_buried_candidates() {
        let mut set = ProspectiveBlockSet::new(16);
        set.insert(block(1, 0, 1));
        set.insert(block(2, 1, 2));
        assert_eq!(set.prune_to(1), 1);
        assert!(!set.contains(&[1; 32]));
        assert!(set.contains(&[2; 32]));
    }
}
