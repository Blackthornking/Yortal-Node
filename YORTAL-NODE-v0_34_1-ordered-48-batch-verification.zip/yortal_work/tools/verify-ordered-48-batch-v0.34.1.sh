#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
V="$ROOT/crates/node/src/verifier.rs"
S="$ROOT/crates/state/src/state_service.rs"
D="$ROOT/crates/node/src/downloader.rs"
L="$ROOT/crates/state/src/lib.rs"

fail(){ echo "[FAIL] $*" >&2; exit 1; }

grep -q 'pub const VERIFICATION_BATCH_SIZE: usize = 48;' "$V" || fail "48-block verifier batch constant missing"
grep -q 'batch.sort_by_key(|b| b.request.height);' "$V" || fail "batch height ordering missing"
grep -q 'verification batch parent mismatch' "$V" || fail "parent-link gate missing"
grep -q 'fn partition_batch' "$V" || fail "deterministic verifier partition missing"
grep -q 'items.chunks(MAX_BLOCKS_PER_PROOF_BATCH)' "$V" || fail "per-verifier ordered proof chunks missing"
grep -q 'state.offer_batch(verified)' "$V" || fail "whole-batch state handoff missing"
grep -q 'VerifiedBatch(Vec<SemanticBlock>)' "$S" || fail "state VerifiedBatch request missing"
grep -q 'pub fn offer_batch' "$S" || fail "state batch API missing"
grep -q 'pub const MAX_BLOCKS_IN_FLIGHT: usize = 48;' "$D" || fail "global 48-block lifecycle bound missing"
grep -q 'pub fn apply_prepared_commit' "$L" || fail "single canonical prepared commit path missing"
grep -q 'let mut w = self.db.writer()?' "$L" || fail "RocksDB writer path missing"

if grep -q 'state.offer(verified)' "$V"; then
  fail "old per-block semantic handoff still present"
fi

python3 - <<'PY'

def partition(n, workers):
    w=max(1,min(workers,max(1,n)))
    base=n//w
    rem=n%w
    out=[]
    start=0
    for i in range(w):
        length=base+(1 if i<rem else 0)
        out.append(range(start,start+length))
        start += length
    return out

ranges=partition(48,6)
assert [len(x) for x in ranges] == [8,8,8,8,8,8]
assert list(x for r in ranges for x in r) == list(range(48))
ranges=partition(48,5)
assert [len(x) for x in ranges] == [10,10,10,9,9]
assert list(x for r in ranges for x in r) == list(range(48))
print('[PASS] partition invariants')
PY

echo '[PASS] ordered 48-block pipeline static invariants'
