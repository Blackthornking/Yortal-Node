//! Yodel One verify-only Groth16 over BLS12-381.
//!
//! A node never needs R1CS synthesis, circuit gadgets, evaluation domains, or
//! proving-key query vectors. This module owns the consensus verification layer:
//! proof and verifying-key decoding with subgroup checks, the Groth16 pairing
//! equation, public-input packing, and randomized batch verification.
//!
//! Field and curve arithmetic is deliberately NOT reimplemented here. Fp/Fp2
//! for BLS12-381 is where both the speed and the correctness risk live, and it
//! wants audited assembly. This module owns the protocol layer and calls the
//! curve crate underneath, so the arithmetic backend can be swapped (for
//! example to blst's aarch64 assembly) without touching consensus logic.
//!
//! # The batch identity
//!
//! For proofs (A_i, B_i, C_i) with public inputs x_i, each valid proof satisfies
//!
//! ```text
//!   e(A_i, B_i) = e(alpha, beta) · e(L_i, gamma) · e(C_i, delta)
//!   L_i = IC_0 + Σ_j x_ij · IC_{j+1}
//! ```
//!
//! With secret random 128-bit scalars r_i, the batch checks
//!
//! ```text
//!   Π_i e(r_i·A_i, B_i) · e(Σ r_i·L_i, -gamma) · e(Σ r_i·C_i, -delta)
//!     == e(alpha, beta)^(Σ r_i)
//! ```
//!
//! # Batch construction
//!
//! A per-proof API would build `L_i` independently and then combine it:
//! N·(k+1) scalar multiplications. Expanding the sum instead:
//!
//! ```text
//!   Σ_i r_i·L_i = (Σ_i r_i)·IC_0 + Σ_j (Σ_i r_i·x_ij)·IC_{j+1}
//! ```
//!
//! The IC points are fixed in the verifying key. So the whole batch costs k+1
//! scalar multiplications regardless of how many proofs it holds: for a Sapling
//! spend, 8 instead of 8N. The scalar accumulation that replaces them is field
//! arithmetic, which is orders of magnitude cheaper than group arithmetic.
//!
//! This is exact algebra, not an approximation. The group element fed to the
//! pairing is identical to the one the per-proof form produces, so the equation
//! and its ~2^-128 soundness bound are unchanged.
//!
//! # Safety properties this module must keep
//!
//! * A batch failure is a hint, never a verdict: it says something in the set
//!   is bad, not which. Callers must re-check individually and treat the
//!   single-proof result as final.
//! * The r_i must be unpredictable and fresh per batch, from the OS RNG. They
//!   must never be derived from block or transaction data: a peer able to
//!   influence them could craft proofs that cancel.

use bls12_381::{multi_miller_loop, pairing, G1Affine, G1Projective, G2Affine, G2Prepared, Gt, Scalar};
use group::Curve;
use rand_core::{OsRng, RngCore};
// This crate is edition 2018: TryInto is not in the prelude.
use std::convert::TryInto;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Groth16Error {
    /// A point failed decompression, the curve equation, or the prime-order
    /// subgroup check. Accepting such a point would accept proofs the
    /// reference implementation rejects.
    InvalidPoint,
    /// The encoding was truncated or the input count did not match the key.
    MalformedEncoding,
    /// The pairing equation did not hold.
    VerificationFailed,
}

/// A Groth16 proof: three group elements, 192 bytes compressed.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Proof {
    pub a: G1Affine,
    pub b: G2Affine,
    pub c: G1Affine,
}

impl Proof {
    pub const BYTES: usize = 192;

    /// Decode the compressed proof wire format used by the Zcash Groth16 proofs on
    /// chain: compressed A ‖ B ‖ C.
    ///
    /// `from_compressed` performs the on-curve and prime-order subgroup checks.
    /// Neither may be skipped: a point of small order in the wrong subgroup can
    /// make the pairing equation hold for a proof that is not valid.
    pub fn read(bytes: &[u8]) -> Result<Self, Groth16Error> {
        if bytes.len() < Self::BYTES {
            return Err(Groth16Error::MalformedEncoding);
        }
        let a = read_g1(&bytes[0..48])?;
        let b = read_g2(&bytes[48..144])?;
        let c = read_g1(&bytes[144..192])?;
        if bool::from(a.is_identity()) || bool::from(b.is_identity()) || bool::from(c.is_identity()) {
            return Err(Groth16Error::InvalidPoint);
        }
        Ok(Self { a, b, c })
    }

    pub fn write(&self) -> [u8; Self::BYTES] {
        let mut out = [0u8; Self::BYTES];
        out[0..48].copy_from_slice(&self.a.to_compressed());
        out[48..144].copy_from_slice(&self.b.to_compressed());
        out[144..192].copy_from_slice(&self.c.to_compressed());
        out
    }
}

/// Verifying keys on disk use the *uncompressed* encoding (96/192 bytes),
/// unlike proofs on the wire, which are compressed (48/96). `from_uncompressed`
/// still performs the on-curve and prime-order subgroup checks.
fn read_g1_uncompressed(bytes: &[u8]) -> Result<G1Affine, Groth16Error> {
    let raw: [u8; 96] = bytes.try_into().map_err(|_| Groth16Error::MalformedEncoding)?;
    Option::from(G1Affine::from_uncompressed(&raw)).ok_or(Groth16Error::InvalidPoint)
}

fn read_g2_uncompressed(bytes: &[u8]) -> Result<G2Affine, Groth16Error> {
    let raw: [u8; 192] = bytes.try_into().map_err(|_| Groth16Error::MalformedEncoding)?;
    Option::from(G2Affine::from_uncompressed(&raw)).ok_or(Groth16Error::InvalidPoint)
}

fn read_g1(bytes: &[u8]) -> Result<G1Affine, Groth16Error> {
    let raw: [u8; 48] = bytes.try_into().map_err(|_| Groth16Error::MalformedEncoding)?;
    Option::from(G1Affine::from_compressed(&raw)).ok_or(Groth16Error::InvalidPoint)
}

fn read_g2(bytes: &[u8]) -> Result<G2Affine, Groth16Error> {
    let raw: [u8; 96] = bytes.try_into().map_err(|_| Groth16Error::MalformedEncoding)?;
    Option::from(G2Affine::from_compressed(&raw)).ok_or(Groth16Error::InvalidPoint)
}

/// A Groth16 verifying key.
///
/// `beta_g1` and `delta_g1` appear in the legacy parameter encoding because
/// the same file also contains proving material; verification does not use them, so they are parsed
/// (and subgroup-checked, since a malformed key must not silently load) and
/// then dropped.
#[derive(Debug, Clone)]
pub struct VerifyingKey {
    pub alpha_g1: G1Affine,
    pub beta_g2: G2Affine,
    pub gamma_g2: G2Affine,
    pub delta_g2: G2Affine,
    /// IC_0 followed by one point per public input.
    pub ic: Vec<G1Affine>,
}

impl VerifyingKey {
    /// Fixed part of the encoding, before the IC length and points:
    /// alpha_g1 ‖ beta_g1 ‖ beta_g2 ‖ gamma_g2 ‖ delta_g1 ‖ delta_g2,
    /// uncompressed.
    pub const HEADER_BYTES: usize = 96 + 96 + 192 + 192 + 96 + 192;

    /// Decode a verifying key from the head of a legacy Groth16 parameter file.
    ///
    /// The key is a *prefix*: the proving key's h, l, a, b_g1 and b_g2 query
    /// vectors follow it and are not read. For `sapling-spend.params` the key
    /// is 1,636 bytes of a 47,958,396-byte file, so a node that only verifies
    /// never needs the rest — on disk or in memory.
    pub fn read(bytes: &[u8]) -> Result<Self, Groth16Error> {
        if bytes.len() < Self::HEADER_BYTES + 4 {
            return Err(Groth16Error::MalformedEncoding);
        }
        let alpha_g1 = read_g1_uncompressed(&bytes[0..96])?;
        let _beta_g1 = read_g1_uncompressed(&bytes[96..192])?;
        let beta_g2 = read_g2_uncompressed(&bytes[192..384])?;
        let gamma_g2 = read_g2_uncompressed(&bytes[384..576])?;
        let _delta_g1 = read_g1_uncompressed(&bytes[576..672])?;
        let delta_g2 = read_g2_uncompressed(&bytes[672..864])?;

        let count = u32::from_be_bytes(
            bytes[864..868].try_into().map_err(|_| Groth16Error::MalformedEncoding)?,
        ) as usize;
        // A key with no IC_0 cannot describe any statement. Sapling spend has
        // 8 points (7 public inputs); output has 6 (5 inputs).
        if count == 0 || count > 1024 {
            return Err(Groth16Error::MalformedEncoding);
        }
        let end = 868 + count * 96;
        if bytes.len() < end {
            return Err(Groth16Error::MalformedEncoding);
        }
        let mut ic = Vec::with_capacity(count);
        for i in 0..count {
            let offset = 868 + i * 96;
            ic.push(read_g1_uncompressed(&bytes[offset..offset + 96])?);
        }
        Ok(Self { alpha_g1, beta_g2, gamma_g2, delta_g2, ic })
    }

    /// Byte length of the key at the head of `bytes`, without decoding it.
    /// Lets a loader read the prefix and stop.
    pub fn encoded_len(bytes: &[u8]) -> Result<usize, Groth16Error> {
        if bytes.len() < Self::HEADER_BYTES + 4 {
            return Err(Groth16Error::MalformedEncoding);
        }
        let count = u32::from_be_bytes(
            bytes[864..868].try_into().map_err(|_| Groth16Error::MalformedEncoding)?,
        ) as usize;
        if count == 0 || count > 1024 {
            return Err(Groth16Error::MalformedEncoding);
        }
        Ok(868 + count * 96)
    }

    /// Number of public inputs this key expects.
    pub fn public_inputs(&self) -> usize {
        self.ic.len() - 1
    }
}

/// Load a verifying key from a legacy Groth16 parameter file, reading only its
/// verification-key prefix.
///
/// Parameter files may contain proof-generation query vectors after the
/// verifying-key prefix. The verifier reads only the prefix and never loads
/// those query vectors into memory.
pub fn read_verifying_key_file(path: &std::path::Path) -> std::io::Result<VerifyingKey> {
    use std::io::{Error, ErrorKind, Read};
    let mut file = std::fs::File::open(path)?;
    let mut head = vec![0u8; VerifyingKey::HEADER_BYTES + 4];
    file.read_exact(&mut head)?;
    let total = VerifyingKey::encoded_len(&head)
        .map_err(|e| Error::new(ErrorKind::InvalidData, format!("{e:?} in {}", path.display())))?;
    head.resize(total, 0);
    file.read_exact(&mut head[VerifyingKey::HEADER_BYTES + 4..])?;
    VerifyingKey::read(&head)
        .map_err(|e| Error::new(ErrorKind::InvalidData, format!("{e:?} in {}", path.display())))
}

/// Convert bytes into the exact bit ordering used by the legacy Groth16
/// multipack helper: bits are consumed most-significant-bit first within each
/// byte, then packed little-endian into 254-bit scalar chunks.
///
/// This is intentionally separate from Sapling's field-element decoding. Sprout
/// proofs expose byte strings through `bytes_to_bits`, while Sapling public
/// inputs are already encoded as field elements by the circuit.
pub fn bytes_to_multipacking(bytes: &[u8]) -> Result<Vec<Scalar>, Groth16Error> {
    const CAPACITY: usize = 254; // BLS12-381 Fr capacity.
    let total_bits = bytes.len().checked_mul(8).ok_or(Groth16Error::MalformedEncoding)?;
    if total_bits == 0 {
        return Ok(Vec::new());
    }

    let chunks = (total_bits + CAPACITY - 1) / CAPACITY;
    let mut result = Vec::with_capacity(chunks);
    for chunk_index in 0..chunks {
        let start_bit = chunk_index * CAPACITY;
        let bit_count = (total_bits - start_bit).min(CAPACITY);
        let mut repr = [0u8; 32];
        for local_bit in 0..bit_count {
            let global_bit = start_bit + local_bit;
            let byte = bytes[global_bit / 8];
            let bit_in_byte = 7 - (global_bit % 8); // legacy `bytes_to_bits`
            if ((byte >> bit_in_byte) & 1) != 0 {
                repr[local_bit / 8] |= 1u8 << (local_bit % 8);
            }
        }
        let scalar = Option::from(Scalar::from_bytes(&repr))
            .ok_or(Groth16Error::MalformedEncoding)?;
        result.push(scalar);
    }
    Ok(result)
}

/// A block-chain link used by the Yodel One batch barrier.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ChainLink {
    pub height: u64,
    pub hash: [u8; 32],
    pub prev_hash: [u8; 32],
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ChainLinkError {
    Empty,
    WrongStartHeight { expected: u64, actual: u64 },
    FirstParentMismatch,
    HeightGap { previous: u64, current: u64 },
    ParentMismatch { height: u64 },
}

/// Deterministic ancestry barrier for a verification batch.
///
/// Groth16 proves a statement chosen by its circuit; it cannot by itself infer
/// that a network batch contains the canonical chain's missing parent. Yodel
/// therefore treats canonical `(tip + 1, tip_hash)` as part of the verifier
/// protocol and refuses to enter the proof-verification stage unless every
/// link in the proposed window is present and ordered.
pub fn validate_chain_links(
    expected_height: u64,
    expected_parent: [u8; 32],
    links: &[ChainLink],
) -> Result<(), ChainLinkError> {
    let first = links.first().ok_or(ChainLinkError::Empty)?;
    if first.height != expected_height {
        return Err(ChainLinkError::WrongStartHeight {
            expected: expected_height,
            actual: first.height,
        });
    }
    if first.prev_hash != expected_parent {
        return Err(ChainLinkError::FirstParentMismatch);
    }
    for pair in links.windows(2) {
        let previous = pair[0];
        let current = pair[1];
        if previous.height.checked_add(1) != Some(current.height) {
            return Err(ChainLinkError::HeightGap {
                previous: previous.height,
                current: current.height,
            });
        }
        if current.prev_hash != previous.hash {
            return Err(ChainLinkError::ParentMismatch {
                height: current.height,
            });
        }
    }
    Ok(())
}

/// A verifying key with the per-verification-invariant work done once.
///
/// `alpha_beta` is a full pairing, and the prepared G2 points carry the Miller
/// loop line functions for gamma and delta. Both are fixed for the lifetime of
/// the key, so neither belongs in a per-proof or per-batch path.
pub struct PreparedVerifyingKey {
    pub alpha_beta: Gt,
    neg_gamma: G2Prepared,
    neg_delta: G2Prepared,
    ic: Vec<G1Affine>,
}

impl PreparedVerifyingKey {
    pub fn new(vk: &VerifyingKey) -> Self {
        Self {
            alpha_beta: pairing(&vk.alpha_g1, &vk.beta_g2),
            neg_gamma: G2Prepared::from(-vk.gamma_g2),
            neg_delta: G2Prepared::from(-vk.delta_g2),
            ic: vk.ic.clone(),
        }
    }

    pub fn public_inputs(&self) -> usize {
        self.ic.len() - 1
    }

    /// L = IC_0 + Σ_j x_j · IC_{j+1} for one proof.
    fn public_input_commitment(&self, inputs: &[Scalar]) -> Result<G1Projective, Groth16Error> {
        if inputs.len() + 1 != self.ic.len() {
            return Err(Groth16Error::MalformedEncoding);
        }
        let mut acc = G1Projective::from(self.ic[0]);
        for (x, base) in inputs.iter().zip(self.ic[1..].iter()) {
            acc += G1Projective::from(*base) * x;
        }
        Ok(acc)
    }

    /// Verify one proof. This is the reference path: the batch is an
    /// optimisation over it, and any batch rejection is resolved by coming
    /// back here.
    pub fn verify(&self, proof: &Proof, inputs: &[Scalar]) -> Result<(), Groth16Error> {
        let l = self.public_input_commitment(inputs)?.to_affine();
        let proof_b = G2Prepared::from(proof.b);
        let terms: [(&G1Affine, &G2Prepared); 3] = [
            (&proof.a, &proof_b),
            (&l, &self.neg_gamma),
            (&proof.c, &self.neg_delta),
        ];
        // e(A,B) · e(L,-gamma) · e(C,-delta) == e(alpha,beta)
        if multi_miller_loop(&terms).final_exponentiation() == self.alpha_beta {
            Ok(())
        } else {
            Err(Groth16Error::VerificationFailed)
        }
    }
}

/// One queued proof and its public inputs.
pub struct BatchItem {
    pub proof: Proof,
    pub inputs: Vec<Scalar>,
}

/// A batch of proofs against one verifying key.
///
/// Correctness note for callers: `verify` returns a single verdict for the
/// whole set. On failure the caller must fall back to per-item verification;
/// the batch cannot say which item was bad, and treating a batch failure as a
/// per-item verdict would reject valid proofs.
#[derive(Default)]
pub struct Batch {
    items: Vec<BatchItem>,
}

impl Batch {
    pub fn new() -> Self {
        Self { items: Vec::new() }
    }

    pub fn push(&mut self, proof: Proof, inputs: Vec<Scalar>) {
        self.items.push(BatchItem { proof, inputs });
    }

    pub fn len(&self) -> usize {
        self.items.len()
    }

    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    pub fn items(&self) -> &[BatchItem] {
        &self.items
    }

    pub fn take(&mut self) -> Vec<BatchItem> {
        std::mem::take(&mut self.items)
    }

    /// Verify every queued proof in one pairing check.
    ///
    /// The randomisers come from the OS RNG and are 128 bits, which is what
    /// bounds a forged batch's success probability at ~2^-128. They are never
    /// derived from chain data.
    pub fn verify(&self, key: &PreparedVerifyingKey) -> Result<(), Groth16Error> {
        if self.items.is_empty() {
            return Ok(());
        }
        let expected_inputs = key.public_inputs();
        for item in &self.items {
            if item.inputs.len() != expected_inputs {
                return Err(Groth16Error::MalformedEncoding);
            }
        }

        // Accumulate in the scalar field first. This is the whole trick: the IC
        // bases are fixed, so Σ_i r_i·L_i becomes k+1 group multiplications for
        // the entire batch instead of k+1 per proof.
        let mut r_sum = Scalar::zero();
        let mut ic_scalars = vec![Scalar::zero(); expected_inputs];
        let mut a_terms: Vec<(G1Affine, G2Prepared)> = Vec::with_capacity(self.items.len());
        let mut c_points: Vec<G1Projective> = Vec::with_capacity(self.items.len());
        let mut c_scalars: Vec<Scalar> = Vec::with_capacity(self.items.len());

        for item in &self.items {
            // A singleton is verified exactly; batching is only probabilistic when
            // more than one proof is combined. This also makes the public Batch API
            // deterministic for the common one-proof case.
            let r = if self.items.len() == 1 { Scalar::one() } else { random_scalar() };
            r_sum += r;
            for (j, x) in item.inputs.iter().enumerate() {
                ic_scalars[j] += r * x;
            }
            // A_i must be scaled individually: it pairs with its own B_i.
            a_terms.push((G1Affine::from(G1Projective::from(item.proof.a) * r), G2Prepared::from(item.proof.b)));
            c_points.push(G1Projective::from(item.proof.c));
            c_scalars.push(r);
        }

        let mut l_acc = G1Projective::from(key.ic[0]) * r_sum;
        for (scalar, base) in ic_scalars.iter().zip(key.ic[1..].iter()) {
            l_acc += G1Projective::from(*base) * scalar;
        }
        let c_acc = multi_scalar_mul(&c_points, &c_scalars);

        let l_affine = l_acc.to_affine();
        let c_affine = c_acc.to_affine();
        let mut terms: Vec<(&G1Affine, &G2Prepared)> = Vec::with_capacity(a_terms.len() + 2);
        for (a, b) in &a_terms {
            terms.push((a, b));
        }
        terms.push((&l_affine, &key.neg_gamma));
        terms.push((&c_affine, &key.neg_delta));

        if multi_miller_loop(&terms).final_exponentiation() == key.alpha_beta * r_sum {
            Ok(())
        } else {
            Err(Groth16Error::VerificationFailed)
        }
    }

    /// Verify each item on its own and return the indices that failed. Used to
    /// resolve a batch rejection into per-proof verdicts.
    pub fn verify_individually(&self, key: &PreparedVerifyingKey) -> Vec<usize> {
        self.items
            .iter()
            .enumerate()
            .filter_map(|(i, item)| key.verify(&item.proof, &item.inputs).err().map(|_| i))
            .collect()
    }
}

/// A fresh 128-bit randomiser. Wider than needed for the soundness bound and
/// cheaper to multiply by than a full-width scalar.
fn random_scalar() -> Scalar {
    loop {
        let mut bytes = [0u8; 64];
        OsRng.fill_bytes(&mut bytes[..16]);
        let scalar = Scalar::from_bytes_wide(&bytes);
        if !bool::from(scalar.is_zero()) {
            return scalar;
        }
    }
}

/// Σ scalars_i · points_i, bucketed by scalar window (Pippenger).
///
/// Used for Σ r_i·C_i, which is the only genuine variable-base multi-scalar
/// multiplication left once the IC regrouping has removed the others.
fn multi_scalar_mul(points: &[G1Projective], scalars: &[Scalar]) -> G1Projective {
    debug_assert_eq!(points.len(), scalars.len());
    if points.is_empty() {
        return G1Projective::identity();
    }
    // Below this size the bucket bookkeeping costs more than it saves.
    if points.len() < 8 {
        let mut acc = G1Projective::identity();
        for (p, s) in points.iter().zip(scalars.iter()) {
            acc += p * s;
        }
        return acc;
    }

    // The randomisers are 128-bit, so only the low 16 bytes carry information.
    const WINDOW: usize = 8;
    const BUCKETS: usize = 1 << WINDOW;
    const BITS: usize = 128;

    let bytes: Vec<[u8; 32]> = scalars.iter().map(|s| s.to_bytes()).collect();
    let mut acc = G1Projective::identity();
    let mut window = (BITS / WINDOW) as isize - 1;
    while window >= 0 {
        for _ in 0..WINDOW {
            acc = acc.double();
        }
        let mut buckets = vec![G1Projective::identity(); BUCKETS];
        for (point, scalar) in points.iter().zip(bytes.iter()) {
            // WINDOW is 8, so each window is exactly one little-endian byte.
            let digit = scalar[window as usize] as usize;
            if digit != 0 {
                buckets[digit] += point;
            }
        }
        // Σ i·bucket_i by running sum, from the top bucket down.
        let mut running = G1Projective::identity();
        let mut windowed = G1Projective::identity();
        for bucket in buckets.iter().skip(1).rev() {
            running += bucket;
            windowed += running;
        }
        acc += windowed;
        window -= 1;
    }
    acc
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_truncated_proof_is_rejected() {
        assert_eq!(Proof::read(&[0u8; 100]).unwrap_err(), Groth16Error::MalformedEncoding);
    }

    #[test]
    fn an_uncompressable_point_is_rejected() {
        // All-zero compressed bytes have no compression flag set, so this is
        // not a valid encoding of any point.
        assert_eq!(Proof::read(&[0u8; Proof::BYTES]).unwrap_err(), Groth16Error::InvalidPoint);
    }

    #[test]
    fn a_truncated_verifying_key_is_rejected() {
        assert_eq!(VerifyingKey::read(&[0u8; 64]).unwrap_err(), Groth16Error::MalformedEncoding);
    }

    #[test]
    fn the_sapling_key_lengths_match_the_published_parameters() {
        // sapling-spend.params: 8 IC points -> 1636 bytes.
        let mut spend = vec![0u8; 868];
        spend[864..868].copy_from_slice(&8u32.to_be_bytes());
        spend.extend(std::iter::repeat(0u8).take(8 * 96));
        assert_eq!(VerifyingKey::encoded_len(&spend).unwrap(), 1636);

        // sapling-output.params: 6 IC points -> 1444 bytes.
        let mut output = vec![0u8; 868];
        output[864..868].copy_from_slice(&6u32.to_be_bytes());
        output.extend(std::iter::repeat(0u8).take(6 * 96));
        assert_eq!(VerifyingKey::encoded_len(&output).unwrap(), 1444);
    }

    #[test]
    fn sprout_byte_packing_uses_legacy_msb_byte_order() {
        let packed = bytes_to_multipacking(&[0b1000_0001]).unwrap();
        assert_eq!(packed.len(), 1);
        // Bit sequence is [1,0,0,0,0,0,0,1], so the scalar is 1 + 2^7.
        assert_eq!(packed[0], Scalar::from(129u64));
    }

    #[test]
    fn chain_barrier_rejects_a_batch_with_a_missing_first_parent() {
        let links = [
            ChainLink { height: 2, hash: [2u8; 32], prev_hash: [1u8; 32] },
            ChainLink { height: 3, hash: [3u8; 32], prev_hash: [2u8; 32] },
        ];
        assert_eq!(
            validate_chain_links(1, [0u8; 32], &links),
            Err(ChainLinkError::WrongStartHeight { expected: 1, actual: 2 })
        );
    }

    #[test]
    fn chain_barrier_rejects_parent_hash_mismatch() {
        let links = [
            ChainLink { height: 10, hash: [10u8; 32], prev_hash: [9u8; 32] },
            ChainLink { height: 11, hash: [11u8; 32], prev_hash: [8u8; 32] },
        ];
        assert_eq!(
            validate_chain_links(10, [9u8; 32], &links),
            Err(ChainLinkError::ParentMismatch { height: 11 })
        );
    }

    #[test]
    fn multi_scalar_mul_matches_the_naive_sum() {
        let points: Vec<G1Projective> = (1u64..=12).map(|i| G1Projective::generator() * Scalar::from(i)).collect();
        let scalars: Vec<Scalar> = (1u64..=12).map(|i| Scalar::from(i * 7 + 1)).collect();
        let mut expected = G1Projective::identity();
        for (p, s) in points.iter().zip(scalars.iter()) {
            expected += p * s;
        }
        assert_eq!(multi_scalar_mul(&points, &scalars), expected);
    }

    #[test]
    fn randomisers_are_fresh_per_call() {
        assert_ne!(random_scalar(), random_scalar());
    }
}
