//! Yodel One verify-only batch proof verifier.
//!
//! This module verifies many proofs against the same verifying key with ONE
//! multi-Miller loop and ONE final exponentiation, using the random
//! linear-combination technique.
//!
//! The default node verifier does not link to the proof-generation stack.
//! Proof and verifying-key decoding come from [`crate::groth16`], a verify-only
//! implementation. The verifying key is read from the parameter-file prefix,
//! while proof-generation query vectors are never loaded by the node verifier.
//!
//! Two properties here are worth stating because they are easy to lose in a
//! rewrite and both are better than the obvious implementation:
//!
//! * The public-input commitments are regrouped. Rather than building each
//!   `L_i = IC_0 + Σ_j x_ij·IC_{j+1}` and then combining them — N·(k+1) group
//!   multiplications — `ic_coeff` accumulates `Σ_i r_i·x_ij` in the scalar
//!   field and multiplies each fixed IC base once. The batch costs k+1 group
//!   multiplications no matter how many proofs it holds: 8 instead of 8N for a
//!   Sapling spend. This is exact algebra, so the element fed to the pairing is
//!   identical and the soundness bound is unchanged.
//! * A batch of one uses r = 1 rather than a random scalar, so the single-proof
//!   path through this code is the exact Groth16 equation with no wasted
//!   randomness, and `verify_set` bisects a failing batch to the exact failing
//!   items instead of re-checking everything linearly.
//!
//! For proofs (A_i, B_i, C_i) with public inputs x_i, each valid proof satisfies
//!
//! ```text
//!   e(A_i, B_i) = e(alpha, beta) * e(L_i, gamma) * e(C_i, delta)
//!   L_i = IC_0 + sum_j x_ij * IC_{j+1}
//! ```
//!
//! With secret random 128-bit scalars r_i the batch checks
//!
//! ```text
//!   prod_i e(r_i*A_i, B_i) * e(sum r_i*L_i, -gamma) * e(sum r_i*C_i, -delta)
//!     == e(alpha, beta)^(sum r_i)
//! ```
//!
//! If any proof is invalid the batch equation holds with probability at most
//! ~2^-128. When a batch fails, every item is re-checked on its own (a batch of
//! one) so the exact failing items are reported.
//!
//! [`SaplingBatchTx`] runs every Sapling check that is *not* a Groth16 pairing
//! according to the pinned Ycash/Librustzcash 0.5 consensus rules:
//! small-order checks on cv and rk, spendAuthSig, the cv sum and bindingSig. It
//! derives the same public inputs and queues the proof instead of verifying it.
//! Callers treat a batch rejection as a hint only: the consensus layer re-runs
//! the original single-proof verifier on the rejected transaction and that
//! result is final.

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::OnceLock;

use crate::groth16::{Batch, PreparedVerifyingKey, Proof};
use bls12_381::Scalar;
use group::GroupEncoding;
use zcash_primitives::{
    constants::{SPENDING_KEY_GENERATOR, VALUE_COMMITMENT_RANDOMNESS_GENERATOR, VALUE_COMMITMENT_VALUE_GENERATOR},
    redjubjub::{PublicKey, Signature},
    transaction::components::Amount,
};

use crate::verify::ProofError;

/// Global switch. Cleared by [`disable_batching`] (env `YORTAL_BATCH_VERIFY=0`
/// or repeated batch/legacy disagreement) so the node falls back to the
/// original per-proof verifier.
static BATCH_DISABLED: AtomicBool = AtomicBool::new(false);
static BATCHES_RUN: AtomicU64 = AtomicU64::new(0);
static BATCH_PROOFS: AtomicU64 = AtomicU64::new(0);
static BATCH_FAILURES: AtomicU64 = AtomicU64::new(0);

pub fn batching_enabled() -> bool {
    if BATCH_DISABLED.load(Ordering::Relaxed) { return false; }
    if std::env::var("YORTAL_BATCH_VERIFY").ok().as_deref() == Some("0") {
        BATCH_DISABLED.store(true, Ordering::Relaxed);
        return false;
    }
    true
}

pub fn disable_batching() { BATCH_DISABLED.store(true, Ordering::Relaxed); }

/// (batches verified, proofs in them, batches that failed)
pub fn batch_stats() -> (u64, u64, u64) {
    (BATCHES_RUN.load(Ordering::Relaxed), BATCH_PROOFS.load(Ordering::Relaxed), BATCH_FAILURES.load(Ordering::Relaxed))
}

/// Verify a set of items against one prepared Groth16 verifying key.
///
/// Multi-item slices use the randomized batch equation from `crate::groth16::Batch`.
/// A singleton is verified with the exact per-proof equation so failure isolation
/// cannot inherit the negligible randomized-batch error probability.
fn verify_set(key: &PreparedVerifyingKey, items: &[&Item], failed: &mut Vec<u64>) {
    if items.is_empty() {
        return;
    }
    if items.len() == 1 {
        if key.verify(&items[0].proof, &items[0].inputs).is_err() {
            failed.push(items[0].tag);
        }
        return;
    }

    let mut batch = Batch::new();
    for item in items {
        batch.push(item.proof.clone(), item.inputs.clone());
    }
    if batch.verify(key).is_ok() {
        return;
    }

    // A failing randomized batch is only a locator hint. Bisect until the exact
    // proof(s) responsible are checked by the deterministic singleton path.
    let mid = items.len() / 2;
    verify_set(key, &items[..mid], failed);
    verify_set(key, &items[mid..], failed);
}

/// Accumulates Sapling spend and output proofs across many transactions.
#[derive(Default)]
pub struct SaplingBatch {
    spends: Vec<Item>,
    outputs: Vec<Item>,
}

impl SaplingBatch {
    pub fn new() -> Self { Self::default() }

    pub fn len(&self) -> usize { self.spends.len() + self.outputs.len() }
    pub fn is_empty(&self) -> bool { self.len() == 0 }

    /// Move a transaction's proofs (which passed every non-pairing check)
    /// into the batch under `tag`.
    pub fn push(&mut self, tag: u64, tx: SaplingBatchTx) {
        for (proof, inputs) in tx.spends { self.spends.push(Item { proof, inputs, tag }); }
        for (proof, inputs) in tx.outputs { self.outputs.push(Item { proof, inputs, tag }); }
    }

    /// Check every queued proof. `Ok(())` if all are valid, otherwise the
    /// sorted, de-duplicated tags that own at least one invalid proof.
    pub fn verify(self) -> Result<(), Vec<u64>> {
        if self.is_empty() { return Ok(()); }
        let (Some(spend_vk), Some(output_vk)) = (
            crate::sapling_spend_prepared_verifying_key(),
            crate::sapling_output_prepared_verifying_key(),
        ) else {
            let mut tags: Vec<u64> = self.spends.iter().chain(self.outputs.iter()).map(|i| i.tag).collect();
            tags.sort_unstable();
            tags.dedup();
            return Err(tags);
        };
        BATCHES_RUN.fetch_add(1, Ordering::Relaxed);
        BATCH_PROOFS.fetch_add(self.len() as u64, Ordering::Relaxed);
        let mut failed = Vec::new();
        let spends: Vec<&Item> = self.spends.iter().collect();
        let outputs: Vec<&Item> = self.outputs.iter().collect();
        verify_set(spend_vk, &spends, &mut failed);
        verify_set(output_vk, &outputs, &mut failed);
        if failed.is_empty() { return Ok(()); }
        BATCH_FAILURES.fetch_add(1, Ordering::Relaxed);
        failed.sort_unstable();
        failed.dedup();
        Err(failed)
    }
}

/// Per-transaction Sapling checks with the Groth16 pairing deferred.
/// Mirrors the consensus-facing behavior of the pinned 0.5 verifier context.
pub struct SaplingBatchTx {
    cv_sum: jubjub::ExtendedPoint,
    spends: Vec<(Proof, Vec<Scalar>)>,
    outputs: Vec<(Proof, Vec<Scalar>)>,
}

fn is_small_order(p: &jubjub::ExtendedPoint) -> bool {
    bool::from(p.mul_by_cofactor().is_identity())
}

/// `multipack::compute_multipacking(bytes_to_bits_le(bytes))` for 32 bytes:
/// 254 low bits in the first scalar, the top 2 bits in the second.
fn multipack_32(bytes: &[u8; 32]) -> Option<[Scalar; 2]> {
    let mut lo = *bytes;
    lo[31] &= 0x3f;
    let mut hi = [0u8; 32];
    hi[0] = bytes[31] >> 6;
    let a = crate::de_ct(Scalar::from_bytes(&lo))?;
    let b = crate::de_ct(Scalar::from_bytes(&hi))?;
    Some([a, b])
}

fn affine_uv(p: &jubjub::ExtendedPoint) -> (Scalar, Scalar) {
    let a = jubjub::AffinePoint::from(*p);
    (a.get_u(), a.get_v())
}

impl SaplingBatchTx {
    pub fn new() -> Self {
        Self { cv_sum: jubjub::ExtendedPoint::identity(), spends: Vec::new(), outputs: Vec::new() }
    }

    pub fn check_spend(
        &mut self,
        cv: &[u8; 32],
        anchor: &[u8; 32],
        nullifier: &[u8; 32],
        rk: &[u8; 32],
        zkproof: &[u8; 192],
        spend_auth_sig: &[u8; 64],
        sighash: &[u8; 32],
    ) -> Result<(), ProofError> {
        let bad = || ProofError::InvalidSpendProof;
        let cv = crate::de_ct(jubjub::ExtendedPoint::from_bytes(cv)).ok_or_else(bad)?;
        let anchor = crate::de_ct(Scalar::from_bytes(anchor)).ok_or_else(bad)?;
        let rk = PublicKey::read(&rk[..]).map_err(|_| bad())?;
        let sig = Signature::read(&spend_auth_sig[..]).map_err(|_| bad())?;
        let proof = Proof::read(&zkproof[..]).map_err(|_| bad())?;

        if is_small_order(&cv) { return Err(bad()); }
        self.cv_sum += cv;
        if is_small_order(&rk.0) { return Err(bad()); }

        let mut msg = [0u8; 64];
        msg[0..32].copy_from_slice(&rk.0.to_bytes());
        msg[32..64].copy_from_slice(sighash);
        if !rk.verify(&msg, &sig, SPENDING_KEY_GENERATOR) { return Err(bad()); }

        let (rk_u, rk_v) = affine_uv(&rk.0);
        let (cv_u, cv_v) = affine_uv(&cv);
        let nf = multipack_32(nullifier).ok_or_else(bad)?;
        self.spends.push((proof, vec![rk_u, rk_v, cv_u, cv_v, anchor, nf[0], nf[1]]));
        Ok(())
    }

    pub fn check_output(
        &mut self,
        cv: &[u8; 32],
        cmu: &[u8; 32],
        ephemeral_key: &[u8; 32],
        zkproof: &[u8; 192],
    ) -> Result<(), ProofError> {
        let bad = || ProofError::InvalidOutputProof;
        let cv = crate::de_ct(jubjub::ExtendedPoint::from_bytes(cv)).ok_or_else(bad)?;
        let cmu = crate::de_ct(Scalar::from_bytes(cmu)).ok_or_else(bad)?;
        // epk must decode, like librustzcash_sapling_check_output.
        let _epk = crate::de_ct(jubjub::ExtendedPoint::from_bytes(ephemeral_key)).ok_or_else(bad)?;
        let proof = Proof::read(&zkproof[..]).map_err(|_| bad())?;

        if is_small_order(&cv) { return Err(bad()); }
        self.cv_sum -= cv;

        let (cv_u, cv_v) = affine_uv(&cv);
        self.outputs.push((proof, vec![cv_u, cv_v, cmu]));
        Ok(())
    }

    /// Run all deferred Groth16 pairings for this transaction using the
    /// verify-only keys. This is the single-transaction reference path used by
    /// the FFI context; block verification can instead aggregate many
    /// transactions through `ProofBatch`.
    pub fn verify_proofs(&self) -> Result<(), ProofError> {
        if !self.spends.is_empty() {
            let Some(key) = crate::sapling_spend_prepared_verifying_key() else {
                return Err(ProofError::NotInitialized);
            };
            for (proof, inputs) in &self.spends {
                key.verify(proof, inputs)
                    .map_err(|_| ProofError::InvalidSpendProof)?;
            }
        }
        if !self.outputs.is_empty() {
            let Some(key) = crate::sapling_output_prepared_verifying_key() else {
                return Err(ProofError::NotInitialized);
            };
            for (proof, inputs) in &self.outputs {
                key.verify(proof, inputs)
                    .map_err(|_| ProofError::InvalidOutputProof)?;
            }
        }
        Ok(())
    }

    pub fn final_check(&self, value_balance: i64, binding_sig: &[u8; 64], sighash: &[u8; 32]) -> Result<(), ProofError> {
        let bad = || ProofError::InvalidBindingSignature;
        let amount = Amount::from_i64(value_balance).map_err(|_| bad())?;
        let sig = Signature::read(&binding_sig[..]).map_err(|_| bad())?;
        let vb = compute_value_balance(amount).ok_or_else(bad)?;
        let bvk = PublicKey(self.cv_sum - vb);
        let mut msg = [0u8; 64];
        msg[0..32].copy_from_slice(&bvk.0.to_bytes());
        msg[32..64].copy_from_slice(sighash);
        if bvk.verify(&msg, &sig, VALUE_COMMITMENT_RANDOMNESS_GENERATOR) { Ok(()) } else { Err(bad()) }
    }
}

/// Pinned 0.5 value-balance calculation used by the consensus context.
fn compute_value_balance(value: Amount) -> Option<jubjub::ExtendedPoint> {
    let raw = i64::from(value);
    let abs = raw.checked_abs()? as u64;
    let mut vb = VALUE_COMMITMENT_VALUE_GENERATOR * jubjub::Fr::from(abs);
    if raw < 0 { vb = -vb; }
    Some(vb.into())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn multipack_matches_bit_packing() {
        let mut bytes = [0u8; 32];
        for (i, b) in bytes.iter_mut().enumerate() { *b = (i as u8).wrapping_mul(37).wrapping_add(11); }
        bytes[31] = 0xff;
        let [a, b] = multipack_32(&bytes).unwrap();
        // Reference: pack little-endian bits into 254-bit chunks.
        let bits: Vec<bool> = bytes.iter().flat_map(|byte| (0..8).map(move |i| (byte >> i) & 1 == 1)).collect();
        let pack = |chunk: &[bool]| {
            let mut out = [0u8; 32];
            for (i, bit) in chunk.iter().enumerate() { if *bit { out[i / 8] |= 1 << (i % 8); } }
            Scalar::from_bytes(&out).unwrap()
        };
        assert_eq!(a, pack(&bits[..254]));
        assert_eq!(b, pack(&bits[254..]));
    }
}
