//! Transport: peer bookkeeping and the streaming block downloader.
//!
//! The downloader owns one rule and nothing else: at most
//! [`MAX_BLOCKS_IN_TRANSIT_PER_PEER`] outstanding block requests per peer, with
//! a slot replenished the moment a block arrives. It never declares a block
//! valid and never chooses the canonical chain.
//!
//! Network delivery remains asynchronous, but the semantic verifier assembles
//! the claimed window into an ordered verification frontier before verification.

use std::collections::{HashMap, HashSet};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use anyhow::{anyhow, Result};
use crate::peer_manager::PeerManager;
use ycash_state::state_service::SyncMetrics;
use ycash_state::State;

/// Outstanding block requests allowed per peer. Transport backpressure only:
/// changing it changes throughput and memory, never consensus acceptance.
pub const MAX_BLOCKS_IN_TRANSIT_PER_PEER: usize = 16;

/// Global ceiling on blocks claimed but not yet canonical. Resource bound.
pub const MAX_BLOCKS_IN_FLIGHT: usize = 16;

/// A peer that sends nothing for a requested block this long loses the claim,
/// so the hash can be requested from someone else. The block is not rejected:
/// a failed download never poisons a hash.
pub const REQUEST_TIMEOUT: Duration = Duration::from_secs(90);

/// A request for the exact next canonical block is retried much sooner than a
/// normal transport request. Later blocks may be buffered, but they cannot be
/// committed until this parent arrives, so head-of-line recovery is latency
/// critical and remains a transport-only policy.
pub const CANONICAL_PARENT_RETRY_TIMEOUT: Duration = Duration::from_secs(8);

/// One block the downloader has asked for, with the header-derived context its
/// semantic verification needs. Gathering this in bulk at assignment time keeps
/// the verifier threads off the database entirely.
#[derive(Clone, Debug)]
pub struct BlockRequest {
    pub height: u64,
    pub hash: [u8; 32],
    /// Cumulative chain work at this height, from the verified header chain.
    pub work: [u8; 32],
    /// Median time past, as consensus defines it for this height.
    pub median_time_past: u32,
}

/// Lifecycle of one claimed hash. A hash stays occupied from its first
/// transport claim until semantic verification has rejected it or the ordered
/// state service has published/discarded it.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum LifecycleState {
    Transport,
    Verifying,
    Verified,
    /// Accepted by the ordered state service queue; it remains claimed until
    /// the candidate is committed or discarded.
    Queued,
}

/// How long the block at tip+1 may stay claimed without arriving before the
/// claim is broken and the block is offered to a different peer, at the
/// slowest point of the bounded back-off. Every other claim can afford to wait:
/// only this one blocks the chain.
pub const HEAD_STALL_TIMEOUT: Duration = Duration::from_secs(30);

/// Upper bound of the head-request back-off. The retry timeout for the exact
/// canonical head starts at [`CANONICAL_PARENT_RETRY_TIMEOUT`] and grows by half
/// after every failed attempt on the same hash, so a genuinely slow (large
/// block, weak mobile link) delivery is not restarted forever, but it never
/// exceeds this bound.
const HEAD_RETRY_TIMEOUT_MAX: Duration = HEAD_STALL_TIMEOUT;

/// Exclusive hand-off window given to the peer nominated to take over a head.
const HEAD_HANDOFF_WINDOW: Duration = Duration::from_secs(2);

/// A peer that timed out on a head is not given the same head again for this
/// long, as long as some other peer is connected.
const HEAD_PEER_COOLDOWN: Duration = Duration::from_secs(20);

/// A head that has been Verifying/Verified this long without ever showing up
/// as a candidate at the ordered gate is treated as an orphaned lifecycle
/// entry (lost worker, dropped message) and re-requested. Generous on
/// purpose: verification of a large block on a phone can take seconds.
pub const HEAD_LIFECYCLE_TIMEOUT: Duration = Duration::from_secs(120);

#[derive(Clone, Debug)]
struct Claim {
    state: LifecycleState,
    /// Peer whose transport request owns the claim. Recorded for EVERY claim,
    /// not only for claims made through the head path: the block that becomes
    /// canonical+1 was almost always claimed earlier as ordinary forward work,
    /// and head recovery must be able to take that claim over.
    owner: String,
    claimed_at: Instant,
    state_since: Instant,
    /// When this hash first became the exact canonical head (canonical + 1).
    head_since: Option<Instant>,
}

#[derive(Default)]
struct HeadFailures {
    /// Number of failed transport attempts on this head.
    count: u32,
    /// Peers that failed this head, and when.
    peers: HashMap<String, Instant>,
    last: Option<Instant>,
}

#[derive(Default)]
struct RegistryInner {
    claims: HashMap<[u8; 32], Claim>,
    /// Peer selected to receive the next canonical-head request after a forced
    /// reassignment, and when it was nominated.
    handoff: HashMap<[u8; 32], (Option<String>, Instant)>,
    failures: HashMap<[u8; 32], HeadFailures>,
}

/// What the registry currently knows about the exact canonical head.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum HeadStatus {
    /// Nobody holds the head.
    Free,
    /// A peer is nominated by the watchdog, but has not yet issued getdata.
    Reserved { owner: String, age: Duration },
    /// A peer holds a transport request for it.
    Transport { owner: String, age: Duration },
    /// It arrived and is owned by verification / the ordered gate.
    Lifecycle { age: Duration },
}

/// Explicit lifecycle for the exact canonical head. This is deliberately kept
/// separate from telemetry: scheduling code reads the tracker/registry state,
/// while the dashboard only observes snapshots of it.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum HeadPhase {
    Free,
    Claimed,
    Arrived,
    Verifying,
    Verified,
    Queued,
    Stalled,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HeadSnapshot {
    pub height: u64,
    pub hash: [u8; 32],
    pub phase: HeadPhase,
}

#[derive(Default)]
pub struct HeadLifecycleTracker {
    inner: Mutex<Option<HeadSnapshot>>,
}

impl HeadLifecycleTracker {
    pub fn set_target(&self, height: u64, hash: [u8; 32]) {
        let mut guard = self.inner.lock().unwrap_or_else(|e| e.into_inner());
        if guard.as_ref().map(|x| (x.height, x.hash)) != Some((height, hash)) {
            *guard = Some(HeadSnapshot { height, hash, phase: HeadPhase::Free });
        }
    }

    pub fn set_phase(&self, hash: &[u8; 32], phase: HeadPhase) {
        let mut guard = self.inner.lock().unwrap_or_else(|e| e.into_inner());
        if let Some(snapshot) = guard.as_mut() {
            if &snapshot.hash == hash { snapshot.phase = phase; }
        }
    }

    pub fn snapshot(&self) -> Option<HeadSnapshot> {
        self.inner.lock().unwrap_or_else(|e| e.into_inner()).clone()
    }
}

/// Global block lifecycle registry. A hash stays occupied from the first
/// transport claim until semantic verification has either rejected it or the
/// ordered state service has successfully published/discarded it. This is the
/// key invariant that prevents a fast downloader from re-requesting a block
/// while the verifier is still processing it.
///
/// All state lives behind one lock so a claim, its owner, its age and the head
/// hand-off can never be observed half-updated.
pub struct InFlightRegistry {
    inner: Mutex<RegistryInner>,
    capacity: usize,
    pub duplicates: AtomicU64,
    head_tracker: Arc<HeadLifecycleTracker>,
}

impl InFlightRegistry {
    pub fn new(capacity: usize) -> Self {
        Self {
            inner: Mutex::new(RegistryInner::default()),
            capacity: capacity.max(1),
            duplicates: AtomicU64::new(0),
            head_tracker: Arc::new(HeadLifecycleTracker::default()),
        }
    }

    fn lock(&self) -> std::sync::MutexGuard<'_, RegistryInner> {
        // A poisoned lock must never freeze the downloader: the data is a
        // plain map and stays structurally valid.
        self.inner.lock().unwrap_or_else(|e| e.into_inner())
    }

    pub fn len(&self) -> usize {
        self.lock().claims.len()
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    pub fn head_tracker(&self) -> Arc<HeadLifecycleTracker> {
        Arc::clone(&self.head_tracker)
    }

    pub fn set_head_target(&self, height: u64, hash: [u8; 32]) {
        self.head_tracker.set_target(height, hash);
    }

    pub fn spare_capacity(&self) -> usize {
        self.capacity.saturating_sub(self.len())
    }

    /// True for every non-terminal lifecycle state. A verified prospective
    /// block is deliberately still considered claimed until canonical state
    /// publishes or discards it.
    pub fn is_claimed(&self, hash: &[u8; 32]) -> bool {
        self.lock().claims.contains_key(hash)
    }

    pub fn head_owner(&self, hash: &[u8; 32]) -> Option<String> {
        self.lock().claims.get(hash).map(|c| c.owner.clone())
    }

    fn new_claim(hash_state: LifecycleState, peer: &str, head: bool) -> Claim {
        let now = Instant::now();
        Claim {
            state: hash_state,
            owner: peer.to_string(),
            claimed_at: now,
            state_since: now,
            head_since: if head { Some(now) } else { None },
        }
    }

    /// True if `peer` may take the head right now: it is not locked out by the
    /// hand-off window in favour of another nominated peer, and (when another
    /// peer exists) it has not just failed this same head.
    fn head_eligible(inner: &mut RegistryInner, hash: &[u8; 32], peer: &str, has_alternates: bool) -> bool {
        if let Some((wanted, since)) = inner.handoff.get(hash).cloned() {
            if since.elapsed() < HEAD_HANDOFF_WINDOW {
                if let Some(wanted) = wanted.as_deref() {
                    if wanted != peer {
                        return false;
                    }
                }
            }
            // Either the nominated peer is claiming, or the window expired.
            inner.handoff.remove(hash);
        }
        if has_alternates {
            if let Some(failed_at) = inner.failures.get(hash).and_then(|f| f.peers.get(peer)) {
                if failed_at.elapsed() < HEAD_PEER_COOLDOWN {
                    return false;
                }
            }
        }
        true
    }

    fn record_failure(inner: &mut RegistryInner, hash: &[u8; 32], peer: &str) {
        let now = Instant::now();
        let entry = inner.failures.entry(*hash).or_default();
        entry.count = entry.count.saturating_add(1);
        entry.peers.insert(peer.to_string(), now);
        entry.last = Some(now);
        if inner.failures.len() > 256 {
            inner.failures.retain(|_, f| f.last.map(|t| t.elapsed() < Duration::from_secs(300)).unwrap_or(false));
        }
    }

    fn retry_timeout(inner: &RegistryInner, hash: &[u8; 32], base: Duration) -> Duration {
        let attempts = inner.failures.get(hash).map(|f| f.count).unwrap_or(0).min(8);
        let mut timeout = base;
        for _ in 0..attempts {
            timeout += timeout / 2;
        }
        timeout.min(HEAD_RETRY_TIMEOUT_MAX.max(base))
    }

    /// Current retry timeout for the head: `base`, grown by half per failed
    /// attempt on this hash, bounded by [`HEAD_STALL_TIMEOUT`].
    pub fn head_retry_timeout(&self, hash: &[u8; 32], base: Duration) -> Duration {
        Self::retry_timeout(&self.lock(), hash, base)
    }

    /// Snapshot of the head's claim. Also stamps the moment the hash became the
    /// exact canonical head, so a block that was claimed as forward work long
    /// ago is not judged stale the instant it is promoted.
    pub fn head_status(&self, hash: &[u8; 32]) -> HeadStatus {
        let mut inner = self.lock();
        let now = Instant::now();
        match inner.claims.get_mut(hash) {
            None => {
                if let Some((Some(owner), since)) = inner.handoff.get(hash).cloned() {
                    let age = now.duration_since(since);
                    if age < HEAD_HANDOFF_WINDOW {
                        return HeadStatus::Reserved { owner, age };
                    }
                    inner.handoff.remove(hash);
                }
                HeadStatus::Free
            }
            Some(claim) => {
                let head_since = *claim.head_since.get_or_insert(now);
                match claim.state {
                    LifecycleState::Transport => {
                        self.head_tracker.set_phase(hash, HeadPhase::Claimed);
                        HeadStatus::Transport {
                        owner: claim.owner.clone(),
                        age: now.duration_since(claim.claimed_at.max(head_since)),
                        }
                    }
                    LifecycleState::Verifying => { self.head_tracker.set_phase(hash, HeadPhase::Verifying); HeadStatus::Lifecycle { age: now.duration_since(claim.state_since) } }
                    LifecycleState::Verified => { self.head_tracker.set_phase(hash, HeadPhase::Verified); HeadStatus::Lifecycle { age: now.duration_since(claim.state_since) } }
                    LifecycleState::Queued => { self.head_tracker.set_phase(hash, HeadPhase::Queued); HeadStatus::Lifecycle { age: now.duration_since(claim.state_since) } }
                }
            }
        }
    }

    /// Reserve the canonical head without ever exceeding the single global
    /// 16-block lifecycle budget. Head recovery must respect the same budget as
    /// every other stage; otherwise the pipeline is no longer truly bounded.
    /// The normal assignment path prioritises this height, so a full window is
    /// allowed to drain before the head is requested again.
    pub fn reserve_head(&self, hash: [u8; 32], peer: &str, has_alternates: bool) -> bool {
        let mut inner = self.lock();
        if inner.claims.contains_key(&hash)
            || inner.claims.len() >= self.capacity
            || !Self::head_eligible(&mut inner, &hash, peer, has_alternates) {
            return false;
        }
        inner.handoff.insert(hash, (Some(peer.to_string()), Instant::now()));
        self.head_tracker.set_phase(&hash, HeadPhase::Stalled);
        true
    }

    pub fn claim_head(&self, hash: [u8; 32], peer: &str, has_alternates: bool) -> bool {
        let mut inner = self.lock();
        if inner.claims.contains_key(&hash) || inner.claims.len() >= self.capacity {
            return false;
        }
        if !Self::head_eligible(&mut inner, &hash, peer, has_alternates) {
            return false;
        }
        inner.claims.insert(hash, Self::new_claim(LifecycleState::Transport, peer, true));
        self.head_tracker.set_phase(&hash, HeadPhase::Claimed);
        true
    }

    /// Atomically take over a stale transport claim on the canonical head for
    /// `peer`, without waiting for the current owner's thread to notice.
    ///
    /// This is the global watchdog: any peer that asks for work can break a
    /// head request that is older than the (backed-off) timeout, so recovery
    /// never depends on the owning peer's thread being responsive. Returns the
    /// previous owner when the claim was taken over. Verification and
    /// prospective-state claims are never touched.
    pub fn steal_stale_head(&self, hash: &[u8; 32], peer: &str, base_timeout: Duration, has_alternates: bool) -> Option<String> {
        let mut inner = self.lock();
        let now = Instant::now();
        let (owner, age) = match inner.claims.get(hash) {
            Some(c) if c.state == LifecycleState::Transport => {
                let since = c.head_since.unwrap_or(c.claimed_at).max(c.claimed_at);
                (c.owner.clone(), now.duration_since(since))
            }
            _ => return None,
        };
        if owner == peer {
            return None;
        }
        if age < Self::retry_timeout(&inner, hash, base_timeout) {
            return None;
        }
        if has_alternates {
            if let Some(failed_at) = inner.failures.get(hash).and_then(|f| f.peers.get(peer)) {
                if failed_at.elapsed() < HEAD_PEER_COOLDOWN {
                    return None;
                }
            }
        }
        Self::record_failure(&mut inner, hash, &owner);
        inner.handoff.remove(hash);
        inner.claims.insert(*hash, Self::new_claim(LifecycleState::Transport, peer, true));
        self.head_tracker.set_phase(hash, HeadPhase::Claimed);
        Some(owner)
    }

    /// Atomically release a stale canonical-head transport claim held by
    /// `old_peer` and nominate another connected peer for the next request. The
    /// old peer cannot immediately reclaim the head while another peer exists.
    pub fn reassign_head(&self, hash: &[u8; 32], old_peer: &str, preferred_peer: Option<String>) -> bool {
        let mut inner = self.lock();
        let owned = matches!(
            inner.claims.get(hash),
            Some(c) if c.state == LifecycleState::Transport && c.owner == old_peer
        );
        if !owned {
            return false;
        }
        inner.claims.remove(hash);
        Self::record_failure(&mut inner, hash, old_peer);
        self.head_tracker.set_phase(hash, HeadPhase::Stalled);
        match preferred_peer {
            Some(peer) => {
                inner.handoff.insert(*hash, (Some(peer), Instant::now()));
            }
            None => {
                inner.handoff.remove(hash);
            }
        }
        true
    }

    /// Release a transport claim, but only if `peer` still owns it. A session
    /// that timed out, got `notfound`, or disconnected must not free a claim
    /// that has since been taken over by another peer or moved on to
    /// verification.
    pub fn release_transport(&self, hash: &[u8; 32], peer: &str) -> bool {
        let mut inner = self.lock();
        let owned = matches!(
            inner.claims.get(hash),
            Some(c) if c.state == LifecycleState::Transport && c.owner == peer
        );
        if owned {
            inner.claims.remove(hash);
        }
        owned
    }

    /// Break a stale *transport* claim. Verification and prospective-state
    /// claims must never be stolen by the downloader: once a block has arrived
    /// or has been handed to the ordered state queue, releasing its lifecycle
    /// entry can create a duplicate download while the original candidate is
    /// still present. That is exactly the kind of stale-known-block race Zebra
    /// guards against.
    pub fn break_stale_transport_claim(&self, hash: &[u8; 32], age: Duration) -> bool {
        let mut inner = self.lock();
        let stale = matches!(
            inner.claims.get(hash),
            Some(c) if c.state == LifecycleState::Transport && c.claimed_at.elapsed() > age
        );
        if stale {
            inner.claims.remove(hash);
        }
        stale
    }

    /// Break an orphaned Verifying/Verified claim on the head: one that has sat
    /// in that state longer than `age` although the ordered gate never received
    /// the candidate (the caller has already established that). Normal
    /// terminal events release claims; this only recovers from a lost one.
    pub fn break_stale_lifecycle(&self, hash: &[u8; 32], age: Duration) -> bool {
        let mut inner = self.lock();
        let stale = matches!(
            inner.claims.get(hash),
            Some(c) if matches!(c.state, LifecycleState::Verifying | LifecycleState::Verified) && c.state_since.elapsed() >= age
        );
        if stale {
            inner.claims.remove(hash);
            inner.handoff.remove(hash);
            self.head_tracker.set_phase(hash, HeadPhase::Stalled);
        }
        stale
    }

    /// Claim a hash for `peer`. Fails if it is already in any lifecycle state
    /// or the global bound is hit.
    pub fn claim(&self, hash: [u8; 32], peer: &str) -> bool {
        let mut inner = self.lock();
        if inner.claims.len() >= self.capacity {
            return false;
        }
        if inner.claims.contains_key(&hash) {
            self.duplicates.fetch_add(1, Ordering::Relaxed);
            return false;
        }
        inner.claims.insert(hash, Self::new_claim(LifecycleState::Transport, peer, false));
        true
    }

    /// Transition transport ownership to the verifier without freeing the
    /// global lifecycle slot.
    pub fn mark_verifying(&self, hash: &[u8; 32]) -> bool {
        let mut inner = self.lock();
        match inner.claims.get_mut(hash) {
            Some(claim) if claim.state == LifecycleState::Transport => {
                claim.state = LifecycleState::Verifying;
                claim.state_since = Instant::now();
                self.head_tracker.set_phase(hash, HeadPhase::Verifying);
                true
            }
            _ => false,
        }
    }

    /// A block a peer really delivered for a hash we asked it for, but whose
    /// transport claim was released in the meantime (head hand-off, timeout).
    /// The data is valid and already here: adopt it into Verifying instead of
    /// throwing it away and downloading it again. Fails if any claim exists.
    pub fn adopt_arrival(&self, hash: &[u8; 32], peer: &str) -> bool {
        let mut inner = self.lock();
        if inner.claims.contains_key(hash) || inner.claims.len() >= self.capacity {
            return false;
        }
        inner.handoff.remove(hash);
        inner.claims.insert(*hash, Self::new_claim(LifecycleState::Verifying, peer, false));
        self.head_tracker.set_phase(hash, HeadPhase::Verifying);
        true
    }

    /// Semantic verification succeeded. Keep the hash occupied while the
    /// ordered state gate holds it prospectively.
    pub fn mark_verified(&self, hash: &[u8; 32]) -> bool {
        let mut inner = self.lock();
        match inner.claims.get_mut(hash) {
            Some(claim) if claim.state == LifecycleState::Verifying => {
                claim.state = LifecycleState::Verified;
                claim.state_since = Instant::now();
                self.head_tracker.set_phase(hash, HeadPhase::Verified);
                true
            }
            _ => false,
        }
    }

    /// Mark the explicit VERIFIED -> QUEUED transition once the ordered state
    /// service has accepted the candidate. This removes the old ambiguity where
    /// a long-lived VERIFIED claim could only be distinguished from an actually
    /// queued candidate using telemetry.
    pub fn mark_queued(&self, hash: &[u8; 32]) -> bool {
        let mut inner = self.lock();
        match inner.claims.get_mut(hash) {
            Some(claim) if claim.state == LifecycleState::Verified => {
                claim.state = LifecycleState::Queued;
                claim.state_since = Instant::now();
                self.head_tracker.set_phase(hash, HeadPhase::Queued);
                true
            }
            _ => false,
        }
    }

    /// Release a terminal lifecycle entry: semantic rejection, state-queue
    /// failure, contextual rejection, publication failure, or successful
    /// canonical publication.
    pub fn release(&self, hash: &[u8; 32]) {
        let mut inner = self.lock();
        inner.claims.remove(hash);
        inner.handoff.remove(hash);
        self.head_tracker.set_phase(hash, HeadPhase::Free);
    }

    pub fn transport_claims(&self) -> Vec<[u8; 32]> {
        self.lock().claims.iter().filter_map(|(hash, claim)| {
            (claim.state == LifecycleState::Transport).then_some(*hash)
        }).collect()
    }

    pub fn release_transport_unless_canonical(&self, canonical_hashes: &std::collections::HashSet<[u8; 32]>) -> usize {
        let mut inner = self.lock();
        let stale: Vec<[u8; 32]> = inner.claims.iter()
            .filter_map(|(hash, claim)| {
                (claim.state == LifecycleState::Transport && !canonical_hashes.contains(hash)).then_some(*hash)
            })
            .collect();
        for hash in &stale {
            inner.claims.remove(hash);
            inner.handoff.remove(hash);
            self.head_tracker.set_phase(hash, HeadPhase::Free);
        }
        stale.len()
    }

    /// Release every claim, whatever state it is in.
    ///
    /// Used by the sync restart: after a stall, no claim is trustworthy --
    /// the owner may be gone, the block may have been dropped, the lifecycle
    /// may have leaked. Clearing the lot and re-requesting is cheaper than
    /// reasoning about which.
    pub fn clear(&self) -> usize {
        let mut inner = self.lock();
        let count = inner.claims.len();
        inner.claims.clear();
        count
    }

    pub fn release_many(&self, hashes: &[[u8; 32]]) {
        let mut inner = self.lock();
        for hash in hashes {
            inner.claims.remove(hash);
            inner.handoff.remove(hash);
            self.head_tracker.set_phase(hash, HeadPhase::Free);
            // Committed or discarded: the head's failure history is over.
            inner.failures.remove(hash);
        }
    }
}

/// Chooses which blocks to request next, from the verified header chain above
/// the canonical tip.
///
/// Header ancestry decides only what is *worth asking for*. The state service
/// remains the authority on validity, so a wrong guess here costs bandwidth and
/// nothing else.
pub struct BlockAssigner {
    state: Arc<State>,
    registry: Arc<InFlightRegistry>,
    metrics: Arc<SyncMetrics>,
    /// How far above the canonical tip blocks may be requested. Sized to the
    /// candidate capacity: requesting further ahead than the state service can
    /// buffer only wastes bandwidth and claim slots.
    window: usize,
    cursor: Mutex<u64>,
}

impl BlockAssigner {
    pub fn new(
        state: Arc<State>,
        registry: Arc<InFlightRegistry>,
        metrics: Arc<SyncMetrics>,
        window: usize,
    ) -> Self {
        Self { state, registry, metrics, window, cursor: Mutex::new(0) }
    }

    /// Reset the scan position to just above the canonical tip. Called after a
    /// commit run or a reorganisation so skipped heights are revisited.
    pub fn rewind_to_canonical(&self) -> Result<()> {
        let tip = self.state.tip_height()?.unwrap_or(0);
        if let Ok(mut cursor) = self.cursor.lock() {
            *cursor = tip;
        }
        // A header reorg can orphan transport claims for hashes that are no
        // longer canonical. Reconcile only Transport claims; once a block has
        // entered verification or the ordered queue its lifecycle is protected.
        let mut canonical = HashSet::new();
        if let Some(header_tip) = self.state.header_height()? {
            let start = tip.saturating_add(1).max(1);
            let end = header_tip.min(tip.saturating_add(self.window as u64 + 2));
            if start <= end {
                for (_height, hash) in self.state.header_hashes_range(start, end)? {
                    canonical.insert(hash);
                }
            }
            if tip > 0 {
                if let Some(hash) = self.state.header_hash_by_height(tip)? {
                    canonical.insert(hash32(hash, "header hash")?);
                }
            }
        }
        self.registry.release_transport_unless_canonical(&canonical);
        Ok(())
    }

    /// Claim up to `want` blocks for one peer, with their verification context
    /// read in bulk.
    ///
    /// `has_alternates` says whether another peer is connected, which decides
    /// whether a peer that just failed the canonical head is kept away from it.
    /// `head_only` restricts the call to the canonical head: a peer whose
    /// window is full of forward work must still be able to take the one block
    /// that unblocks the chain.
    pub fn assign(&self, want: usize, peer: &str, has_alternates: bool, head_only: bool) -> Result<Vec<BlockRequest>> {
        // The exact canonical head is prioritised, but it uses the same global
        // lifecycle capacity as every other block. A full window must drain
        // before another claim can be created; there is no hidden +1 slot.
        if want == 0 {
            return Ok(Vec::new());
        }
        let canonical = self.state.tip_height()?.unwrap_or(0);
        let header_tip = self.state.header_height()?.unwrap_or(0);
        self.metrics.raise_header_height(header_tip);
        if header_tip <= canonical {
            return Ok(Vec::new());
        }

        // Always try the exact next canonical block first. The forward cursor
        // may already be hundreds of blocks ahead because those blocks were
        // successfully buffered; that must never starve the one block needed
        // to advance canonical state.
        let mut out = Vec::with_capacity(want);
        if let Some(head) = self.claim_canonical_head(canonical, peer, has_alternates)? {
            out.push(head);
        }
        if head_only {
            return Ok(out);
        }
        let forward_want = want.saturating_sub(out.len()).min(self.registry.spare_capacity());
        match self.assign_forward(forward_want, canonical, header_tip, peer) {
            Ok(more) => {
                out.extend(more);
                Ok(out)
            }
            Err(e) => {
                // Never leave a claim behind that no session will ever request.
                for request in &out {
                    self.registry.release_transport(&request.hash, peer);
                }
                Err(e)
            }
        }
    }

    /// Claim, retry or take over the exact canonical head (`canonical + 1`).
    ///
    /// The head is judged by what the registry says about its *claim*, not by a
    /// flag: a block that was claimed earlier as forward work and has just
    /// become the head is owned by some peer and is retried, reassigned or
    /// stolen exactly like any other head request. A head request older than
    /// the (backed-off) timeout is taken over by whichever peer asks for work
    /// first, so recovery does not depend on the owning peer's thread being
    /// responsive.
    fn claim_canonical_head(&self, canonical: u64, peer: &str, has_alternates: bool) -> Result<Option<BlockRequest>> {
        let next_height = canonical.saturating_add(1);
        let Some(raw_hash) = self.state.header_hash_by_height(next_height)? else { return Ok(None) };
        let hash = hash32(raw_hash, "header hash")?;
        self.registry.set_head_target(next_height, hash);

        let mut steal = false;
        match self.registry.head_status(&hash) {
            HeadStatus::Free => {}
            HeadStatus::Reserved { owner, age: _ } => {
                if owner != peer {
                    self.metrics.set_missing_parent_in_flight(false);
                    return Ok(None);
                }
            }
            HeadStatus::Transport { owner, age } => {
                let timeout = self.registry.head_retry_timeout(&hash, CANONICAL_PARENT_RETRY_TIMEOUT);
                if owner == peer || age < timeout {
                    // A live request (or our own, which our own session
                    // retries). Leave ownership intact.
                    self.metrics.set_missing_parent_in_flight(true);
                    return Ok(None);
                }
                steal = true;
            }
            HeadStatus::Lifecycle { age } => {
                if age < HEAD_LIFECYCLE_TIMEOUT || !self.registry.break_stale_lifecycle(&hash, HEAD_LIFECYCLE_TIMEOUT) {
                    // Verification or the ordered gate owns it.
                    self.metrics.set_missing_parent_in_flight(true);
                    return Ok(None);
                }
                self.metrics.trace_head(
                    peer.to_string(),
                    "LIFECYCLE_RECOVERED",
                    next_height,
                    Some(hash),
                    format!("head sat {}s in verification without reaching the ordered gate; claim broken", age.as_secs()),
                );
            }
        }

        let Some(request) = self.request_at_height(next_height)? else { return Ok(None) };
        let claimed = if steal {
            match self.registry.steal_stale_head(&hash, peer, CANONICAL_PARENT_RETRY_TIMEOUT, has_alternates) {
                Some(previous) => {
                    self.metrics.trace_head(
                        peer.to_string(),
                        "STOLEN",
                        next_height,
                        Some(hash),
                        format!("stale head request from {previous} taken over by {peer}"),
                    );
                    self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                    self.metrics.expired_requests.fetch_add(1, Ordering::Relaxed);
                    self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
                    self.metrics.mark_parent_retry();
                    true
                }
                None => false,
            }
        } else {
            self.registry.claim_head(hash, peer, has_alternates)
        };
        // Truthful flag: "active" only while somebody really holds the claim.
        self.metrics.set_missing_parent_in_flight(self.registry.is_claimed(&hash));
        Ok(if claimed { Some(request) } else { None })
    }

    /// Claim specific heights, lowest first.
    ///
    /// The batch assembler decides what is missing; this just fetches it. That
    /// inverts the previous arrangement, where the downloader chose a window
    /// and the gate hoped the block it needed was inside it.
    pub fn assign_heights(&self, heights: &[u64], want: usize, peer: &str) -> Result<Vec<BlockRequest>> {
        let mut out = Vec::with_capacity(want.min(heights.len()));
        for (index, height) in heights.iter().enumerate() {
            if out.len() >= want {
                break;
            }
            let Some(request) = self.request_at_height(*height)? else { continue };
            // The first height is canonical+1. If that claim cannot be made,
            // stop rather than filling the remaining 15 slots with children.
            // This permanently reserves the head position in the 16-block
            // window and prevents a missing parent from being starved.
            if !self.registry.claim(request.hash, peer) {
                if index == 0 {
                    break;
                }
                continue;
            }
            self.metrics.raise_download_height(request.height);
            out.push(request);
        }
        Ok(out)
    }

    pub(crate) fn request_at_height(&self, height: u64) -> Result<Option<BlockRequest>> {
        let Some(hash) = self.state.header_hash_by_height(height)? else { return Ok(None) };
        let Some(work) = self.state.header_work_by_height(height)? else { return Ok(None) };
        let mtp = median_time_past_range(&self.state, height, height)?
            .get(&height).copied().unwrap_or(0);
        Ok(Some(BlockRequest { height, hash: hash32(hash, "header hash")?, work: hash32(work, "chain work")?, median_time_past: mtp }))
    }

    /// Claim blocks from a window anchored at the canonical tip.
    ///
    /// The window is `canonical+1 ..= canonical+window`, where `window` is the
    /// number of candidates the state service can actually hold. Two
    /// consequences matter:
    ///
    /// * The block needed to advance the chain is always the *first* height
    ///   considered, so it can never be starved by work further ahead.
    /// * Nothing is fetched that cannot be buffered, so the downloader cannot
    ///   run a thousand blocks past the commit frontier, fill every claim slot
    ///   with blocks the gate cannot use, and leave no budget to fetch the one
    ///   block that would unblock it.
    ///
    /// This replaces a monotonic cursor that advanced even for heights it
    /// failed to claim and never returned to the gap it left behind.
    fn assign_forward(&self, want: usize, canonical: u64, header_tip: u64, peer: &str) -> Result<Vec<BlockRequest>> {
        if want == 0 {
            return Ok(Vec::new());
        }
        let window = self.window.max(1) as u64;
        let start = canonical.saturating_add(1);
        let end = header_tip.min(canonical.saturating_add(window));
        if start > end {
            return Ok(Vec::new());
        }

        let hashes = self.state.header_hashes_range(start, end)?;
        let works = self.state.header_works_range(start, end)?;
        let mtps = median_time_past_range(&self.state, start, end)?;

        let mut out = Vec::with_capacity(want);
        for height in start..=end {
            if out.len() >= want {
                break;
            }
            // canonical+1 is owned exclusively by the head-recovery path.
            // Never let the speculative forward path bypass a peer hand-off
            // and reclaim a head that was just forcibly reassigned.
            if height == start {
                continue;
            }
            let (Some(hash), Some(work)) = (hashes.get(&height).copied(), works.get(&height).copied()) else {
                // A hole in the header chain: nothing above it is requestable
                // yet, so stop rather than skipping past it.
                break;
            };
            // Already in flight, in the verifier, or buffered as a candidate.
            if !self.registry.claim(hash, peer) {
                continue;
            }
            out.push(BlockRequest {
                height,
                hash,
                work,
                median_time_past: mtps.get(&height).copied().unwrap_or(0),
            });
        }
        Ok(out)
    }

    pub fn canonical_height(&self) -> Result<u64> {
        Ok(self.state.tip_height()?.unwrap_or(0))
    }

    pub fn header_hash(&self, height: u64) -> Result<Option<[u8; 32]>> {
        Ok(self.state.header_hash_by_height(height)?.and_then(|raw| hash32(raw, "header hash").ok()))
    }
}

fn hash32(raw: Vec<u8>, what: &str) -> Result<[u8; 32]> {
    if raw.len() != 32 {
        return Err(anyhow!("{what} has invalid length {}", raw.len()));
    }
    let mut out = [0u8; 32];
    out.copy_from_slice(&raw);
    Ok(out)
}

/// Median time past for every height in `start..=end`, from one range read.
///
/// This is the same quantity the consensus layer expects; computing it in bulk
/// here is a database-access optimisation, not a rule change.
pub fn median_time_past_range(state: &State, start: u64, end: u64) -> Result<HashMap<u64, u32>> {
    let from = start.saturating_sub(11).max(1);
    let times: HashMap<u64, u32> = state.header_times_range(from, end)?.into_iter().collect();
    let mut out = HashMap::new();
    for height in start..=end {
        let floor = height.saturating_sub(11);
        let mut window = Vec::with_capacity(11);
        if floor == 0 && height > 0 {
            window.push(ycash_consensus::GENESIS_TIME);
        }
        for h in floor.max(1)..height {
            if let Some(t) = times.get(&h) {
                window.push(*t);
            }
        }
        let median = if window.is_empty() {
            0
        } else {
            window.sort_unstable();
            window[window.len() / 2]
        };
        out.insert(height, median);
    }
    Ok(out)
}

/// One peer's outstanding requests.
pub struct PeerDownloadSession {
    peer: String,
    assigner: Arc<BlockAssigner>,
    registry: Arc<InFlightRegistry>,
    peers: Arc<PeerManager>,
    metrics: Arc<SyncMetrics>,
    in_flight: HashMap<[u8; 32], (BlockRequest, Instant)>,
    limit: usize,
}

impl PeerDownloadSession {
    pub fn new(
        peer: impl Into<String>,
        assigner: Arc<BlockAssigner>,
        registry: Arc<InFlightRegistry>,
        peers: Arc<PeerManager>,
        metrics: Arc<SyncMetrics>,
    ) -> Self {
        let peer = peer.into();
        peers.connected(&peer);
        Self {
            peer,
            assigner,
            registry,
            peers,
            metrics,
            in_flight: HashMap::new(),
            limit: MAX_BLOCKS_IN_TRANSIT_PER_PEER,
        }
    }

    /// Override the per-peer transport limit. Provided so the same chain can be
    /// synchronised at 16 blocks per peer and compared: consensus
    /// results must be identical.
    pub fn with_limit(mut self, limit: usize) -> Self {
        self.limit = limit.clamp(1, MAX_BLOCKS_IN_TRANSIT_PER_PEER);
        self
    }

    pub fn peer(&self) -> &str {
        &self.peer
    }

    pub fn in_flight(&self) -> usize {
        self.in_flight.len()
    }

    fn publish_peer_stats(&self) {
        self.peers.update(&self.peer, |s| s.in_flight = self.in_flight.len());
        self.metrics
            .blocks_in_flight_total
            .store(self.peers.total_in_flight() as u64, Ordering::Relaxed);
    }

    /// Fill the peer's request window back up to the limit. Returns the hashes
    /// to put in a `getdata`, which is empty when the window is full, the global
    /// bound is reached, or the header chain has nothing further to offer.
    ///
    /// A full window does not stop this peer from taking over the canonical
    /// head: the head may use one slot beyond the limit. Otherwise a peer whose
    /// window is packed with forward work could never pick up the one block the
    /// whole pipeline is waiting for.
    /// Fill this peer's window from an explicit height list, lowest first.
    ///
    /// Used by the ordered batch pipeline: the assembler names exactly the
    /// heights the current batch is waiting for, so the head is always the
    /// first thing requested and no other height can starve it.
    pub fn top_up_heights(&mut self, heights: &[u64]) -> Result<Vec<[u8; 32]>> {
        let free = self.limit.saturating_sub(self.in_flight.len());
        if free == 0 || heights.is_empty() {
            return Ok(Vec::new());
        }
        let assigned = self.assigner.assign_heights(heights, free, &self.peer)?;
        let mut hashes = Vec::with_capacity(assigned.len());
        let now = Instant::now();
        for request in assigned {
            hashes.push(request.hash);
            self.in_flight.insert(request.hash, (request, now));
        }
        if !hashes.is_empty() {
            let count = hashes.len() as u64;
            let in_flight = self.in_flight.len();
            self.peers.update(&self.peer, |st| {
                st.in_flight = in_flight;
                st.requested = st.requested.saturating_add(count);
            });
        }
        Ok(hashes)
    }

    pub fn top_up(&mut self) -> Result<Vec<[u8; 32]>> {
        debug_assert!(self.in_flight.len() <= self.limit);
        let free = self.limit.saturating_sub(self.in_flight.len());
        if free == 0 {
            return Ok(Vec::new());
        }
        let want = free;
        let has_alternates = self.peers.peer_count() > 1;
        let assigned = self.assigner.assign(want, &self.peer, has_alternates, false)?;
        let mut hashes = Vec::with_capacity(assigned.len());
        let now = Instant::now();
        let canonical = self.assigner.canonical_height().unwrap_or(0);
        for request in assigned {
            if request.height == canonical.saturating_add(1) {
                self.metrics.trace_head(
                    self.peer.clone(),
                    "CLAIMED",
                    request.height,
                    Some(request.hash),
                    "canonical_height + 1 assigned to this peer",
                );
                self.metrics.set_missing_parent_in_flight(true);
            }
            hashes.push(request.hash);
            self.metrics.raise_download_height(request.height);
            self.in_flight.insert(request.hash, (request, now));
        }
        if !hashes.is_empty() {
            let count = hashes.len() as u64;
            self.peers.update(&self.peer, |s| {
                s.in_flight = self.in_flight.len();
                s.requested = s.requested.saturating_add(count);
            });
            self.metrics
                .blocks_in_flight_total
                .store(self.peers.total_in_flight() as u64, Ordering::Relaxed);
        }
        Ok(hashes)
    }

    /// A block arrived. Frees exactly one slot, immediately: the caller tops up
    /// again without waiting for the other 47.
    ///
    /// The first valid arrival of a hash wins, whichever peer it comes from: a
    /// late delivery from a peer whose head request was already handed to
    /// someone else is still accepted if nothing else has arrived yet.
    pub fn on_block(&mut self, hash: &[u8; 32], bytes: usize) -> Option<BlockRequest> {
        let (request, _) = self.in_flight.remove(hash)?;
        // The transport slot is free, but the global lifecycle slot is not:
        // keep ownership until semantic verification and ordered publication
        // finish. This prevents immediate duplicate getdata for a block that
        // is still inside the verifier.
        // A block that is already canonical is never adopted again: a duplicate
        // delivery behind a hand-off must not re-enter verification.
        let accepted = self.registry.mark_verifying(hash)
            || (request.height > self.assigner.canonical_height().unwrap_or(u64::MAX)
                && self.registry.adopt_arrival(hash, &self.peer));
        self.peers.update(&self.peer, |s| {
            s.in_flight = self.in_flight.len();
            if accepted {
                s.received = s.received.saturating_add(1);
            }
        });
        if !accepted {
            // Somebody else already delivered this block.
            self.metrics
                .blocks_in_flight_total
                .store(self.peers.total_in_flight() as u64, Ordering::Relaxed);
            return None;
        }
        self.metrics.blocks_downloaded.fetch_add(1, Ordering::Relaxed);
        self.metrics.last_received_height.fetch_max(request.height, Ordering::Relaxed);
        if self.assigner.canonical_height().map(|h| request.height == h.saturating_add(1)).unwrap_or(false) {
            self.metrics.trace_head(
                self.peer.clone(),
                "ARRIVED",
                request.height,
                Some(request.hash),
                format!("block bytes={bytes}; request claim released; queued for semantic verification"),
            );
            // Keep the head marked in-flight: the transport slot is free, but
            // semantic verification now owns the lifecycle and must finish
            // before another peer can claim the same hash.
            self.metrics.set_missing_parent_in_flight(true);
        }
        self.metrics.bytes_downloaded.fetch_add(bytes as u64, Ordering::Relaxed);
        self.metrics
            .blocks_in_flight_total
            .store(self.peers.total_in_flight() as u64, Ordering::Relaxed);
        Some(request)
    }

    /// Retry the exact block immediately following the canonical tip when this
    /// peer's request for it has gone stale.
    ///
    /// Ownership is read from the registry, which records the owner of EVERY
    /// transport claim. The head is very often a block that was claimed earlier
    /// as ordinary forward work; treating only claims made through the head
    /// path as reassignable meant such a head could never be retried until the
    /// 90-second transport timeout, while the dashboard showed "head request
    /// active, retries 0".
    ///
    /// The release is a global hand-off: the transport claim is freed, another
    /// connected peer is nominated to receive the next request and this peer is
    /// barred from it for a cool-down. The local in-flight entry is kept so a
    /// late delivery from this peer is still accepted (first arrival wins).
    pub fn retry_canonical_parent(&mut self, base_timeout: Duration) -> Result<bool> {
        let canonical = self.assigner.canonical_height()?;
        let next_height = canonical.saturating_add(1);
        let Some(hash) = self.assigner.header_hash(next_height)? else {
            return Ok(false);
        };
        let age = match self.registry.head_status(&hash) {
            HeadStatus::Transport { owner, age } if owner == self.peer => age,
            _ => return Ok(false),
        };
        let timeout = self.registry.head_retry_timeout(&hash, base_timeout);
        if age < timeout {
            return Ok(false);
        }

        let alternate = self.peers.best_alternate(&self.peer);
        if !self.registry.reassign_head(&hash, &self.peer, alternate.clone()) {
            // The claim moved (arrived, or another peer took it) between the
            // status read and now. Nothing to do.
            return Ok(false);
        }
        self.peers.update(&self.peer, |s| s.timeouts = s.timeouts.saturating_add(1));
        self.metrics.set_missing_parent_in_flight(false);
        self.metrics.trace_head(
            self.peer.clone(),
            "REASSIGN",
            next_height,
            Some(hash),
            format!(
                "head request exceeded {}s; released globally; next_peer={}",
                timeout.as_secs(),
                alternate.as_deref().unwrap_or("any")
            ),
        );
        self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
        self.metrics.expired_requests.fetch_add(1, Ordering::Relaxed);
        self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
        self.metrics.parent_retry_unix_ms.store(
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_millis() as u64)
                .unwrap_or(0),
            Ordering::Relaxed,
        );
        self.metrics.mark_parent_retry();
        let _ = self.assigner.rewind_to_canonical();
        Ok(true)
    }

    /// Hand a head claim this session owns to another peer, or simply free a
    /// non-head claim this session owns. Only claims still owned by this peer
    /// are touched.
    fn give_up(&self, hash: &[u8; 32], height: u64, canonical: u64, event: &str, detail: &str) {
        if height == canonical.saturating_add(1) {
            let alternate = self.peers.best_alternate(&self.peer);
            let handed_off = self.registry.reassign_head(hash, &self.peer, alternate.clone());
            self.metrics.trace_head(
                self.peer.clone(),
                event,
                height,
                Some(*hash),
                format!(
                    "{detail}; {} next_peer={}",
                    if handed_off { "handed off" } else { "claim not owned by this peer" },
                    alternate.as_deref().unwrap_or("any")
                ),
            );
            if handed_off {
                self.metrics.set_missing_parent_in_flight(false);
                self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                self.metrics.parent_retry_height.store(height, Ordering::Relaxed);
                self.metrics.mark_parent_retry();
            }
        } else {
            self.registry.release_transport(hash, &self.peer);
        }
    }

    /// Drop claims this peer has not delivered in time, so another peer can
    /// fetch them.
    pub fn expire_stale(&mut self, timeout: Duration) -> usize {
        let now = Instant::now();
        let stale: Vec<[u8; 32]> = self
            .in_flight
            .iter()
            .filter(|(_, (_, sent))| now.duration_since(*sent) > timeout)
            .map(|(hash, _)| *hash)
            .collect();
        let canonical = self.assigner.canonical_height().unwrap_or(0);
        for hash in &stale {
            let Some((request, sent)) = self.in_flight.remove(hash) else { continue };
            self.give_up(
                hash,
                request.height,
                canonical,
                "TIMEOUT_REASSIGN",
                &format!("normal request timeout after {}s", sent.elapsed().as_secs()),
            );
        }
        if !stale.is_empty() {
            let count = stale.len() as u64;
            self.peers.update(&self.peer, |s| {
                s.in_flight = self.in_flight.len();
                s.timeouts = s.timeouts.saturating_add(count);
            });
            self.metrics.expired_requests.fetch_add(count, Ordering::Relaxed);
            let _ = self.assigner.rewind_to_canonical();
        }
        stale.len()
    }

    /// Release exactly one requested hash, used for a peer's `notfound` reply.
    /// Older code expired the entire peer window on one `notfound`, causing
    /// unrelated requests to churn and making head-of-line recovery harder to trace.
    pub fn release_hash(&mut self, hash: &[u8; 32], reason: &str) -> bool {
        let Some((request, _)) = self.in_flight.remove(hash) else { return false };
        let canonical = self.assigner.canonical_height().unwrap_or(0);
        self.give_up(hash, request.height, canonical, "NOTFOUND", reason);
        if request.height == canonical.saturating_add(1) {
            let _ = self.assigner.rewind_to_canonical();
        }
        self.publish_peer_stats();
        true
    }

    /// Give up every claim, e.g. when the connection ends.
    pub fn release_all(&mut self) {
        let canonical = self.assigner.canonical_height().unwrap_or(0);
        let entries: Vec<([u8; 32], u64)> = self.in_flight.iter().map(|(h, (r, _))| (*h, r.height)).collect();
        for (hash, height) in entries {
            self.give_up(&hash, height, canonical, "DISCONNECT_REASSIGN", "peer session ended");
        }
        self.in_flight.clear();
        self.peers.disconnected(&self.peer);
        self.metrics
            .blocks_in_flight_total
            .store(self.peers.total_in_flight() as u64, Ordering::Relaxed);
        let _ = self.assigner.rewind_to_canonical();
    }
}

impl Drop for PeerDownloadSession {
    fn drop(&mut self) {
        self.release_all();
    }
}

pub fn not_requested(hash: &[u8; 32]) -> anyhow::Error {
    anyhow!("peer sent a block that was not requested: {}", hex_hash(hash))
}

pub fn hex_hash(hash: &[u8; 32]) -> String {
    let mut s = String::with_capacity(64);
    for b in hash.iter().rev() {
        s.push_str(&format!("{b:02x}"));
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;

    const A: &str = "peer-a";
    const B: &str = "peer-b";

    #[test]
    fn lifecycle_claim_is_held_through_verification_until_terminal_release() {
        let registry = InFlightRegistry::new(2);
        let hash = [9u8; 32];
        assert!(registry.claim(hash, A));
        assert!(!registry.claim(hash, A));
        assert!(registry.mark_verifying(&hash));
        assert!(!registry.claim(hash, A));
        assert!(registry.mark_verified(&hash));
        assert!(!registry.claim(hash, A));
        registry.release(&hash);
        assert!(registry.claim(hash, A));
    }

    #[test]
    fn the_registry_refuses_a_second_claim_on_one_hash() {
        let registry = InFlightRegistry::new(8);
        assert!(registry.claim([7u8; 32], A));
        assert!(!registry.claim([7u8; 32], B));
        registry.release(&[7u8; 32]);
        assert!(registry.claim([7u8; 32], B));
    }

    #[test]
    fn stale_head_recovery_never_steals_a_verified_candidate() {
        let registry = InFlightRegistry::new(8);
        let hash = [4u8; 32];
        assert!(registry.claim(hash, A));
        assert!(registry.mark_verifying(&hash));
        assert!(registry.mark_verified(&hash));
        // A verified candidate may legitimately spend time waiting for the
        // ordered gate. It must not become a duplicate transport request.
        assert!(!registry.break_stale_transport_claim(&hash, Duration::ZERO));
        assert!(registry.steal_stale_head(&hash, B, Duration::ZERO, true).is_none());
        assert!(!registry.reassign_head(&hash, A, Some(B.into())));
        assert!(!registry.release_transport(&hash, A));
        assert!(registry.is_claimed(&hash));
    }

    #[test]
    fn canonical_head_claim_respects_the_global_capacity() {
        let registry = InFlightRegistry::new(1);
        assert!(registry.claim([1u8; 32], A));
        // Head recovery never creates a hidden +1 slot. The existing claim must
        // drain before the canonical head can be requested.
        assert_eq!(registry.spare_capacity(), 0);
        assert!(!registry.claim_head([2u8; 32], A, true));
        assert_eq!(registry.len(), 1);
    }

    #[test]
    fn head_reassignment_cannot_be_reclaimed_by_old_peer() {
        let registry = InFlightRegistry::new(8);
        let hash = [6u8; 32];
        assert!(registry.claim_head(hash, A, true));
        assert_eq!(registry.head_owner(&hash).as_deref(), Some(A));
        assert!(registry.reassign_head(&hash, A, Some(B.into())));
        assert!(!registry.claim_head(hash, A, true));
        assert!(registry.claim_head(hash, B, true));
        assert_eq!(registry.head_owner(&hash).as_deref(), Some(B));
    }

    /// The v0.33.2 stall: the block that becomes canonical+1 was claimed
    /// earlier as ordinary forward work, so no head owner was recorded and
    /// head recovery refused to touch it ("head request active, retries 0").
    #[test]
    fn a_forward_claim_promoted_to_head_can_be_reassigned() {
        let registry = InFlightRegistry::new(8);
        let hash = [5u8; 32];
        assert!(registry.claim(hash, A)); // forward claim, not claim_head
        assert_eq!(registry.head_owner(&hash).as_deref(), Some(A));
        assert!(registry.reassign_head(&hash, A, Some(B.into())));
        assert!(!registry.is_claimed(&hash));
        assert!(registry.claim_head(hash, B, true));
    }

    #[test]
    fn a_stale_head_request_is_taken_over_by_another_peer() {
        let registry = InFlightRegistry::new(8);
        let hash = [3u8; 32];
        assert!(registry.claim(hash, A));
        // A fresh request is left alone.
        assert!(registry.steal_stale_head(&hash, B, Duration::from_secs(3600), true).is_none());
        // The owner cannot steal from itself.
        assert!(registry.steal_stale_head(&hash, A, Duration::ZERO, true).is_none());
        // A stale one is taken over atomically.
        assert_eq!(registry.steal_stale_head(&hash, B, Duration::ZERO, true).as_deref(), Some(A));
        assert_eq!(registry.head_owner(&hash).as_deref(), Some(B));
        // The previous owner is now on cool-down for this head.
        assert!(registry.reassign_head(&hash, B, None));
        assert!(!registry.claim_head(hash, A, true));
        // ...unless it is the only peer left.
        assert!(registry.claim_head(hash, A, false));
    }

    #[test]
    fn a_session_cannot_release_a_claim_it_no_longer_owns() {
        let registry = InFlightRegistry::new(8);
        let hash = [8u8; 32];
        assert!(registry.claim(hash, A));
        assert_eq!(registry.steal_stale_head(&hash, B, Duration::ZERO, true).as_deref(), Some(A));
        assert!(!registry.release_transport(&hash, A));
        assert!(registry.is_claimed(&hash));
        assert!(registry.release_transport(&hash, B));
        assert!(!registry.is_claimed(&hash));
    }

    #[test]
    fn a_late_delivery_after_release_is_adopted_not_discarded() {
        let registry = InFlightRegistry::new(8);
        let hash = [2u8; 32];
        assert!(registry.claim_head(hash, A, true));
        assert!(registry.reassign_head(&hash, A, Some(B.into())));
        assert!(!registry.mark_verifying(&hash));
        assert!(registry.adopt_arrival(&hash, A));
        assert!(!registry.adopt_arrival(&hash, B));
        assert!(registry.mark_verified(&hash));
        assert!(!registry.claim_head(hash, B, true));
    }

    #[test]
    fn head_retry_timeout_backs_off_and_is_bounded() {
        let registry = InFlightRegistry::new(8);
        let hash = [1u8; 32];
        let base = Duration::from_secs(8);
        assert_eq!(registry.head_retry_timeout(&hash, base), base);
        assert!(registry.claim_head(hash, A, true));
        assert!(registry.reassign_head(&hash, A, None));
        assert_eq!(registry.head_retry_timeout(&hash, base), Duration::from_secs(12));
        for _ in 0..20 {
            assert!(registry.claim_head(hash, B, false));
            assert!(registry.reassign_head(&hash, B, None));
        }
        assert_eq!(registry.head_retry_timeout(&hash, base), HEAD_STALL_TIMEOUT);
        // A committed head forgets its history.
        registry.release_many(&[hash]);
        assert_eq!(registry.head_retry_timeout(&hash, base), base);
    }

    #[test]
    fn head_reservation_is_visible_until_peer_claims_it() {
        let registry = InFlightRegistry::new(8);
        let hash = [0xABu8; 32];
        assert!(registry.reserve_head(hash, A, true));
        assert!(matches!(registry.head_status(&hash), HeadStatus::Reserved { ref owner, .. } if owner == A));
        assert!(registry.claim_head(hash, A, true));
        assert!(matches!(registry.head_status(&hash), HeadStatus::Transport { ref owner, .. } if owner == A));
    }

    #[test]
    fn head_status_reports_owner_and_lifecycle() {
        let registry = InFlightRegistry::new(8);
        let hash = [0xAAu8; 32];
        assert_eq!(registry.head_status(&hash), HeadStatus::Free);
        assert!(registry.claim(hash, A));
        assert!(matches!(registry.head_status(&hash), HeadStatus::Transport { ref owner, .. } if owner == A));
        assert!(registry.mark_verifying(&hash));
        assert!(matches!(registry.head_status(&hash), HeadStatus::Lifecycle { .. }));
    }

    #[test]
    fn an_orphaned_head_lifecycle_entry_can_be_recovered() {
        let registry = InFlightRegistry::new(8);
        let hash = [0xBBu8; 32];
        assert!(registry.claim(hash, A));
        // Transport claims are not lifecycle claims.
        assert!(!registry.break_stale_lifecycle(&hash, Duration::ZERO));
        assert!(registry.mark_verifying(&hash));
        assert!(!registry.break_stale_lifecycle(&hash, Duration::from_secs(3600)));
        assert!(registry.break_stale_lifecycle(&hash, Duration::ZERO));
        assert!(!registry.is_claimed(&hash));
    }

    #[test]
    fn late_arrival_respects_global_capacity() {
        let registry = InFlightRegistry::new(1);
        let hash = [0xCCu8; 32];
        assert!(registry.claim_head(hash, A, true));
        assert!(registry.reassign_head(&hash, A, Some(B.into())));
        assert!(registry.claim([0xDDu8; 32], B));
        assert!(!registry.adopt_arrival(&hash, A));
    }

    #[test]
    fn explicit_verified_to_queued_head_lifecycle() {
        let registry = InFlightRegistry::new(4);
        let hash = [0xEEu8; 32];
        registry.set_head_target(42, hash);
        assert!(registry.claim_head(hash, A, true));
        assert_eq!(registry.head_tracker().snapshot().unwrap().phase, HeadPhase::Claimed);
        assert!(registry.mark_verifying(&hash));
        assert_eq!(registry.head_tracker().snapshot().unwrap().phase, HeadPhase::Verifying);
        assert!(registry.mark_verified(&hash));
        assert_eq!(registry.head_tracker().snapshot().unwrap().phase, HeadPhase::Verified);
        assert!(registry.mark_queued(&hash));
        assert_eq!(registry.head_tracker().snapshot().unwrap().phase, HeadPhase::Queued);
    }


    #[test]
    fn the_registry_enforces_the_global_bound() {
        let registry = InFlightRegistry::new(2);
        assert!(registry.claim([1u8; 32], A));
        assert!(registry.claim([2u8; 32], A));
        assert!(!registry.claim([3u8; 32], A));
        assert_eq!(registry.spare_capacity(), 0);
        registry.release(&[1u8; 32]);
        assert!(registry.claim([3u8; 32], A));
    }

    #[test]
    fn the_per_peer_window_never_exceeds_the_transport_limit() {
        assert_eq!(MAX_BLOCKS_IN_TRANSIT_PER_PEER, 16);
        assert!(MAX_BLOCKS_IN_FLIGHT >= MAX_BLOCKS_IN_TRANSIT_PER_PEER);
    }
}
