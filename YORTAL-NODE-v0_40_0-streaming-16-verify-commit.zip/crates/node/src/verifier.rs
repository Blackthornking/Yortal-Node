//! Semantic (context-free) verification.
//!
//! Verification owns the expensive consensus work. Context-free checks start
//! as soon as each block arrives inside the single 16-block lifecycle window;
//! results are retained by height until the complete exact window is ready. The
//! verifier coordinator then performs state-dependent transaction/script
//! preparation against a consistent snapshot. Only the resulting prepared
//! mutation plan crosses into canonical publication.
//!
//! Canonical publication is deliberately not a validation stage: it only
//! rechecks the prepared parent/tip and atomically writes the prepared state.

use std::collections::{BTreeMap, BTreeSet};
use std::sync::atomic::Ordering;
use std::sync::mpsc::{sync_channel, Receiver, SyncSender};
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

use anyhow::{anyhow, bail, Result};
use ycash_chain::{genesis_hash_internal, txid};
use ycash_consensus::{validate_for_commit_batched_with_parsed, Context, ProofBatch};
use ycash_state::prospective::SemanticBlock;
use ycash_state::State;
use ycash_state::state_service::SyncMetrics;
use ycash_state::BlockCommit;

use crate::downloader::{BlockRequest, InFlightRegistry};
use ycash_crypto::{validate_chain_links, ChainLink, ChainLinkError};

/// Optional assume-valid checkpoint, carried over unchanged. Full verification
/// is the default; this is used only when YCASH_ASSUME_VALID=1 and the verified
/// header at the checkpoint height matches.
pub const ASSUME_VALID_HEIGHT: u64 = 2_250_000;
pub const ASSUME_VALID_HASH_DISPLAY: &str =
    "000003f98b7497fdcd8a6b6d10a93a887c5d47127e24a9dc3a40cb65754d21e7";

/// Blocks a verifier thread folds into one Groth16 batch.
///
/// The batch identity costs one final exponentiation regardless of how many
/// proofs it holds, so a bigger batch amortises it better. One block per batch
/// wastes that on blocks with few shielded transactions. Grouping is bounded
/// rather than unlimited because a worker only groups what has *already*
/// arrived: it never waits for more blocks, so latency at the chain tip is
/// unchanged.
///
/// This is a scheduling constant. It changes how proofs are grouped for
/// verification, never which proofs must verify.
pub const MAX_BLOCKS_PER_PROOF_BATCH: usize = 8;

/// A downloaded block with the header context its verification needs.
#[derive(Debug)]
pub struct RawBlock {
    pub request: BlockRequest,
    pub raw: Vec<u8>,
    /// Peer that supplied the block. Diagnostic provenance only.
    pub source_peer: String,
}

/// Result of one verifier attempt with enough provenance to close the block
/// lifecycle exactly once.
pub struct VerifyOutcome {
    pub height: u64,
    pub hash: [u8; 32],
    pub source_peer: String,
    pub result: Result<SemanticBlock>,
}

/// The prev-hash field of a block header, read straight from the wire bytes.
///
/// Header layout: version(4) | prev(32) | merkle(32) | final Sapling root(32) |
/// time(4) | bits(4) | nonce(32) | solution.
pub fn header_prev(raw: &[u8]) -> Result<[u8; 32]> {
    if raw.len() < 36 {
        bail!("block is too short to contain a header");
    }
    let mut prev = [0u8; 32];
    prev.copy_from_slice(&raw[4..36]);
    Ok(prev)
}

/// Run every context-free consensus check for one block.
///
/// This is the same entry point the previous pipeline used, called with the
/// same arguments for the same block; only the surrounding scheduling changed.
pub fn semantic_verify(block: RawBlock, assume_valid: bool) -> Result<SemanticBlock> {
    let RawBlock { request, raw, .. } = block;
    let height = request.height;
    let ctx = Context {
        height,
        prev_height: height.saturating_sub(1),
        median_time_past: request.median_time_past,
    };
    let assume_valid = assume_valid && height <= ASSUME_VALID_HEIGHT;

    // Sapling proofs in one block share a batch: one multi-Miller loop per
    // verifying key rather than one pairing check per proof. A rejection is
    // re-checked by the single-proof verifier, whose result is final.
    let mut proofs = ProofBatch::new();
    let (validated, parsed_txs) = validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, &mut proofs)
        .map_err(|e| anyhow!("block {height}: {e:?}"))?;
    if proofs.proofs() > 0 {
        if let Err((h, e)) = proofs.finish() {
            bail!("block {h}: {e:?}");
        }
    }
    if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
        bail!("block {height}: consensus decoder returned inconsistent transaction data");
    }

    let prev = header_prev(&raw)?;
    let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
    let precomputed_txs: Vec<ycash_script::PrecomputedTxData> =
        parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();

    Ok(SemanticBlock::from_commit(BlockCommit {
        height,
        hash: request.hash,
        prev,
        work: request.work,
        raw,
        txs,
        parsed_txs,
        precomputed_txs,
        proofs_verified: true,
    }))
}

/// Verify a group of blocks, folding every Sapling proof in the group into one
/// batch.
///
/// On batch rejection each block is re-verified on its own. The batch says only
/// that something in the set is bad, never which block, so a batch verdict is
/// never reported as a per-block result.
pub fn verify_group(blocks: Vec<RawBlock>, assume_valid: bool) -> Vec<VerifyOutcome> {
    if blocks.len() == 1 {
        let mut blocks = blocks;
        let block = blocks.remove(0);
        let height = block.request.height;
        let hash = block.request.hash;
        let source_peer = block.source_peer.clone();
        return vec![VerifyOutcome { height, hash, source_peer, result: semantic_verify(block, assume_valid) }];
    }

    let mut batch = ProofBatch::new();
    let mut staged: Vec<Result<SemanticBlock>> = Vec::with_capacity(blocks.len());
    let mut retained: Vec<RawBlock> = Vec::with_capacity(blocks.len());
    for block in blocks {
        let raw_for_retry = RawBlock {
            request: block.request.clone(),
            raw: block.raw.clone(),
            source_peer: block.source_peer.clone(),
        };
        retained.push(raw_for_retry);
        staged.push(verify_into_batch(block, assume_valid, &mut batch));
    }

    if batch.proofs() > 0 {
        if let Err((height, e)) = batch.finish() {
            // Isolate: re-verify every block in the group individually. The
            // lifecycle remains owned throughout this retry; no transport
            // request can be issued for any member while isolation runs.
            eprintln!("[VERIFY] proof batch rejected at height {height} ({e:?}); isolating {} blocks", retained.len());
            return retained
                .into_iter()
                .map(|raw| {
                    let height = raw.request.height;
                    let hash = raw.request.hash;
                    let source_peer = raw.source_peer.clone();
                    VerifyOutcome { height, hash, source_peer, result: semantic_verify(raw, assume_valid) }
                })
                .collect();
        }
    }

    retained
        .into_iter()
        .zip(staged)
        .map(|(raw, result)| VerifyOutcome {
            height: raw.request.height,
            hash: raw.request.hash,
            source_peer: raw.source_peer,
            result,
        })
        .collect()
}

/// Every context-free check for one block except the Groth16 pairing, which is
/// queued into the caller's batch.
pub(crate) fn verify_into_batch(block: RawBlock, assume_valid: bool, batch: &mut ProofBatch) -> Result<SemanticBlock> {
    let RawBlock { request, raw, .. } = block;
    let height = request.height;
    let ctx = Context {
        height,
        prev_height: height.saturating_sub(1),
        median_time_past: request.median_time_past,
    };
    let assume_valid = assume_valid && height <= ASSUME_VALID_HEIGHT;
    let (validated, parsed_txs) = validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, batch)
        .map_err(|e| anyhow!("block {height}: {e:?}"))?;
    if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
        bail!("block {height}: consensus decoder returned inconsistent transaction data");
    }
    let prev = header_prev(&raw)?;
    let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
    let precomputed_txs: Vec<ycash_script::PrecomputedTxData> =
        parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();
    Ok(SemanticBlock::from_commit(BlockCommit {
        height,
        hash: request.hash,
        prev,
        work: request.work,
        raw,
        txs,
        parsed_txs,
        precomputed_txs,
        proofs_verified: true,
    }))
}

/// Maximum contiguous verification micro-batch.
///
/// The downloader and lifecycle registry now keep a single 16-block resource window, and verification no
/// waits for all 16 to arrive. Once canonical+1 through canonical+16 are
/// present, the coordinator verifies that exact contiguous window. This removes
/// the old large head-of-line blocking while preserving the no-gap parent
/// invariant.
pub const VERIFICATION_BATCH_SIZE: usize = crate::PIPELINE_BATCH_SIZE;

struct VerifierTask {
    batch_id: u64,
    items: Vec<(usize, RawBlock)>,
}

struct VerifierResult {
    batch_id: u64,
    worker_id: usize,
    results: Vec<(usize, VerifyOutcome)>,
}

/// Partition the exact 16 ordered positions into contiguous numbered verifier ranges.
/// The first `remainder` verifiers receive one extra block, so every position
/// appears exactly once and verifier order is deterministic.
fn partition_batch(batch_len: usize, verifiers: usize) -> Vec<std::ops::Range<usize>> {
    let n = verifiers.max(1).min(batch_len.max(1));
    let base = batch_len / n;
    let remainder = batch_len % n;
    let mut ranges = Vec::with_capacity(n);
    let mut start = 0;
    for id in 0..n {
        let len = base + usize::from(id < remainder);
        let end = start + len;
        ranges.push(start..end);
        start = end;
    }
    ranges
}

/// Validate that a collected network batch is exactly one contiguous ancestry
/// chain. This is a scheduling gate only: contextual consensus validity is still
/// performed later by the ordered state service.
fn normalize_batch(
    mut batch: Vec<RawBlock>,
    expected_height: u64,
    expected_parent: [u8; 32],
) -> std::result::Result<Vec<RawBlock>, (Vec<RawBlock>, anyhow::Error)> {
    if batch.is_empty() {
        return Err((batch, anyhow!("empty verification batch")));
    }
    batch.sort_by_key(|b| b.request.height);

    let mut links = Vec::with_capacity(batch.len());
    for block in &batch {
        let prev = match header_prev(&block.raw) {
            Ok(prev) => prev,
            Err(e) => return Err((batch, e)),
        };
        links.push(ChainLink {
            height: block.request.height,
            hash: block.request.hash,
            prev_hash: prev,
        });
    }

    match validate_chain_links(expected_height, expected_parent, &links) {
        Ok(()) => Ok(batch),
        Err(ChainLinkError::WrongStartHeight { expected, actual }) => Err((
            batch,
            anyhow!("verification batch must start at canonical tip + 1: expected {expected}, got {actual}"),
        )),
        Err(ChainLinkError::FirstParentMismatch) => Err((
            batch,
            anyhow!("verification batch first block does not point to the canonical tip"),
        )),
        Err(ChainLinkError::HeightGap { previous, current }) => Err((
            batch,
            anyhow!("verification batch is not contiguous: {previous} followed by {current}"),
        )),
        Err(ChainLinkError::ParentMismatch { height }) => Err((
            batch,
            anyhow!("verification batch parent mismatch at height {height}"),
        )),
        Err(ChainLinkError::Empty) => Err((batch, anyhow!("empty verification batch"))),
    }
}

/// Fixed numbered verifier pool feeding the canonical publisher.
///
/// The pool is deliberately two-level:
///
/// 1. The coordinator retains arrivals by height and waits only for a
///    contiguous prefix beginning at canonical+1.
/// 2. That prefix is capped at the 16-block verification micro-batch size and is
///    split into contiguous numbered verifier sub-batches.
/// 3. Results are gathered by batch/position; the coordinator then performs
///    contextual/script validation and hands only a prepared mutation plan to
///    canonical publication.
#[derive(Clone)]
pub struct VerifierPool {
    tx: SyncSender<RawBlock>,
    metrics: Arc<SyncMetrics>,
}

impl VerifierPool {
    pub fn spawn(
        workers: usize,
        _queue_depth: usize,
        chain: Arc<State>,
        metrics: Arc<SyncMetrics>,
        registry: Arc<InFlightRegistry>,
        assume_valid: bool,
    ) -> Result<Self> {
        let workers = workers.max(1).min(VERIFICATION_BATCH_SIZE);
        let (tx, rx) = sync_channel::<RawBlock>(VERIFICATION_BATCH_SIZE);
        let (result_tx, result_rx) = sync_channel::<VerifierResult>(workers.saturating_mul(2).max(1));
        let mut task_txs = Vec::with_capacity(workers);

        metrics.verifier_workers.store(workers as u64, Ordering::Relaxed);

        for id in 0..workers {
            let (task_tx, task_rx) = sync_channel::<VerifierTask>(1);
            task_txs.push(task_tx);
            let result_tx = result_tx.clone();
            let worker_metrics = Arc::clone(&metrics);
            thread::Builder::new()
                .name(format!("yortal-verify-{id}"))
                .spawn(move || {
                    while let Ok(task) = task_rx.recv() {
                        let VerifierTask { batch_id, items } = task;
                        // A dequeued task is active validation even though the
                        // ingress queue is already empty. Keep this visible so
                        // the dashboard does not call an active verifier an
                        // idle/queued state.
                        worker_metrics.semantic_active_workers.fetch_add(1, Ordering::Relaxed);
                        let mut results = Vec::with_capacity(items.len());
                        // The verifier owns a contiguous sub-batch and processes
                        // it strictly in position order. Proof pairing is still
                        // capped by MAX_BLOCKS_PER_PROOF_BATCH so the 16-block
                        // scheduling layer does not accidentally enlarge the
                        // cryptographic proof batch.
                        for chunk in items.chunks(MAX_BLOCKS_PER_PROOF_BATCH) {
                            let positions: Vec<usize> = chunk.iter().map(|(position, _)| *position).collect();
                            let blocks: Vec<RawBlock> = chunk
                                .iter()
                                .map(|(_, block)| RawBlock {
                                    request: block.request.clone(),
                                    raw: block.raw.clone(),
                                    source_peer: block.source_peer.clone(),
                                })
                                .collect();
                            let outcomes = verify_group(blocks, assume_valid);
                            results.extend(positions.into_iter().zip(outcomes));
                        }
                        worker_metrics.semantic_active_workers.fetch_sub(1, Ordering::Relaxed);
                        if result_tx.send(VerifierResult { batch_id, worker_id: id, results }).is_err() {
                            return;
                        }
                    }
                })
                .map_err(|e| anyhow!("failed to start verifier thread {id}: {e}"))?;
        }
        drop(result_tx);

        let assembler_state = Arc::clone(&chain);
        let assembler_metrics = Arc::clone(&metrics);
        let assembler_registry = Arc::clone(&registry);
        thread::Builder::new()
            .name("yortal-verify-batch-coordinator".into())
            .spawn(move || {
                // One lifecycle batch is still exactly 16 blocks, but the
                // semantic verifier no longer waits for all 16 to arrive before
                // starting work. Blocks are verified as they arrive and the
                // results are retained until the complete exact-height window is
                // ready for one ordered contextual preparation + atomic publish.
                // This overlaps network delivery with expensive verification
                // without widening the global 16-block lifecycle window.
                let mut batch_id = 0u64;
                let mut expected_height = 0u64;
                let mut expected_parent = [0u8; 32];
                let mut received: BTreeMap<u64, RawBlock> = BTreeMap::new();
                let mut dispatched: BTreeSet<u64> = BTreeSet::new();
                let mut results: BTreeMap<usize, VerifyOutcome> = BTreeMap::new();
                let mut worker_busy = vec![false; task_txs.len()];
                let mut semantic_started: Option<Instant> = None;
                let mut semantic_failed = false;

                let reset_batch = |received: &mut BTreeMap<u64, RawBlock>,
                                   dispatched: &mut BTreeSet<u64>,
                                   results: &mut BTreeMap<usize, VerifyOutcome>,
                                   worker_busy: &mut Vec<bool>,
                                   semantic_started: &mut Option<Instant>,
                                   semantic_failed: &mut bool| {
                    received.clear();
                    dispatched.clear();
                    results.clear();
                    worker_busy.fill(false);
                    *semantic_started = None;
                    *semantic_failed = false;
                };

                let release_received = |received: &mut BTreeMap<u64, RawBlock>,
                                        registry: &InFlightRegistry| {
                    for block in received.values() {
                        registry.release(&block.request.hash);
                    }
                };

                loop {
                    // Multiplex network arrivals and verifier completions. A
                    // short receive timeout keeps both sides flowing while
                    // avoiding a busy-spin when the pipeline is genuinely idle.
                    match rx.recv_timeout(Duration::from_millis(10)) {
                        Ok(block) => {
                            if received.is_empty() {
                                let canonical_height = match assembler_state.tip_height() {
                                    Ok(height) => height,
                                    Err(e) => {
                                        assembler_metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
                                        assembler_registry.release(&block.request.hash);
                                        eprintln!("[VERIFY-BATCH] canonical tip height read failed: {e}");
                                        continue;
                                    }
                                };
                                expected_height = canonical_height.unwrap_or(0).saturating_add(1);
                                let tip_hash = match assembler_state.tip_hash() {
                                    Ok(hash) => hash,
                                    Err(e) => {
                                        assembler_metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
                                        assembler_registry.release(&block.request.hash);
                                        eprintln!("[VERIFY-BATCH] canonical tip hash read failed: {e}");
                                        continue;
                                    }
                                };
                                expected_parent = match (canonical_height, tip_hash) {
                                    (None, None) => genesis_hash_internal(),
                                    (Some(_), Some(hash)) if hash.len() == 32 => {
                                        let mut out = [0u8; 32];
                                        out.copy_from_slice(&hash);
                                        out
                                    }
                                    (Some(_), Some(_)) => {
                                        assembler_metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
                                        assembler_registry.release(&block.request.hash);
                                        eprintln!("[VERIFY-BATCH] canonical tip hash is not 32 bytes");
                                        continue;
                                    }
                                    _ => {
                                        assembler_metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
                                        assembler_registry.release(&block.request.hash);
                                        eprintln!("[VERIFY-BATCH] canonical tip height/hash state is inconsistent");
                                        continue;
                                    }
                                };
                                semantic_failed = false;
                            }
                            let height = block.request.height;
                            let in_window = height >= expected_height
                                && height < expected_height.saturating_add(VERIFICATION_BATCH_SIZE as u64);
                            if !in_window {
                                assembler_metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
                                assembler_registry.release(&block.request.hash);
                            } else if received.contains_key(&height) || dispatched.contains(&height) {
                                // One lifecycle slot is already owned by the
                                // first block at this height; the extra arrival
                                // cannot become canonical in this window.
                                assembler_metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
                                assembler_registry.release(&block.request.hash);
                            } else {
                                received.insert(height, block);
                            }
                        }
                        Err(std::sync::mpsc::RecvTimeoutError::Disconnected) => break,
                        Err(std::sync::mpsc::RecvTimeoutError::Timeout) => {}
                    }

                    // Drain a burst of arrivals so the verifier sees the whole
                    // currently-available frontier without waiting for another
                    // 10 ms tick.
                    while let Ok(block) = rx.try_recv() {
                        if received.is_empty() {
                            let canonical_height = match assembler_state.tip_height() {
                                Ok(height) => height,
                                Err(e) => {
                                    assembler_metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
                                    assembler_registry.release(&block.request.hash);
                                    eprintln!("[VERIFY-BATCH] canonical tip height read failed: {e}");
                                    continue;
                                }
                            };
                            expected_height = canonical_height.unwrap_or(0).saturating_add(1);
                            let tip_hash = match assembler_state.tip_hash() {
                                Ok(hash) => hash,
                                Err(e) => {
                                    assembler_metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
                                    assembler_registry.release(&block.request.hash);
                                    eprintln!("[VERIFY-BATCH] canonical tip hash read failed: {e}");
                                    continue;
                                }
                            };
                            expected_parent = match (canonical_height, tip_hash) {
                                (None, None) => genesis_hash_internal(),
                                (Some(_), Some(hash)) if hash.len() == 32 => {
                                    let mut out = [0u8; 32];
                                    out.copy_from_slice(&hash);
                                    out
                                }
                                _ => {
                                    assembler_metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
                                    assembler_registry.release(&block.request.hash);
                                    eprintln!("[VERIFY-BATCH] canonical tip context is inconsistent");
                                    continue;
                                }
                            };
                            semantic_failed = false;
                        }
                        let height = block.request.height;
                        let in_window = height >= expected_height
                            && height < expected_height.saturating_add(VERIFICATION_BATCH_SIZE as u64);
                        if !in_window || received.contains_key(&height) || dispatched.contains(&height) {
                            assembler_metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
                            assembler_registry.release(&block.request.hash);
                        } else {
                            received.insert(height, block);
                        }
                    }

                    // Dispatch ready blocks immediately. Semantic verification is
                    // context-free here, so a later height may be verified while
                    // an earlier height is still running. Canonical ordering is
                    // restored only when the 16 results are assembled below.
                    if !semantic_failed && !received.is_empty() {
                        for worker_id in 0..task_txs.len() {
                            if worker_busy[worker_id] {
                                continue;
                            }
                            let available: Vec<u64> = received
                                .keys()
                                .filter(|height| !dispatched.contains(height))
                                .copied()
                                .take(MAX_BLOCKS_PER_PROOF_BATCH)
                                .collect();
                            if available.is_empty() {
                                break;
                            }
                            let items: Vec<(usize, RawBlock)> = available
                                .iter()
                                .map(|height| {
                                    let block = received.get(height).expect("received height disappeared");
                                    ((*height - expected_height) as usize, RawBlock {
                                        request: block.request.clone(),
                                        raw: block.raw.clone(),
                                        source_peer: block.source_peer.clone(),
                                    })
                                })
                                .collect();
                            for height in &available {
                                dispatched.insert(*height);
                            }
                            assembler_metrics.semantic_queue.fetch_sub(available.len() as u64, Ordering::Relaxed);
                            if semantic_started.is_none() {
                                semantic_started = Some(Instant::now());
                                assembler_metrics.semantic_batches.fetch_add(1, Ordering::Relaxed);
                                assembler_metrics.last_semantic_batch_blocks.store(
                                    VERIFICATION_BATCH_SIZE as u64,
                                    Ordering::Relaxed,
                                );
                            }
                            if task_txs[worker_id]
                                .send(VerifierTask { batch_id, items })
                                .is_err()
                            {
                                semantic_failed = true;
                                worker_busy[worker_id] = false;
                                break;
                            }
                            worker_busy[worker_id] = true;
                        }
                    }

                    // Process every verifier completion already waiting for us.
                    while let Ok(response) = result_rx.try_recv() {
                        if response.batch_id != batch_id {
                            semantic_failed = true;
                            continue;
                        }
                        if response.worker_id >= worker_busy.len() {
                            semantic_failed = true;
                            continue;
                        }
                        worker_busy[response.worker_id] = false;
                        for (position, outcome) in response.results {
                            if position >= VERIFICATION_BATCH_SIZE || results.contains_key(&position) {
                                semantic_failed = true;
                                continue;
                            }
                            if outcome.result.is_err() {
                                semantic_failed = true;
                                assembler_metrics.semantic_batch_failures.fetch_add(1, Ordering::Relaxed);
                                assembler_metrics.invalid_blocks.fetch_add(1, Ordering::Relaxed);
                                eprintln!(
                                    "[VERIFY-BATCH] batch {batch_id} rejected at position {} / height {}: {:?}",
                                    position,
                                    outcome.height,
                                    outcome.result.as_ref().err()
                                );
                            } else if let Some(block) = received.get(&outcome.height) {
                                if assembler_registry.mark_verified(&block.request.hash) {
                                    assembler_metrics.semantic_verified_blocks.fetch_add(1, Ordering::Relaxed);
                                    assembler_metrics.raise_semantic_height(outcome.height);
                                } else {
                                    semantic_failed = true;
                                }
                            } else {
                                semantic_failed = true;
                            }
                            results.insert(position, outcome);
                        }
                    }

                    // If a worker has not completed yet, its result will be
                    // consumed on the next loop. We can keep receiving network
                    // blocks and dispatching other free workers in the meantime.
                    let all_received = received.len() == VERIFICATION_BATCH_SIZE;
                    let all_verified = results.len() == VERIFICATION_BATCH_SIZE;
                    let workers_idle = worker_busy.iter().all(|busy| !*busy);

                    if all_received && all_verified && workers_idle {
                        if let Some(started) = semantic_started.take() {
                            let elapsed = started.elapsed().as_micros() as u64;
                            assembler_metrics.semantic_verify_us.store(elapsed, Ordering::Relaxed);
                            assembler_metrics.semantic_verify_total_us.fetch_add(elapsed, Ordering::Relaxed);
                        }

                        if semantic_failed {
                            release_received(&mut received, assembler_registry.as_ref());
                            reset_batch(
                                &mut received,
                                &mut dispatched,
                                &mut results,
                                &mut worker_busy,
                                &mut semantic_started,
                                &mut semantic_failed,
                            );
                            batch_id = batch_id.saturating_add(1);
                            continue;
                        }

                        let ordered_result = (0..VERIFICATION_BATCH_SIZE)
                            .map(|position| results.remove(&position).expect("all 16 verification results present").result)
                            .collect::<Vec<_>>();
                        let verified_blocks = ordered_result
                            .into_iter()
                            .map(|result| result.expect("semantic failure already handled"))
                            .collect::<Vec<_>>();
                        let raw_blocks = received.values().map(|block| RawBlock {
                            request: block.request.clone(),
                            raw: block.raw.clone(),
                            source_peer: block.source_peer.clone(),
                        }).collect::<Vec<_>>();

                        match normalize_batch(raw_blocks, expected_height, expected_parent) {
                            Ok(_) => {
                                let mut commits = Vec::with_capacity(verified_blocks.len());
                                for block in verified_blocks {
                                    commits.push(block.commit);
                                }
                                if let Err(e) = prepare_and_publish(
                                    batch_id,
                                    commits,
                                    &received,
                                    &assembler_state,
                                    &assembler_metrics,
                                    &assembler_registry,
                                ) {
                                    eprintln!("[VERIFY-BATCH] batch {batch_id} failed: {e}");
                                }
                            }
                            Err((_, e)) => {
                                assembler_metrics.invalid_blocks.fetch_add(1, Ordering::Relaxed);
                                eprintln!("[VERIFY-BATCH] malformed exact 16-block ancestry window: {e}");
                            }
                        }

                        reset_batch(
                            &mut received,
                            &mut dispatched,
                            &mut results,
                            &mut worker_busy,
                            &mut semantic_started,
                            &mut semantic_failed,
                        );
                        batch_id = batch_id.saturating_add(1);
                        continue;
                    }

                    // A semantic failure should never enter contextual state
                    // preparation. Once all in-flight verifier tasks are done,
                    // release the whole lifecycle window and start clean.
                    if semantic_failed && worker_busy.iter().all(|busy| !*busy) {
                        release_received(&mut received, assembler_registry.as_ref());
                        reset_batch(
                            &mut received,
                            &mut dispatched,
                            &mut results,
                            &mut worker_busy,
                            &mut semantic_started,
                            &mut semantic_failed,
                        );
                        batch_id = batch_id.saturating_add(1);
                    }
                }
            })
            .map_err(|e| anyhow!("failed to start verifier batch coordinator: {e}"))?;

        Ok(Self { tx, metrics })
    }

    /// Hand a downloaded block to the asynchronous verifier coordinator.
    /// This is intentionally blocking backpressure: a full 16-block window
    /// pauses the producer instead of dropping the block.
    pub fn submit(&self, block: RawBlock) -> Result<()> {
        self.metrics.semantic_queue.fetch_add(1, Ordering::Relaxed);
        self.tx.send(block).map_err(|_| {
            self.metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
            anyhow!("verifier batch coordinator stopped")
        })
    }
}

/// Finish the exact-16 pipeline after all semantic results are complete.
///
/// The verifier owns contextual/state-dependent validation and prepares the full
/// mutation plan. Canonical publication consumes only that prepared plan.
fn prepare_and_publish(
    batch_id: u64,
    commits: Vec<ycash_state::BlockCommit>,
    received: &BTreeMap<u64, RawBlock>,
    state: &Arc<State>,
    metrics: &Arc<SyncMetrics>,
    registry: &Arc<InFlightRegistry>,
) -> Result<()> {
    metrics.contextual_active_batches.fetch_add(1, Ordering::Relaxed);
    let prepare_started = Instant::now();
    let prepared = match state.prepare_commit_batch(&commits) {
        Ok(prepared) => prepared,
        Err(e) => {
            metrics.contextual_active_batches.fetch_sub(1, Ordering::Relaxed);
            metrics.invalid_blocks.fetch_add(1, Ordering::Relaxed);
            eprintln!("[VERIFY-BATCH] contextual validation rejected batch {batch_id}: {e}");
            for block in received.values() {
                registry.release(&block.request.hash);
            }
            return Ok(());
        }
    };
    metrics.contextual_active_batches.fetch_sub(1, Ordering::Relaxed);
    let prepare_us = prepare_started.elapsed().as_micros() as u64;
    metrics.contextual_prepare_us.store(prepare_us, Ordering::Relaxed);
    metrics.raise_semantic_height(received.keys().next_back().copied().unwrap_or(0));
    metrics.highest_contextually_verified_height.fetch_max(
        received.keys().next_back().copied().unwrap_or(0),
        Ordering::Relaxed,
    );

    if let Err(e) = state.apply_prepared_commit(prepared) {
        eprintln!("[VERIFY-BATCH] canonical publication failed for batch {batch_id}: {e}");
        for block in received.values() {
            registry.release(&block.request.hash);
        }
        return Ok(());
    }

    let timing = state.last_commit_timing();
    metrics.database_write_us.store(timing.db_write_us, Ordering::Relaxed);
    metrics.last_publication_blocks.store(VERIFICATION_BATCH_SIZE as u64, Ordering::Relaxed);
    metrics.committed_blocks.fetch_add(VERIFICATION_BATCH_SIZE as u64, Ordering::Relaxed);
    let last_height = received.keys().next_back().copied().unwrap_or(0);
    let first_height = received.keys().next().copied().unwrap_or(0);
    metrics.canonical_height.store(last_height, Ordering::Relaxed);
    metrics.commit_batches.fetch_add(1, Ordering::Relaxed);
    metrics.commit_total_us.fetch_add(timing.total_us, Ordering::Relaxed);
    metrics.last_commit_total_us.store(timing.total_us, Ordering::Relaxed);
    metrics.last_commit_unix.store(
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0),
        Ordering::Relaxed,
    );
    *metrics.last_commit_timing.lock().unwrap() = timing;

    for block in received.values() {
        registry.release(&block.request.hash);
    }
    metrics.trace_head(
        "ordered-commit",
        "COMMITTED",
        last_height,
        received.get(&last_height).map(|b| b.request.hash),
        format!(
            "published exact {}-block sequence {}..{}; commit stage performed publication only",
            VERIFICATION_BATCH_SIZE,
            first_height,
            last_height
        ),
    );
    metrics.clear_missing_parent();
    Ok(())
}

/// Default verifier width: leave one core for the ordered state engine and one
/// for the Android UI thread, and never drop below one worker.
pub fn default_verifier_workers() -> usize {
    std::thread::available_parallelism()
        .map(|n| n.get().saturating_sub(2).max(1))
        .unwrap_or(1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn verifier_partition_covers_16_positions_in_order() {
        let ranges = partition_batch(16, 4);
        assert_eq!(ranges, vec![0..4, 4..8, 8..12, 12..16]);
        let covered: Vec<usize> = ranges.into_iter().flat_map(|r| r.collect::<Vec<_>>()).collect();
        assert_eq!(covered, (0..16).collect::<Vec<_>>());
    }

    #[test]
    fn verifier_partition_handles_non_divisible_worker_counts_for_exact_window() {
        let ranges = partition_batch(16, 3);
        assert_eq!(ranges.iter().map(|r| r.len()).collect::<Vec<_>>(), vec![6, 5, 5]);
        assert_eq!(ranges.first().unwrap().start, 0);
        assert_eq!(ranges.last().unwrap().end, 16);
    }

    fn test_raw_block(height: u64, hash: u8, prev: u8) -> RawBlock {
        let mut raw = vec![0u8; 140];
        raw[4..36].copy_from_slice(&[prev; 32]);
        RawBlock {
            request: BlockRequest {
                height,
                hash: [hash; 32],
                work: [0u8; 32],
                median_time_past: 0,
            },
            raw,
            source_peer: "test".into(),
        }
    }

    #[test]
    fn normalize_batch_restores_height_order_and_checks_parent_links() {
        let input = vec![
            test_raw_block(3, 3, 2),
            test_raw_block(1, 1, 0),
            test_raw_block(2, 2, 1),
        ];
        let ordered = normalize_batch(input, 1, [0u8; 32]).unwrap();
        assert_eq!(ordered.iter().map(|b| b.request.height).collect::<Vec<_>>(), vec![1, 2, 3]);
    }

    #[test]
    fn normalize_batch_rejects_a_height_gap_and_returns_claims_for_release() {
        let input = vec![
            test_raw_block(1, 1, 0),
            test_raw_block(3, 3, 2),
        ];
        let err = normalize_batch(input, 1, [0u8; 32]).unwrap_err();
        assert_eq!(err.0.len(), 2);
    }

    #[test]
    fn normalize_batch_rejects_a_child_window_not_attached_to_the_canonical_tip() {
        let input = vec![test_raw_block(2, 2, 1), test_raw_block(3, 3, 2)];
        let err = normalize_batch(input, 1, [0u8; 32]).unwrap_err();
        assert!(err.1.to_string().contains("canonical tip + 1"));
    }

    #[test]
    fn header_prev_is_read_from_the_wire_bytes() {
        let mut raw = vec![0u8; 140];
        raw[4..36].copy_from_slice(&[9u8; 32]);
        assert_eq!(header_prev(&raw).unwrap(), [9u8; 32]);
        assert!(header_prev(&[0u8; 8]).is_err());
    }
}
