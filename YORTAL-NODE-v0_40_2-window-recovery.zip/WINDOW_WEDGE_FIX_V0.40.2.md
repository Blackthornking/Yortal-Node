# YORTAL NODE v0.40.2 — the 16-block window can no longer wedge the downloader

## Symptom

Block fetch stops dead while header sync keeps running. The dashboard shows
`BOTTLENECK: FETCH`, `NET 100%`, in-flight pinned at the cap, `0.0 blocks/s`,
`0 B/s`, no verifier activity and no commit activity. Nothing recovers it.

## Why v0.40.1 made this reachable

v0.40.1 moved `prepare_commit_batch()` / `apply_prepared_commit()` off the
verifier coordinator onto the `yortal-ordered-commit` worker. That is the right
shape, but it broke an assumption the coordinator still relied on: that by the
time it reset its window, the previous window was already published.

The coordinator anchors a new window with
`expected_height = state.tip_height() + 1`, read on the first arrival after a
reset. While a commit is outstanding, `tip_height()` still returns the
*previous* base, so the coordinator can re-open the window that is being
committed right now. Those 16 heights can never be claimed again, so the window
never reaches 16 blocks and never completes.

Three things then turn a rare race into a permanent stop:

1. The `normalize_batch` failure path cleared `received` without releasing the
   16 lifecycle claims. The lifecycle window is exactly as wide as the global
   in-flight cap (16 == 16), so leaking one window leaves the registry
   permanently full: `missing_heights()` returns nothing, no getdata is ever
   sent again, and every transport timeout is irrelevant because there is no
   free slot to re-request into.
2. A partly-filled window had no timeout at all. It waited for its 16th block
   forever while holding every slot the downloader would have needed to fetch it.
3. Only `canonical + 1` had a lifecycle watchdog (`break_stale_lifecycle`).
   `break_stale_transport_claim` was dead code, and no sweeper existed for
   non-head Verifying/Verified/Queued claims.

## Changes

`crates/node/src/verifier.rs`

- New `anchor_window()`, used by both arrival paths. It returns `None` while a
  commit is outstanding, so a window is never anchored on a stale canonical tip.
  A block that arrives in that gap has its lifecycle claim released and is
  re-requested; it is never silently dropped.
- New `commit_pending` flag, set by the coordinator *before* the hand-off and
  cleared by the commit worker only after publication has succeeded or failed.
- The `normalize_batch` failure path now releases the whole window
  (`release_received`) before resetting. This was the leak.
- New `WINDOW_STALL_TIMEOUT` (90 s, matching `REQUEST_TIMEOUT`). A window that
  holds blocks for that long without a single arrival or verifier result gives
  every claim back, resets, and lets transport re-request the heights from
  whichever peers are alive. Logged and traced as `WINDOW_STALL_RECOVERED`.

`crates/node/src/downloader.rs`

- New `InFlightRegistry::sweep_orphaned_lifecycle(age)` and
  `ORPHANED_LIFECYCLE_TIMEOUT` (300 s). Transport claims are untouched; they
  keep their owner-aware timeouts.

`crates/node/src/lib.rs`

- `watchdog_head_once()` (already on a 1 s tick) runs the sweep as a backstop,
  then rewinds the assigner. It is deliberately far slower than the verifier's
  own 90 s recovery, so it only ever fires for a claim whose owner is gone.

## Invariants unchanged

`download -> semantic verify -> exact 16 assembly -> ordered commit worker ->
atomic publication`. Still one canonical publisher, still a bounded commit queue
of one, still exactly 16 blocks per canonical publication, still strict height
ordering. Nothing here weakens a consensus check: every added path releases
claims so blocks are fetched again, never accepts a block that was not verified.

## Known remaining gap

`all_received == 16` is still the only way a window can publish, so a short run
at the chain tip (fewer than 16 blocks above the canonical tip) cannot commit
until 16 more blocks exist. `flush_partial_batch()` is wired to the legacy
`BatchAssembler`, which the streaming pipeline no longer feeds. This does not
affect initial sync; it will matter at the tip.

## Validation

No `cargo`/`rustc` in the packaging environment, so this was not compiled here.
Delimiters and the edited call graph were checked statically. Run
`cargo check -p ycash-node && cargo test -p ycash-node` before building the APK.
