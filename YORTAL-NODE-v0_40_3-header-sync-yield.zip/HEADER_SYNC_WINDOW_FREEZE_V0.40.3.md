# YORTAL NODE v0.40.3 — header sync no longer freezes block download

## Symptom

Identical to v0.40.1: block fetch stops, `BOTTLENECK: FETCH`, `NET 100%`,
`0.0 blocks/s`, `0 B/s`, nothing verifying, nothing committing — while
`Pipeline: header sync: height N` keeps climbing at ~478 headers/s.

That last line is the clue. Header sync running is not incidental to the
freeze; it *is* the freeze.

## Cause

In `peer_session()` one thread does both jobs for a peer. It owns a
`PeerDownloadSession` holding up to 16 block claims, and it can also take
`sync_owner` and call `sync_headers()` — from the `awaiting_headers` branch at
the top of the loop, or from the `inv` handler at the bottom.

`sync_headers()` blocks that thread until the header chain runs out. While it is
in there:

- its 16 block claims stay in the registry,
- its 16 local in-flight entries stay in the session,
- `expire_stale()` and `retry_canonical_parent()` never run, because both only
  run on that peer's own thread.

The lifecycle window is exactly as wide as the global in-flight cap (16 == 16),
so those claims are the entire budget. `missing_heights()` returns nothing for
every other peer, no getdata is sent by anyone, and block download is stopped
for the full duration of header sync. Nothing times out, because the only code
that would time it out is parked inside `sync_headers()`.

This is why it survived the v0.40.2 window-recovery work: the coordinator's
window was never the thing holding the claims. Transport was.

## Changes

`crates/node/src/downloader.rs`

- `PeerDownloadSession::yield_window()` — release every claim this session holds
  without marking the peer disconnected. Head claims are handed off as usual; a
  late delivery to this session is still adopted on arrival.
- `InFlightRegistry::sweep_stale_transport(age)` — break transport claims older
  than `age` regardless of owner.

`crates/ycash-android-node/src/main.rs`

- Both in-loop `sync_headers()` call sites now call `download.yield_window()`
  first, so another peer picks the window up immediately instead of waiting for
  header sync to finish.

`crates/node/src/lib.rs`

- `watchdog_head_once()` (1 s tick) now also runs `sweep_stale_transport`
  at `REQUEST_TIMEOUT` (90 s). Recovery from a parked peer thread no longer
  depends on that thread ever running again.

## Carried over from v0.40.2

- `anchor_window()` + `commit_pending`: no window is anchored on a stale
  canonical tip while the ordered commit worker is publishing.
- `normalize_batch` failure releases the window instead of leaking 16 claims.
- `WINDOW_STALL_TIMEOUT` (90 s) releases a window that stops progressing.
- `sweep_orphaned_lifecycle` (300 s) backstop.

## Validation

No `cargo`/`rustc` in the packaging environment. Delimiters and the edited call
graph were checked statically. Run `cargo check -p ycash-node -p ycash-android-node`
before building the APK.
