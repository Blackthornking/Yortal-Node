# YORTAL NODE v0.40.4 — block download is no longer single-peer

## What the dashboard showed

`HDR 59840 · DL 1840 · SEM 1825 · CTX 1824 · COM 1824`, in-flight 16, validation
queue 0, prospective 0, nothing verifying, nothing committing.

DL − COM = 16, so the whole budget was claimed for heights 1825..1840. SEM 1825
says exactly one of those sixteen arrived and was verified. The other fifteen
never came, and nothing else could be requested because those fifteen claims are
the entire budget.

## Cause

v0.36.9 set every stage to 16 and `SyncConfig::from_env()` forced
`blocks_in_transit_per_peer = PIPELINE_BATCH_SIZE`, so the per-peer transport
limit equals the global in-flight cap. One peer therefore takes all 16 claims on
its first pass, and block download is single-peer by construction no matter how
many peers are connected. Whatever that peer does — go quiet, stall mid-frame,
serve one block out of sixteen — the node does with it, until timeouts fire.

`expire_stale()` (90 s) and `retry_canonical_parent()` (8 s) only run on that
peer's own thread, and `read_message()` gave a started frame 180 s to finish, so
a peer that stopped mid-message parked the thread holding all sixteen claims for
up to three minutes with no timeout running at all.

## Changes

- `PEER_TRANSPORT_SHARE = PIPELINE_BATCH_SIZE / 4` (4). Default per-peer
  transport limit, no longer forced up to the global cap in `from_env()`
  (`YORTAL_BLOCKS_IN_TRANSIT_PER_PEER` still overrides). The global bound, the
  exact-16 commit window and the ordering invariants are unchanged: the same 16
  heights are now fetched from up to four peers, so one silent peer costs four
  slots instead of sixteen.
- `STALE_TRANSPORT_SWEEP = 30 s`, used by the 1 s watchdog tick instead of the
  90 s owner-side timeout. `REQUEST_TIMEOUT` is unchanged for the peer's own
  `expire_stale()`.
- `read_message()` mid-frame timeout 180 s -> 45 s. Still far more than a 2 MiB
  frame needs on mobile data.

## New on-device diagnostics (no logcat needed)

When the bottleneck is `FETCH` and the oldest claim is over 15 s old, the
Pipeline error line now reads:

```
Fetch stalled · 16 claim(s) held (15 transport / 1 lifecycle) · oldest 47s in transport from 52.41.64.197:8833 · next height 1825
```

That names the state the budget is stuck in and which peer is holding it. If it
freezes again, that line is the thing to send.

## Carried over

v0.40.2: `anchor_window` + `commit_pending`, the `normalize_batch` claim leak
fix, `WINDOW_STALL_TIMEOUT` (90 s), `sweep_orphaned_lifecycle` (300 s).
v0.40.3: `yield_window()` before header sync, global `sweep_stale_transport`.

## Validation

No `cargo`/`rustc` here. Run `cargo check -p ycash-node -p ycash-android-node`
before building the APK.
