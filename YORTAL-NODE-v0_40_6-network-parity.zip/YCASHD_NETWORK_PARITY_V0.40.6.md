# YORTAL NODE v0.40.6 — remaining ycashd network-behaviour gaps

A second pass over ycash-4.5.0, this time asking only "what does the Ycash
network expect from a peer that YORTAL does not do".

## Checked and correct — no change needed

- Mainnet magic `24 e9 27 64`, default port 8833. Match.
- `PROTOCOL_VERSION = 270013`. YORTAL sends the same, and rejects peers below
  it. ycashd's own rule is the current epoch's `nProtocolVersion`, which on
  mainnet is CANOPY = 270013, so the gate is exactly right.
- Mainnet activation heights: Overwinter 347500, Sapling 419200, Ycash 570000,
  Blossom 1100000, Heartwood 1100003, Canopy 1100006. All match
  `crates/consensus/src/lib.rs`. (The 207500/280000/510248/661610 figures in
  chainparams.cpp are the **testnet** block — worth knowing, they look like
  plausible mainnet values and are not.)
- Branch IDs through Canopy, `MAX_HEADERS_RESULTS = 160`, Equihash 200,9 ->
  192,7 at the Ycash upgrade, YDF mandate end 2275000. All match.

## Fixed here

### 1. The pong deadline was killing the peers that were working

`net.h`: `PING_INTERVAL = 2 * 60`, `TIMEOUT_INTERVAL = 20 * 60`. YORTAL pinged
every 120 s (correct) but dropped the session if no pong arrived within **30
seconds**.

That is not survivable on this protocol. `ProcessMessages()` returns early while
`vRecvGetData` is non-empty, so a peer part-way through serving our block
requests will not answer a ping *at all* until the queue drains. The 30 s
deadline therefore disconnects precisely the peers that are busy delivering
blocks to us, and does it while they hold part of the 16-claim budget.

Now `PONG_TIMEOUT = 20 * 60`, matching `TIMEOUT_INTERVAL`.

### 2. We advertised NODE_NETWORK without serving anything

The version message claimed `NODE_NETWORK` on both the outbound and the inbound
path, but the inbound handler answers only `version`, `verack`, `ping` and
`addr`. It serves no `getheaders` and no `getdata`.

ycashd gates its own block requests on the remote's NODE_NETWORK bit
(`pto->fClient`), so advertising it invites every inbound peer to request blocks
from us, receive silence, and drop us as a stalling peer — and gets our address
relayed around the network as a full node. `LOCAL_SERVICES = 0` until inbound
`getdata`/`getheaders` are actually implemented.

## Still missing, not done here

- **Serving blocks and headers.** Needed to be a real network participant, not
  to sync. Once implemented, set `LOCAL_SERVICES` back to NODE_NETWORK.
- **`sendheaders` (BIP 130).** ycashd supports it; without it new blocks are
  announced by `inv`, which YORTAL already handles. Optional.
- **Transaction relay.** YORTAL ignores `tx` and tx `inv` entirely. Fine for a
  sync-only node; required for mempool/wallet use.

## Validation

No `cargo`/`rustc` here. Run `cargo check -p ycash-node -p ycash-android-node`
before building the APK.
