# YORTAL NODE v0.40.5 — what ycashd 4.5.0 does that YORTAL does not

Read against `src/main.cpp` / `src/net.cpp` of ycash-4.5.0, looking only for
things that bear on the block-fetch freeze.

## 1. ycashd serves ONE block per `getdata` pass, and stops talking meanwhile

`ProcessGetData()` ends its loop with:

```cpp
if (inv.type == MSG_BLOCK || inv.type == MSG_FILTERED_BLOCK)
    break;
```

and `ProcessMessages()` begins with:

```cpp
if (!pfrom->vRecvGetData.empty())
    ProcessGetData(pfrom, ...);
// this maintains the order of responses
if (!pfrom->vRecvGetData.empty()) return fOk;
```

So one block is sent per message-handler pass, and **while any getdata item is
still queued the peer will not process a single further message from us** — not
ping, not getheaders, not a new getdata. It also breaks out entirely while its
send buffer to us is at `SendBufferSize()` (1 MB by default).

Consequences for YORTAL:

- A 16-hash getdata to one peer buys no delivery parallelism at all. It
  serialises through that peer's handler loop.
- For the whole time that queue is draining, that peer looks dead to every other
  part of our code. This is what `Handshake: WAITING_FOR_PEER · 24498 ms` is.
- Splitting the window across peers is the only way to get concurrent delivery.
  v0.40.4's per-peer share of 4 is the right shape; this is the reference
  behaviour that makes it necessary rather than merely safer.

## 2. ycashd's download window is 1024, not 16

`main.h`: `MAX_BLOCKS_IN_TRANSIT_PER_PEER = 16`, `BLOCK_DOWNLOAD_WINDOW = 1024`.
`FindNextBlocksToDownload()` fetches at most 16 per peer inside a 1024-wide
window anchored at the last common block.

YORTAL pins per-peer window, global in-flight cap, prospective capacity and
commit batch all to 16. One peer's in-flight set is therefore the entire
pipeline, which is why any single peer hiccup is a full stop rather than a
slowdown. Widening the fetch window properly needs the verifier coordinator to
buffer heights above the current 16-block window (it currently releases and
drops them), so it is not done here — but it is the structural fix.

## 3. ycashd disconnects stalling peers; YORTAL only moves the claim

`BLOCK_STALLING_TIMEOUT = 2` seconds: if the download window cannot move because
one peer is the only one holding something we need, that peer is disconnected.
Separately, `GetBlockTimeout()` disconnects on a per-block timeout.

YORTAL reassigns the claim and keeps the peer. Given finding 1, that peer is
still working through our old getdata queue and is unresponsive to everything
else, so keeping it connected is worse than dropping it.

## 4. ycashd never requests blocks from a peer without NODE_NETWORK

`SendMessages()`: `if (!pto->fDisconnect && !pto->fClient && ... )`, where
`fClient = !(nServices & NODE_NETWORK)`. `FindNextBlocksToDownload()` also
returns immediately when the peer's best known chain is not ahead of ours
("This peer has nothing interesting").

YORTAL parses the peer's `version` for its start height (dashboard only) and
**never looks at `nServices` at all**. Any peer that completes a handshake can be
handed a quarter — previously all — of the block budget, including peers that
will never answer a block getdata.

## Changes in this build

- `parse_version_services()`; the peer's service bits are kept for the session.
  The block-download branch now runs only for peers advertising NODE_NETWORK
  whose advertised height is above our tip. Non-serving peers still do headers,
  addr and ping, and never take a lifecycle claim.
- `PEER_BLOCK_STALL_DISCONNECT = 20 s`. `PeerDownloadSession` tracks
  `last_progress` (a request issued or a block delivered). `drive_peer()` now
  yields the window and ends the session when a peer holds requests and delivers
  nothing for that long — ycashd's stalling disconnect, with a much more
  forgiving timeout.

## Carried over

v0.40.2 window recovery and claim-leak fix, v0.40.3 `yield_window()` before
header sync plus the global transport sweep, v0.40.4 per-peer share of 4,
30 s stale-transport sweep, 45 s mid-frame read timeout, and the on-device
"Fetch stalled · N claim(s) held ..." diagnostic line.

## Validation

No `cargo`/`rustc` here. Run `cargo check -p ycash-node -p ycash-android-node`
before building the APK.
