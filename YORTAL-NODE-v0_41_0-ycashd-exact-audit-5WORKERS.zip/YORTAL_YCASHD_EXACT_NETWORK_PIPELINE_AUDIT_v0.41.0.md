# YORTAL v0.41.0 — ycashd network/pipeline alignment audit

## Reference
Audited against the Ycash `ycashd` code lineage and the Zcash P2P protocol that ycashd inherits. Ycash identifies `ycashd` as its node implementation and its repository is a fork of Zcash.

## Wire/network limits
- `MAX_HEADERS_RESULTS = 160`
- `MAX_GETDATA_SZ = 1000`
- `MAX_INV_SZ = 50000`
- P2P message maximum = 2 MiB in this implementation
- `MAX_BLOCKS_IN_TRANSIT_PER_PEER = 16`
- `BLOCK_DOWNLOAD_WINDOW = 1024`
- block stalling/reassignment target = 2 seconds

## Pipeline alignment
The previous YORTAL implementation was **not** actually ycashd-like end-to-end: it imposed a global 16-block lifecycle and a four-worker semantic verifier with a 16-block atomic publication batch. That is a YORTAL-specific pipeline, not ycashd.

This build changes the active sync pipeline to the ycashd model: transport can have a 1024-block moving download window while each peer is capped at 16 outstanding blocks; consensus/state application is sequential at one block at a time; verifier width is 1; and the state publication path no longer requires an exact 16-block batch.

The 16-block value therefore exists only where ycashd uses it: **per peer transport**, not as a global consensus/pipeline window.

## DoS / peer behavior audit
The source was checked for message-size and inventory bounds, duplicate VERSION handling, minimum protocol version handling, address limits, header-count limits, and invalid-header/block peer penalties.

## Important limitation
This is a source-level alignment build. The execution environment has no Cargo/Rust toolchain, so a native `cargo check`/`cargo test` could not be run here. The Ycash upstream source was independently checked through public source/protocol documentation; where the exact historical ycashd implementation is inherited from Zcash, the inherited protocol rules are treated as authoritative.
