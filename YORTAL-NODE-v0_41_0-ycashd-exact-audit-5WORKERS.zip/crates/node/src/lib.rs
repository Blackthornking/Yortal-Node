//! YORTAL synchronisation engine.
//!
//! ```text
//!   peers (n)             16-block window             async verifier frontier   ordered gate     writer
//!   ┌──────────────┐      ┌──────────────────┐       ┌─────────────────┐      ┌──────────┐   ┌───────┐
//!   │ block stream │ ───► │ bounded claims   │ ─────►│ contiguous h+1  │ ───► │ absorb   │──►│ one   │
//!   │ per-peer     │      │ / bounded 16     │       │ prefix, max 16  │      │ ordered  │   │ Write │
//!   └──────────────┘      └──────────────────┘       └───────┬─────────┘      └──────────┘   └───────┘
//!                                                           │ results by original position
//!                                                           └──────────────► reassemble
//! ```
//!
//! Network delivery and semantic verification are asynchronous. Verification
//! does not wait for a larger resource window: as soon as
//! canonical+1 exists, the coordinator can verify a contiguous prefix of up to
//! 16 blocks. A missing parent still blocks only the verification frontier; no
//! higher block can bypass it into canonical state.

use std::sync::atomic::Ordering;
use std::sync::Arc;

use anyhow::{bail, Result};
use ycash_chain::genesis_hash_internal;
use ycash_crypto::{validate_chain_links, ChainLink};
use ycash_state::state_service::{StateService, StateServiceHandle, SyncMetrics};
use ycash_state::State;

pub mod batch;
pub mod downloader;
pub mod peer_manager;
pub mod verifier;

pub use downloader::{
    BlockAssigner, BlockRequest, HeadLifecycleTracker, HeadPhase, HeadSnapshot, HeadStatus, InFlightRegistry, PeerDownloadSession, MAX_BLOCKS_IN_FLIGHT,
    MAX_BLOCKS_IN_TRANSIT_PER_PEER, REQUEST_TIMEOUT, CANONICAL_PARENT_RETRY_TIMEOUT,
};
pub use peer_manager::{PeerManager, PeerStats};
pub use verifier::{RawBlock, VerifierPool, ASSUME_VALID_HASH_DISPLAY, ASSUME_VALID_HEIGHT};

/// Semantic verification threads: one per batch slice.
pub const VERIFIER_WORKERS: usize = 1;

/// Maximum blocks in the single live verification window. The coordinator
/// serialises batches, so there is never a second verification batch in flight.
pub const PIPELINE_BATCH_SIZE: usize = 1;

/// Ycashd block download window: blocks may be requested up to 1024 heights
/// ahead of the validated/canonical tip. This is transport policy, not consensus.
pub const BLOCK_DOWNLOAD_WINDOW: usize = 1024;

/// Maximum number of blocks a single peer may have in flight, matching ycashd.
pub const YCAHSD_BLOCKS_IN_TRANSIT_PER_PEER: usize = 16;

/// Transparent script threads.
///
/// Script checks are captured by the ordered state-preparation walk and executed
/// asynchronously on the persistent shared pool. This keeps UTXO/Sprout/Sapling
/// mutation ordered while overlapping pure script work with later state work in
/// the same exact 16-block lifecycle window.
pub const SCRIPT_WORKERS: usize = 2;

/// Cores held for roles that must never wait: canonical publication and
/// header/peer I/O.
pub const RESERVED_CORES: usize = 2;

/// Transport and resource settings. None of these is a consensus parameter:
/// the same chain synchronised with any combination of them must produce the
/// same canonical state.
#[derive(Clone, Debug)]
pub struct SyncConfig {
    pub blocks_in_transit_per_peer: usize,
    pub max_blocks_in_flight: usize,
    pub prospective_capacity: usize,
    pub verifier_workers: usize,
    /// Transparent script verification threads.
    pub script_workers: usize,
    pub verifier_queue: usize,
    pub assume_valid: bool,
}

impl SyncConfig {
    /// How far above the canonical tip blocks may be requested.
    ///
    /// Held a margin below the candidate capacity so a full pipeline never
    /// evicts. The margin is one round of per-peer requests, which is the most
    /// that can land between two assignment passes.
    pub fn download_window(&self) -> usize {
        // One bounded global pipeline. Per-peer limits only divide the window;
        // they never multiply it.
        self.max_blocks_in_flight.min(self.prospective_capacity).max(1)
    }
}

impl Default for SyncConfig {
    fn default() -> Self {
        Self {
            blocks_in_transit_per_peer: YCAHSD_BLOCKS_IN_TRANSIT_PER_PEER,
            max_blocks_in_flight: BLOCK_DOWNLOAD_WINDOW,
            prospective_capacity: BLOCK_DOWNLOAD_WINDOW,
            // Default fixed roles: five permanent worker stations, all
            // persistent for the process lifetime (never spawned/torn down
            // per block). In order along the pipeline: one semantic verifier
            // lane, one canonical committer, one Android/header housekeeping
            // slot (the two RESERVED_CORES), and two transparent-script
            // workers on the persistent Rayon pool running concurrently
            // during contextual preparation.
            verifier_workers: VERIFIER_WORKERS,
            script_workers: SCRIPT_WORKERS,
            verifier_queue: BLOCK_DOWNLOAD_WINDOW,
            assume_valid: false,
        }
    }
}

impl SyncConfig {
    /// Read the transport settings from the environment, so they can be changed
    /// on a device without rebuilding. Consensus cannot be changed this way.
    pub fn from_env() -> Self {
        let mut cfg = Self::default();
        if let Some(v) = env_usize("YORTAL_BLOCKS_IN_TRANSIT_PER_PEER") {
            cfg.blocks_in_transit_per_peer = v.clamp(1, YCAHSD_BLOCKS_IN_TRANSIT_PER_PEER);
        }
        if let Some(v) = env_usize("YORTAL_MAX_BLOCKS_IN_FLIGHT") {
            cfg.max_blocks_in_flight = v.clamp(1, BLOCK_DOWNLOAD_WINDOW);
        }
        if let Some(v) = env_usize("YORTAL_PROSPECTIVE_BLOCKS") {
            cfg.prospective_capacity = v.clamp(1, BLOCK_DOWNLOAD_WINDOW);
        }
        cfg.max_blocks_in_flight = cfg.max_blocks_in_flight.min(BLOCK_DOWNLOAD_WINDOW);
        cfg.prospective_capacity = cfg.prospective_capacity.min(BLOCK_DOWNLOAD_WINDOW);
        cfg.verifier_queue = BLOCK_DOWNLOAD_WINDOW;
        cfg.verifier_workers = VERIFIER_WORKERS;
        cfg.script_workers = SCRIPT_WORKERS;
        cfg.assume_valid = std::env::var("YCASH_ASSUME_VALID").ok().as_deref() == Some("1")
            && std::env::var("YCASH_FULL_VERIFY").ok().as_deref() != Some("1");
        cfg
    }
}

fn env_usize(name: &str) -> Option<usize> {
    std::env::var(name).ok().and_then(|v| v.trim().parse::<usize>().ok())
}

/// Everything the peer threads need, started once per process.
#[derive(Clone)]
pub struct SyncEngine {
    pub state: Arc<State>,
    /// Legacy height buffer retained for diagnostics/tests. Live arrivals are
    /// submitted directly to the asynchronous verifier coordinator.
    pub assembler: Arc<batch::BatchAssembler>,
    pub peers: Arc<PeerManager>,
    pub registry: Arc<InFlightRegistry>,
    pub assigner: Arc<BlockAssigner>,
    pub verifiers: VerifierPool,
    pub gate: StateServiceHandle,
    pub metrics: Arc<SyncMetrics>,
    pub config: SyncConfig,
}

impl SyncEngine {
    /// The height the ordered gate needs next. Everything is anchored to this
    /// height: the resource window, download requests and verifier frontier.
    pub fn next_height(&self) -> u64 {
        self.state.tip_height().ok().flatten().unwrap_or(0) + 1
    }

    /// Heights in the bounded download window that are not already claimed.
    ///
    /// Verification is intentionally asynchronous now: a block can move from
    /// transport directly into the verifier coordinator without being copied
    /// into a second "16 must be full" assembler. Lifecycle claims are the
    /// source of truth for whether a height is already in transit, waiting in
    /// verification, or held by the state gate.
    pub fn missing_heights(&self) -> Vec<u64> {
        let header_tip = self.header_tip();
        let start = self.next_height();
        let end = header_tip.min(start.saturating_add(self.config.download_window().saturating_sub(1) as u64));
        if start > end {
            return Vec::new();
        }

        (start..=end)
            .filter_map(|height| match self.assigner.request_at_height(height) {
                Ok(Some(request)) if !self.registry.is_claimed(&request.hash) => Some(height),
                _ => None,
            })
            .collect()
    }

    /// Highest validated header, read from the database rather than from a
    /// counter someone remembered to update.
    ///
    /// The dashboard reported HDR 0 while the chain was at 192 because the
    /// header height was only ever written by the header-sync routine; if that
    /// returned early, the figure stayed stale. Reading state makes it true by
    /// construction.
    pub fn header_tip(&self) -> u64 {
        let tip = self.state.header_height().ok().flatten().unwrap_or(0);
        self.metrics.raise_header_height(tip);
        tip
    }

    /// Whether block download is waiting on the header chain rather than on a
    /// peer. These need opposite responses, so they must not look alike: one
    /// wants another peer asked, the other wants header sync resumed.
    pub fn awaiting_headers(&self) -> bool {
        self.header_tip() < self.next_height()
    }

    /// Start the ordered state gate, the canonical writer and the verifier
    /// pool. Fails if a canonical writer already exists.
    pub fn start(state: Arc<State>, config: SyncConfig) -> Result<Self> {
        let assembler = Arc::new(batch::BatchAssembler::new(batch::BATCH_BLOCKS));
        // Size the script pool with the verifiers rather than letting each
        // assume it owns the device.
        ycash_state::chainstate::set_script_worker_budget(config.script_workers);
        let metrics = SyncMetrics::new();
        // One lifecycle registry spans transport, semantic verification and
        // ordered publication. The state gate releases entries only after a
        // successful canonical write or an explicit discard.
        let registry = Arc::new(InFlightRegistry::new(config.max_blocks_in_flight));
        let lifecycle: ycash_state::state_service::CandidateLifecycleHook = {
            let registry = Arc::clone(&registry);
            Arc::new(move |event: ycash_state::state_service::CandidateLifecycleEvent, hashes: Vec<[u8; 32]>| {
                match event {
                    ycash_state::state_service::CandidateLifecycleEvent::Committed
                    | ycash_state::state_service::CandidateLifecycleEvent::Discarded => registry.release_many(&hashes),
                }
            })
        };
        let gate = StateService::spawn_with_lifecycle_hook(
            Arc::clone(&state),
            config.prospective_capacity,
            Arc::clone(&metrics),
            Some(lifecycle),
        )?;
        let verifiers = VerifierPool::spawn(
            config.verifier_workers,
            config.verifier_queue,
            Arc::clone(&state),
            Arc::clone(&metrics),
            Arc::clone(&registry),
            config.assume_valid,
        )?;
        let assigner = Arc::new(BlockAssigner::new(
            Arc::clone(&state),
            Arc::clone(&registry),
            Arc::clone(&metrics),
            // Strictly *less* than the candidate set can hold.
            //
            // Every claimed block is either in transit or buffered, and every
            // claim lies inside this window, so buffered <= window. Keeping the
            // window below capacity therefore means eviction never happens at
            // all. Setting the two equal — which is what this was — guarantees
            // the opposite: the buffer sits permanently at capacity, every
            // arrival evicts a block, the eviction frees that block's claim,
            // and it is immediately re-requested. The chain still advances, in
            // bursts, while a large share of the bandwidth goes on re-fetching
            // blocks that were thrown away.
            config.download_window(),
        ));
        assigner.rewind_to_canonical()?;
        let peers = Arc::new(PeerManager::new());
        if let Ok(Some(tip)) = state.tip_height() {
            metrics
                .canonical_height
                .store(tip, std::sync::atomic::Ordering::Relaxed);
        }
        Ok(Self { assembler, state, peers, registry, assigner, verifiers, gate, metrics, config })
    }

    /// Per-peer request window.
    pub fn session(&self, peer: &str) -> PeerDownloadSession {
        PeerDownloadSession::new(
            peer,
            Arc::clone(&self.assigner),
            Arc::clone(&self.registry),
            Arc::clone(&self.peers),
            Arc::clone(&self.metrics),
        )
        .with_limit(self.config.blocks_in_transit_per_peer)
    }

    /// Run the transport-level canonical-head watchdog independently of peer
    /// socket loops. This matters on Android because a peer thread can be
    /// blocked in a socket read while the exact tip+1 request is stalled.
    /// Releasing/nominating the claim here does not touch consensus state; the
    /// next responsive peer will pick the head up on its normal request pass.
    pub fn watchdog_head_once(&self) -> Result<bool> {
        let canonical = self.assigner.canonical_height()?;
        let next_height = canonical.saturating_add(1);
        let Some(hash) = self.assigner.header_hash(next_height)? else { return Ok(false) };
        self.registry.set_head_target(next_height, hash);
        match self.registry.head_status(&hash) {
            HeadStatus::Free => {
                // The watchdog is also able to recover a completely unclaimed
                // head. It reserves the hash for a healthy connected peer; the
                // peer's normal assignment pass performs the actual getdata.
                let Some(peer) = self.peers.best_peer() else { return Ok(false) };
                let alternates = self.peers.peer_count() > 1;
                if !self.registry.reserve_head(hash, &peer, alternates) { return Ok(false); }
                self.metrics.set_missing_parent_in_flight(false);
                self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
                self.metrics.mark_parent_retry();
                self.metrics.trace_head(peer, "WATCHDOG_RESERVE", next_height, Some(hash), "head was free; watchdog nominated a peer for recovery");
                let _ = self.assigner.rewind_to_canonical();
                Ok(true)
            }
            HeadStatus::Reserved { .. } => {
                // A peer is already nominated and has not yet issued getdata.
                // The hand-off window is short; if it lapses the head reads as
                // Free again and the next watchdog tick nominates a peer.
                Ok(false)
            }
            HeadStatus::Transport { owner, age } => {
                let timeout = self.registry.head_retry_timeout(&hash, CANONICAL_PARENT_RETRY_TIMEOUT);
                if age < timeout { return Ok(false); }
                let alternate = self.peers.best_alternate(&owner);
                if !self.registry.reassign_head(&hash, &owner, alternate.clone()) { return Ok(false); }
                self.peers.update(&owner, |s| s.timeouts = s.timeouts.saturating_add(1));
                self.metrics.set_missing_parent_in_flight(false);
                self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                self.metrics.expired_requests.fetch_add(1, Ordering::Relaxed);
                self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
                self.metrics.mark_parent_retry();
                self.metrics.trace_head(owner.clone(), "WATCHDOG_REASSIGN", next_height, Some(hash), format!("head request exceeded {}s outside peer loop; next_peer={}", timeout.as_secs(), alternate.as_deref().unwrap_or("none")));
                let _ = self.assigner.rewind_to_canonical();
                Ok(true)
            }
            HeadStatus::Lifecycle { age } => {
                if age < downloader::HEAD_LIFECYCLE_TIMEOUT { return Ok(false); }
                if !self.registry.break_stale_lifecycle(&hash, downloader::HEAD_LIFECYCLE_TIMEOUT) { return Ok(false); }
                let Some(peer) = self.peers.best_peer() else { return Ok(true) };
                let alternates = self.peers.peer_count() > 1;
                let _ = self.registry.reserve_head(hash, &peer, alternates);
                self.metrics.set_missing_parent_in_flight(false);
                self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
                self.metrics.mark_parent_retry();
                self.metrics.trace_head(peer, "WATCHDOG_LIFECYCLE_RECOVERY", next_height, Some(hash), format!("head lifecycle stalled for {}s; lifecycle claim reset", age.as_secs()));
                let _ = self.assigner.rewind_to_canonical();
                Ok(true)
            }
        }
    }

    /// Handle one `block` message: match it to an outstanding request, free the
    /// slot and queue it for semantic verification.
    ///
    /// A block nobody asked for is ignored rather than trusted, and an unknown
    /// hash is never counted against the peer's window.
    pub fn on_block_message(&self, session: &mut PeerDownloadSession, raw: Vec<u8>) -> Result<bool> {
        let Some(hash) = block_hash(&raw) else { return Ok(false) };
        let bytes = raw.len();
        let Some(request) = session.on_block(&hash, bytes) else { return Ok(false) };
        let source_peer = session.peer().to_string();
        let block = RawBlock { request: request.clone(), raw, source_peer };

        // Never verify synchronously on the peer/socket thread. The verifier
        // coordinator owns the ordered-parent barrier and will only dispatch a
        // contiguous prefix beginning at canonical+1. A child received before
        // its parent therefore stays buffered, but the network remains free to
        // service the parent request and other peers.
        // Backpressure is deliberate: a full verifier window must stop the
        // producer, never discard a block. In particular the canonical head
        // must never be released merely because verifier ingress is full.
        if let Err(e) = self.verifiers.submit(block) {
            // Only a stopped verifier is a terminal transport error.
            // The normal Full condition is impossible here because submit()
            // blocks until the bounded coordinator accepts the block.
            self.registry.release(&request.hash);
            return Err(e);
        }
        Ok(true)
    }

    /// Verify one assembled batch and hand it to the ordered gate in order.
    ///
    /// Split across the verifiers as contiguous slices, each verified in height
    /// order, then concatenated back in index order. Splitting cannot change
    /// the outcome: a block's semantic checks are a pure function of that
    /// block, so which verifier runs them is invisible to the result.
    pub fn commit_batch(&self, blocks: Vec<RawBlock>) -> Result<()> {
        let first = blocks.first().map(|b| b.request.height).unwrap_or(0);
        let last = blocks.last().map(|b| b.request.height).unwrap_or(0);
        if blocks.len() != PIPELINE_BATCH_SIZE {
            for block in &blocks {
                self.registry.release(&block.request.hash);
            }
            bail!("sync commit requires exactly {} contiguous blocks, got {}", PIPELINE_BATCH_SIZE, blocks.len());
        }

        // Defense in depth: the assembler is already anchored to next_height,
        // but commit_batch is also callable directly. Make ancestry an explicit
        // precondition of entering Groth16 verification so a child can never be
        // verified as part of a detached window. Read the canonical height
        // directly here so a state-DB error fails closed instead of silently
        // falling back to height 0.
        let batch_hashes: Vec<[u8; 32]> = blocks.iter().map(|b| b.request.hash).collect();
        let canonical_height = match self.state.tip_height() {
            Ok(height) => height,
            Err(e) => {
                for hash in &batch_hashes {
                    self.registry.release(hash);
                }
                return Err(e);
            }
        };
        let expected_height = match canonical_height.unwrap_or(0).checked_add(1) {
            Some(height) => height,
            None => {
                for hash in &batch_hashes {
                    self.registry.release(hash);
                }
                bail!("canonical height overflow");
            }
        };
        let tip_hash = match self.state.tip_hash() {
            Ok(hash) => hash,
            Err(e) => {
                for hash in &batch_hashes {
                    self.registry.release(hash);
                }
                return Err(e);
            }
        };
        let expected_parent = match (canonical_height, tip_hash) {
            (None, None) => genesis_hash_internal(),
            (Some(_), Some(hash)) if hash.len() == 32 => {
                let mut out = [0u8; 32];
                out.copy_from_slice(&hash);
                out
            }
            (Some(_), Some(_)) => {
                for hash in &batch_hashes {
                    self.registry.release(hash);
                }
                bail!("canonical tip hash is not 32 bytes");
            }
            _ => {
                for hash in &batch_hashes {
                    self.registry.release(hash);
                }
                bail!("canonical tip height/hash state is inconsistent");
            }
        };
        let mut links = Vec::with_capacity(blocks.len());
        for block in &blocks {
            let prev = match self::verifier::header_prev(&block.raw) {
                Ok(prev) => prev,
                Err(e) => {
                    for hash in &batch_hashes {
                        self.registry.release(hash);
                    }
                    return Err(e);
                }
            };
            links.push(ChainLink {
                height: block.request.height,
                hash: block.request.hash,
                prev_hash: prev,
            });
        }
        if let Err(e) = validate_chain_links(expected_height, expected_parent, &links) {
            for block in &blocks {
                self.registry.release(&block.request.hash);
            }
            bail!("refusing to verify detached/incomplete ancestry batch: {e:?}");
        }

        let verified = batch::verify_batch_in_order(blocks, self.config.verifier_workers, self.config.assume_valid);

        if let Some((height, reason)) = &verified.rejected {
            // The batch is contiguous, so nothing above a rejection is usable.
            // Release the whole window and let it be fetched again; a bad block
            // from one peer must not wedge the chain.
            self.metrics.invalid_blocks.fetch_add(1, Ordering::Relaxed);
            eprintln!("[BATCH] {first}..{last} rejected at height {height}: {reason}");
            for hash in &batch_hashes {
                self.registry.release(hash);
            }
            for hash in self.assembler.clear() {
                self.registry.release(&hash);
            }
        }

        for block in verified.blocks {
            self.metrics.raise_semantic_height(block.height);
            self.gate.offer(block)?;
        }
        Ok(())
    }

    /// Release a short run at the chain tip, where a full batch will never
    /// arrive because no further blocks exist yet.
    pub fn flush_partial_batch(&self) -> Result<bool> {
        let next_height = self.next_height();
        let Some(batch) = self.assembler.flush_partial(next_height) else { return Ok(false) };
        self.commit_batch(batch)?;
        Ok(true)
    }

    /// Hashes to put in the next `getdata`, refilling the peer's window.
    pub fn next_requests(&self, session: &mut PeerDownloadSession) -> Result<Vec<[u8; 32]>> {
        // The canonical parent is special: later blocks cannot be committed
        // around it, so do not make tip+1 wait for the normal 90s transport
        // timeout. A short head retry lets another peer take over quickly.
        session.retry_canonical_parent(CANONICAL_PARENT_RETRY_TIMEOUT)?;
        session.expire_stale(REQUEST_TIMEOUT);

        // Ask for exactly what the current batch is missing, lowest height
        // first. The head is therefore always the first request issued, and no
        // speculative work can occupy the window ahead of it.
        // Headers first: without them there is nothing to request, and the
        // node should say so instead of reporting a missing parent.
        if self.awaiting_headers() {
            self.metrics.set_missing_parent_in_flight(false);
            return Ok(Vec::new());
        }

        let missing = self.missing_heights();
        if missing.is_empty() {
            // The window is complete and waiting on verification or commit;
            // at the chain tip, release whatever short run exists rather than
            // waiting for 16 blocks that do not exist yet.
            self.flush_partial_batch()?;
            return Ok(Vec::new());
        }
        session.top_up_heights(&missing)
    }

    /// Record an exact canonical-head transport event for diagnostics.
    pub fn trace_head(&self, peer: impl Into<String>, event: impl Into<String>, height: u64, hash: Option<[u8; 32]>, detail: impl Into<String>) {
        self.metrics.trace_head(peer, event, height, hash, detail);
    }

    /// Nudge the ordered gate, e.g. after the header chain advanced.
    pub fn poke(&self) {
        self.gate.poke();
    }
}

/// Block hash: double SHA-256 over the header including its Equihash solution.
pub fn block_hash(raw: &[u8]) -> Option<[u8; 32]> {
    use sha2::{Digest, Sha256};
    let mut cursor = 140usize;
    let solution_len = read_compact_size(raw, &mut cursor)? as usize;
    let end = cursor.checked_add(solution_len)?;
    let header = raw.get(..end)?;
    let digest = Sha256::digest(Sha256::digest(header));
    let mut out = [0u8; 32];
    out.copy_from_slice(&digest);
    Some(out)
}

fn read_compact_size(raw: &[u8], cursor: &mut usize) -> Option<u64> {
    let first = *raw.get(*cursor)?;
    *cursor += 1;
    let value = match first {
        0xfd => {
            let v = u16::from_le_bytes(raw.get(*cursor..*cursor + 2)?.try_into().ok()?) as u64;
            *cursor += 2;
            v
        }
        0xfe => {
            let v = u32::from_le_bytes(raw.get(*cursor..*cursor + 4)?.try_into().ok()?) as u64;
            *cursor += 4;
            v
        }
        0xff => {
            let v = u64::from_le_bytes(raw.get(*cursor..*cursor + 8)?.try_into().ok()?);
            *cursor += 8;
            v
        }
        n => n as u64,
    };
    Some(value)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transport_settings_stay_inside_their_bounds() {
        let cfg = SyncConfig::default();
        assert_eq!(cfg.blocks_in_transit_per_peer, YCAHSD_BLOCKS_IN_TRANSIT_PER_PEER);
        assert_eq!(cfg.max_blocks_in_flight, BLOCK_DOWNLOAD_WINDOW);
        assert_eq!(cfg.prospective_capacity, BLOCK_DOWNLOAD_WINDOW);
        assert_eq!(cfg.download_window(), BLOCK_DOWNLOAD_WINDOW);
        assert_eq!(cfg.verifier_queue, BLOCK_DOWNLOAD_WINDOW);
        assert_eq!(cfg.verifier_workers, VERIFIER_WORKERS);
        assert_eq!(cfg.script_workers, SCRIPT_WORKERS);
        // Five permanent worker stations in a line: one verify lane, one
        // commit lane and one housekeeping lane (the two RESERVED_CORES),
        // plus two persistent script workers. Every station is fixed for
        // the life of the process; none is spawned per block.
        assert_eq!(VERIFIER_WORKERS + RESERVED_CORES + SCRIPT_WORKERS, 5);
        assert!(SCRIPT_WORKERS <= VERIFIER_WORKERS + 1);
    }

    #[test]
    fn compact_size_decodes_every_width() {
        let mut c = 0;
        assert_eq!(read_compact_size(&[0x10], &mut c), Some(0x10));
        c = 0;
        assert_eq!(read_compact_size(&[0xfd, 0x01, 0x02], &mut c), Some(0x0201));
        c = 0;
        assert_eq!(read_compact_size(&[0xfe, 1, 0, 0, 0], &mut c), Some(1));
    }
}
