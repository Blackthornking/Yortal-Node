//! Semantic (context-free) verification.
//!
//! Verification owns the expensive consensus work. Context-free checks start
//! as soon as each block arrives inside the single 16-block lifecycle window;
//! results are retained by height until the complete exact window is ready. The
//! ordered commit worker then performs state-dependent transaction/script
//! preparation against a consistent snapshot. Only the resulting prepared
//! mutation plan crosses into canonical publication.
//!
//! Canonical publication is deliberately not a validation stage: it only
//! rechecks the prepared parent/tip and atomically writes the prepared state.

use std::collections::{BTreeMap, BTreeSet};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::mpsc::{sync_channel, SyncSender};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

use anyhow::{anyhow, bail, Result};
use ycash_chain::txid;
use ycash_consensus::{validate_for_commit_batched_with_parsed, Context, ProofBatch};
use ycash_state::prospective::SemanticBlock;
use ycash_state::State;
use ycash_state::state_service::SyncMetrics;
use ycash_state::BlockCommit;

use crate::downloader::{BlockRequest, InFlightRegistry};

/// Optional assume-valid checkpoint, carried over unchanged. Full verification
/// is the default; this is used only when YCASH_ASSUME_VALID=1 and the verified
/// header at the checkpoint height matches.
pub const ASSUME_VALID_HEIGHT: u64 = 2_250_000;
pub const ASSUME_VALID_HASH_DISPLAY: &str =
    "000003f98b7497fdcd8a6b6d10a93a887c5d47127e24a9dc3a40cb65754d21e7";

/// Blocks a verifier thread folds into one Groth16 batch.
///
/// The batch identity costs one final exponentiation regardless of how many
/// proofs it holds, so a bigger batch amortises it better. One block per batch
/// wastes that on blocks with few shielded transactions. Grouping is bounded
/// rather than unlimited because a worker only groups what has *already*
/// arrived: it never waits for more blocks, so latency at the chain tip is
/// unchanged.
///
/// This is a scheduling constant. It changes how proofs are grouped for
/// verification, never which proofs must verify.
pub const MAX_BLOCKS_PER_PROOF_BATCH: usize = 8;

/// A downloaded block with the header context its verification needs.
#[derive(Debug)]
pub struct RawBlock {
    pub request: BlockRequest,
    pub raw: Vec<u8>,
    /// Peer that supplied the block. Diagnostic provenance only.
    pub source_peer: String,
}

/// Result of one verifier attempt with enough provenance to close the block
/// lifecycle exactly once.
pub struct VerifyOutcome {
    pub height: u64,
    pub hash: [u8; 32],
    pub source_peer: String,
    pub result: Result<SemanticBlock>,
}

/// Work handed from the verifier coordinator to the single ordered commit
/// owner. Keeping this on a dedicated worker prevents the coordinator from
/// blocking on the expensive state-preparation/write path: it can return to
/// multiplexing verifier completions immediately while canonical publication
/// remains strictly serialized. The lifecycle window is still exactly 16.
struct CommitRequest {
    batch_id: u64,
    commits: Vec<BlockCommit>,
    received: BTreeMap<u64, RawBlock>,
}

/// The prev-hash field of a block header, read straight from the wire bytes.
///
/// Header layout: version(4) | prev(32) | merkle(32) | final Sapling root(32) |
/// time(4) | bits(4) | nonce(32) | solution.
pub fn header_prev(raw: &[u8]) -> Result<[u8; 32]> {
    if raw.len() < 36 {
        bail!("block is too short to contain a header");
    }
    let mut prev = [0u8; 32];
    prev.copy_from_slice(&raw[4..36]);
    Ok(prev)
}

/// Run every context-free consensus check for one block.
///
/// This is the same entry point the previous pipeline used, called with the
/// same arguments for the same block; only the surrounding scheduling changed.
pub fn semantic_verify(block: RawBlock, assume_valid: bool) -> Result<SemanticBlock> {
    let RawBlock { request, raw, .. } = block;
    let height = request.height;
    let ctx = Context {
        height,
        prev_height: height.saturating_sub(1),
        median_time_past: request.median_time_past,
    };
    let assume_valid = assume_valid && height <= ASSUME_VALID_HEIGHT;

    // Sapling proofs in one block share a batch: one multi-Miller loop per
    // verifying key rather than one pairing check per proof. A rejection is
    // re-checked by the single-proof verifier, whose result is final.
    let mut proofs = ProofBatch::new();
    let (validated, parsed_txs) = validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, &mut proofs)
        .map_err(|e| anyhow!("block {height}: {e:?}"))?;
    if proofs.proofs() > 0 {
        if let Err((h, e)) = proofs.finish() {
            bail!("block {h}: {e:?}");
        }
    }
    if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
        bail!("block {height}: consensus decoder returned inconsistent transaction data");
    }

    let prev = header_prev(&raw)?;
    let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
    let precomputed_txs: Vec<ycash_script::PrecomputedTxData> =
        parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();

    Ok(SemanticBlock::from_commit(BlockCommit {
        height,
        hash: request.hash,
        prev,
        work: request.work,
        raw,
        txs,
        parsed_txs,
        precomputed_txs,
        proofs_verified: true,
    }))
}

/// Verify a group of blocks, folding every Sapling proof in the group into one
/// batch.
///
/// On batch rejection each block is re-verified on its own. The batch says only
/// that something in the set is bad, never which block, so a batch verdict is
/// never reported as a per-block result.
pub fn verify_group(blocks: Vec<RawBlock>, assume_valid: bool) -> Vec<VerifyOutcome> {
    if blocks.len() == 1 {
        let mut blocks = blocks;
        let block = blocks.remove(0);
        let height = block.request.height;
        let hash = block.request.hash;
        let source_peer = block.source_peer.clone();
        return vec![VerifyOutcome { height, hash, source_peer, result: semantic_verify(block, assume_valid) }];
    }

    let mut batch = ProofBatch::new();
    let mut staged: Vec<Result<SemanticBlock>> = Vec::with_capacity(blocks.len());
    let mut retained: Vec<RawBlock> = Vec::with_capacity(blocks.len());
    for block in blocks {
        let raw_for_retry = RawBlock {
            request: block.request.clone(),
            raw: block.raw.clone(),
            source_peer: block.source_peer.clone(),
        };
        retained.push(raw_for_retry);
        staged.push(verify_into_batch(block, assume_valid, &mut batch));
    }

    if batch.proofs() > 0 {
        if let Err((height, e)) = batch.finish() {
            // Isolate: re-verify every block in the group individually. The
            // lifecycle remains owned throughout this retry; no transport
            // request can be issued for any member while isolation runs.
            eprintln!("[VERIFY] proof batch rejected at height {height} ({e:?}); isolating {} blocks", retained.len());
            return retained
                .into_iter()
                .map(|raw| {
                    let height = raw.request.height;
                    let hash = raw.request.hash;
                    let source_peer = raw.source_peer.clone();
                    VerifyOutcome { height, hash, source_peer, result: semantic_verify(raw, assume_valid) }
                })
                .collect();
        }
    }

    retained
        .into_iter()
        .zip(staged)
        .map(|(raw, result)| VerifyOutcome {
            height: raw.request.height,
            hash: raw.request.hash,
            source_peer: raw.source_peer,
            result,
        })
        .collect()
}

/// Every context-free check for one block except the Groth16 pairing, which is
/// queued into the caller's batch.
pub(crate) fn verify_into_batch(block: RawBlock, assume_valid: bool, batch: &mut ProofBatch) -> Result<SemanticBlock> {
    let RawBlock { request, raw, .. } = block;
    let height = request.height;
    let ctx = Context {
        height,
        prev_height: height.saturating_sub(1),
        median_time_past: request.median_time_past,
    };
    let assume_valid = assume_valid && height <= ASSUME_VALID_HEIGHT;
    let (validated, parsed_txs) = validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, batch)
        .map_err(|e| anyhow!("block {height}: {e:?}"))?;
    if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
        bail!("block {height}: consensus decoder returned inconsistent transaction data");
    }
    let prev = header_prev(&raw)?;
    let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
    let precomputed_txs: Vec<ycash_script::PrecomputedTxData> =
        parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();
    Ok(SemanticBlock::from_commit(BlockCommit {
        height,
        hash: request.hash,
        prev,
        work: request.work,
        raw,
        txs,
        parsed_txs,
        precomputed_txs,
        proofs_verified: true,
    }))
}

/// Exact cryptographic verification batch.
///
/// Four shared verifier workers dynamically consume the 16 blocks in this
/// batch. The dispatcher waits for all 16 results before releasing the next
/// batch, preserving a hard batch boundary without assigning fixed heights to
/// individual workers.
pub const VERIFICATION_BATCH_SIZE: usize = crate::PIPELINE_BATCH_SIZE;

/// Simple bounded verifier queue. Network transport may stay ahead of the
/// canonical commit point, but only by a small fixed amount. This replaces the
/// old range/slice/coordinator pipeline with one queue and one ordered commit
/// gate. The cryptographic verifier itself is unchanged.
pub const VERIFIER_QUEUE_CAPACITY: usize = crate::VERIFIER_QUEUE_CAPACITY;

/// Result of the cryptographic/consensus verifier.
struct VerifyResult {
    outcome: VerifyOutcome,
}

/// Decrement a counter without ever wrapping below zero. The dashboard's queue
/// figure is diagnostic only, but a wrapped counter would show ~1.8e19 blocks.
fn saturating_dec(counter: &AtomicU64) {
    let _ = counter.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |v| Some(v.saturating_sub(1)));
}

/// Remember heights that must be verified again when their replacement
/// download reaches the batch dispatcher.
fn note_retry(set: &Mutex<BTreeSet<u64>>, heights: impl IntoIterator<Item = u64>) {
    if let Ok(mut set) = set.lock() {
        for height in heights {
            set.insert(height);
        }
    }
}

/// Publish the latest pipeline failure for the dashboard. The coordinator shows
/// it only while the canonical tip is still the height recorded here.
fn record_failure(metrics: &SyncMetrics, tip: u64, text: String) {
    let text: String = text.replace('\n', " ").chars().take(300).collect();
    if let Ok(mut slot) = metrics.last_pipeline_failure.lock() {
        *slot = text;
    }
    metrics.last_pipeline_failure_tip.store(tip, Ordering::Relaxed);
}

/// Pause between repeated failures so a deterministic rejection cannot turn
/// into a hot download/verify loop. The first two failures retry immediately;
/// after that the delay doubles from 250 ms up to 15 s. The pipeline is already
/// stalled at that height, so the pause costs nothing.
fn failure_backoff(streak: u32) -> Duration {
    if streak < 3 {
        return Duration::ZERO;
    }
    let shift = (streak - 3).min(6);
    Duration::from_millis(250u64 << shift).min(Duration::from_secs(15))
}

/// Best-effort text for a caught panic payload.
fn panic_text(payload: &(dyn std::any::Any + Send)) -> String {
    if let Some(text) = payload.downcast_ref::<&str>() {
        (*text).to_string()
    } else if let Some(text) = payload.downcast_ref::<String>() {
        text.clone()
    } else {
        "unknown panic".to_string()
    }
}

#[derive(Clone)]
pub struct VerifierPool {
    tx: SyncSender<RawBlock>,
    metrics: Arc<SyncMetrics>,
}

impl VerifierPool {
    pub fn spawn(
        _workers: usize,
        _queue_depth: usize,
        chain: Arc<State>,
        metrics: Arc<SyncMetrics>,
        registry: Arc<InFlightRegistry>,
        assume_valid: bool,
    ) -> Result<Self> {
        // The verifier stage is deliberately fixed at four workers. They share
        // one current 16-block work queue, so a worker may take ANY block in
        // the current batch. No worker is assigned a permanent height lane.
        // The dispatcher will not release batch N+1 until all 16 results from
        // batch N have returned.
        let workers = 4usize;
        let (tx, dispatch_rx) = sync_channel::<RawBlock>(VERIFIER_QUEUE_CAPACITY);
        let (work_tx, work_rx) = sync_channel::<RawBlock>(VERIFICATION_BATCH_SIZE);
        let (worker_result_tx, worker_result_rx) = sync_channel::<VerifyResult>(VERIFICATION_BATCH_SIZE);
        let shared_rx = Arc::new(std::sync::Mutex::new(work_rx));
        metrics.verifier_workers.store(workers as u64, Ordering::Relaxed);

        // Heights that a later stage rejected or discarded and that must be
        // verified again when their replacement download arrives. The batch
        // dispatcher's barrier only ever moves forward, so without this record a
        // re-downloaded block for an already-dispatched height looked "stale" and
        // was thrown away forever: the batch could never be completed and the
        // node sat in "validation queued" with every worker idle.
        let retry_heights: Arc<Mutex<BTreeSet<u64>>> = Arc::new(Mutex::new(BTreeSet::new()));

        // Stage 1a: four identical cryptographic workers. They pull dynamically
        // from the same 16-block batch queue; whichever worker finishes first
        // simply takes the next available block.
        for id in 0..workers {
            let rx = Arc::clone(&shared_rx);
            let result_tx = worker_result_tx.clone();
            let worker_metrics = Arc::clone(&metrics);
            thread::Builder::new()
                .name(format!("yortal-crypto-verify-{id}"))
                .spawn(move || loop {
                    let block = match rx.lock().ok().and_then(|r| r.recv().ok()) {
                        Some(block) => block,
                        None => break,
                    };
                    worker_metrics.semantic_active_workers.fetch_add(1, Ordering::Relaxed);
                    let height = block.request.height;
                    let hash = block.request.hash;
                    let source_peer = block.source_peer.clone();
                    // A panic inside verification must become an ordinary
                    // rejection. Otherwise the worker thread dies without
                    // returning a result, the dispatcher waits forever for the
                    // 16th result of the batch, and the active-worker counter
                    // is left permanently raised.
                    let result = match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                        semantic_verify(block, assume_valid)
                    })) {
                        Ok(result) => result,
                        Err(payload) => Err(anyhow!("block {height}: verifier panicked: {}", panic_text(&*payload))),
                    };
                    worker_metrics.semantic_active_workers.fetch_sub(1, Ordering::Relaxed);
                    if result_tx.send(VerifyResult {
                        outcome: VerifyOutcome { height, hash, source_peer, result },
                    }).is_err() {
                        break;
                    }
                })
                .map_err(|e| anyhow!("failed to start cryptographic verifier {id}: {e}"))?;
        }
        drop(worker_result_tx);

        // Stage 1b: one batch dispatcher. It collects the exact next 16 heights,
        // feeds those 16 jobs to the four shared workers, then waits for ALL 16
        // results. Only after the complete batch has finished does it release
        // any block from the next batch. This is the requested batch barrier.
        let dispatch_state = Arc::clone(&chain);
        let dispatch_metrics = Arc::clone(&metrics);
        let dispatch_registry = Arc::clone(&registry);
        let dispatch_retry = Arc::clone(&retry_heights);
        let (result_tx, result_rx) = sync_channel::<VerifyResult>(VERIFIER_QUEUE_CAPACITY);
        thread::Builder::new()
            .name("yortal-16-block-batch-dispatch".into())
            .spawn(move || {
                let mut pending: BTreeMap<u64, RawBlock> = BTreeMap::new();
                let mut expected_first = match dispatch_state.tip_height() {
                    Ok(Some(tip)) => tip.saturating_add(1),
                    Ok(None) => 1,
                    Err(e) => {
                        eprintln!("[VERIFY] initial tip read failed: {e}");
                        return;
                    }
                };
                let mut batch_id = 0u64;

                while let Ok(block) = dispatch_rx.recv() {
                    let height = block.request.height;
                    let hash = block.request.hash;
                    if height < expected_first {
                        // Behind the batch barrier. Normally this is a duplicate
                        // delivery of a block that was already dispatched, and it
                        // is discarded. But if a later stage rejected or dropped
                        // this height it is the replacement download, and it must
                        // be verified again or the ordered batch can never
                        // complete. Recovery blocks are verified on their own,
                        // outside the barrier, then handed to the preparation
                        // stage, which reorders by height.
                        let wanted = dispatch_retry
                            .lock()
                            .map(|mut set| set.remove(&height))
                            .unwrap_or(false);
                        if !wanted {
                            dispatch_registry.release(&hash);
                            saturating_dec(&dispatch_metrics.semantic_queue);
                            continue;
                        }
                        dispatch_metrics.pipeline_retries.fetch_add(1, Ordering::Relaxed);
                        dispatch_metrics.trace_head(
                            "crypto-batch",
                            "RETRY_DISPATCH",
                            height,
                            Some(hash),
                            format!(
                                "re-verifying rejected/discarded height {} behind barrier {}",
                                height, expected_first
                            ),
                        );
                        if work_tx.send(block).is_err() {
                            return;
                        }
                        let verified = match worker_result_rx.recv() {
                            Ok(v) => v,
                            Err(_) => return,
                        };
                        if result_tx.send(verified).is_err() {
                            return;
                        }
                        continue;
                    }
                    if let Some(replaced) = pending.insert(height, block) {
                        // Keep the newest candidate for this height. Only one
                        // candidate for a height can enter a verification batch.
                        // If the older candidate is the same block, its lifecycle
                        // claim now belongs to the newer arrival and must stay.
                        if replaced.request.hash != hash {
                            dispatch_registry.release(&replaced.request.hash);
                        }
                        saturating_dec(&dispatch_metrics.semantic_queue);
                    }

                    loop {
                        let heights: Vec<u64> =
                            (expected_first..expected_first.saturating_add(VERIFICATION_BATCH_SIZE as u64)).collect();
                        if !heights.iter().all(|h| pending.contains_key(h)) {
                            break;
                        }

                        dispatch_metrics.trace_head(
                            "crypto-batch",
                            "DISPATCH",
                            *heights.last().unwrap(),
                            pending.get(&expected_first).map(|b| b.request.hash),
                            format!(
                                "dispatching complete verification batch {}: {}..{} across four shared workers",
                                batch_id,
                                expected_first,
                                *heights.last().unwrap()
                            ),
                        );

                        for h in &heights {
                            let block = pending.remove(h).expect("verification batch member disappeared");
                            if work_tx.send(block).is_err() {
                                return;
                            }
                        }

                        // The batch is not considered verified until every one of
                        // its 16 blocks has returned. Completion order is arbitrary;
                        // the preparation stage reorders by height.
                        for _ in 0..VERIFICATION_BATCH_SIZE {
                            let verified = match worker_result_rx.recv() {
                                Ok(v) => v,
                                Err(_) => return,
                            };
                            if result_tx.send(verified).is_err() {
                                return;
                            }
                        }

                        dispatch_metrics.trace_head(
                            "crypto-batch",
                            "COMPLETE",
                            *heights.last().unwrap(),
                            None,
                            format!(
                                "all {} blocks in verification batch {} completed; releasing next batch",
                                VERIFICATION_BATCH_SIZE,
                                batch_id
                            ),
                        );
                        expected_first = expected_first.saturating_add(VERIFICATION_BATCH_SIZE as u64);
                        batch_id = batch_id.saturating_add(1);
                    }

                    // Telemetry: what the dispatcher is holding and which height
                    // it is still waiting for. Blocks held here are waiting on the
                    // network, not on a verifier, and must not be reported as a
                    // validation backlog.
                    dispatch_metrics.dispatch_pending.store(pending.len() as u64, Ordering::Relaxed);
                    let gap = if pending.is_empty() {
                        0
                    } else {
                        (expected_first..expected_first.saturating_add(VERIFICATION_BATCH_SIZE as u64))
                            .find(|h| !pending.contains_key(h))
                            .unwrap_or(0)
                    };
                    dispatch_metrics.dispatch_gap_height.store(gap, Ordering::Relaxed);
                }
            })
            .map_err(|e| anyhow!("failed to start 16-block verification dispatcher: {e}"))?;

        // Stage 2: exactly one expensive state-preparation worker. It owns the
        // ordering/reassembly barrier and performs all contextual/UTXO/script
        // preparation for one exact 16-block batch. It waits for the commit
        // acknowledgement before preparing the next batch, because the next
        // preparation must observe the state produced by the previous batch.
        let (prepared_tx, prepared_rx) = sync_channel::<PreparedBatch>(4);
        let (commit_ack_tx, commit_ack_rx) = sync_channel::<bool>(1);
        let prepare_state = Arc::clone(&chain);
        let prepare_metrics = Arc::clone(&metrics);
        let prepare_registry = Arc::clone(&registry);
        let prepare_retry = Arc::clone(&retry_heights);
        thread::Builder::new()
            .name("yortal-expensive-state-prepare".into())
            .spawn(move || {
                let mut verified: BTreeMap<u64, SemanticBlock> = BTreeMap::new();
                let mut batch_id = 0u64;
                // Consecutive failures without a successful publication in
                // between. Used only to stop a deterministic rejection from
                // becoming a hot download/verify loop.
                let mut failure_streak = 0u32;

                while let Ok(VerifyResult { outcome }) = result_rx.recv() {
                    saturating_dec(&prepare_metrics.semantic_queue);
                    let height = outcome.height;
                    let hash = outcome.hash;

                    if let Err(err) = &outcome.result {
                        prepare_metrics.invalid_blocks.fetch_add(1, Ordering::Relaxed);
                        let tip_now = prepare_state.tip_height().ok().flatten().unwrap_or(0);
                        eprintln!("[VERIFY] block {height} rejected: {err:#}");
                        record_failure(
                            &prepare_metrics,
                            tip_now,
                            format!("block {height} rejected by verifier: {err:#}"),
                        );
                        // Record the retry BEFORE releasing the claim: the
                        // replacement download can only start after the release,
                        // and the dispatcher must already know to accept it.
                        note_retry(&prepare_retry, std::iter::once(height));
                        failure_streak = failure_streak.saturating_add(1);
                        thread::sleep(failure_backoff(failure_streak));
                        prepare_registry.release(&hash);
                        continue;
                    }

                    if let Ok(Some(tip)) = prepare_state.tip_height() {
                        if height <= tip {
                            prepare_registry.release(&hash);
                            continue;
                        }
                    }
                    if let Some(existing) = verified.get(&height) {
                        // Duplicate of a height already held. If it is the very
                        // same block the claim is shared and must be kept.
                        if existing.hash != hash {
                            prepare_registry.release(&hash);
                        }
                        continue;
                    }

                    verified.insert(height, outcome.result.expect("checked above"));

                    loop {
                        let tip = match prepare_state.tip_height() {
                            Ok(v) => v.unwrap_or(0),
                            Err(e) => {
                                eprintln!("[PREPARE] tip read failed: {e}");
                                break;
                            }
                        };
                        let first = tip.saturating_add(1);
                        let heights: Vec<u64> =
                            (first..first.saturating_add(VERIFICATION_BATCH_SIZE as u64)).collect();
                        if !heights.iter().all(|h| verified.contains_key(h)) {
                            break;
                        }

                        let mut commits = Vec::with_capacity(VERIFICATION_BATCH_SIZE);
                        let mut hashes = Vec::with_capacity(VERIFICATION_BATCH_SIZE);
                        for h in &heights {
                            let block = verified.remove(h).expect("verified height disappeared");
                            hashes.push(block.hash);
                            commits.push(block.commit);
                        }

                        let first_height = heights[0];
                        let last_height = *heights.last().unwrap();
                        prepare_metrics.contextual_active_batches.fetch_add(1, Ordering::Relaxed);
                        let prepare_started = Instant::now();
                        let prepared_result: Result<ycash_state::PreparedCommit> =
                            match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                                prepare_state.prepare_commit_batch_owned(commits)
                            })) {
                                Ok(result) => result,
                                Err(payload) => Err(anyhow!("state preparation panicked: {}", panic_text(&*payload))),
                            };
                        let prepared = match prepared_result {
                            Ok(prepared) => prepared,
                            Err(e) => {
                                prepare_metrics.contextual_active_batches.fetch_sub(1, Ordering::Relaxed);
                                prepare_metrics.invalid_blocks.fetch_add(1, Ordering::Relaxed);
                                eprintln!("[PREPARE] contextual validation rejected batch {batch_id} ({first_height}..{last_height}): {e:#}");
                                record_failure(
                                    &prepare_metrics,
                                    tip,
                                    format!("batch {first_height}..{last_height} rejected by state preparation: {e:#}"),
                                );
                                // All 16 blocks are discarded and will be
                                // downloaded again; each must be accepted back
                                // through the recovery lane.
                                note_retry(&prepare_retry, first_height..=last_height);
                                failure_streak = failure_streak.saturating_add(1);
                                thread::sleep(failure_backoff(failure_streak));
                                for h in &hashes {
                                    prepare_registry.release(h);
                                }
                                batch_id = batch_id.saturating_add(1);
                                continue;
                            }
                        };
                        let prepare_us = prepare_started.elapsed().as_micros() as u64;
                        prepare_metrics.contextual_active_batches.fetch_sub(1, Ordering::Relaxed);
                        prepare_metrics.contextual_prepare_us.store(prepare_us, Ordering::Relaxed);
                        prepare_metrics.highest_contextually_verified_height.fetch_max(last_height, Ordering::Relaxed);

                        let envelope = PreparedBatch {
                            batch_id,
                            first_height,
                            last_height,
                            hashes,
                            prepared,
                        };
                        if prepared_tx.send(envelope).is_err() {
                            return;
                        }

                        match commit_ack_rx.recv() {
                            Ok(true) => {
                                failure_streak = 0;
                                // Everything at or below the new tip is settled;
                                // forget any retry marks that were never used.
                                if let Ok(mut set) = prepare_retry.lock() {
                                    let keep = set.split_off(&last_height.saturating_add(1));
                                    *set = keep;
                                }
                            }
                            Ok(false) => {
                                // Publication failed: the batch is gone and every
                                // later verified block was built on a state that
                                // no longer exists. Discard them all and take
                                // each one back through the recovery lane.
                                let mut redo: Vec<u64> = (first_height..=last_height).collect();
                                for (held_height, block) in std::mem::take(&mut verified) {
                                    redo.push(held_height);
                                    prepare_registry.release(&block.hash);
                                }
                                note_retry(&prepare_retry, redo);
                                failure_streak = failure_streak.saturating_add(1);
                                thread::sleep(failure_backoff(failure_streak));
                            }
                            Err(_) => return,
                        }
                        batch_id = batch_id.saturating_add(1);
                    }
                }
            })
            .map_err(|e| anyhow!("failed to start expensive state-preparation worker: {e}"))?;

        // Stage 3: exactly one canonical commit worker. This worker performs
        // publication only: apply_prepared_commit rechecks the prepared tip /
        // parent and executes the atomic RocksDB write. No parsing, UTXO
        // discovery, script execution, proof verification, or other expensive
        // consensus work occurs here.
        let commit_state = Arc::clone(&chain);
        let commit_metrics = Arc::clone(&metrics);
        let commit_registry = Arc::clone(&registry);
        thread::Builder::new()
            .name("yortal-batch-commit".into())
            .spawn(move || {
                while let Ok(batch) = prepared_rx.recv() {
                    let started = Instant::now();
                    let prepared = batch.prepared;
                    let result: Result<()> = match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                        commit_state.apply_prepared_commit(prepared)
                    })) {
                        Ok(result) => result,
                        Err(payload) => Err(anyhow!("canonical publication panicked: {}", panic_text(&*payload))),
                    };
                    let committed_ok = result.is_ok();
                    match result {
                        Ok(()) => {
                            let timing = commit_state.last_commit_timing();
                            commit_metrics.database_write_us.store(timing.db_write_us, Ordering::Relaxed);
                            commit_metrics.last_publication_blocks.store(
                                VERIFICATION_BATCH_SIZE as u64,
                                Ordering::Relaxed,
                            );
                            commit_metrics.committed_blocks.fetch_add(
                                VERIFICATION_BATCH_SIZE as u64,
                                Ordering::Relaxed,
                            );
                            commit_metrics.canonical_height.store(batch.last_height, Ordering::Relaxed);
                            commit_metrics.commit_batches.fetch_add(1, Ordering::Relaxed);
                            commit_metrics.commit_total_us.fetch_add(timing.total_us, Ordering::Relaxed);
                            commit_metrics.last_commit_total_us.store(timing.total_us, Ordering::Relaxed);
                            commit_metrics.last_commit_unix.store(
                                std::time::SystemTime::now()
                                    .duration_since(std::time::UNIX_EPOCH)
                                    .map(|d| d.as_secs())
                                    .unwrap_or(0),
                                Ordering::Relaxed,
                            );
                            *commit_metrics.last_commit_timing.lock().unwrap() = timing;
                            commit_metrics.trace_head(
                                "ordered-commit",
                                "COMMITTED",
                                batch.last_height,
                                batch.hashes.last().copied(),
                                format!(
                                    "published exact {}-block sequence {}..{}; commit worker performed publication only in {}us",
                                    VERIFICATION_BATCH_SIZE,
                                    batch.first_height,
                                    batch.last_height,
                                    started.elapsed().as_micros()
                                ),
                            );
                            commit_metrics.clear_missing_parent();
                        }
                        Err(e) => {
                            eprintln!("[COMMIT] batch {} publication failed: {e:#}", batch.batch_id);
                            commit_metrics.semantic_batch_failures.fetch_add(1, Ordering::Relaxed);
                            let tip_now = commit_state.tip_height().ok().flatten().unwrap_or(0);
                            record_failure(
                                &commit_metrics,
                                tip_now,
                                format!(
                                    "batch {}..{} publication failed: {e:#}",
                                    batch.first_height, batch.last_height
                                ),
                            );
                        }
                    }

                    for hash in &batch.hashes {
                        commit_registry.release(hash);
                    }
                    let _ = commit_ack_tx.send(committed_ok);
                }
            })
            .map_err(|e| anyhow!("failed to start canonical commit worker: {e}"))?;

        Ok(Self { tx, metrics })
    }

    /// Bounded producer backpressure. Four 16-block windows may wait behind
    /// the workers; transport itself remains limited to 16 blocks per peer.
    pub fn submit(&self, block: RawBlock) -> Result<()> {
        self.metrics.semantic_queue.fetch_add(1, Ordering::Relaxed);
        self.tx.send(block).map_err(|_| {
            self.metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
            anyhow!("cryptographic verifier stopped")
        })
    }
}

/// Owned hand-off between the single expensive preparation worker and the
/// single canonical commit worker. Keeping the prepared mutation plan owned is
/// what lets the stages communicate without copying raw block data or using a
/// self-referential lifetime.
struct PreparedBatch {
    batch_id: u64,
    first_height: u64,
    last_height: u64,
    hashes: Vec<[u8; 32]>,
    prepared: ycash_state::PreparedCommit,
}

/// Default verifier width: leave one core for the ordered state engine and one
/// for the Android UI thread, and never drop below one worker.
pub fn default_verifier_workers() -> usize {
    std::thread::available_parallelism()
        .map(|n| n.get().saturating_sub(2).max(1))
        .unwrap_or(1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn failure_backoff_grows_then_caps() {
        assert_eq!(failure_backoff(1), Duration::ZERO);
        assert_eq!(failure_backoff(2), Duration::ZERO);
        assert_eq!(failure_backoff(3), Duration::from_millis(250));
        assert_eq!(failure_backoff(4), Duration::from_millis(500));
        assert_eq!(failure_backoff(100), Duration::from_secs(15));
    }

    #[test]
    fn queue_counter_never_wraps() {
        let counter = AtomicU64::new(1);
        saturating_dec(&counter);
        saturating_dec(&counter);
        assert_eq!(counter.load(Ordering::Relaxed), 0);
    }

    #[test]
    fn retry_marks_are_recorded_once() {
        let set = Mutex::new(BTreeSet::new());
        note_retry(&set, 5..=7);
        note_retry(&set, std::iter::once(6));
        assert_eq!(set.lock().unwrap().len(), 3);
    }

    #[test]
    fn verifier_queue_is_four_16_block_windows() {
        assert_eq!(VERIFIER_QUEUE_CAPACITY, 64);
        assert_eq!(VERIFICATION_BATCH_SIZE, 16);
        assert_eq!(VERIFIER_QUEUE_CAPACITY / VERIFICATION_BATCH_SIZE, 4);
    }
}
