//! Android sync coordinator.
//!
//! Each peer runs on its own thread with a blocking socket, which suits the
//! streaming downloader exactly: the thread asks for up to 48 blocks, then
//! services whatever arrives, handing each block to the verifier pool and
//! immediately refilling the freed slot. No peer waits for another peer, and no
//! block waits for 47 siblings.
//!
//! This module owns none of the consensus logic. It is the glue between the
//! app's existing P2P session loop and [`ycash_node::SyncEngine`].

use std::net::TcpStream;
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

use ycash_node::{PeerDownloadSession, SyncConfig, SyncEngine};
use ycash_state::State;

use crate::runtime::SharedState;
use crate::{read_message, send};

pub use ycash_node::{ASSUME_VALID_HASH_DISPLAY, ASSUME_VALID_HEIGHT, MAX_BLOCKS_IN_TRANSIT_PER_PEER};

/// How often a peer thread republishes pipeline telemetry.
const TELEMETRY_INTERVAL: Duration = Duration::from_millis(500);

#[derive(Clone)]
pub struct SyncCoordinator {
    engine: SyncEngine,
}

impl SyncCoordinator {
    pub fn start(state: Arc<State>) -> std::io::Result<Self> {
        let engine = SyncEngine::start(state, SyncConfig::from_env())
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))?;
        // Keep head-of-line recovery independent from any individual peer's
        // blocking socket loop. A stalled peer must not be able to prevent the
        // canonical parent from being reassigned to another connected peer.
        let watchdog_engine = engine.clone();
        thread::Builder::new()
            .name("ycash-head-watchdog".into())
            .spawn(move || loop {
                thread::sleep(Duration::from_secs(1));
                if let Err(e) = watchdog_engine.watchdog_head_once() {
                    tracing::debug!(error = %e, "head watchdog tick failed");
                }
            })
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))?;
        Ok(Self { engine })
    }

    pub fn verify_threads(&self) -> usize {
        self.engine.config.verifier_workers
    }

    pub fn session(&self, peer: &str) -> PeerDownloadSession {
        self.engine.session(peer)
    }

    /// Reconsider the candidate tree after the header chain moved.
    /// True when block download is waiting on the header chain rather than on
    /// a peer.
    pub fn awaiting_headers(&self) -> bool {
        self.engine.awaiting_headers()
    }

    pub fn headers_advanced(&self) {
        if let Ok(Some(height)) = self.engine.state.header_height() {
            self.engine.metrics.raise_header_height(height);
        }
        let _ = self.engine.assigner.rewind_to_canonical();
        self.engine.poke();
    }

    /// Ask this peer for more blocks, if its window has room and the header
    /// chain has something to offer. Returns the number of blocks requested.
    pub fn request_more(&self, stream: &mut TcpStream, session: &mut PeerDownloadSession) -> std::io::Result<usize> {
        let hashes = self
            .engine
            .next_requests(session)
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))?;
        if hashes.is_empty() {
            return Ok(0);
        }
        send(stream, "getdata", &ycash_network::runtime::getdata_payload(&hashes))?;
        if let Ok(canonical) = self.engine.assigner.canonical_height() {
            let next_height = canonical.saturating_add(1);
            if let Ok(Some(head_hash)) = self.engine.assigner.header_hash(next_height) {
                if hashes.iter().any(|h| *h == head_hash) {
                    self.engine.trace_head(
                        session.peer().to_string(),
                        "GETDATA_SENT",
                        next_height,
                        Some(head_hash),
                        format!("requested exact canonical head; window_count={}", hashes.len()),
                    );
                }
            }
        }
        Ok(hashes.len())
    }

    /// Feed one `block` message into the pipeline.
    pub fn on_block(&self, session: &mut PeerDownloadSession, raw: Vec<u8>) -> bool {
        match self.engine.on_block_message(session, raw) {
            Ok(accepted) => accepted,
            Err(e) => {
                eprintln!("[SYNC] verifier submit failed: {e}");
                false
            }
        }
    }

    /// Copy the live counters into the dashboard's shared state.
    pub fn publish_telemetry(&self, live: &SharedState) {
        // Read the header tip from the database, not from whatever the header
        // sync routine last wrote. A routine that returns early leaves the old
        // figure behind, which is how the dashboard showed HDR 0 with the
        // chain at 192.
        let header_tip = self.engine.header_tip();
        let m = &self.engine.metrics;
        let canonical = m.canonical_height.load(Ordering::Relaxed);
        let header_height = m.highest_header_height.load(Ordering::Relaxed);
        let semantic_height = m.highest_semantically_verified_height.load(Ordering::Relaxed);
        let contextual_height = m.highest_contextually_verified_height.load(Ordering::Relaxed);
        let in_flight = m.blocks_in_flight_total.load(Ordering::Relaxed);
        let prospective = m.prospective_blocks.load(Ordering::Relaxed);
        let verify_workers = m.verifier_workers.load(Ordering::Relaxed);
        let active_semantic_workers = m.semantic_active_workers.load(Ordering::Relaxed);
        let active_contextual_batches = m.contextual_active_batches.load(Ordering::Relaxed);
        let commit_batches = m.commit_batches.load(Ordering::Relaxed);
        // Blocks the batch dispatcher is holding for the rest of its 16-block
        // window, and the lowest height it is still waiting for. Those blocks
        // are waiting on the network, not on a verifier.
        let dispatch_pending = m.dispatch_pending.load(Ordering::Relaxed);
        let batch_gap = m.dispatch_gap_height.load(Ordering::Relaxed);
        // A verifier / state-preparation / publication failure is shown only
        // while the canonical tip is still where it happened, i.e. while it is
        // actually blocking progress.
        let failure_text = if m.last_pipeline_failure_tip.load(Ordering::Relaxed) == canonical {
            m.last_pipeline_failure.lock().map(|text| text.clone()).unwrap_or_default()
        } else {
            String::new()
        };
        let semantic_verified = m.semantic_verified_blocks.load(Ordering::Relaxed);
        let semantic_us_total = m.semantic_verify_total_us.load(Ordering::Relaxed);
        let commit_us_total = m.commit_total_us.load(Ordering::Relaxed);
        let last_commit_us = m.last_commit_total_us.load(Ordering::Relaxed);
        let last_commit_unix = m.last_commit_unix.load(Ordering::Relaxed);
        let timing = m.last_commit_timing.lock().unwrap().clone();

        let mut st = live.write().unwrap();
        if header_tip > st.headers_height {
            st.headers_height = header_tip;
        }
        let previous_commit_batches = st.db_commits;
        if canonical > 0 {
            st.local_height = canonical;
        }
        st.headers_height = header_height;
        st.download_height = m.download_height.load(Ordering::Relaxed);
        st.semantic_verified_height = semantic_height;
        st.contextual_verified_height = contextual_height;
        st.pipeline_inflight_ranges = in_flight;
        st.pipeline_pending_ranges = prospective;
        st.pipeline_verify_threads = verify_workers;
        st.pipeline_max_validation_workers = verify_workers;
        st.pipeline_cfg_validation_workers = verify_workers;
        // `verifier_workers` is the configured width; `verifying_jobs` is the
        // live work actually executing right now. The latter must not be inferred
        // from `validation_queue`, because dequeued workers leave that queue at 0.
        st.verifying_jobs = active_semantic_workers.saturating_add(active_contextual_batches);
        st.pipeline_max_inflight_ranges = self.engine.config.max_blocks_in_flight as u64;
        st.pipeline_cfg_inflight_ranges = self.engine.config.max_blocks_in_flight as u64;
        st.pipeline_cfg_min_window = self.engine.config.blocks_in_transit_per_peer as u64;
        st.pipeline_cfg_max_window = self.engine.config.blocks_in_transit_per_peer as u64;
        st.pipeline_cfg_window_step = 0;
        st.pipeline_commit_batch = m.last_publication_blocks.load(Ordering::Relaxed);
        st.pipeline_active_range_len = self.engine.config.blocks_in_transit_per_peer as u64;
        st.pipeline_max_range_len = self.engine.config.blocks_in_transit_per_peer as u64;
        st.pipeline_lookahead = self.engine.config.download_window() as u64;
        st.current_window = self.engine.config.download_window() as u64;
        st.blocks_received = m.blocks_downloaded.load(Ordering::Relaxed);
        st.block_bytes_received = m.bytes_downloaded.load(Ordering::Relaxed);
        st.blocks_validated = semantic_verified;
        st.blocks_committed = m.committed_blocks.load(Ordering::Relaxed);
        st.reorgs = m.reorgs.load(Ordering::Relaxed);
        st.duplicate_blocks = m.duplicate_blocks.load(Ordering::Relaxed);
        st.evicted_prospective = m.evicted_prospective.load(Ordering::Relaxed);
        st.blocks_in_flight = in_flight;
        st.validation_queue = m.semantic_queue.load(Ordering::Relaxed);
        st.dispatch_pending = dispatch_pending;
        st.batch_gap_height = batch_gap;
        st.contextual_queue = m.contextual_queue.load(Ordering::Relaxed);
        st.last_semantic_verify_us = m.semantic_verify_us.load(Ordering::Relaxed);
        st.last_contextual_prepare_us = m.contextual_prepare_us.load(Ordering::Relaxed);
        st.buffered_ranges = prospective;

        let max_inflight = self.engine.config.max_blocks_in_flight.max(1) as f64;
        let max_prospective = self.engine.config.prospective_capacity.max(1) as f64;
        let max_verify_queue = self.engine.config.verifier_queue.max(1) as f64;
        st.pipeline_network_pressure = (in_flight as f64 / max_inflight).min(1.0);
        st.pipeline_validation_pressure = (st.validation_queue as f64 / max_verify_queue).min(1.0);
        st.pipeline_db_pressure = (prospective as f64 / max_prospective).min(1.0);
        st.pipeline_memory_pressure = st.pipeline_db_pressure;
        st.pipeline_cpu_pressure = 0.0; // CPU pressure is not sampled by the native sync engine.
        let missing_head = st.missing_parent_height > canonical && !st.missing_parent_hash.is_empty();
        st.pipeline_bottleneck = if header_height == 0 && canonical == 0 {
            "STARTUP".into()
        } else if missing_head {
            "ORDERED HEAD / MISSING PARENT".into()
        } else if active_contextual_batches > 0 {
            "VALIDATION / STATE PREP".into()
        } else if active_semantic_workers > 0 {
            "VALIDATION / VERIFYING".into()
        } else if !failure_text.is_empty() {
            "VALIDATION / RETRY".into()
        } else if batch_gap > 0 {
            "FETCH / BATCH GAP".into()
        } else if st.validation_queue > 0 {
            "VALIDATION / QUEUED".into()
        } else if prospective > 0 && contextual_height <= canonical {
            "COMMIT / PARENT WAIT".into()
        } else if contextual_height > canonical {
            "COMMIT / READY".into()
        } else if in_flight > 0 {
            "FETCH".into()
        } else if header_height > canonical {
            "FETCH / HEADER GAP".into()
        } else {
            "NONE / HEALTHY".into()
        };
        // `pipeline_error` is reserved for an actual blocking condition. Active
        // verification is normal pipeline work, not an error, and must not turn
        // the dashboard red merely because the canonical writer is waiting for it.
        st.pipeline_error = if !failure_text.is_empty() {
            format!("Last failure at tip {}: {}", canonical, failure_text)
        } else if missing_head {
            format!(
                "Canonical head blocked at height {} · missing block parent · wait {}s · {} · retries {}",
                st.missing_parent_height,
                st.missing_parent_wait_ms / 1000,
                if st.missing_parent_candidate_present { "candidate present" } else if st.missing_parent_in_flight { "head request active" } else { "head request needs recovery" },
                st.missing_parent_retries,
            )
        } else if st.pipeline_bottleneck == "COMMIT / PARENT WAIT" {
            "Ordered commit is waiting for the next validated parent.".into()
        } else {
            String::new()
        };
        st.batch_size = m.last_publication_blocks.load(Ordering::Relaxed);
        st.active_block_workers = verify_workers;
        st.db_commits = commit_batches;
        st.invalid_blocks = m.invalid_blocks.load(Ordering::Relaxed);
        st.expired_requests = m.expired_requests.load(Ordering::Relaxed);
        st.stalled_parent_waits = m.stalled_parent_waits.load(Ordering::Relaxed);
        st.parent_retries = m.parent_retries.load(Ordering::Relaxed);
        st.parent_retry_height = m.parent_retry_height.load(Ordering::Relaxed);
        st.parent_retry_unix_ms = m.parent_retry_unix_ms.load(Ordering::Relaxed);
        let missing = m.missing_parent.lock().unwrap().clone();
        st.missing_parent_height = missing.height;
        st.missing_parent_hash = missing.hash;
        st.missing_parent_retries = missing.retries;
        st.missing_parent_in_flight = missing.in_flight;
        st.missing_parent_candidate_present = missing.candidate_present;
        st.head_trace = m.head_trace_snapshot().iter().rev().take(32).map(|e| {
            format!("#{} {} peer={} h={} hash={} {}", e.seq, e.unix_ms, e.peer, e.height, e.hash, e.detail.replace('\n', " "))
        }).collect::<Vec<_>>().join("\n");
        st.missing_parent_wait_ms = if missing.since_unix_ms == 0 {
            0
        } else {
            (crate::runtime::unix_time().max(0) as u64).saturating_mul(1000).saturating_sub(missing.since_unix_ms)
        };
        st.validation_ms_total = semantic_us_total / 1000;
        st.db_commit_ms_total = commit_us_total / 1000;
        st.last_commit_total_us = last_commit_us;
        st.last_commit_unix = last_commit_unix as i64;

        // Stage heights are intentionally copied independently. They are the
        // most useful way to distinguish a transport stall from semantic
        // verification, contextual validation, or ordered publication.
        st.last_block_height = m.last_received_height.load(Ordering::Relaxed);

        // The detailed timing record is authoritative and is only replaced
        // after a successful RocksDB publication.
        st.last_begin_ms = timing.begin_ms;
        st.last_state_validation_ms = timing.state_validation_ms;
        st.last_state_validation_us = timing.state_validation_us;
        st.last_state_unattributed_us = timing.state_unattributed_us;
        st.last_header_hash_us = timing.header_hash_us;
        st.last_connector_new_us = timing.connector_new_us;
        st.last_connector_other_us = timing.connector_other_us;
        st.last_block_root_us = timing.block_root_us;
        st.last_block_root_level_us = timing.block_root_level_us;
        st.last_block_root_level_hashes = timing.block_root_level_hashes;
        st.last_block_root_empty_us = timing.block_root_empty_us;
        st.last_block_root_empty_hashes = timing.block_root_empty_hashes;
        st.last_block_root_hash_us = timing.block_root_hash_us;
        st.last_block_root_hashes = timing.block_root_hashes;
        st.last_block_loop_other_us = timing.block_loop_other_us;
        st.last_slowest_block_height = timing.slowest_block_height;
        st.last_slowest_block_us = timing.slowest_block_us;
        st.last_slowest_block_other_us = timing.slowest_block_other_us;
        st.last_slowest_tx_height = timing.slowest_tx_height;
        st.last_slowest_tx_index = timing.slowest_tx_index;
        st.last_slowest_tx_us = timing.slowest_tx_us;
        st.last_slowest_tx_other_us = timing.slowest_tx_other_us;
        st.last_tree_ms = timing.tree_ms;
        st.last_parent_state_load_ms = timing.parent_state_load_ms;
        st.last_parent_state_load_us = timing.parent_state_load_us;
        st.last_block_parse_us = timing.block_parse_us;
        st.last_block_parse_ms = timing.block_parse_ms;
        st.last_txid_us = timing.txid_us;
        st.last_tx_parse_us = timing.tx_parse_us;
        st.last_tx_connect_ms = timing.tx_connect_ms;
        st.last_tx_connect_us = timing.tx_connect_us;
        st.last_sigops_ms = timing.sigops_ms;
        st.last_sigops_us = timing.sigops_us;
        st.last_bip30_ms = timing.bip30_ms;
        st.last_bip30_us = timing.bip30_us;
        st.last_utxo_lookup_ms = timing.utxo_lookup_ms;
        st.last_utxo_lookup_us = timing.utxo_lookup_us;
        st.last_sprout_requirements_ms = timing.sprout_requirements_ms;
        st.last_sprout_requirements_us = timing.sprout_requirements_us;
        st.last_value_checks_ms = timing.value_checks_ms;
        st.last_value_checks_us = timing.value_checks_us;
        st.last_script_ms = timing.script_ms;
        st.last_script_us = timing.script_us;
        st.last_coin_state_update_ms = timing.coin_state_update_ms;
        st.last_coin_state_update_us = timing.coin_state_update_us;
        st.last_sprout_apply_ms = timing.sprout_apply_ms;
        st.last_sprout_apply_us = timing.sprout_apply_us;
        st.last_sapling_validate_ms = timing.sapling_validate_ms;
        st.last_sapling_validate_us = timing.sapling_validate_us;
        st.last_sapling_anchor_lookup_ms = timing.sapling_anchor_lookup_ms;
        st.last_sapling_anchor_lookup_us = timing.sapling_anchor_lookup_us;
        st.last_sapling_nullifier_lookup_ms = timing.sapling_nullifier_lookup_ms;
        st.last_sapling_nullifier_lookup_us = timing.sapling_nullifier_lookup_us;
        st.last_sapling_tree_update_ms = timing.sapling_tree_update_ms;
        st.last_sapling_tree_update_us = timing.sapling_tree_update_us;
        st.last_block_finalize_ms = timing.block_finalize_ms;
        st.last_block_finalize_us = timing.block_finalize_us;
        st.last_tree_encode_us = timing.tree_encode_us;
        st.last_read_transaction_us = timing.read_transaction_us;
        st.last_read_transaction_commit_us = timing.read_transaction_commit_us;
        st.last_parent_frontier_load_us = timing.parent_frontier_load_us;
        st.last_sprout_state_load_us = timing.sprout_state_load_us;
        st.last_sapling_anchor_queries = timing.sapling_anchor_queries;
        st.last_sapling_nullifier_queries = timing.sapling_nullifier_queries;
        st.last_sapling_empty_hashes_avoided = timing.sapling_empty_hashes_avoided;
        st.last_sapling_root_cache_hits = timing.sapling_root_cache_hits;
        st.last_utxo_lookups = timing.utxo_lookups;
        st.last_bip30_checks = timing.bip30_checks;
        st.last_script_checks = timing.script_checks;
        st.last_script_parallel_workers = timing.script_parallel_workers;
        st.last_script_parallel_us = timing.script_parallel_us;
        st.last_script_input_work_us = timing.script_input_work_us;
        st.last_script_slowest_input_index = timing.script_slowest_input_index;
        st.last_script_slowest_input_us = timing.script_slowest_input_us;
        st.last_script_slowest_input_tx_height = timing.script_slowest_input_tx_height;
        st.last_script_slowest_input_tx_index = timing.script_slowest_input_tx_index;
        st.last_script_transaction_input_extraction_us = timing.script_transaction_input_extraction_us;
        st.last_script_sig_construction_us = timing.script_sig_construction_us;
        st.last_script_pubkey_retrieval_us = timing.script_pubkey_retrieval_us;
        st.last_script_parsing_us = timing.script_parsing_us;
        st.last_signature_hash_preparation_us = timing.signature_hash_preparation_us;
        st.last_ecdsa_verification_us = timing.ecdsa_verification_us;
        st.last_script_interpreter_us = timing.script_interpreter_us;
        st.last_script_cache_lookup_us = timing.script_cache_lookup_us;
        st.last_script_synchronization_us = timing.script_synchronization_us;
        st.last_script_permit_wait_us = timing.script_permit_wait_us;
        st.last_script_active_peak = timing.script_active_peak;
        st.last_script_scheduler_gap_us = timing.script_scheduler_gap_us;
        st.last_script_worker_wall_us = timing.script_worker_wall_us;
        st.last_script_worker_input_work_us = timing.script_worker_input_work_us;
        st.last_script_worker_inputs = timing.script_worker_inputs;
        st.last_script_spawn_us = timing.script_spawn_us;
        st.last_script_join_us = timing.script_join_us;
        st.last_script_pool_overhead_us = timing.script_pool_overhead_us;
        st.last_script_pool_threads = timing.script_pool_threads;
        st.last_script_worker_max_us = timing.script_worker_max_us;
        st.last_script_worker_min_us = timing.script_worker_min_us;
        st.last_utxo_cache_hits = timing.utxo_cache_hits;
        st.last_utxo_cache_misses = timing.utxo_cache_misses;
        st.last_utxo_db_lookup_us = timing.utxo_db_lookup_us;
        st.last_utxo_db_lookup_keys = timing.utxo_db_lookup_keys;
        st.last_utxo_cache_hit_rate_ppm = timing.utxo_cache_hit_rate_ppm;
        st.last_parent_state_cache_hit = timing.parent_state_cache_hit;
        st.last_sprout_state_cache_hit = timing.sprout_state_cache_hit;
        st.last_db_write_ms = timing.db_write_ms;
        st.last_db_write_us = timing.db_write_us;
        st.last_sql_write_ms = timing.sql_write_ms;
        st.last_index_write_ms = timing.index_write_ms;
        st.last_sqlite_commit_ms = timing.sqlite_commit_ms;
        st.last_sqlite_commit_us = timing.sqlite_commit_us;
        st.last_rollback_ms = timing.rollback_ms;

        // Preserve the most recent successful commit in the UI rolling window.
        // The sample is sourced from the same authoritative CommitTiming record
        // as the single-value diagnostics above, never from UI poll duration.
        if commit_batches > previous_commit_batches && timing.blocks > 0 {
                st.record_rolling_commit(crate::runtime::RollingCommitSample {
                    blocks: timing.blocks,
                    txs: timing.txs,
                    total_us: timing.total_us,
                    state_validation_us: timing.state_validation_us,
                    tx_connect_us: timing.tx_connect_us,
                    script_us: timing.script_us,
                    script_transaction_input_extraction_us: timing.script_transaction_input_extraction_us,
                    script_sig_construction_us: timing.script_sig_construction_us,
                    script_pubkey_retrieval_us: timing.script_pubkey_retrieval_us,
                    script_parsing_us: timing.script_parsing_us,
                    signature_hash_preparation_us: timing.signature_hash_preparation_us,
                    ecdsa_verification_us: timing.ecdsa_verification_us,
                    script_interpreter_us: timing.script_interpreter_us,
                    script_cache_lookup_us: timing.script_cache_lookup_us,
                    script_synchronization_us: timing.script_synchronization_us,
                    sqlite_commit_us: timing.sqlite_commit_us,
                    db_write_us: timing.db_write_us,
                });
        }
    }

    pub fn canonical_height(&self) -> u64 {
        self.engine.metrics.canonical_height.load(Ordering::Relaxed)
    }
}

/// Drive one peer's block streaming for a single pass of its session loop.
///
/// Returns true when the peer did block work, so the caller can keep looping
/// without falling through to its idle handling.
fn parse_inv_hashes(payload: &[u8]) -> Vec<[u8; 32]> {
    let mut i = 0usize;
    let Ok(count) = ycash_network::runtime::read_compact_size(payload, &mut i) else { return Vec::new() };
    let count = (count as usize).min(ycash_network::MAX_INV_SZ);
    let mut out = Vec::with_capacity(count);
    for _ in 0..count {
        if i.saturating_add(36) > payload.len() { break; }
        let kind = u32::from_le_bytes(payload[i..i + 4].try_into().unwrap());
        i += 4;
        let mut hash = [0u8; 32];
        hash.copy_from_slice(&payload[i..i + 32]);
        i += 32;
        if kind == 2 { out.push(hash); }
    }
    out
}

pub fn drive_peer(
    coordinator: &SyncCoordinator,
    stream: &mut TcpStream,
    session: &mut PeerDownloadSession,
    live: &SharedState,
    last_telemetry: &mut Instant,
) -> std::io::Result<bool> {
    let requested = coordinator.request_more(stream, session)?;
    if last_telemetry.elapsed() >= TELEMETRY_INTERVAL {
        coordinator.publish_telemetry(live);
        *last_telemetry = Instant::now();
    }
    if session.in_flight() == 0 {
        return Ok(requested > 0);
    }

    // Service whatever the peer has sent. One arrival frees one slot, which the
    // next call refills: there is no "wait for the batch" state.
    match read_message(stream) {
        Ok((cmd, payload)) => match cmd.as_str() {
            "block" => {
                coordinator.on_block(session, payload);
                Ok(true)
            }
            "ping" => {
                send(stream, "pong", &payload)?;
                Ok(true)
            }
            "notfound" => {
                // Release only the hashes explicitly returned by `notfound`.
                // Releasing the entire 48-block window here used to churn
                // unrelated requests and could repeatedly move the head claim
                // between peers without telling us which peer failed it.
                let hashes = parse_inv_hashes(&payload);
                for hash in &hashes {
                    let _ = session.release_hash(hash, "peer returned notfound for exact head request");
                }
                Ok(true)
            }
            _ => Ok(false),
        },
        Err(e) if crate::is_timeout(&e) => {
            session.expire_stale(session.ycash_stall_timeout());
            Ok(false)
        }
        Err(e) => Err(e),
    }
}
