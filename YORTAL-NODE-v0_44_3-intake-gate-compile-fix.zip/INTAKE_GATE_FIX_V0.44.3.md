# YORTAL v0.44.3 — intake-gate compile fix and tail-release fix

## CI failure (v0.44.2 build)
```
error[E0425]: cannot find value `tx` in this scope
  --> crates/node/src/verifier.rs:838:19
        Ok(Self { tx, metrics })
```
v0.44.2 renamed the network-facing sender to `intake_tx` but the constructor still
used `tx`. Fixed: `Ok(Self { tx: intake_tx, metrics })`. Everything else in the
workspace type-checked up to that point; the node crate stopped at this name
resolution error, so the rest of the new intake-gate code was reviewed by hand
(see below) rather than by the compiler.

## Logic bug found while reviewing the intake gate
`BatchAssembler::offer()` only looks for a complete window when a NEW block is
offered, and returns at most one batch. One arrival can complete several
consecutive batches (later batches may already be sitting complete, waiting only
for the earlier one). The 0.44.1 dispatcher drained them in an inner loop; the
0.44.2 intake gate did not. With all 64 claim slots occupied no further arrival can
come, so the remaining complete batches would wait for a block that cannot be
requested until they commit — a stall at the tail of the window (and at the end
of the chain).

Fix: `BatchAssembler::release_ready(next_height)` (new) releases the next complete
batch without a new block, and the intake gate loops on it after each `offer()`.

## Other small fixes
* `BatchAssembler::take(height)` (new): a second copy of a height already held now
  frees the older copy's lifecycle claim (if it was a different block) and
  decrements the queue counter instead of silently leaking both.
* Dispatcher: removed the now-unused `pending` map and `batch_id`.
* Telemetry gap height is 0 while the intake gate holds nothing.
* New unit test `assembler_drains_consecutive_complete_batches`.

## Not changed
Exact-16 batches, four verifier workers, single preparation worker, single
publisher, retry lane from v0.44.1.

## Known limitation (unchanged design)
Every stage requires a FULL 16-block batch, so at the chain tip the last <16 blocks
are not committed until 16 are available.

## Validation
`cargo` is not available in the packaging environment. Run
`cargo check --workspace --all-targets` and `cargo test -p ycash-node` in CI.
