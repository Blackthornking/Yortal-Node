//! Ordered batch pipeline.
//!
//! The canonical publication unit is exactly [`BATCH_BLOCKS`] blocks. The active
//! verifier path receives only complete contiguous batches from the intake gate;
//! state-dependent preparation and canonical publication still require the exact
//! contiguous N+1 .. N+16 window and publish it atomically in height order.
//!
//! The older helper types below remain useful for deterministic partition tests
//! and compatibility; the live `VerifierPool` scheduler receives only complete
//! assembled batches and reassembles verified results by height before publication.

use std::collections::BTreeMap;
use std::sync::Mutex;

use anyhow::Result;
use ycash_consensus::ProofBatch;
use ycash_state::prospective::SemanticBlock;

use crate::verifier::{verify_into_batch, RawBlock};

/// Blocks per batch, through every stage.
pub const BATCH_BLOCKS: usize = crate::PIPELINE_BATCH_SIZE;

/// Collects arrivals until a full contiguous batch exists.
///
/// Arrivals are unordered by nature: peers answer at different speeds and a
/// hedged head can arrive twice. The assembler turns that back into a strict
/// sequence, so no later stage ever sees a gap.
pub struct BatchAssembler {
    pending: Mutex<BTreeMap<u64, RawBlock>>,
    batch: usize,
}

impl BatchAssembler {
    pub fn new(batch: usize) -> Self {
        Self { pending: Mutex::new(BTreeMap::new()), batch: batch.max(1) }
    }

    pub fn len(&self) -> usize {
        self.pending.lock().map(|p| p.len()).unwrap_or(0)
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Forget everything. Part of a sync restart.
    pub fn clear(&self) -> Vec<[u8; 32]> {
        let Ok(mut pending) = self.pending.lock() else { return Vec::new() };
        let hashes = pending.values().map(|b| b.request.hash).collect();
        pending.clear();
        hashes
    }

    /// Drop anything at or below a height the chain has already passed.
    pub fn prune_below(&self, height: u64) -> Vec<[u8; 32]> {
        let Ok(mut pending) = self.pending.lock() else { return Vec::new() };
        let stale: Vec<u64> = pending.range(..height).map(|(h, _)| *h).collect();
        stale.iter().filter_map(|h| pending.remove(h)).map(|b| b.request.hash).collect()
    }

    /// Heights inside the current batch window that have not arrived.
    ///
    /// This is the authoritative "what is missing" list: the downloader asks
    /// for exactly these, and the batch cannot be released until the list is
    /// empty. A missing parent therefore cannot persist -- it is, by
    /// construction, always the first entry here and always being requested.
    pub fn missing_heights(&self, next_height: u64) -> Vec<u64> {
        let Ok(pending) = self.pending.lock() else { return Vec::new() };
        (0..self.batch as u64)
            .map(|offset| next_height + offset)
            .filter(|h| !pending.contains_key(h))
            .collect()
    }

    /// Offer an arrival. Returns a batch only once heights
    /// `next_height ..= next_height + batch - 1` are all present.
    ///
    /// A duplicate replaces the stored copy rather than being rejected: both
    /// are the same block by hash.
    pub fn offer(&self, block: RawBlock, next_height: u64) -> Option<Vec<RawBlock>> {
        let mut pending = self.pending.lock().ok()?;
        if block.request.height < next_height {
            return None;
        }
        pending.insert(block.request.height, block);
        Self::take_contiguous(&mut pending, next_height, self.batch)
    }

    /// Remove and return the block held for `height`, if any.
    pub fn take(&self, height: u64) -> Option<RawBlock> {
        let mut pending = self.pending.lock().ok()?;
        pending.remove(&height)
    }

    /// Release the next complete batch already held, without offering a new
    /// block. One arrival can complete several consecutive batches; this is how
    /// the caller drains the rest.
    pub fn release_ready(&self, next_height: u64) -> Option<Vec<RawBlock>> {
        let mut pending = self.pending.lock().ok()?;
        Self::take_contiguous(&mut pending, next_height, self.batch)
    }

    /// Release a short run. Used at the chain tip, where a full batch will
    /// never arrive because there are no more blocks to fill it.
    pub fn flush_partial(&self, next_height: u64) -> Option<Vec<RawBlock>> {
        let mut pending = self.pending.lock().ok()?;
        let available = Self::contiguous_len(&pending, next_height);
        if available == 0 {
            return None;
        }
        Self::take_contiguous(&mut pending, next_height, available)
    }

    fn contiguous_len(pending: &BTreeMap<u64, RawBlock>, next_height: u64) -> usize {
        let mut count = 0usize;
        let mut height = next_height;
        while pending.contains_key(&height) {
            count += 1;
            height += 1;
        }
        count
    }

    fn take_contiguous(
        pending: &mut BTreeMap<u64, RawBlock>,
        next_height: u64,
        want: usize,
    ) -> Option<Vec<RawBlock>> {
        if want == 0 || Self::contiguous_len(pending, next_height) < want {
            return None;
        }
        let mut batch = Vec::with_capacity(want);
        for offset in 0..want as u64 {
            batch.push(pending.remove(&(next_height + offset))?);
        }
        Some(batch)
    }
}

/// One verifier's slice of a batch.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Slice {
    /// Verifier index, 0-based. Slice `i` always holds lower heights than
    /// slice `i+1`.
    pub verifier: usize,
    pub start: usize,
    pub end: usize,
}

/// Split `len` blocks across `workers` verifiers as contiguous slices.
///
/// The remainder goes to the earliest verifiers, so sizes differ by at most
/// one and the lowest heights are never the ones left waiting.
pub fn split_slices(len: usize, workers: usize) -> Vec<Slice> {
    if len == 0 {
        return Vec::new();
    }
    let workers = workers.max(1).min(len);
    let base = len / workers;
    let extra = len % workers;
    let mut slices = Vec::with_capacity(workers);
    let mut start = 0usize;
    for verifier in 0..workers {
        let size = base + usize::from(verifier < extra);
        if size == 0 {
            continue;
        }
        slices.push(Slice { verifier, start, end: start + size });
        start += size;
    }
    slices
}

/// Result of verifying one batch.
pub struct VerifiedBatch {
    /// Semantically verified blocks, in height order.
    pub blocks: Vec<SemanticBlock>,
    /// The first failure, if any: (height, reason).
    pub rejected: Option<(u64, String)>,
}

/// Verify a whole batch: split by verifier, each slice verified in height
/// order, results reassembled in order.
///
/// Each slice carries its own Groth16 batch, so proofs are still batched. If a
/// slice's batch is rejected, that slice alone is re-verified block by block,
/// so the failure lands on the block that owns it.
pub fn verify_batch_in_order(blocks: Vec<RawBlock>, workers: usize, assume_valid: bool) -> VerifiedBatch {
    let slices = split_slices(blocks.len(), workers);
    let mut results: Vec<Option<Result<SemanticBlock>>> = (0..blocks.len()).map(|_| None).collect();

    std::thread::scope(|scope| {
        let mut handles = Vec::with_capacity(slices.len());
        for slice in &slices {
            let chunk = &blocks[slice.start..slice.end];
            handles.push((
                *slice,
                scope.spawn(move || verify_slice(chunk, assume_valid)),
            ));
        }
        for (slice, handle) in handles {
            let Ok(chunk_results) = handle.join() else { continue };
            for (offset, result) in chunk_results.into_iter().enumerate() {
                results[slice.start + offset] = Some(result);
            }
        }
    });

    // Reassemble in order, stopping at the first rejection: the batch commits
    // as a contiguous run, so nothing after a gap is usable.
    let mut out = Vec::with_capacity(results.len());
    let mut rejected = None;
    for (index, result) in results.into_iter().enumerate() {
        match result {
            Some(Ok(block)) => out.push(block),
            Some(Err(e)) => {
                let height = blocks.get(index).map(|b| b.request.height).unwrap_or(0);
                rejected = Some((height, e.to_string()));
                break;
            }
            None => break,
        }
    }
    VerifiedBatch { blocks: out, rejected }
}

/// One verifier's work: its slice, in height order, into one proof batch.
fn verify_slice(chunk: &[RawBlock], assume_valid: bool) -> Vec<Result<SemanticBlock>> {
    let mut proofs = ProofBatch::new();
    let mut out: Vec<Result<SemanticBlock>> = Vec::with_capacity(chunk.len());
    for block in chunk {
        out.push(verify_into_batch(clone_raw(block), assume_valid, &mut proofs));
    }
    if proofs.proofs() > 0 {
        if let Err((height, reason)) = proofs.finish() {
            eprintln!("[VERIFY] slice proof batch rejected at height {height} ({reason:?}); isolating");
            return chunk.iter().map(|b| verify_single(b, assume_valid)).collect();
        }
    }
    out
}

fn verify_single(block: &RawBlock, assume_valid: bool) -> Result<SemanticBlock> {
    let mut proofs = ProofBatch::new();
    let verified = verify_into_batch(clone_raw(block), assume_valid, &mut proofs)?;
    if proofs.proofs() > 0 {
        if let Err((height, reason)) = proofs.finish() {
            return Err(anyhow::anyhow!("block {height}: {reason:?}"));
        }
    }
    Ok(verified)
}

fn clone_raw(block: &RawBlock) -> RawBlock {
    RawBlock {
        request: block.request.clone(),
        raw: block.raw.clone(),
        source_peer: block.source_peer.clone(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn slices_are_contiguous_ordered_and_cover_the_batch() {
        for workers in 1..=8 {
            let slices = split_slices(BATCH_BLOCKS, workers);
            assert_eq!(slices[0].start, 0);
            assert_eq!(slices.last().unwrap().end, BATCH_BLOCKS);
            for pair in slices.windows(2) {
                assert_eq!(pair[0].end, pair[1].start);
                assert!(pair[0].verifier < pair[1].verifier);
            }
            let total: usize = slices.iter().map(|s| s.end - s.start).sum();
            assert_eq!(total, BATCH_BLOCKS);
        }
    }

    #[test]
    fn four_verifiers_split_sixteen_evenly() {
        let slices = split_slices(16, 4);
        assert_eq!(slices.len(), 4);
        for slice in &slices {
            assert_eq!(slice.end - slice.start, 4);
        }
    }

    #[test]
    fn a_remainder_goes_to_the_earliest_verifiers() {
        let sizes: Vec<usize> = split_slices(50, 4).iter().map(|s| s.end - s.start).collect();
        assert_eq!(sizes, vec![13, 13, 12, 12]);
    }

    #[test]
    fn assembler_will_not_release_a_batch_while_the_first_parent_is_missing() {
        fn raw(height: u64, hash: u8, prev: u8) -> RawBlock {
            let mut bytes = vec![0u8; 140];
            bytes[4..36].copy_from_slice(&[prev; 32]);
            RawBlock {
                request: crate::downloader::BlockRequest {
                    height,
                    hash: [hash; 32],
                    work: [0u8; 32],
                    median_time_past: 0,
                },
                raw: bytes,
                source_peer: "test".into(),
            }
        }

        let assembler = BatchAssembler::new(2);
        assert!(assembler.offer(raw(2, 2, 1), 1).is_none());
        let batch = assembler.offer(raw(1, 1, 0), 1).expect("parent arrival unlocks the contiguous window");
        assert_eq!(batch.iter().map(|b| b.request.height).collect::<Vec<_>>(), vec![1, 2]);
    }

    #[test]
    fn assembler_drains_consecutive_complete_batches() {
        fn raw(height: u64) -> RawBlock {
            RawBlock {
                request: crate::downloader::BlockRequest {
                    height,
                    hash: [height as u8; 32],
                    work: [0u8; 32],
                    median_time_past: 0,
                },
                raw: vec![0u8; 140],
                source_peer: "test".into(),
            }
        }

        // Batch 2 (heights 17..=32) is complete first; batch 1 completes last.
        let assembler = BatchAssembler::new(BATCH_BLOCKS);
        for height in 17..=(2 * BATCH_BLOCKS as u64) {
            assert!(assembler.offer(raw(height), 1).is_none());
        }
        for height in 2..=BATCH_BLOCKS as u64 {
            assert!(assembler.offer(raw(height), 1).is_none());
        }
        let first = assembler.offer(raw(1), 1).expect("batch 1 is complete");
        assert_eq!(first.len(), BATCH_BLOCKS);
        // Batch 2 is already complete and must be releasable with no new arrival.
        let second = assembler.release_ready(1 + BATCH_BLOCKS as u64).expect("batch 2 is complete");
        assert_eq!(second.first().unwrap().request.height, 1 + BATCH_BLOCKS as u64);
        assert!(assembler.release_ready(1 + 2 * BATCH_BLOCKS as u64).is_none());
        assert!(assembler.take(1).is_none());
    }

    #[test]
    fn assembler_requires_all_sixteen_before_release() {
        fn raw(height: u64) -> RawBlock {
            RawBlock {
                request: crate::downloader::BlockRequest {
                    height,
                    hash: [height as u8; 32],
                    work: [0u8; 32],
                    median_time_past: 0,
                },
                raw: vec![0u8; 140],
                source_peer: "test".into(),
            }
        }

        let assembler = BatchAssembler::new(BATCH_BLOCKS);
        for height in (2..=BATCH_BLOCKS as u64).rev() {
            assert!(assembler.offer(raw(height), 1).is_none());
        }
        let batch = assembler.offer(raw(1), 1).expect("all sixteen arrivals release exactly one batch");
        assert_eq!(batch.len(), BATCH_BLOCKS);
        assert_eq!(batch.first().unwrap().request.height, 1);
        assert_eq!(batch.last().unwrap().request.height, BATCH_BLOCKS as u64);
        assert!(batch.windows(2).all(|w| w[1].request.height == w[0].request.height + 1));
    }

    #[test]
    fn assembler_does_not_start_from_the_lowest_received_height() {
        fn raw(height: u64) -> RawBlock {
            RawBlock {
                request: crate::downloader::BlockRequest {
                    height,
                    hash: [height as u8; 32],
                    work: [0u8; 32],
                    median_time_past: 0,
                },
                raw: vec![0u8; 140],
                source_peer: "test".into(),
            }
        }

        let assembler = BatchAssembler::new(3);
        assert!(assembler.offer(raw(5), 4).is_none());
        assert_eq!(assembler.len(), 1);
    }
}
