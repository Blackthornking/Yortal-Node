# YORTAL v0.45.0 — strict intake gate, four queued batches, batch-only pipeline

The pipeline now matches the intended shape exactly:

```text
peers ──► INTAKE GATE ──► ready queue ──► 4 verify ──► 1 prepare ──► 1 commit
          1 worker        4 complete      workers      worker        worker
          sorts + holds   batches         all 16       expensive     publish
          until all 16                    required     work only     only
```

## What was wrong

### 1. The ready queue could never hold four batches
The download window was 64 lifecycle claims (`VERIFIER_QUEUE_CAPACITY = 16 × 4`),
but a claim is held from "requested from a peer" until "published or discarded".
In steady state the pipeline itself holds 32–48 of those claims (one batch being
verified, one being prepared, one being published), so the gate had at most one
or two batches' worth of window left. Four queued batches was arithmetically
impossible: the gate could only assemble the next batch *after* a commit freed
claims, so the network went idle during every verify/prepare/commit cycle.

The window is now derived from the batch structure instead of being a round
number:

| | batches | blocks |
|---|---|---|
| ready queue (`INTAKE_READY_BATCHES`) | 4 | 64 |
| in the pipeline (`PIPELINE_INFLIGHT_BATCHES`) | 3 | 48 |
| being assembled (`INTAKE_ASSEMBLY_BATCHES`) | 1 | 16 |
| **`VERIFIER_QUEUE_CAPACITY`** | **8** | **128** |

`crates/node/src/lib.rs` carries this as a comment and a unit test, so the
window cannot drift away from the batch layout again. This is the memory knob:
128 blocks are resident at peak. Halving `INTAKE_READY_BATCHES` halves the
queue's share.

### 2. The retry lane broke strictness
v0.44.1 added a side lane: when a later stage rejected a height, the
re-downloaded block was verified **on its own**, outside any batch, because the
dispatcher's barrier had already moved past it. That is exactly what the design
forbids — a single block going through the pipeline without its batch.

The retry lane is gone. Rejection now works the other way round:

* Any stage that rejects a block, rejects a batch, or fails to publish records
  the canonical tip + 1 and bumps a shared **epoch**.
* Every stage drops what it is holding above the tip and restarts from that
  height. The intake gate releases its held blocks' claims so they are fetched
  again.
* The replacement blocks come back through the gate and are re-verified as part
  of a **complete, ordered, full batch**, like every other height.

`PipelineReset` in `verifier.rs` is the whole mechanism; every batch carries the
epoch it was assembled in, and a stage discards any batch tagged with an older
one. There is no path by which a partial or lone block reaches a verifier.

### 3. A malformed batch killed the node
The dispatcher `return`ed on a batch-shape violation, terminating the thread.
Nothing restarts it, so the node stalled permanently with no error visible past
the first line. It now releases the batch and resets instead.

### 4. One rejected block let the other fifteen through
A verifier rejection was reported per block, and the surviving blocks of that
batch continued into the preparation stage's reordering map. Now a rejection
anywhere in a batch voids the whole batch: the preparation worker can only ever
receive a batch in which all 16 blocks verified.

### 5. The chain tail could never commit
Every stage required exactly 16 blocks, so the last <16 blocks of the chain were
never published — the node stopped up to 15 blocks short of the tip, forever.

The gate now detects the one case where a full batch is impossible: it holds
every remaining height up to the validated header tip, and nothing new has
arrived for 3 seconds. It then releases that short run, flagged `tail`. The run
is still strictly complete and contiguous — no height inside it is missing — it
is simply shorter than 16. This is the only place a batch is not 16 blocks, and
it only triggers at the actual end of the chain.

## Stage contracts

**Intake gate** (`yortal-16-block-intake-gate`, 1 worker) — the only producer of
work. Sorts unordered arrivals by height into a `BatchAssembler` and releases
`first..first+15` only when all sixteen are in hand. Drains consecutively: one
arrival can complete several batches that were waiting on an earlier one.
Duplicates below the barrier are released, not queued. Wakes every 250 ms so a
reset is honoured even with no traffic.

**Dispatcher + 4 verifier workers** — takes one complete batch, hands all its
blocks to the four shared workers (no worker owns a height lane), and waits for
**every** result before touching the next batch. A rejection or a worker panic
voids the batch and resets.

**1 state-preparation worker** — all expensive contextual/UTXO/script work for
one batch, via `prepare_commit_batch_owned`. Refuses any batch that does not
start at tip + 1. Waits for the commit acknowledgement before preparing the
next, because the next preparation must observe the state the previous batch
produced.

**1 commit worker** — `apply_prepared_commit` only: canonical tip/parent recheck
and the atomic RocksDB write. No parsing, UTXO discovery, script execution or
proof verification.

## Also fixed

* `semantic_queue` is decremented exactly once per submitted block, on every
  path (stale, replaced, reset, stale epoch, malformed, verified).
* `BatchAssembler::insert()` added: store without releasing, so the gate can
  store then drain. `offer()` (store-and-maybe-release) did both at once, which
  is why the tail-of-window drain needed a second method in 0.44.3.
* A poisoned assembler lock no longer leaks a lifecycle claim.
* `highest_semantically_verified_height`, `semantic_batches`,
  `semantic_verify_us` and `last_semantic_batch_blocks` are populated again; the
  dashboard's verify figures were dead after the 0.42 redesign.
* `SyncConfig::from_env` no longer contains clamps to `PIPELINE_BATCH_SIZE` that
  were unconditionally overwritten three lines later.
* `pipeline_retries` now counts pipeline resets.

## Not changed

Consensus rules, `semantic_verify`, `prepare_commit_batch_owned`,
`apply_prepared_commit`, the Ycash wire protocol, and the 16-blocks-in-transit
per-peer limit.

## Validation

`cargo` is not available in the packaging environment. Run on a Rust host:

```
cargo check --workspace --all-targets
cargo test -p ycash-node
```

New tests: `insert_never_releases_until_the_whole_window_is_present` (batch.rs),
`a_reset_moves_every_stage_to_the_same_height`,
`repeated_resets_back_off_but_a_publication_clears_the_streak`,
`the_ready_queue_holds_four_complete_batches` (verifier.rs),
`the_window_covers_every_batch_that_can_hold_claims_at_once` (lib.rs).
