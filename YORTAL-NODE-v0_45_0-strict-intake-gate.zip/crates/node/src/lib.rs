//! YORTAL synchronisation engine.
//!
//! ```text
//!   peers            intake gate          ready queue        verify        prepare      commit
//!   ┌────────┐      ┌─────────────┐      ┌───────────┐    ┌─────────┐   ┌────────┐   ┌────────┐
//!   │ blocks │ ───► │ 1 worker    │ ───► │ 4 complete│───►│ 4 crypto│──►│ 1 state│──►│ 1 batch│
//!   │ 16/peer│      │ sort + hold │      │ batches   │    │ workers │   │ worker │   │ writer │
//!   └────────┘      │ until all 16│      └───────────┘    └─────────┘   └────────┘   └────────┘
//!                   └─────────────┘        always ready     all 16      expensive    publish
//!                    no gaps leave                          required     work only    only
//! ```
//!
//! One worker, the intake gate, stands between the network and the pipeline. It
//! sorts unordered arrivals by height and releases a batch only once all 16 of
//! its blocks have been fetched and are in hand, so no stage below it ever sees
//! a gap. Four complete batches are queued behind it, so the verifiers always
//! have a full batch ready.
//!
//! Past the gate the batch is the only unit of work: four verifier workers take
//! its blocks in any order but every result is required before the next batch
//! starts; one worker does the expensive contextual/UTXO/script preparation;
//! one worker publishes the batch atomically and does nothing else.
//!
//! Nothing partial moves and nothing moves alone. If any stage rejects, the
//! whole batch is discarded and every stage resets to the canonical tip, so a
//! height that must be fetched again comes back inside a complete batch like
//! any other.

use std::sync::atomic::Ordering;
use std::sync::Arc;

use anyhow::{bail, Result};
use ycash_state::state_service::SyncMetrics;
use ycash_state::State;

pub mod batch;
pub mod downloader;
pub mod peer_manager;
pub mod verifier;

pub use downloader::{
    BlockAssigner, BlockRequest, HeadLifecycleTracker, HeadPhase, HeadSnapshot, HeadStatus, InFlightRegistry, PeerDownloadSession, MAX_BLOCKS_IN_FLIGHT,
    MAX_BLOCKS_IN_TRANSIT_PER_PEER, REQUEST_TIMEOUT, CANONICAL_PARENT_RETRY_TIMEOUT,
};
pub use peer_manager::{PeerManager, PeerStats};
pub use verifier::{RawBlock, VerifierPool, ASSUME_VALID_HASH_DISPLAY, ASSUME_VALID_HEIGHT};

/// Semantic verification threads: one per batch slice.
pub const VERIFIER_WORKERS: usize = 4;

/// Blocks per batch, through every stage: intake, verification, state
/// preparation and canonical publication. This is the unit of work.
pub const PIPELINE_BATCH_SIZE: usize = 16;

/// Complete batches the intake gate keeps queued ahead of verification, so the
/// four verifier workers always have a full batch waiting when they finish one.
pub const INTAKE_READY_BATCHES: usize = 4;

/// Batches inside the pipeline at once: one being verified, one waiting for the
/// preparation worker, one being prepared/published.
pub const PIPELINE_INFLIGHT_BATCHES: usize = 3;

/// Batches the gate may be assembling while the ready queue is full. Without
/// this the download window fills up with queued and in-pipeline batches and
/// the network sits idle until a commit frees claims.
pub const INTAKE_ASSEMBLY_BATCHES: usize = 1;

/// Block lifecycle claims, which is also the download window.
///
/// Every block between "requested from a peer" and "published or discarded"
/// holds one claim. The window has to cover all of them at once, or the gate
/// can never fill its ready queue:
///
/// ```text
///   ready queue        4 batches  (INTAKE_READY_BATCHES)
///   in the pipeline    3 batches  (verify, handoff, prepare/commit)
///   being assembled    1 batch    (INTAKE_ASSEMBLY_BATCHES)
///                    = 8 batches = 128 blocks
/// ```
///
/// This is the memory knob. 128 blocks are held in RAM at peak; halving
/// `INTAKE_READY_BATCHES` halves the queue's share of that.
pub const VERIFIER_QUEUE_CAPACITY: usize = PIPELINE_BATCH_SIZE
    * (INTAKE_READY_BATCHES + PIPELINE_INFLIGHT_BATCHES + INTAKE_ASSEMBLY_BATCHES);

/// Transparent script threads.
///
/// Script checks are captured by the ordered state-preparation walk and executed
/// asynchronously on the persistent shared pool. This keeps UTXO/Sprout/Sapling
/// mutation ordered while overlapping pure script work with later state work in
/// the same exact 16-block lifecycle window.
pub const SCRIPT_WORKERS: usize = 5;

/// Cores held for roles that must never wait: canonical publication and
/// header/peer I/O.
pub const RESERVED_CORES: usize = 2;

/// Transport and resource settings. None of these is a consensus parameter:
/// the same chain synchronised with any combination of them must produce the
/// same canonical state.
#[derive(Clone, Debug)]
pub struct SyncConfig {
    pub blocks_in_transit_per_peer: usize,
    pub max_blocks_in_flight: usize,
    pub prospective_capacity: usize,
    pub verifier_workers: usize,
    /// Transparent script verification threads.
    pub script_workers: usize,
    pub verifier_queue: usize,
    pub assume_valid: bool,
}

impl SyncConfig {
    /// How far above the canonical tip blocks may be requested.
    ///
    /// Held a margin below the candidate capacity so a full pipeline never
    /// evicts. The margin is one round of per-peer requests, which is the most
    /// that can land between two assignment passes.
    pub fn download_window(&self) -> usize {
        // One bounded global pipeline. Per-peer limits only divide the window;
        // they never multiply it.
        self.max_blocks_in_flight.min(self.prospective_capacity).max(1)
    }
}

impl Default for SyncConfig {
    fn default() -> Self {
        Self {
            blocks_in_transit_per_peer: PIPELINE_BATCH_SIZE,
            max_blocks_in_flight: VERIFIER_QUEUE_CAPACITY,
            prospective_capacity: VERIFIER_QUEUE_CAPACITY,
            // Default fixed roles: semantic verification has four worker lanes;
            // the canonical writer and Android/header housekeeping retain their
            // reserved roles. Transparent script work uses the persistent Rayon
            // pool concurrently during contextual preparation.
            verifier_workers: VERIFIER_WORKERS,
            script_workers: SCRIPT_WORKERS,
            verifier_queue: VERIFIER_QUEUE_CAPACITY,
            assume_valid: false,
        }
    }
}

impl SyncConfig {
    /// Read the transport settings from the environment, so they can be changed
    /// on a device without rebuilding. Consensus cannot be changed this way.
    pub fn from_env() -> Self {
        let mut cfg = Self::default();
        if let Some(v) = env_usize("YORTAL_BLOCKS_IN_TRANSIT_PER_PEER") {
            cfg.blocks_in_transit_per_peer = v.clamp(1, PIPELINE_BATCH_SIZE);
        }
        // Claims cover transport, the intake gate, verification, preparation
        // and publication together. The window is derived from the batch
        // structure rather than from the number of peers, so it is not an
        // independent setting: the values below are fixed on purpose, and the
        // environment cannot widen one stage on its own and starve another.
        cfg.blocks_in_transit_per_peer = PIPELINE_BATCH_SIZE;
        cfg.max_blocks_in_flight = VERIFIER_QUEUE_CAPACITY;
        cfg.prospective_capacity = VERIFIER_QUEUE_CAPACITY;
        cfg.verifier_queue = VERIFIER_QUEUE_CAPACITY;
        if let Some(v) = env_usize("YORTAL_VERIFY_THREADS") {
            // 0 is the documented automatic mode. Do not clamp it to 1: that
            // silently disabled the device-derived verifier width on Android.
            cfg.verifier_workers = if v == 0 {
                VERIFIER_WORKERS
            } else {
                v.clamp(1, 64)
            };
        }
        cfg.assume_valid = std::env::var("YCASH_ASSUME_VALID").ok().as_deref() == Some("1")
            && std::env::var("YCASH_FULL_VERIFY").ok().as_deref() != Some("1");
        cfg
    }
}

fn env_usize(name: &str) -> Option<usize> {
    std::env::var(name).ok().and_then(|v| v.trim().parse::<usize>().ok())
}

/// Everything the peer threads need, started once per process.
#[derive(Clone)]
pub struct SyncEngine {
    pub state: Arc<State>,
    pub peers: Arc<PeerManager>,
    pub registry: Arc<InFlightRegistry>,
    pub assigner: Arc<BlockAssigner>,
    pub verifiers: VerifierPool,
    pub metrics: Arc<SyncMetrics>,
    pub config: SyncConfig,
}

impl SyncEngine {
    /// The height the ordered pipeline needs next. Everything is anchored to this
    /// height: the resource window, download requests and verifier frontier.
    pub fn next_height(&self) -> u64 {
        self.state.tip_height().ok().flatten().unwrap_or(0) + 1
    }

    /// Heights in the bounded download window that are not already claimed.
    ///
    /// Verification is intentionally asynchronous now: a block can move from
    /// transport directly into the verifier coordinator without being copied
    /// into a second "16 must be full" assembler. Lifecycle claims are the
    /// source of truth for whether a height is already in transit, waiting in
    /// verification, or held by the preparation/commit stages.
    pub fn missing_heights(&self) -> Vec<u64> {
        let header_tip = self.header_tip();
        let start = self.next_height();
        let end = header_tip.min(start.saturating_add(self.config.download_window().saturating_sub(1) as u64));
        if start > end {
            return Vec::new();
        }

        (start..=end)
            .filter_map(|height| match self.assigner.request_at_height(height) {
                Ok(Some(request)) if !self.registry.is_claimed(&request.hash) => Some(height),
                _ => None,
            })
            .collect()
    }

    /// Highest validated header, read from the database rather than from a
    /// counter someone remembered to update.
    ///
    /// The dashboard reported HDR 0 while the chain was at 192 because the
    /// header height was only ever written by the header-sync routine; if that
    /// returned early, the figure stayed stale. Reading state makes it true by
    /// construction.
    pub fn header_tip(&self) -> u64 {
        let tip = self.state.header_height().ok().flatten().unwrap_or(0);
        self.metrics.raise_header_height(tip);
        tip
    }

    /// Whether block download is waiting on the header chain rather than on a
    /// peer. These need opposite responses, so they must not look alike: one
    /// wants another peer asked, the other wants header sync resumed.
    pub fn awaiting_headers(&self) -> bool {
        self.header_tip() < self.next_height()
    }

    /// Start the cryptographic verifier, one expensive state-preparation worker,
    /// and one canonical batch-commit worker.
    pub fn start(state: Arc<State>, config: SyncConfig) -> Result<Self> {
        // Size the script pool with the verifiers rather than letting each
        // assume it owns the device.
        ycash_state::chainstate::set_script_worker_budget(config.script_workers);
        let metrics = SyncMetrics::new();
        // One lifecycle registry spans transport, cryptographic verification,
        // expensive state preparation and canonical publication. The dedicated
        // preparation/commit stages release entries only after their batch has
        // been resolved.
        let registry = Arc::new(InFlightRegistry::new(config.max_blocks_in_flight));
        let verifiers = VerifierPool::spawn(
            config.verifier_workers,
            config.verifier_queue,
            Arc::clone(&state),
            Arc::clone(&metrics),
            Arc::clone(&registry),
            config.assume_valid,
        )?;
        let assigner = Arc::new(BlockAssigner::new(
            Arc::clone(&state),
            Arc::clone(&registry),
            Arc::clone(&metrics),
            // Strictly *less* than the candidate set can hold.
            //
            // Every claimed block is either in transit or buffered, and every
            // claim lies inside this window, so buffered <= window. Keeping the
            // window below capacity therefore means eviction never happens at
            // all. Setting the two equal — which is what this was — guarantees
            // the opposite: the buffer sits permanently at capacity, every
            // arrival evicts a block, the eviction frees that block's claim,
            // and it is immediately re-requested. The chain still advances, in
            // bursts, while a large share of the bandwidth goes on re-fetching
            // blocks that were thrown away.
            config.download_window(),
        ));
        assigner.rewind_to_canonical()?;
        let peers = Arc::new(PeerManager::new());
        if let Ok(Some(tip)) = state.tip_height() {
            metrics
                .canonical_height
                .store(tip, std::sync::atomic::Ordering::Relaxed);
        }
        Ok(Self { state, peers, registry, assigner, verifiers, metrics, config })
    }

    /// Per-peer request window.
    pub fn session(&self, peer: &str) -> PeerDownloadSession {
        PeerDownloadSession::new(
            peer,
            Arc::clone(&self.assigner),
            Arc::clone(&self.registry),
            Arc::clone(&self.peers),
            Arc::clone(&self.metrics),
        )
        .with_limit(self.config.blocks_in_transit_per_peer)
    }

    /// Run the transport-level canonical-head watchdog independently of peer
    /// socket loops. This matters on Android because a peer thread can be
    /// blocked in a socket read while the exact tip+1 request is stalled.
    /// Releasing/nominating the claim here does not touch consensus state; the
    /// next responsive peer will pick the head up on its normal request pass.
    pub fn watchdog_head_once(&self) -> Result<bool> {
        let canonical = self.assigner.canonical_height()?;
        let next_height = canonical.saturating_add(1);
        let Some(hash) = self.assigner.header_hash(next_height)? else { return Ok(false) };
        self.registry.set_head_target(next_height, hash);
        match self.registry.head_status(&hash) {
            HeadStatus::Free => {
                // The watchdog is also able to recover a completely unclaimed
                // head. It reserves the hash for a healthy connected peer; the
                // peer's normal assignment pass performs the actual getdata.
                let Some(peer) = self.peers.best_peer() else { return Ok(false) };
                let alternates = self.peers.peer_count() > 1;
                if !self.registry.reserve_head(hash, &peer, alternates) { return Ok(false); }
                self.metrics.set_missing_parent_in_flight(false);
                self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
                self.metrics.mark_parent_retry();
                self.metrics.trace_head(peer, "WATCHDOG_RESERVE", next_height, Some(hash), "head was free; watchdog nominated a peer for recovery");
                let _ = self.assigner.rewind_to_canonical();
                Ok(true)
            }
            HeadStatus::Reserved { .. } => {
                // A peer is already nominated and has not yet issued getdata.
                // The hand-off window is short; if it lapses the head reads as
                // Free again and the next watchdog tick nominates a peer.
                Ok(false)
            }
            HeadStatus::Transport { owner, age } => {
                let timeout = self.registry.head_retry_timeout(&hash, CANONICAL_PARENT_RETRY_TIMEOUT);
                if age < timeout { return Ok(false); }
                let alternate = self.peers.best_alternate(&owner);
                if !self.registry.reassign_head(&hash, &owner, alternate.clone()) { return Ok(false); }
                self.peers.update(&owner, |s| s.timeouts = s.timeouts.saturating_add(1));
                self.metrics.set_missing_parent_in_flight(false);
                self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                self.metrics.expired_requests.fetch_add(1, Ordering::Relaxed);
                self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
                self.metrics.mark_parent_retry();
                self.metrics.trace_head(owner.clone(), "WATCHDOG_REASSIGN", next_height, Some(hash), format!("head request exceeded {}s outside peer loop; next_peer={}", timeout.as_secs(), alternate.as_deref().unwrap_or("none")));
                let _ = self.assigner.rewind_to_canonical();
                Ok(true)
            }
            HeadStatus::Lifecycle { age } => {
                if age < downloader::HEAD_LIFECYCLE_TIMEOUT { return Ok(false); }
                if !self.registry.break_stale_lifecycle(&hash, downloader::HEAD_LIFECYCLE_TIMEOUT) { return Ok(false); }
                let Some(peer) = self.peers.best_peer() else { return Ok(true) };
                let alternates = self.peers.peer_count() > 1;
                let _ = self.registry.reserve_head(hash, &peer, alternates);
                self.metrics.set_missing_parent_in_flight(false);
                self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
                self.metrics.mark_parent_retry();
                self.metrics.trace_head(peer, "WATCHDOG_LIFECYCLE_RECOVERY", next_height, Some(hash), format!("head lifecycle stalled for {}s; lifecycle claim reset", age.as_secs()));
                let _ = self.assigner.rewind_to_canonical();
                Ok(true)
            }
        }
    }

    /// Handle one `block` message: match it to an outstanding request, free the
    /// slot and queue it for semantic verification.
    ///
    /// A block nobody asked for is ignored rather than trusted, and an unknown
    /// hash is never counted against the peer's window.
    pub fn on_block_message(&self, session: &mut PeerDownloadSession, raw: Vec<u8>) -> Result<bool> {
        let Some(hash) = block_hash(&raw) else { return Ok(false) };
        let bytes = raw.len();
        let Some(request) = session.on_block(&hash, bytes) else { return Ok(false) };
        let source_peer = session.peer().to_string();
        let block = RawBlock { request: request.clone(), raw, source_peer };

        // Never verify synchronously on the peer/socket thread. The verifier
        // coordinator owns the ordered-parent barrier and will only dispatch a
        // contiguous prefix beginning at canonical+1. A child received before
        // its parent therefore stays buffered, but the network remains free to
        // service the parent request and other peers.
        // Backpressure is deliberate: a full verifier window must stop the
        // producer, never discard a block. In particular the canonical head
        // must never be released merely because verifier ingress is full.
        if let Err(e) = self.verifiers.submit(block) {
            // Only a stopped verifier is a terminal transport error.
            // The normal Full condition is impossible here because submit()
            // blocks until the bounded coordinator accepts the block.
            self.registry.release(&request.hash);
            return Err(e);
        }
        Ok(true)
    }

    /// Hashes to put in the next `getdata`, refilling the peer's window.
    pub fn next_requests(&self, session: &mut PeerDownloadSession) -> Result<Vec<[u8; 32]>> {
        // The canonical parent is special: later blocks cannot be committed
        // around it, so do not make tip+1 wait for the normal 90s transport
        // timeout. A short head retry lets another peer take over quickly.
        session.retry_canonical_parent(CANONICAL_PARENT_RETRY_TIMEOUT)?;
        session.expire_stale(session.ycash_stall_timeout());

        // Ask for exactly what the current batch is missing, lowest height
        // first. The head is therefore always the first request issued, and no
        // speculative work can occupy the window ahead of it.
        // Headers first: without them there is nothing to request, and the
        // node should say so instead of reporting a missing parent.
        if self.awaiting_headers() {
            self.metrics.set_missing_parent_in_flight(false);
            return Ok(Vec::new());
        }

        let missing = self.missing_heights();
        if missing.is_empty() {
            return Ok(Vec::new());
        }
        session.top_up_heights(&missing)
    }

    /// Record an exact canonical-head transport event for diagnostics.
    pub fn trace_head(&self, peer: impl Into<String>, event: impl Into<String>, height: u64, hash: Option<[u8; 32]>, detail: impl Into<String>) {
        self.metrics.trace_head(peer, event, height, hash, detail);
    }

    /// The active sync path has no separate state-service thread. Header
    /// advancement is observed directly by the downloader/verifier stages, so
    /// there is no gate thread to poke. Kept as a compatibility no-op for
    /// callers that used the old state-gate API.
    pub fn poke(&self) {}
}

/// Block hash: double SHA-256 over the header including its Equihash solution.
pub fn block_hash(raw: &[u8]) -> Option<[u8; 32]> {
    use sha2::{Digest, Sha256};
    let mut cursor = 140usize;
    let solution_len = read_compact_size(raw, &mut cursor)? as usize;
    let end = cursor.checked_add(solution_len)?;
    let header = raw.get(..end)?;
    let digest = Sha256::digest(Sha256::digest(header));
    let mut out = [0u8; 32];
    out.copy_from_slice(&digest);
    Some(out)
}

fn read_compact_size(raw: &[u8], cursor: &mut usize) -> Option<u64> {
    let first = *raw.get(*cursor)?;
    *cursor += 1;
    let value = match first {
        0xfd => {
            let v = u16::from_le_bytes(raw.get(*cursor..*cursor + 2)?.try_into().ok()?) as u64;
            *cursor += 2;
            v
        }
        0xfe => {
            let v = u32::from_le_bytes(raw.get(*cursor..*cursor + 4)?.try_into().ok()?) as u64;
            *cursor += 4;
            v
        }
        0xff => {
            let v = u64::from_le_bytes(raw.get(*cursor..*cursor + 8)?.try_into().ok()?);
            *cursor += 8;
            v
        }
        n => n as u64,
    };
    Some(value)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transport_settings_stay_inside_their_bounds() {
        let cfg = SyncConfig::default();
        assert_eq!(cfg.blocks_in_transit_per_peer, 16);
        assert_eq!(cfg.max_blocks_in_flight, VERIFIER_QUEUE_CAPACITY);
        assert_eq!(cfg.prospective_capacity, VERIFIER_QUEUE_CAPACITY);
        assert_eq!(cfg.download_window(), VERIFIER_QUEUE_CAPACITY);
        assert_eq!(cfg.verifier_queue, VERIFIER_QUEUE_CAPACITY);
        assert_eq!(cfg.verifier_workers, VERIFIER_WORKERS);
        assert_eq!(cfg.script_workers, SCRIPT_WORKERS);
        // Four verifier lanes plus the two reserved roles and one remaining
        // housekeeping slot. The exact runtime CPU availability is device-specific.
        assert_eq!(VERIFIER_WORKERS + RESERVED_CORES + 1, 7);
        assert!(SCRIPT_WORKERS <= VERIFIER_WORKERS + 1);
    }

    #[test]
    fn the_window_covers_every_batch_that_can_hold_claims_at_once() {
        // Queued + in-pipeline + assembling. If the window were any smaller the
        // gate could not fill its ready queue: every claim would already be
        // held by a batch further down the pipeline, and the network would go
        // idle until a commit released some.
        assert_eq!(PIPELINE_BATCH_SIZE, 16);
        assert_eq!(INTAKE_READY_BATCHES, 4);
        assert_eq!(VERIFIER_QUEUE_CAPACITY, 16 * 8);
        assert!(
            VERIFIER_QUEUE_CAPACITY
                > PIPELINE_BATCH_SIZE * (INTAKE_READY_BATCHES + PIPELINE_INFLIGHT_BATCHES)
        );
    }

    #[test]
    fn compact_size_decodes_every_width() {
        let mut c = 0;
        assert_eq!(read_compact_size(&[0x10], &mut c), Some(0x10));
        c = 0;
        assert_eq!(read_compact_size(&[0xfd, 0x01, 0x02], &mut c), Some(0x0201));
        c = 0;
        assert_eq!(read_compact_size(&[0xfe, 1, 0, 0, 0], &mut c), Some(1));
    }
}
