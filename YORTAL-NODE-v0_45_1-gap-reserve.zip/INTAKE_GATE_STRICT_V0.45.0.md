# YORTAL v0.45.0 — strict intake gate, four queued batches, batch-only pipeline

The pipeline now matches the intended shape exactly:

```text
peers ──► INTAKE GATE ──► ready queue ──► 4 verify ──► 1 prepare ──► 1 commit
          1 worker        4 complete      workers      worker        worker
          sorts + holds   batches         all 16       expensive     publish
          until all 16                    required     work only     only
```

## What was wrong

### 1. The ready queue could never hold four batches
The download window was 64 lifecycle claims (`VERIFIER_QUEUE_CAPACITY = 16 × 4`),
but a claim is held from "requested from a peer" until "published or discarded".
In steady state the pipeline itself holds 32–48 of those claims (one batch being
verified, one being prepared, one being published), so the gate had at most one
or two batches' worth of window left. Four queued batches was arithmetically
impossible: the gate could only assemble the next batch *after* a commit freed
claims, so the network went idle during every verify/prepare/commit cycle.

The window is now derived from the batch structure instead of being a round
number:

| | batches | blocks |
|---|---|---|
| ready queue (`INTAKE_READY_BATCHES`) | 4 | 64 |
| in the pipeline (`PIPELINE_INFLIGHT_BATCHES`) | 3 | 48 |
| being assembled (`INTAKE_ASSEMBLY_BATCHES`) | 1 | 16 |
| **`VERIFIER_QUEUE_CAPACITY`** | **8** | **128** |

`crates/node/src/lib.rs` carries this as a comment and a unit test, so the
window cannot drift away from the batch layout again. This is the memory knob:
128 blocks are resident at peak. Halving `INTAKE_READY_BATCHES` halves the
queue's share.

### 2. The retry lane broke strictness
v0.44.1 added a side lane: when a later stage rejected a height, the
re-downloaded block was verified **on its own**, outside any batch, because the
dispatcher's barrier had already moved past it. That is exactly what the design
forbids — a single block going through the pipeline without its batch.

The retry lane is gone. Rejection now works the other way round:

* Any stage that rejects a block, rejects a batch, or fails to publish records
  the canonical tip + 1 and bumps a shared **epoch**.
* Every stage drops what it is holding above the tip and restarts from that
  height. The intake gate releases its held blocks' claims so they are fetched
  again.
* The replacement blocks come back through the gate and are re-verified as part
  of a **complete, ordered, full batch**, like every other height.

`PipelineReset` in `verifier.rs` is the whole mechanism; every batch carries the
epoch it was assembled in, and a stage discards any batch tagged with an older
one. There is no path by which a partial or lone block reaches a verifier.

### 3. A malformed batch killed the node
The dispatcher `return`ed on a batch-shape violation, terminating the thread.
Nothing restarts it, so the node stalled permanently with no error visible past
the first line. It now releases the batch and resets instead.

### 4. One rejected block let the other fifteen through
A verifier rejection was reported per block, and the surviving blocks of that
batch continued into the preparation stage's reordering map. Now a rejection
anywhere in a batch voids the whole batch: the preparation worker can only ever
receive a batch in which all 16 blocks verified.

### 5. The chain tail could never commit
Every stage required exactly 16 blocks, so the last <16 blocks of the chain were
never published — the node stopped up to 15 blocks short of the tip, forever.

The gate now detects the one case where a full batch is impossible: it holds
every remaining height up to the validated header tip, and nothing new has
arrived for 3 seconds. It then releases that short run, flagged `tail`. The run
is still strictly complete and contiguous — no height inside it is missing — it
is simply shorter than 16. This is the only place a batch is not 16 blocks, and
it only triggers at the actual end of the chain.

## Stage contracts

**Intake gate** (`yortal-16-block-intake-gate`, 1 worker) — the only producer of
work. Sorts unordered arrivals by height into a `BatchAssembler` and releases
`first..first+15` only when all sixteen are in hand. Drains consecutively: one
arrival can complete several batches that were waiting on an earlier one.
Duplicates below the barrier are released, not queued. Wakes every 250 ms so a
reset is honoured even with no traffic.

**Dispatcher + 4 verifier workers** — takes one complete batch, hands all its
blocks to the four shared workers (no worker owns a height lane), and waits for
**every** result before touching the next batch. A rejection or a worker panic
voids the batch and resets.

**1 state-preparation worker** — all expensive contextual/UTXO/script work for
one batch, via `prepare_commit_batch_owned`. Refuses any batch that does not
start at tip + 1. Waits for the commit acknowledgement before preparing the
next, because the next preparation must observe the state the previous batch
produced.

**1 commit worker** — `apply_prepared_commit` only: canonical tip/parent recheck
and the atomic RocksDB write. No parsing, UTXO discovery, script execution or
proof verification.

## Also fixed

* `semantic_queue` is decremented exactly once per submitted block, on every
  path (stale, replaced, reset, stale epoch, malformed, verified).
* `BatchAssembler::insert()` added: store without releasing, so the gate can
  store then drain. `offer()` (store-and-maybe-release) did both at once, which
  is why the tail-of-window drain needed a second method in 0.44.3.
* A poisoned assembler lock no longer leaks a lifecycle claim.
* `highest_semantically_verified_height`, `semantic_batches`,
  `semantic_verify_us` and `last_semantic_batch_blocks` are populated again; the
  dashboard's verify figures were dead after the 0.42 redesign.
* `SyncConfig::from_env` no longer contains clamps to `PIPELINE_BATCH_SIZE` that
  were unconditionally overwritten three lines later.
* `pipeline_retries` now counts pipeline resets.

## Not changed

Consensus rules, `semantic_verify`, `prepare_commit_batch_owned`,
`apply_prepared_commit`, the Ycash wire protocol, and the 16-blocks-in-transit
per-peer limit.

## Validation

`cargo` is not available in the packaging environment. Run on a Rust host:

```
cargo check --workspace --all-targets
cargo test -p ycash-node
```

New tests: `insert_never_releases_until_the_whole_window_is_present` (batch.rs),
`a_reset_moves_every_stage_to_the_same_height`,
`repeated_resets_back_off_but_a_publication_clears_the_streak`,
`the_ready_queue_holds_four_complete_batches` (verifier.rs),
`the_window_covers_every_batch_that_can_hold_claims_at_once` (lib.rs).

---

# v0.45.1 — the window and the claim capacity must not be the same number

## Symptom
Sync ran, then stopped dead. Dashboard at the stall:

```
HDR 127840 · DL 10768 · SEM 10640 · CTX 10640 · COM 10640
Global in-flight cap 128 · In-flight blocks 11 · Validation queue 117
Verifier workers 0 · Last commit 21s ago
Pipeline: waiting for block 10653 to complete the 16-block batch ·
117 block(s) held (network wait, not validation)
BOTTLENECK: FETCH / BATCH GAP
```

## Root cause
117 held + 11 in flight = 128 = the entire claim capacity. Zero spare.

Every lifecycle claim sits at a height inside the download window, and v0.45.0
set the window and the claim capacity to the same number (128). So the gate was
able to hold almost the whole window — heights 10641…10768, everything except
10653 — while waiting for that one missing block. With no claim slot free, the
assigner could not issue a request for 10653. It is returned by
`missing_heights()` every pass and rejected by `InFlightRegistry::claim()` every
pass, because `claims.len() >= capacity`.

The gate waits for a block that cannot be requested until the gate lets go, and
the gate does not let go until the block arrives. Permanent, silent, and it
reports itself as a network wait because from the gate's point of view that is
exactly what it looks like.

This is the same trap the old `BlockAssigner` comment warned about for the
prospective buffer. It came back because the claim window was sized to the
batch layout and nothing was left over.

## Fix
Separate the two numbers:

| | |
|---|---|
| `BLOCK_DOWNLOAD_WINDOW` | 128 (8 batches — unchanged lookahead) |
| `GAP_RESERVE_BLOCKS` | 16 (one batch) |
| `VERIFIER_QUEUE_CAPACITY` (claim capacity) | 144 |

Since every claim is at a height in the window, `held + in_pipeline + in_flight
≤ window < capacity`, so at least 16 slots are always free for the lowest
missing heights — which is the order `missing_heights()` returns them in. A gap
can always be fetched.

Memory is unchanged: the reserve is claim slots, not resident blocks. The gate
still holds at most 128.

`SyncConfig::download_window()` now derives itself as `max_blocks_in_flight −
GAP_RESERVE_BLOCKS`, so the two cannot be set equal by accident again, and
`the_claim_capacity_always_exceeds_the_download_window` asserts it.

The dashboard will now read `cap 144 · lookahead 128`.

## Liveness valve
The arithmetic above says the stall cannot recur, but the consequence of being
wrong is a node that never moves and does not say so. The gate therefore checks
directly: if it is holding a gap and `spare_capacity() == 0` continuously for 20
seconds, it drops the blocks furthest from the tip (one batch worth), releases
their claims, and logs `GAP_STARVATION`. The furthest-ahead blocks are the least
useful thing it is holding, and they will be re-fetched.
