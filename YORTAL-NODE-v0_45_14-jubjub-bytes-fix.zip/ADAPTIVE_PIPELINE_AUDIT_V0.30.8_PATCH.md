# YORTAL v0.30.8 adaptive pipeline audit / patch

## Findings and fixes

1. **Verifier receive serialization:** every verifier held a mutex around blocking `Receiver::recv()`. When the queue was empty, one worker could hold the receiver mutex while waiting, preventing other workers from receiving newly queued jobs. The verifier loop now uses short `try_recv()` polling, so the fixed pool can actually consume jobs concurrently.
2. **Adaptation was commit-driven:** Android worker/window adaptation was updated mainly after a successful commit. A long validation, DB, or network stall could therefore retain the old budget. A 500 ms adaptive sampler now updates worker, range, and in-flight budgets continuously.
3. **Range size was not actually adaptive:** the planner always used `max_range_len` (100), even when the adaptive window shrank. The active range is now `min(current_window, max_range_len)`, so pressure changes request size as well as lookahead. The dashboard now shows the active range separately from its 100-block ceiling.
4. **Commit batch was frozen at startup:** the committer captured its maximum batch once. It now reads the current adaptive window every scheduling pass, so commit batch size follows pressure.
5. **Network pressure was ignored:** the Android commit observation used `network_ratio = 0.0`, so the network stage could never influence the adaptive controller. Peer starvation / no leased work conditions now feed network pressure, and the live dashboard exposes it.
6. **The 7-worker ceiling is device-derived:** `available_parallelism().saturating_sub(1).max(1)` is retained. On an 8-core device this gives 7 adaptive validation workers.
7. **CPU budget was previously duplicated across stages:** the pipeline verifier and the ordered commit's persistent Rayon script pool could each use cores-1 independently. A shared script-execution gate now divides the single cores-1 active CPU budget between those stages dynamically. The persistent Rayon pool remains fixed to avoid thread churn, but only the currently allocated number of script jobs may execute at once.

## Screenshot diagnosis

The supplied captures show state validation dominated by **TX connect**, at about **90.5% (31.34 ms)** and **91.8% (50.28 ms)** in the two views. Within TX connect, script checks account for essentially all of that measured time, while the script verifier reports 7 workers. That means simply raising the worker ceiling is not enough to remove the observed bottleneck.

The second important signal is **AVG FULL COMMIT ~212.8 ms**. The script pool is now also budgeted against the same device-wide CPU allowance, so the commit stage cannot silently add another cores-1 CPU workload on top of the pipeline verifier. Because canonical state mutation is intentionally one ordered writer, this can become the pipeline barrier even while validation work is parallel. The new pipeline telemetry separates CPU, memory, DB/commit, network, and validation-queue pressure so the live bottleneck can be identified instead of inferred from one timing category.

The network screenshot showing **8 peers** and `HANDSHAKE: waiting for peer (16s)` does not by itself prove the block pipeline is stalled: other pipeline telemetry shows active verification. The new stage telemetry is designed to distinguish handshake/network starvation from validation or ordered-commit head-of-line blocking.

## Consensus safety

These changes modify scheduling, backpressure, range sizing, worker activation, and diagnostics only. They do not skip heights, reorder canonical commits, change consensus predicates, or allow an unverified range into `commit_blocks_batch()`. Range overlap protection and the ordered commit barrier remain in place.

## Build limitation

Cargo is not installed in the audit environment, so a native `cargo check` could not be run here. The patch should therefore be treated as source-audited but **not build-verified** until the existing CI workflow runs workspace tests and the Android ARM64 build.
