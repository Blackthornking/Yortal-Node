# YORTAL v0.30.8 — Fully Adaptive Pipeline

## CPU policy
The native pipeline derives its CPU ceiling from `std::thread::available_parallelism()`.
One logical CPU is reserved for Android/process housekeeping. The remaining CPUs are
the maximum validation/script-verification budget.

For an 8-core device:
- maximum validation workers: 7
- maximum persistent transparent-script verifier threads: 7
- adaptive worker count may fall below 7 when CPU, memory, DB, or validation pressure rises.

The old fixed 4-worker ceiling has been removed.

## Adaptive stages
- Header/block range window: adaptive, 16..2000 lookahead window.
- Per-network range length: adaptive up to the existing 100-block scheduler ceiling.
- In-flight ranges: device-derived ceiling (`2 * (cores - 1)` by default), then pressure-adapted.
- Block validation workers: device-derived ceiling (`cores - 1`), then pressure-adapted.
- Transparent script verification: persistent Rayon pool sized to the same device ceiling,
  with work stealing; no first-transaction 1/2/4-thread lock-in.
- Ordered SQLite commit batch: follows the current adaptive window (1..512 cap), while
  canonical commits remain strictly height ordered.
- Backpressure/lookahead: derived from the current adaptive window and in-flight budget.

## Consensus boundary
Adaptive scheduling does not alter consensus rules. It changes only how many independent
ranges/checks are processed concurrently and how much work is buffered. Canonical state
mutation remains ordered, and the existing full-validation path remains authoritative.
