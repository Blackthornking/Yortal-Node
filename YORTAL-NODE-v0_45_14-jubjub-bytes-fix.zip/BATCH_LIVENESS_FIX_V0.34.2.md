# YORTAL v0.34.2 — ordered batch liveness and RocksDB stall fix

## Fixed

- The 48-block verifier coordinator now retains out-of-order arrivals by height.
- A higher block is never discarded merely because an earlier height has not arrived yet.
- Verification dispatch occurs only from a contiguous ancestry window.
- A smaller batch is allowed only when it reaches the known header tip.
- The old `claimed == batch.len()` tail condition is removed; global lifecycle occupancy no longer controls batch completeness.
- The lifecycle watchdog remains transport-only; verifying/verified claims are not stolen by transport recovery.
- RocksDB background work is increased and L0 slowdown/stop thresholds are explicitly configured to expose and control compaction pressure.

## Failure that this prevents

`H+1, H+2, H+4...` arriving before `H+3` no longer causes the higher blocks to be rejected as a malformed batch. They remain buffered until `H+3` arrives, after which the contiguous window can be dispatched.

This separates:

- transport/lifecycle ownership,
- batch completeness, and
- canonical state availability.

The state layer may still report a genuinely absent canonical candidate, but it no longer receives that condition merely because the verifier assembled an out-of-order set.
