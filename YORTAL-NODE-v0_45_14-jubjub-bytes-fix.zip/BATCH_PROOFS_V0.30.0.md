# YORTAL v0.30.0 — batch proof verification

No consensus rule added, removed or reordered. bellman stays at 0.8.

## Where the time went
- Verify stage: every Sapling Spend/Output Groth16 proof ran its own
  4-pairing check (bellman 0.8 has no batch verifier).
- Commit stage: `commit_blocks_batch` called `validate_sapling_transaction_state`,
  which verified every Sapling proof and signature **a second time**, on the single
  committer thread, while holding the database. Sapling-heavy heights were paying
  for every proof twice.

## Design
### 1. Groth16 batch verifier (`crates/ycash-crypto/src/batch.rs`)
For proofs (A_i, B_i, C_i) with inputs x_i and secret random 128-bit r_i:

    prod e(r_i A_i, B_i) * e(sum r_i L_i, -gamma) * e(sum r_i C_i, -delta) == e(alpha,beta)^(sum r_i)
    L_i = IC_0 + sum_j x_ij IC_{j+1}

One multi-Miller loop and one final exponentiation per verifying key (spend,
output) instead of one full pairing check per proof. An invalid proof passes with
probability ≤ ~2^-128. The key material (alpha·beta pairing, −gamma, −delta,
IC) is precomputed once from the loaded `sapling-spend.params` /
`sapling-output.params`. A failed batch is bisected to the exact failing proofs.

### 2. Sapling checks with the pairing deferred (`SaplingBatchTx`)
Mirrors `zcash_proofs 0.5 SaplingVerificationContext`: point/scalar decoding,
small-order cv and rk, spendAuthSig, cv sum, bindingSig with the value-balance
point, and the same public inputs (rk u/v, cv u/v, anchor, 2-scalar nullifier
multipack; outputs cv u/v, cmu). Only the Groth16 check is queued.

### 3. Consensus wiring (`ycash_consensus::ProofBatch`)
- `validate_for_commit_batched` = `validate_for_commit_opts`, but Sapling proofs
  go into the batch. `ProofBatch::finish()` completes the block's validity.
- **Safety net:** any rejection (eager checks or batch) is re-checked with the
  original single-proof verifier, and that result is final. The batch path can
  only speed up acceptance; it can never be the sole reason a block is rejected.
  Three disagreements disable batching for the process (`[BATCH] stage=DISABLED`).
- `YORTAL_BATCH_VERIFY=0` turns batching off.

### 4. Pipeline (`pipeline_sync.rs`)
- One global `ProofBatch` per downloaded verification window (≤16 blocks).
  Four workers prepare contiguous slices in parallel; their deferred Sapling proof
  queues are merged before the single Spend batch and single Output batch are verified.
- Blocks from the verify stage carry `BlockCommit.proofs_verified = true`; the
  committer then checks anchors, nullifiers and the note tree but does not
  re-verify proofs. `State::put_block` still sets `false` and verifies everything.
- Log: `[PIPELINE] stage=BATCH_VERIFY range=a..b proofs=N ms=… total_batches=…`.

## Not batched (yet)
- RedJubjub spendAuthSig/bindingSig: still verified one by one (eagerly).
- Sprout Groth16 JoinSplit proofs: only the prepared key is kept in memory and
  they are skipped under assume-valid (≤ 2,250,000) anyway.

## Untested here
Written without a compiler. The first GitHub Actions run is the compile check.
Correctness of the Sapling public inputs can only be exercised with real params
and real shielded blocks: watch for `[BATCH] stage=MISMATCH` in node.log — if it
appears, batching disables itself and the original verifier takes over.
