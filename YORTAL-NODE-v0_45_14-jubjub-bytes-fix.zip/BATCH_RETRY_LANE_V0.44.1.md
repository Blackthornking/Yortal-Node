# YORTAL v0.44.1 — batch retry lane (fix: "VALIDATION / QUEUED", workers idle, no commits)

## Symptom
Sync runs normally, then stops. Dashboard: `BOTTLENECK: VALIDATION / QUEUED`,
"N block(s) waiting" (N up to ~62), all verifier/state-prep workers idle, last
commit ages indefinitely.

## Root cause
The 16-block dispatcher (`yortal-16-block-batch-dispatch`) keeps a private
`expected_first` barrier that only ever moves forward, and it discards any block
with `height < expected_first` as a stale duplicate.

If ANY block of a dispatched batch is later rejected or discarded —
  * `semantic_verify` returns Err,
  * `prepare_commit_batch_owned` rejects the batch (all 16 blocks dropped),
  * canonical publication fails (batch + every later verified block dropped)
— its lifecycle claim is released and the downloader correctly fetches it again.
The replacement arrives with `height < expected_first`, so the dispatcher threw it
away. The preparation stage then waits forever for that height, the claim slot is
re-used for the same doomed re-download, and every discarded copy leaked +1 into
`semantic_queue` (that is why the dashboard showed 62 "waiting" with a 64-slot
window and zero workers running).

## Fix (crates/node/src/verifier.rs)
* Retry lane: whenever the semantic / preparation / commit stage discards a
  height, it records it in a shared `retry_heights` set BEFORE releasing the
  claim. A block that arrives behind the barrier is now verified on its own
  (outside the 16-block barrier) if its height is in that set, and handed to the
  preparation stage, which already reorders by height. Normal duplicates are still
  dropped.
* `semantic_queue` accounting fixed: dropped/replaced blocks decrement it, and all
  decrements saturate at zero.
* A replaced duplicate of the SAME block no longer releases the claim that now
  belongs to the newer arrival (which caused re-request churn).
* Panics in `semantic_verify`, `prepare_commit_batch_owned` and
  `apply_prepared_commit` are caught and treated as rejections instead of silently
  killing a worker thread and hanging the batch barrier.
* Repeated failures back off (0, 0, 250 ms, 500 ms … capped at 15 s) so a
  deterministic rejection cannot become a hot download/verify loop.

## Telemetry
* `pipeline_error` now carries the actual failure text while the canonical tip is
  still where the failure happened: "Last failure at tip N: block M rejected by
  verifier: …" / "batch A..B rejected by state preparation: …" / "batch A..B
  publication failed: …".
* New bottleneck `FETCH / BATCH GAP`: the dispatcher is holding blocks but waiting
  on the network for a specific height. New JSON fields `batch_gap_height`,
  `dispatch_pending`. New bottleneck `VALIDATION / RETRY` while a failure is
  outstanding. `VALIDATION / QUEUED` is no longer reported for blocks that are only
  waiting for a batch to fill.
* "Ranges quarantined" (= `invalid_blocks`) counts each rejection.

## What this does NOT change
Consensus rules, exact-16 batching, four verifier workers, single preparation
worker, single canonical publisher, batch barrier on the normal path.

## Note
Registry / download window is 64 (`VERIFIER_QUEUE_CAPACITY`), not 16 as
config/pipeline.toml comments say — `SyncConfig::from_env` overwrites the clamped
values. Behaviour left as is.

## Validation
`cargo`/`rustc` are not available in the packaging environment: not compiled or
run here. Run `cargo check --workspace --all-targets` and the `ycash-node` tests
(three new unit tests in verifier.rs) on a Rust host before deploying.
