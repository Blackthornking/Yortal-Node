# v0.36.7 - Bellman removed, build fixed

## Build failure (v0.36.6)

    error: expected identifier, found `#`
      --> crates/ycash-crypto/src/rustzcash.rs:59:9
       59 |         #[cfg(feature = "prover")] PROOF_GENERATION_KEY_GENERATOR,

`#[cfg]` attributes are not allowed on individual items inside a `use { ... }`
list. That parse error stopped `ycash-crypto` before any type-checking, so
every problem behind it was hidden. Gating those imports was also wrong on its
own terms: `Diversifier`, `Rseed` and `PROOF_GENERATION_KEY_GENERATOR` are used
by non-prover functions (`librustzcash_check_diversifier`, `_ivk_to_pkd`,
`_nsk_to_nk`, note nullifier/commitment), so a default build would have failed
with unresolved names even without the syntax error.

## Removed

* `bellman` and `zcash_proofs` dependencies, and the `prover` feature, from
  `crates/ycash-crypto/Cargo.toml`.
* Prover FFI in `rustzcash.rs`: `librustzcash_sprout_prove`,
  `librustzcash_sapling_output_proof`, `librustzcash_sapling_spend_proof`,
  `librustzcash_sapling_binding_sig`, `librustzcash_sapling_proving_ctx_init`,
  `librustzcash_sapling_proving_ctx_free`.
* The `static mut` proving state (`SAPLING_SPEND_PARAMS`, `SAPLING_OUTPUT_PARAMS`,
  `SAPLING_SPEND_VK`, `SAPLING_OUTPUT_VK`, `SPROUT_GROTH16_PARAMS_PATH`) and the
  `load_parameters` call in `librustzcash_init_zksnark_params`.
* Every `#[cfg(feature = "prover")]` item and the imports that only served it
  (`Bls12`, `File`, `BufReader`, `PathBuf`, `Amount`, `MerklePath`,
  `PaymentAddress`, `ProofGenerationKey`, `Signature`).

Nothing else in the workspace called any of these.

## Fixed while in there (would have been the next errors)

* `librustzcash_sapling_check_spend/_check_output/_final_check` dereferenced raw
  pointers (`&*cv`, ...) outside an `unsafe` block (E0133). Now inside `unsafe`.
* `ycash_crypto::{validate_chain_links, ChainLink, ChainLinkError}` are imported
  by `crates/node` but were only reachable as `ycash_crypto::groth16::...`.
  Re-exported from the crate root.
* `batch.rs` test `random_scalars_are_nonzero` referenced `OsRng` and a
  `random_scalar(&mut rng)` that do not exist in that module (CI runs
  `cargo check --workspace --all-targets`, which compiles tests). Removed;
  `groth16.rs` already has the equivalent test.
* `groth16::random_scalar` used `Scalar::is_zero()`, which needs `ff::Field`
  in scope; now `scalar != Scalar::zero()`.

* (v0.36.8) `batch.rs` had lost its `Item` struct (`proof`, `inputs`, `tag`),
  used by `verify_set` and `SaplingBatch`; restored. Removed the now-unused
  `OnceLock` import. This was the only error in the second CI log.

* (v0.36.9) `crates/node/src/verifier.rs:434` formatted an `Option<u64>` with
  `{}`; now `{canonical_height:?}`. `ycash-crypto`, `ycash-state` and the other
  upstream crates passed in the previous CI run.

## Consequence to be aware of

The single-proof reference path (`zcash_proofs::SaplingVerificationContext`)
no longer exists, so the side-by-side differential check recommended in
`YORTAL_V0_33_PIPELINE_DESIGN.md` cannot be run inside this tree. Verify against
ycashd/zebra-ycash test vectors or a separate build before relying on it for
consensus decisions.

## Guard

`tools/verify-no-bellman.sh` fails if `bellman`, `zcash_proofs` or a `prover`
feature reappears in any `.rs`, `Cargo.toml`, script or gradle file.

## Not compiled here

No Rust toolchain was available when this was prepared. Changes were checked
statically (brace balance, symbol cross-references, grep for leftovers). The
real test is `cargo check --workspace --all-targets` in CI.
