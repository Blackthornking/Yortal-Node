# YORTAL NODE v0.40.1 — 16-block verifier/commit blocking fix

## What changed

- Preserved the exact **16-block lifecycle window**.
- Preserved exact height ordering and one canonical commit owner.
- Removed `prepare_commit_batch()` / `apply_prepared_commit()` from the verifier coordinator thread.
- Added a dedicated `yortal-ordered-commit` worker with a bounded queue of one commit request.
- The verifier coordinator now hands a complete 16-block sequence to the ordered commit worker and immediately returns to its receive/verification loop.
- `contextual_active_batches` now measures the actual ordered-commit worker rather than making the coordinator appear idle during the commit path.
- Registry ownership is still released only after the batch is published or discarded, so the global in-flight cap remains exactly 16 and duplicate lifecycle claims are not reopened.

## Ordering invariant

`download -> semantic verify -> exact 16 assembly -> ordered commit worker -> atomic publication`

The commit queue is bounded to one item and has a single consumer, so canonical publication cannot reorder batches.

## Validation note

The supplied environment does not contain `cargo`/`rustc`, so a local Rust compile/test could not be executed here. The edited Rust source was checked for balanced delimiters and the archive was rebuilt from the supplied v0.40.0 source tree.
