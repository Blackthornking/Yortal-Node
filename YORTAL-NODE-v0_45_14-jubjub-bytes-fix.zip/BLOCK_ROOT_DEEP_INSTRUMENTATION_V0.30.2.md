# YORTAL v0.30.2 — Deep block-root instrumentation

This build instruments the existing Sapling commitment-tree root calculation without changing
the consensus algorithm or introducing cached roots.

## What is measured

For each ordered commit batch:

- total `block_root_us`
- time for each Merkle root level 0..31
- number of root hashes performed at each level
- time spent rebuilding empty subtrees by hash depth
- number of empty-subtree hashes
- time spent in the actual root hash at each level
- number of root hashes

The implementation deliberately mirrors the existing `SaplingConsensusState::root()` algorithm.
In particular, `empty(level)` is still rebuilt for every empty frontier slot. This makes the
telemetry useful for proving whether the current 431 ms hotspot is repeated empty-subtree
construction rather than silently measuring an optimized implementation.

## UI

The Node Monitor state-validation panel now adds:

- Block root deep total
- Empty-subtree rebuild total and hash count
- Root Merkle hash total and hash count
- Per-level root timing for non-zero levels

The native status JSON exposes the six 32-element telemetry arrays so the UI and log stream use
the same measurements.

## Consensus safety

`root_with_timing()` computes the same root as `root()`. A consensus unit test explicitly compares
the two results. No tree contents, hashing inputs, frontier transitions, or validation rules are
changed by the instrumentation.
