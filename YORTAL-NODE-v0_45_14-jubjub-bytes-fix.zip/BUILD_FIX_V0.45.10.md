# v0.45.10 — compile fixes (ycash-crypto)

Both errors were in `crates/ycash-crypto/src/groth16.rs`, carried over from
v0.45.7 (shared Miller loop); neither was in the v0.45.8/9 changes.

1. `verify_pair`: `Gt * Gt` does not exist. bls12_381 writes the target group
   additively: `+` is the group operation and `* Scalar` is exponentiation.
   The combined check is now
   `alpha_beta_spend * r_sum_spend + alpha_beta_output * r_sum_output`,
   the same form as the single-key `verify_prepared`.
2. Test `multi_scalar_mul_matches_the_naive_sum` called a function that no
   longer exists; it now calls `pippenger_msm` with affine points.

Also: `tools/verify-ordered-48-batch-v0.34.1.sh` updated for the v0.45.9
`verify_batch_in_order` signature.

The crates that depend on ycash-crypto (state, node, android-node) were never
reached by the failed build, so the v0.45.8/9 changes are still uncompiled.
