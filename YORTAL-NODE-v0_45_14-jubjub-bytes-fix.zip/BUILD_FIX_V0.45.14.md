# v0.45.14 — compile fix

CI (0.45.13): `crates/yortal-ed25519` compiled cleanly. One error stopped
`ycash-crypto`:

- `redjubjub_batch.rs:55` — `jubjub::AffinePoint::from_bytes` takes
  `[u8; 32]` by value in jubjub 0.5.1; the call passed `&r_bytes`.
  Now `from_bytes(r_bytes)`.
- Removed the unused `use group::{Group, GroupEncoding};` in the same file.

state, node and android-node are still not reached by a successful build.
