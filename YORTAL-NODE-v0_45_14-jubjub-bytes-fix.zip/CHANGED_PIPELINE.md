# Changed Pipeline — v0.28.0

This build changes the Android concurrent block pipeline after an audit against Ycash 4.5.0 `ycashd`.

## Changes

- Per-peer block request ranges are capped at **16 blocks**, matching `ycashd`'s `MAX_BLOCKS_IN_TRANSIT_PER_PEER = 16`.
- The adaptive window remains a **global lookahead** and is no longer treated as a per-peer request size.
- Block-fetch errors now preserve their original I/O kind and identify the failing phase (`getdata send`, block stream read, or block-stream pong send).
- Block progress timeout increased from 60s to **180s**. Ycash 4.5.0's post-Blossom minimum block timeout is 150s (`0.5 * 75s * 4`), so the Android node no longer drops a peer sooner than the reference minimum.
- P2P user-agent is `/YcashAndroid:0.28.0/`.
- RPC/network protocol reporting is aligned with Ycash 4.5.0 (`270013`).
- Added scheduler regression tests for the 16-block per-peer range limit.

## Reference values audited

Ycash 4.5.0 `src/main.h`: `MAX_BLOCKS_IN_TRANSIT_PER_PEER = 16`, `BLOCK_DOWNLOAD_WINDOW = 1024`, `BLOCK_STALLING_TIMEOUT = 2`.

Ycash 4.5.0 `src/main.cpp`: `GetBlockTimeout()` uses `0.5 * PoWTargetSpacing * (4 + validated-queued-count)`. Post-Blossom spacing is 75 seconds, making the base timeout 150 seconds.

## v0.30.3 consensus-safe performance pass

- Transparent script checks now use bounded parallel workers while canonical UTXO/state mutation remains single-threaded and ordered.
- ZIP143/243 `PrecomputedTxData` is carried from stateless validation into the ordered commit stage.
- Exact canonical parent Sapling/Sprout state is cached in-process and reused only when the cache tip exactly matches the next block's parent.
- A bounded positive UTXO cache reduces repeated SQLite point lookups; misses always fall back to SQLite.
- Cache state is published only after the atomic SQLite commit and is discarded on reorg / `set_tip()`.
- Dashboard telemetry exposes script-worker count, script parallel time, UTXO cache hits/misses, and parent/Sprout cache hits.
