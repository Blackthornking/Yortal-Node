# YORTAL v0.30.1 — CHANGED PIPELINE

## Purpose
Fix sync stalls where parallel fetch/validation outruns the single stateful database committer.

## Changes
- Default lookahead reduced from 2048 to 256 blocks.
- Default ordered commit batch reduced from 256 to 16 blocks.
- Android adaptive scheduler now reacts to commit latency and buffered-range pressure.
- Stateless validation now returns parsed transactions so the state commit path can reuse them instead of parsing each transaction a second time.
- Normal forward extension no longer executes reorg rollback SQL. Rollback statements run only when the first block's parent is not the current canonical tip.
- State commit emits `[DBPIPE]` timing records for state validation, rollback, DB writes, and SQLite commit.
- Android status exposes verifying jobs, buffered ranges, and the last commit phase timings.
- Existing consensus ordering remains strict: blocks are still committed only in contiguous height order.

## Expected behaviour
Fetch/verify can remain parallel, but the bounded queue should stay near the configured lookahead and the writer should process small ordered batches. A slow SQLite/state stage should reduce scheduling pressure instead of accumulating thousands of uncommitted blocks.
