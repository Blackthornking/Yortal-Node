# v0.27.1 audit fixes

This package contains the corrective pass for the Android node diagnostics/database audit.

## Fixed

- SQLite `txs_block_hash` index was created before the `txs` table. The schema now creates `txs` first and its index second.
- Added SQLite `PRAGMA user_version` schema versioning (`2`).
- Unversioned/partially-created node databases from the old startup bug are detected and rebuilt automatically. This is intentional for the fresh-install/re-sync path.
- Sapling final treestate is persisted per canonical block, including the complete frontier, instead of only persisting the latest frontier globally.
- Sapling reorg validation reconstructs the working frontier from the fork parent rather than cloning the current tip state.
- Sapling anchors are restricted to earlier canonical block treestates; anchors from the branch being replaced cannot accidentally validate a reorg.
- Sapling nullifier checks use only earlier canonical ancestors and also reject duplicates across a commit batch.
- Orphaned canonical transaction/nullifier index rows are removed during reorg before replacement rows are inserted.
- Batch commits validate block linkage and state before changing canonical flags, preserving atomic failure behavior.
- `validate_for_commit` no longer uses a fresh empty Sapling tree as a false historical-state check. Cryptographic Sapling proofs are verified statelessly; historical anchors/nullifiers are checked by the state layer.
- Added state regression tests for fresh schema creation and recovery from the old unversioned partial database.
- CI now runs `cargo test --workspace --all-targets` before packaging and includes a SQLite schema-order smoke check.
- Removed the stray `crates/consensus/src/lib.rs.tmp` artifact.
- Android/native node version strings were aligned to `0.27.1` and protocol advertisement was aligned to `270014`.

## Deliberate fail-closed boundary

Transparent input script/signature validation and the Sprout JoinSplit state backend remain explicit consensus prerequisites. The node does not silently accept transparent spends or JoinSplits without those state/verification backends.
