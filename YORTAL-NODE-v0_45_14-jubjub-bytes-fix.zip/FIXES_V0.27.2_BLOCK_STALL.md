# v0.27.2 — block sync stall / peer churn

## Cause
`validate_for_commit` rejects any block containing a non-coinbase transparent
spend or a Sprout JoinSplit (no UTXO/script or Sprout backend yet). The chain
has these from the first few hundred blocks. That error was treated as a peer
fault: range released (retry), connection dropped, next peer gets the same
range, same failure -> retries, quarantine, requeue, repeat. Result: 0 ranges
completed, in-flight grows to the lookahead cap, peers drain to 1, headers
keep going on the header-owner peer.

## Fix
1. "Node can't validate this yet" errors are tagged (`node-unsupported:`,
   `ErrorKind::Unsupported`). They no longer drop peers or burn retries; the
   pipeline halts with a clear message ("block sync halted: block N: ...").
2. Assume-valid checkpoint (`ASSUME_VALID_HEIGHT` / `ASSUME_VALID_HASH_DISPLAY`
   in `crates/ycash-android-node/src/pipeline_sync.rs`). Fill from
   `checkpointData` in ycash 4.5.0 `src/chainparams.cpp`. Only activates if our
   PoW-verified header at that height matches. Below it, script/JoinSplit checks
   are skipped (PoW, merkle, coinbase, size, Sapling proofs still run).

## Not solved
Above the checkpoint, sync still halts at the first transparent spend until a
real UTXO/script backend (and Sprout tree) exists.
