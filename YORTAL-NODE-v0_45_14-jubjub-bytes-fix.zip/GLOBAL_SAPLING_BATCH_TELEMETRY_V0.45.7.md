# v0.45.7 Global Sapling Batch Runtime Telemetry

The active 16-block verifier now publishes runtime-only telemetry proving the
cryptographic batch boundary and its composition.

JSON/API fields:

- `sapling_batch_blocks` — number of contiguous blocks represented by the most recent global Sapling batch; normally `16` for a full verification window.
- `sapling_batch_proofs` — total deferred Sapling Groth16 proofs.
- `sapling_batch_spend_proofs` — Spend Groth16 proof count.
- `sapling_batch_output_proofs` — Output Groth16 proof count.
- `sapling_batch_verify_us` — elapsed microseconds spent in the global Sapling verifier. On a rejected randomized batch this includes the required proof-isolation fallback.

The verifier also emits:

`[SAPLING-BATCH] sapling_batch_blocks=16 sapling_batch_proofs=... sapling_batch_spend_proofs=... sapling_batch_output_proofs=... sapling_batch_verify_us=...`

These fields are diagnostics only. They do not affect consensus, chain selection,
validation decisions, retry policy, or scheduling.
