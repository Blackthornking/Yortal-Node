# v0.45.7 — active 16-block global Sapling proof batching

## What changed

The live verifier previously split a 16-block window across four workers and each
worker performed its own deferred Sapling Groth16 batch. That meant the active
cryptographic batching boundary was the worker slice, not the full 16-block
window.

The active path now:

1. assembles the complete contiguous 16-block window;
2. splits the window into four contiguous worker slices;
3. performs parsing, consensus decoding, point checks, RedJubjub checks and
   public-input preparation in parallel;
4. returns each worker's deferred Sapling proof queue to the coordinator;
5. merges all worker queues into one `ProofBatch`, rebasing transaction tags;
6. keeps separate Spend/Output verification-key accumulators, but combines their prepared pairing terms into one shared `multi_miller_loop` and final exponentiation;
7. if the global batch rejects, re-runs the authoritative single-proof verifier
   on the window and rejects at the first actual invalid block.

No proof format or consensus equation is changed.

## Consensus safety

The randomized Groth16 batch remains an optimization only. The existing
single-proof verifier remains authoritative for batch failures. Worker-local
non-pairing failures are also preserved as ordinary block failures.

The transaction tags are rebased when worker batches are merged so a failed
proof can still be mapped back to its original transaction height.

## Verification

The source-level verification script now checks the active 16-block global
batch wiring and worker-queue merge invariants.

A full Cargo build could not be run in this environment because `cargo` is not
installed. The repository's static verification script passes:

`tools/verify-ordered-48-batch-v0.34.1.sh`

and reports the active 16-block global Sapling proof batching invariants.

## v0.45.7 verifier acceleration

The deferred Groth16 path now performs the remaining group work as follows:

* Each proof is prepared independently with Rayon: a fresh 128-bit batch
  randomizer, `r*A`, prepared `B`, and the weighted public-input scalars are
  produced without serialising proof preparation.
* The accumulated `C` terms use an adaptive-window Pippenger MSM.
* The public-input commitment is regrouped as
  `L = r_sum*IC_0 + Σ_j(Σ_i r_i*x_ij)*IC_j` and evaluated as one adaptive
  Pippenger MSM over the fixed IC bases, replacing point-by-point scalar
  multiplication in the batch path.
* Spend and Output retain separate accumulators because they have different
  verifying keys, while their preparation/MSM work runs concurrently.
* The resulting Spend and Output `A/B`, `L/-gamma`, and `C/-delta` terms are
  submitted to one `multi_miller_loop`, followed by one final exponentiation
  for the combined successful batch.

This changes only verification scheduling and group-arithmetic implementation;
no Sapling proof encoding, public-input construction, or consensus equation is
changed. A randomized aggregate failure remains a locator hint and is resolved
through exact single-proof verification.
