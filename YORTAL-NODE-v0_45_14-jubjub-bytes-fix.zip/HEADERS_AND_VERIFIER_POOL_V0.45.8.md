# v0.45.8 — headers no longer stop, verifiers are a persistent 4-thread Rayon pool

## 1. Headers stopped early (sync_coordinator.rs)
`wants_headers()` had a hysteresis throttle: header sync paused once the header
chain was `HEADER_LEAD_HIGH` (2048) ahead of the committed tip and only resumed
when the tip closed to within `HEADER_LEAD_LOW` (512). Headers therefore stopped
about 2 000 blocks in, and any slowdown in the block pipeline kept them stopped.
The throttle is removed: headers are fetched until the peer has none left, one
`getheaders` round trip per turn, interleaved with block service. At the chain
tip `HEADER_IDLE_BACKOFF` still stops repeated empty requests.

## 2. Header ownership could leak (main.rs)
`sync_owner` was cleared with a plain `store(false)` after `sync_headers`. A panic
on that path left it set forever, so no peer could take header sync again.
It is now a `HeaderOwner` guard released on drop, including on unwind.

## 3. Verifiers were per-batch threads (batch.rs, verifier.rs)
`verify_batch_in_order` spawned 4 scoped OS threads per 16-block batch and
joined them at the end, so between batches there were no verifier threads.
It now runs on one persistent Rayon pool (`yortal-verify-0..3`) built once in
`VerifierPool::spawn`. The global Sapling proof batch and the proof-isolation
fallback also run on that pool. Panics per slice are still caught and turned
into a batch rejection.

## 4. Dashboard "verifying jobs" read 5 (sync_coordinator.rs)
It was crypto workers + the state-preparation batch. It is now only the live
count of busy verifier threads (0–4), maintained by the workers themselves.
`pipeline_verify_threads` / `active_block_workers` report the pool width (4).

Consensus rules, batch boundaries and commit order are unchanged.
