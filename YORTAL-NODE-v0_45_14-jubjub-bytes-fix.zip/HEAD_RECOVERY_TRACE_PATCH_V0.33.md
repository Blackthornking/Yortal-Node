# YORTAL v0.33 — Canonical Head Recovery Trace Patch

## Purpose

Trace the exact `canonical_height + 1` block across every transport transition so a head-of-line stall can be diagnosed from the Android `/status` endpoint without guessing from aggregate throughput.

## Exact trace events

Each event contains a monotonic sequence number, wall-clock milliseconds, peer address, height, block hash, event name, and detail.

- `WAITING` — ordered state gate cannot find the exact canonical next block in the prospective set.
- `CLAIMED` — a specific peer claimed `canonical_height + 1`.
- `GETDATA_SENT` — that peer actually sent a `getdata` containing the exact head hash.
- `ARRIVED` — the exact requested block arrived from that peer and was queued for semantic verification.
- `NOTFOUND` — the peer explicitly reported the exact head hash as unavailable.
- `RETRY_TIMEOUT` — the 8-second canonical-head transport timeout released the claim.
- `RETRY_STALE` — the normal transport timeout released the exact head claim.
- `DISCONNECT_RELEASE` — a peer connection ended while holding the exact head request.
- `COMMITTED` — the ordered writer successfully published the run containing the head.

The last 128 events are retained natively; the Android status endpoint exposes the newest 32 as `head_trace`.

## Recovery fix

The old `notfound` path called `expire_stale(Duration::from_secs(0))`, which released the entire peer request window when one `notfound` arrived. That caused unrelated block claims to churn and could obscure which peer actually failed the canonical head.

The patched path parses the `notfound` inventory and releases only the hashes explicitly returned by that peer. If the returned hash is the canonical head, it immediately clears the head in-flight flag and rewinds assignment to the canonical tip so another peer can claim the exact block.

## Consensus safety

The patch changes transport diagnostics and request ownership only. It does not change block validation, contextual consensus rules, chain-work selection, canonical ordering, or database publication semantics.

## Build note

The source tree was statically checked for balanced braces, JSON format placeholder/argument count, and the new trace/recovery paths. A local `cargo fmt`/`cargo test` run was not possible in the packaging environment because the Rust toolchain (`cargo`) is not installed. The GitHub Actions build should therefore remain the authoritative compile/test check.


## Verifier lifecycle patch

The head-recovery trace is now backed by a real lifecycle invariant: a requested block hash remains globally owned after transport arrival while it is being semantically verified and while its verified candidate is resident in the ordered prospective set. The transport slot is freed immediately, but the global hash claim is not.

Lifecycle transitions are `Transport -> Verifying -> Verified -> terminal release`. Semantic rejection releases immediately; state-queue failure releases immediately; successful canonical publication and explicit candidate discard/prune release through a state-service lifecycle hook. This prevents a fast downloader from issuing duplicate `getdata` for a block that is already being verified, while retaining the existing per-peer streaming window.

Head telemetry now includes `VERIFYING`, `VERIFIED`, and `CANDIDATE_QUEUED` events in addition to the transport and ordered-gate events.
