# YORTAL v0.33.4 — independent canonical-head watchdog

## Field symptom addressed

The dashboard can show:

- `Canonical head blocked ... missing block parent`
- `head request active`
- `retries 0`
- headers continuing to arrive
- `0 blocks/s`

while a peer thread is blocked in a socket read. In v0.33.3 the watchdog logic
was present, but recovery was still normally entered through `next_requests()`;
that requires a peer thread to reach the request loop.

## Change

`SyncEngine::watchdog_head_once()` now performs a transport-only check once per
second from a dedicated Android watchdog thread. If the exact canonical
`tip + 1` transport claim exceeds the same bounded back-off timeout, the claim
is atomically released and the healthiest alternate peer is nominated. With a
single peer the claim is released so that peer can reclaim it when its socket
loop becomes responsive.

Consensus state, validation, chain selection, database contents, addresses and
network protocol settings are unchanged.

## Expected effect

A stalled head should no longer wait for the 90-second generic transport
expiry merely because the owning peer thread is blocked. With multiple peers,
the next responsive peer can request the parent on its next pass. The dashboard
should show `WATCHDOG_REASSIGN` in the head trace and `parent_retries` should
increase after a real stale-head event.

## Build/test

Run:

```text
cargo test -p ycash-node
cargo test -p ycash-android-node
```

Then reproduce the field case and verify that `WATCHDOG_REASSIGN` appears before
30 seconds and that the canonical height advances once the parent is delivered.
