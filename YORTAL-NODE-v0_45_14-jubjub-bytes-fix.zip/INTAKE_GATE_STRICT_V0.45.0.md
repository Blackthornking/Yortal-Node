# YORTAL v0.45.0 — strict intake gate, four queued batches, batch-only pipeline

The pipeline now matches the intended shape exactly:

```text
peers ──► INTAKE GATE ──► ready queue ──► 4 verify ──► 1 prepare ──► 1 commit
          1 worker        4 complete      workers      worker        worker
          sorts + holds   batches         all 16       expensive     publish
          until all 16                    required     work only     only
```

## What was wrong

### 1. The ready queue could never hold four batches
The download window was 64 lifecycle claims (`VERIFIER_QUEUE_CAPACITY = 16 × 4`),
but a claim is held from "requested from a peer" until "published or discarded".
In steady state the pipeline itself holds 32–48 of those claims (one batch being
verified, one being prepared, one being published), so the gate had at most one
or two batches' worth of window left. Four queued batches was arithmetically
impossible: the gate could only assemble the next batch *after* a commit freed
claims, so the network went idle during every verify/prepare/commit cycle.

The window is now derived from the batch structure instead of being a round
number:

| | batches | blocks |
|---|---|---|
| ready queue (`INTAKE_READY_BATCHES`) | 4 | 64 |
| in the pipeline (`PIPELINE_INFLIGHT_BATCHES`) | 3 | 48 |
| being assembled (`INTAKE_ASSEMBLY_BATCHES`) | 1 | 16 |
| **`VERIFIER_QUEUE_CAPACITY`** | **8** | **128** |

`crates/node/src/lib.rs` carries this as a comment and a unit test, so the
window cannot drift away from the batch layout again. This is the memory knob:
128 blocks are resident at peak. Halving `INTAKE_READY_BATCHES` halves the
queue's share.

### 2. The retry lane broke strictness
v0.44.1 added a side lane: when a later stage rejected a height, the
re-downloaded block was verified **on its own**, outside any batch, because the
dispatcher's barrier had already moved past it. That is exactly what the design
forbids — a single block going through the pipeline without its batch.

The retry lane is gone. Rejection now works the other way round:

* Any stage that rejects a block, rejects a batch, or fails to publish records
  the canonical tip + 1 and bumps a shared **epoch**.
* Every stage drops what it is holding above the tip and restarts from that
  height. The intake gate releases its held blocks' claims so they are fetched
  again.
* The replacement blocks come back through the gate and are re-verified as part
  of a **complete, ordered, full batch**, like every other height.

`PipelineReset` in `verifier.rs` is the whole mechanism; every batch carries the
epoch it was assembled in, and a stage discards any batch tagged with an older
one. There is no path by which a partial or lone block reaches a verifier.

### 3. A malformed batch killed the node
The dispatcher `return`ed on a batch-shape violation, terminating the thread.
Nothing restarts it, so the node stalled permanently with no error visible past
the first line. It now releases the batch and resets instead.

### 4. One rejected block let the other fifteen through
A verifier rejection was reported per block, and the surviving blocks of that
batch continued into the preparation stage's reordering map. Now a rejection
anywhere in a batch voids the whole batch: the preparation worker can only ever
receive a batch in which all 16 blocks verified.

### 5. The chain tail could never commit
Every stage required exactly 16 blocks, so the last <16 blocks of the chain were
never published — the node stopped up to 15 blocks short of the tip, forever.

The gate now detects the one case where a full batch is impossible: it holds
every remaining height up to the validated header tip, and nothing new has
arrived for 3 seconds. It then releases that short run, flagged `tail`. The run
is still strictly complete and contiguous — no height inside it is missing — it
is simply shorter than 16. This is the only place a batch is not 16 blocks, and
it only triggers at the actual end of the chain.

## Stage contracts

**Intake gate** (`yortal-16-block-intake-gate`, 1 worker) — the only producer of
work. Sorts unordered arrivals by height into a `BatchAssembler` and releases
`first..first+15` only when all sixteen are in hand. Drains consecutively: one
arrival can complete several batches that were waiting on an earlier one.
Duplicates below the barrier are released, not queued. Wakes every 250 ms so a
reset is honoured even with no traffic.

**Dispatcher + 4 verifier workers** — takes one complete batch, hands all its
blocks to the four shared workers (no worker owns a height lane), and waits for
**every** result before touching the next batch. A rejection or a worker panic
voids the batch and resets.

**1 state-preparation worker** — all expensive contextual/UTXO/script work for
one batch, via `prepare_commit_batch_owned`. Refuses any batch that does not
start at tip + 1. Waits for the commit acknowledgement before preparing the
next, because the next preparation must observe the state the previous batch
produced.

**1 commit worker** — `apply_prepared_commit` only: canonical tip/parent recheck
and the atomic RocksDB write. No parsing, UTXO discovery, script execution or
proof verification.

## Also fixed

* `semantic_queue` is decremented exactly once per submitted block, on every
  path (stale, replaced, reset, stale epoch, malformed, verified).
* `BatchAssembler::insert()` added: store without releasing, so the gate can
  store then drain. `offer()` (store-and-maybe-release) did both at once, which
  is why the tail-of-window drain needed a second method in 0.44.3.
* A poisoned assembler lock no longer leaks a lifecycle claim.
* `highest_semantically_verified_height`, `semantic_batches`,
  `semantic_verify_us` and `last_semantic_batch_blocks` are populated again; the
  dashboard's verify figures were dead after the 0.42 redesign.
* `SyncConfig::from_env` no longer contains clamps to `PIPELINE_BATCH_SIZE` that
  were unconditionally overwritten three lines later.
* `pipeline_retries` now counts pipeline resets.

## Not changed

Consensus rules, `semantic_verify`, `prepare_commit_batch_owned`,
`apply_prepared_commit`, the Ycash wire protocol, and the 16-blocks-in-transit
per-peer limit.

## Validation

`cargo` is not available in the packaging environment. Run on a Rust host:

```
cargo check --workspace --all-targets
cargo test -p ycash-node
```

New tests: `insert_never_releases_until_the_whole_window_is_present` (batch.rs),
`a_reset_moves_every_stage_to_the_same_height`,
`repeated_resets_back_off_but_a_publication_clears_the_streak`,
`the_ready_queue_holds_four_complete_batches` (verifier.rs),
`the_window_covers_every_batch_that_can_hold_claims_at_once` (lib.rs).

---

# v0.45.1 — the window and the claim capacity must not be the same number

## Symptom
Sync ran, then stopped dead. Dashboard at the stall:

```
HDR 127840 · DL 10768 · SEM 10640 · CTX 10640 · COM 10640
Global in-flight cap 128 · In-flight blocks 11 · Validation queue 117
Verifier workers 0 · Last commit 21s ago
Pipeline: waiting for block 10653 to complete the 16-block batch ·
117 block(s) held (network wait, not validation)
BOTTLENECK: FETCH / BATCH GAP
```

## Root cause
117 held + 11 in flight = 128 = the entire claim capacity. Zero spare.

Every lifecycle claim sits at a height inside the download window, and v0.45.0
set the window and the claim capacity to the same number (128). So the gate was
able to hold almost the whole window — heights 10641…10768, everything except
10653 — while waiting for that one missing block. With no claim slot free, the
assigner could not issue a request for 10653. It is returned by
`missing_heights()` every pass and rejected by `InFlightRegistry::claim()` every
pass, because `claims.len() >= capacity`.

The gate waits for a block that cannot be requested until the gate lets go, and
the gate does not let go until the block arrives. Permanent, silent, and it
reports itself as a network wait because from the gate's point of view that is
exactly what it looks like.

This is the same trap the old `BlockAssigner` comment warned about for the
prospective buffer. It came back because the claim window was sized to the
batch layout and nothing was left over.

## Fix
Separate the two numbers:

| | |
|---|---|
| `BLOCK_DOWNLOAD_WINDOW` | 128 (8 batches — unchanged lookahead) |
| `GAP_RESERVE_BLOCKS` | 16 (one batch) |
| `VERIFIER_QUEUE_CAPACITY` (claim capacity) | 144 |

Since every claim is at a height in the window, `held + in_pipeline + in_flight
≤ window < capacity`, so at least 16 slots are always free for the lowest
missing heights — which is the order `missing_heights()` returns them in. A gap
can always be fetched.

Memory is unchanged: the reserve is claim slots, not resident blocks. The gate
still holds at most 128.

`SyncConfig::download_window()` now derives itself as `max_blocks_in_flight −
GAP_RESERVE_BLOCKS`, so the two cannot be set equal by accident again, and
`the_claim_capacity_always_exceeds_the_download_window` asserts it.

The dashboard will now read `cap 144 · lookahead 128`.

## Liveness valve
The arithmetic above says the stall cannot recur, but the consequence of being
wrong is a node that never moves and does not say so. The gate therefore checks
directly: if it is holding a gap and `spare_capacity() == 0` continuously for 20
seconds, it drops the blocks furthest from the tip (one batch worth), releases
their claims, and logs `GAP_STARVATION`. The furthest-ahead blocks are the least
useful thing it is holding, and they will be re-fetched.

---

# v0.45.2 — the node was eating its own blocks

## Symptom
Second stall, different cause. `cap 128 · lookahead 128 · 144/144`, 111 held,
17 in flight, gap at 11036, **0.0 blocks/s and 0 B/s for 34s while headers ran
at 552/s**.

The gap reserve worked — 128 claims of 144, 16 spare, so 11036 was claimable
and was in fact already claimed and in flight. The block had been requested and
was not arriving. Nor was any of the other 16.

## Root cause: `sync_headers` discarded every block message
`sync_headers()` owns the socket while it runs and reads it in an inner loop
until a `headers` message arrives. Its match had arms for `headers`, `ping`,
`reject` and `addr`, then:

```rust
Ok(_)=>{}
```

`block` fell into that arm. Blocks already requested and already on the wire
were read off the socket and thrown away. Their requests stayed outstanding
until they timed out, were re-requested, and were discarded again if header sync
was still running — which it was, continuously, because `sync_headers` loops
until the peer returns an empty `headers` message and the header chain was
89,000 blocks ahead of the committed tip.

Zero block bytes with healthy header traffic was not a peer that had stopped
serving blocks. It was us reading them and dropping them.

`sync_headers` now takes an optional `(&SyncCoordinator, &mut
PeerDownloadSession)` sink and feeds arriving blocks to it. The peer's download
session is created before the first header sync so the sink exists from the
start.

## Also fixed

### A delivered block repays a timeout
`PeerStats.timeouts` drives both the retry backoff (2s doubling to a 64s
ceiling) and the peer ranking, and it only ever counted upwards — nothing
decremented it on a successful delivery. Five stalls and a peer was pinned at
64s and at the bottom of the ranking for the rest of the session no matter how
well it behaved afterwards. A delivered block now decrements it. A peer that is
genuinely failing still accumulates faster than it delivers; one that had a bad
minute earns its way back.

### The batch gap is as urgent as the canonical head
`SyncMetrics.dispatch_gap_height` is the height the intake gate is waiting on.
Under the batch barrier it blocks the node exactly as hard as the canonical head
does: every verifier idles and the blocks already held are useless until it
lands. It was treated as ordinary lookahead — full backoff, bare release on
expiry, so the peer that had just failed to deliver could immediately re-claim
it.

* New `GAP_REQUEST_TIMEOUT` (the 2s default): the gap height never inherits the
  peer's backed-off deadline.
* `give_up()` hands the gap height to a different peer, the same as the head,
  instead of releasing it back into the pool.

### Expiry actually runs
`drive_peer` called `expire_stale` only when the socket read timed out. A peer
sending a steady stream of other messages could therefore hold a stale request
indefinitely. It now runs at the top of every pass, before requesting, so a
freed claim is re-requested in the same call.

---

# v0.45.3 — header sync yields, and stops running away from the block window

Two problems, one structural and one policy.

## Header sync held the peer for the whole run
`sync_headers()` looped until the peer returned an empty `headers` message.
With the header chain tens of thousands ahead of the committed tip that meant
one peer was inside that function more or less permanently. v0.45.2 stopped it
discarding blocks, but it still never called `request_more`, so that peer
drained its 16-block window and then contributed nothing.

It now takes a batch budget (`HEADER_BATCHES_PER_TURN = 1`) and returns after
one `headers` message. A `getheaders` round trip returns at most 160 headers
either way, so yielding costs no extra round trips.

The peer loop no longer `continue`s after a header turn — it falls through to
the block-service pass. Restarting the loop would have gone straight back into
header sync and the yield would have bought nothing.

## Headers ran 89,000 ahead of a 128-block window
Block requests only ever come from `missing_heights()`, capped at
`download_window()`. Headers beyond that are of no use to the block downloader,
and they are not free: a header is around 1.5 KB, so 552 headers/s is roughly
800 KB/s — most of the link, while block throughput was zero.

`SyncCoordinator::wants_headers()` now gates it:

* **Unconditional** while `header_tip <= committed_tip + download_window`. No
  header, no hash, no block request.
* **Above that**, hysteresis: keep running until the lead reaches
  `HEADER_LEAD_HIGH` (2048), stay stopped until it falls below
  `HEADER_LEAD_LOW` (512). A single threshold would flap in and out of header
  sync every few seconds as the tip advanced past it.

Cold start needs no special case: 2048 is far above the 128-block window, so
blocks begin as soon as the first couple of header batches land.

Progress reporting is unaffected — `target_height` comes from the peer's
`version.start_height`, not from the header chain.

## Idle backoff
At the chain tip `wants_headers()` is permanently true (headers equal the tip,
which is below the window), so the peer would have sent `getheaders` on every
pass and been answered with an empty list forever. A turn that does not advance
the header tip now waits `HEADER_IDLE_BACKOFF` (2s) before asking again.

---

# v0.45.4 — the 2s gap deadline was throwing away the block it was waiting for

## Symptom
`HDR 14240 · DL 12368 · SEM/CTX/COM 12240`. 120 held, 8 in flight, waiting on
12249, 37s since the last commit, **every throughput counter at zero**.

## What was *not* wrong
* Claims: 128 of 144, 16 spare. The gap reserve held.
* `headers/s = 0` is correct — the lead was 2000, so the v0.45.3 throttle had
  paused header sync until it falls below 512.

## Root cause
`0 B/s` does not mean the socket was idle. `bytes_downloaded` is only
incremented for a block that is *accepted*, and the blocking block was being
delivered and then discarded:

```rust
pub fn on_block(&mut self, hash: &[u8;32], bytes: usize) -> Option<BlockRequest> {
    let (request, _) = self.in_flight.remove(hash)?;   // <- nothing else matched
```

v0.45.2 gave the batch-gap height a 10× shorter retry deadline —
`GAP_REQUEST_TIMEOUT`, set to the Ycash default stall interval of **2s**. On a
mobile link a block routinely takes longer than that to arrive. So:

1. 12249 is requested.
2. 2s later `expire_stale` gives up on it and removes it from `in_flight`.
3. The block arrives. `in_flight.remove` misses. `on_block` returns `None`,
   `on_block_message` returns `Ok(false)`, the block is dropped.
4. No counter moves — not `bytes_downloaded`, not `duplicate_blocks`, nothing —
   so the dashboard shows a peer sending nothing.
5. The height is re-requested and the cycle repeats forever.

The fix for the previous stall became the cause of this one. The old 64s
deadline was never short enough to race a delivery.

## Fix

### Late arrivals are accepted
The session now keeps requests it gave up on for `ABANDONED_ARRIVAL_WINDOW`
(120s) and matches deliveries against them. A block that is already in hand is
always cheaper than fetching it again; the claim state then decides what happens
to it, exactly as for a normal arrival:

* re-claimed since (by this peer or another) → `mark_verifying` takes it;
* not claimed → `adopt_arrival` takes it;
* already canonical → dropped, as before.

Logged as `LATE_ARRIVAL` in the head trace so this is visible next time.

### A realistic gap deadline
`GAP_REQUEST_TIMEOUT` is now 10s: still six times tighter than the 64s ceiling
an ordinary lookahead request can drift to, but above the time a real delivery
takes. A unit test pins it between the default stall interval and
`REQUEST_TIMEOUT`.

## Separate, still open: state preparation got slow
Around height 12240 the commit time went from ~40ms to **5.4–7.2s per 16-block
batch**, with `DB write 806ms` and `SQLite COMMIT 880ms` in the same sample.
That is a real 100× regression and it is not the stall above — at that point
blocks were still arriving at 5/s and 171 KB/s. It needs its own diagnosis;
the state-validation breakdown at a slow commit would be the place to start.

---

# v0.45.5 — the connector residual was a transaction clone per input

## The measurement
State validation, one 16-block batch, 296 transactions, **65,407 inputs**
(221 per transaction — the 2016 consolidation stretch of the chain):

| | wall | |
|---|---|---|
| connector internal residual | ~5.2s | single-threaded, unattributed |
| script verification | 2.77s | 7 workers, 18.6s CPU |
| BIP30 | 0.79s | 296 checks |
| everything else | <0.3s | |
| **state validation total** | **8.75s** | |

The parallel script work was not the bottleneck. The single-threaded connector
loop was, by about two to one.

## Root cause
```rust
for (input_index, coin) in prevouts.iter().enumerate() {
    self.pending_scripts.push(PendingScriptCheck {
        tx: Arc::new(tx.clone()),                               // per INPUT
        precomputed: precomputed.map(|p| Arc::new(p.clone())),  // per INPUT
        ...
```
The whole transaction was deep-copied once per input. Quadratic in input count,
and invisible: no timer covered this block, so it landed in "connector internal
residual" with no clue what it was. At 221 inputs on a multi-kilobyte
transaction that is hundreds of megabytes of memcpy per batch, on the one
thread everything else waits for.

Both allocations now happen once per transaction and each input clones an `Arc`
(a refcount increment).

## Instrumentation
Two per-input passes ran outside every timer and now have their own, logged in
`[DBPIPE]`:

* `p2sh_sigops_us` — the P2SH sigop count pass. The existing sigops timer closes
  before the prevouts are loaded, so this was never covered.
* `script_queue_us` — building the queued script checks, the block above.

If a residual remains after this, those two numbers say whether it is still in
the connector.

## BIP30
`has_unspent_outputs_of` decoded every `CoinRec` of the transaction — copying
each output's script out of the block cache — to answer a question that needs 26
bytes of fixed header. New `Db::count_unspent_of_tx` applies the same
`unspent_as_of` predicate by reading the header bytes directly and never touches
the scripts.

If BIP30 is still expensive after this, the remaining cost is the RocksDB seek
itself (296 cold-cache prefix seeks), and the next step is a prefix extractor
plus bloom on the UTXO column family.

## Not addressed here
* **ECDSA at 188µs per verification** (12.3s CPU across 65,407 inputs). That is
  2–4× slower than libsecp256k1 on arm64; worth checking which backend is
  actually compiled in.
* **Sighash preparation at 84µs per input** (5.5s CPU). These are
  pre-Overwinter transactions, so sighash is O(transaction size) per input and
  therefore quadratic per transaction. Caching the serialised transaction across
  a transaction's inputs is the fix if `PrecomputedTxData` does not already.

The UTXO cache reading 0 hits / 65,404 misses is expected, not a fault: it holds
50,000 entries and these inputs spend years-old outputs.

---

# v0.45.6 — ECDSA backend, and the sighash allocation

## ECDSA: the backend was already right
`crates/script` depends on `secp256k1 = "0.29"`, which is the Rust binding to
libsecp256k1 — not a pure-Rust implementation. `ecdsa_verify` uses a static
verification-only context via `OnceLock`, so there is no per-call context
construction, which is the usual way this goes wrong. The Android build runs
`cargo build --release`.

So 188µs per verification is not a wrong library or a debug build. The remaining
explanations are thread placement (7 script workers on an 8-core big.LITTLE
phone means most of them land on little cores, which are several times slower
per verification) and codegen settings, addressed below. There is no further
correctness-preserving change available in the verification call itself.

## Release profile
The workspace had no `[profile.release]`, so Cargo's defaults applied: 16
codegen units and no LTO. Consensus validation is dominated by tight inner loops
— secp256k1's Rust glue, SHA-256/BLAKE2b, the script interpreter, the RocksDB
bindings — and those defaults block cross-crate inlining in exactly those paths.
Now `lto = "thin"`, `codegen-units = 1`.

Deliberately **not** `panic = "abort"`: the verifier, state preparation and
commit stages wrap their work in `catch_unwind` so a panic becomes a batch
rejection rather than a dead node. Aborting would turn every one of those into a
crash.

## Sighash: the allocation, not the algorithm
The legacy path allocated a fresh `Vec` of roughly the transaction's size for
every input, filled it, hashed it and dropped it. At 221 inputs per transaction
and 65,407 inputs per batch that is 65,407 allocations of ~30 KB — gigabytes of
malloc/free churn for a buffer whose contents are discarded immediately. One
thread-local buffer is now reused across calls. Not one output byte changes.

### What was not changed, and why
The quadratic behaviour itself stays. Pre-Overwinter sighash serialises the
whole transaction with one input's script substituted, so the cost is O(size)
per input and O(n²) per transaction. This is inherent to the pre-BIP143
algorithm — Bitcoin Core has the same property — and it is the reason ZIP 143
exists.

It can be improved: precompute the transaction serialised with all scripts
empty, keep a SHA-256 midstate after each input, and hash each input's preimage
as `midstate(n) + input n with script + the tail slice`. That removes the
re-serialisation but not the asymptotics, and it is byte-exact consensus surgery
that cannot be validated in this packaging environment. It is worth doing with a
test vector suite in front of it, not blind.

The practical point is that this stretch of chain ends. These input counts are a
property of the 2016 consolidation blocks, not of the node.
