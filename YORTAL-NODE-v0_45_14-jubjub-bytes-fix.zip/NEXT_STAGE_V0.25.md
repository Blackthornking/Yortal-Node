# YORTAL v0.26 — Sapling consensus state

Implemented on top of v0.25.

- ZIP-243 Sapling-era BLAKE2b-256 transaction signature hashing with Ycash consensus branch IDs.
- Sapling spend authorization signatures verified against the transaction SIGHASH.
- Sapling binding signatures verified against the same transaction SIGHASH and valueBalance.
- Sapling output proofs verified.
- Sapling anchors checked against final treestate roots from earlier committed blocks.
- Sapling nullifiers checked against the persistent chain nullifier set and against duplicates in the same transaction.
- Sapling commitment tree frontier is maintained at the ordered database commit boundary.
- Sapling roots and nullifiers are stored in SQLite consensus state.
- No viewing keys, spending keys, wallet seed, or Orchard.
- Shielded state is validated before a batch is committed, inside the same SQLite transaction.

Important: the transparent UTXO/script-signature consensus backend and legacy Sprout JoinSplit consensus backend remain separate gates. This stage does not silently accept those paths.
