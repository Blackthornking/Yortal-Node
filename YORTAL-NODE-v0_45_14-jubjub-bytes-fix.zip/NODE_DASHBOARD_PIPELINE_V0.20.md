# Ycash Node Dashboard / Pipeline v0.20

## Purpose
The Android application is now a dedicated node operator surface. Wallet controls and wallet connection testing are removed from the UI. The node itself remains the focus: chain state, peers, synchronization, pipeline pressure, throughput, validation and database commit performance.

## Dashboard metrics
- Block height / header height / target height / blocks behind
- Sync percentage and sync phase
- Peer count and listener state
- Pipeline window, blocks in flight, validation queue and current batch size
- Headers/sec
- Blocks/sec
- Block download bytes/sec
- Validation throughput (validated blocks/sec)
- Database commit throughput (commits/sec)
- Total receive throughput (header + block bytes/sec)
- Average block validation time
- Average database commit time
- Last block age and node uptime

## Instrumentation added
The status API now exposes cumulative counters for validated headers, header bytes, block bytes, DB commits, in-flight blocks, validation queue, batch size, validation time and DB commit time. The Android UI derives live rates from counter deltas over its two-second status polling interval.

## Pipeline behavior
The existing consensus rules and Ycash wire protocol are preserved. Header validation remains canonical and blocks are committed in height order. Instrumentation makes the real pipeline state visible without claiming that the current implementation is fully multi-peer concurrent block synchronization.

## Next engineering phase
A true multi-peer pipelined synchronizer should be implemented separately behind bounded queues: header fetch -> header validation -> block scheduling -> block receive -> consensus validation -> ordered DB commit, with adaptive concurrency and peer work stealing. It should be benchmarked before changing defaults.
