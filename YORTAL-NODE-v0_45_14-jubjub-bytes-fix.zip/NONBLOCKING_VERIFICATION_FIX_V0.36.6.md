# YORTAL v0.36.6 — non-blocking verification frontier

## Problem

The previous build used the 48-block download window as a hard verification
barrier. A child at `h+2` could be present while `h+1` was slow, and the whole
48-block window remained held until all required members arrived. Worse, the
peer message path called `commit_batch()` synchronously, so socket handling
could wait on the cryptographic verifier.

## Fix

The transport path now submits received blocks to `VerifierPool::try_submit()`
instead of verifying on the peer/socket thread.

The verifier coordinator still enforces the same ancestry rule:

- the first block must be exactly `canonical_height + 1`;
- its `prev_hash` must equal the canonical tip hash;
- every following block must be the next height and point to the previous block;
- a gap leaves higher arrivals buffered and does not bypass the parent.

The coordinator dispatches the first contiguous prefix as soon as it exists,
with a maximum of 8 blocks per verification micro-batch. It does not wait for
the full 48-block resource window to fill.

The 48-block limit therefore remains a memory/transport bound, not a head-of-
line verification barrier.

## Download scheduling

`missing_heights()` now uses the lifecycle registry as the source of truth.
A height is considered unavailable for a new request when its block is already
claimed in transport, verification, or the state pipeline. This avoids asking
for the same block again merely because it moved out of the old assembler.

## Safety property

No later block can be published around an absent parent. The non-blocking change
only alters scheduling and backpressure; the canonical ancestry checks remain
before semantic verification and at the state/commit boundary.

## Validation

Static source checks were updated to require the 8-block verification
micro-batch and asynchronous `try_submit()` path. A full Rust build/test still
requires the project's normal Rust toolchain.
