# YORTAL v0.34.3 — ordered parent barrier

This patch hardens the existing 48-block pipeline so block ordering is enforced at multiple independent boundaries.

## Guarantees

1. The network verifier assembles contiguous heights before verification.
2. Verifier results are reassembled by original position before they cross into state.
3. The state service sorts every `VerifiedBatch` by height again.
4. The state service rejects any batch containing a height gap or parent-hash mismatch before admitting any member.
5. The commit stage re-checks the complete run against the current canonical tip before consuming candidates.
6. The commit stage checks every child points to the immediately preceding block in the same run.
7. No candidate is removed from the prospective set until the complete run passes the ordering barrier.
8. A RocksDB publication remains the single canonical write operation.

## Important distinction

A header can legitimately exist at the next height while its fully verified block is not yet present in the candidate set. That is a waiting condition, not proof that the parent is missing from the network. The ordering barriers prevent a child from being committed before its parent.

## Validation

The source tree was inspected after modification. The environment used for this packaging does not contain the Rust `cargo` executable, so the full Rust test suite could not be executed here. The patch should be built and tested with the project's normal Rust toolchain before deployment.
