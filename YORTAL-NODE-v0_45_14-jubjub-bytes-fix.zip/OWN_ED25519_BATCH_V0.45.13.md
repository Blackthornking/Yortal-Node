# v0.45.13 — own Ed25519, no external packages, batched joinSplitSig

## New crate: crates/yortal-ed25519 (v0.4.0), zero dependencies
Only the Rust standard library. Contains its own SHA-512, arithmetic mod
2^255-19 (5x51-bit limbs), arithmetic mod the group order, Edwards point
arithmetic, ZIP-215 decoding, single verification, and a batch verifier
(random 128-bit weights from /dev/urandom, one combined equation, repeated
keys merged, bisection to single checks to name exactly the bad signatures).

Dropped from the uploaded v0.3.0: the HEEA path (sign bug; needed num-bigint)
and the adaptive batch sizer (not used by the node). All external
dependencies (curve25519-dalek, sha2, subtle, rand_core, zeroize, rayon,
num-bigint, and the dev-only ed25519-zebra, criterion, proptest) are gone.

## Node integration
- `ycash-crypto`: ed25519-zebra removed. `ed25519_verify_zip215` now calls
  `yortal_ed25519::verify`. Unused key-generation/signing FFI removed.
  `Ed25519BatchVerifier` re-exported.
- `consensus`: in the batched (16-block) path each transaction's
  joinSplitSig is queued into `ProofBatch`; `finish` checks them all with one
  Ed25519 batch before the Sapling batch. Sprout proofs are unchanged.
  The unbatched path still checks each signature on its own.

## Validation done here (no Rust toolchain available)
See tools/ed25519-check: the algorithms were transliterated to C and run
against Python big-integer arithmetic and an independent ZIP-215 model.
The Rust crate itself is not yet compiled: run `cargo test -p yortal-ed25519`.
