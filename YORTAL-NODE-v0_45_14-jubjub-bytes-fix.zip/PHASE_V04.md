# Ycash Android Node v0.4 — Consensus & Chain State

This phase moves from a protocol skeleton to a fail-closed validation/commit pipeline.

## Implemented
- strict block parsing with bounded CompactSize fields
- strict consensus FFI entrypoints for Ycash 4.5.0
- contextual height and median-time checks
- persistent SQLite chain/block metadata
- best-chain marker and tip persistence
- undo/nullifier/UTXO tables reserved for atomic state transitions
- commit boundary that validates before state mutation

## Safety boundary
The Rust node does not invent Ycash consensus rules. `Ycash 4.5.0 reference implementation` 4.5.0 remains the oracle until every consensus-critical rule is ported and differential-tested. The Ycash 4.5.0 `fChecked` fix must remain enforced.

## Next
Implement exact Ycash contextual rules, UTXO/nullifier state transitions, cumulative-work chain selection, reorg/undo execution, and historical differential replay.
