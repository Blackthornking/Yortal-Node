# Ycash Android Node — Rust Full v0.8

## Phase 8: Live-network transport runtime

Added:
- TCP connection timeout/read/write configuration
- Ycash-compatible message receive path
- checksum enforcement
- CompactSize serialization
- `version` payload construction
- `verack` payload support
- `getheaders` payload construction
- controlled read-only connectivity probe
- explicit no-relay/no-state-commit behavior in the probe

Ycash mainnet uses P2P port 8833 and the mainnet message-start bytes from the
Ycash chain parameters.

### Test mode

The node can now be pointed at a peer as a transport probe. This phase is still
**not a production sync implementation**: it deliberately does not commit downloaded
blocks or relay transactions until consensus and state integration are complete.

### Next

Phase 9: complete the peer handshake state machine, parse `headers`, request `block`
messages, stream bounded block bodies, validate them through the Ycash consensus
boundary, commit through the v0.5 state engine, and produce a sync-height/status API.
