# Phase 10 — UI wired to node-owned telemetry

The Android UI now polls the Rust node's localhost status endpoint:
GET http://127.0.0.1:8834/status

The endpoint is owned by the Rust node and returns status, peer count, height,
sync state and a diagnostic message.

The Android UI displays those returned values rather than fabricating chain data.

Important: v0.10 completes the UI-to-node telemetry wire, but the status fields
are still initialized by the node runtime. The next implementation step is to
feed them from the live P2P peer manager and chain synchronization/state engine.
No fake mainnet height is claimed.
