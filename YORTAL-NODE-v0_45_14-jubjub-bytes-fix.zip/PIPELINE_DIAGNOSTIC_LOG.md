# Pipeline diagnostic logging

The Android block pipeline now emits plain stderr lines prefixed with `[PIPELINE]`.
They are intended to make the first failing stage unambiguous in Android/logcat.

Typical healthy sequence:

    INIT
    PLAN
    PLAN_RESULT
    CLAIM
    HEADER_LOOKUP
    VALIDATION_MODE
    GETDATA
    BLOCK_OK (one per block)
    VALIDATED_RANGE
    BUFFER
    COMMIT_START
    COMMIT_OK

Important failure stages:

* `CONFIG_MISMATCH` — the caller supplied more than one worker. Strict sequential
  mode expects exactly one.
* `LOOKAHEAD` — more work was planned ahead than the sequential window permits.
* `HEADER_LOOKUP` / `missing header` — the claimed range cannot be mapped to
  stored headers.
* `NOTFOUND` — the peer does not have the requested range.
* `READ_TIMEOUT` / `PROGRESS_TIMEOUT` — the peer stopped delivering requested blocks.
* `VALIDATION_ERROR` — the exact block height and validation error are printed.
* `UNSUPPORTED` — validation requires functionality this node does not have;
  this is deterministic and the pipeline halts instead of cycling peers.
* `RANGE_ERROR` / `RELEASE` — transport/range failure and resulting retry/quarantine
  counters.
* `COMMIT_ERROR` — the database/state commit failed; the exact range and error are
  printed.
* `COMMIT_OK` — commit completed and its duration is shown.

The most useful diagnostic is the **first `VALIDATION_ERROR`, `UNSUPPORTED`, or
`COMMIT_ERROR`** after `CLAIM`. If there is no `CLAIM`, the problem is scheduling.
If there is `CLAIM` but no `GETDATA`, it is header lookup/planning. If there is
`GETDATA` but no `BLOCK_OK`, it is peer/transport. If there are `BLOCK_OK` lines
but no `COMMIT_OK`, it is buffering/commit.
