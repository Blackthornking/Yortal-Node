# YORTAL v0.36.9 — single 16-block verification window fix

This patch changes the live sync pipeline to one bounded 16-block verification window.

## Changes

- Verification micro-batch maximum: **16 blocks**.
- Legacy ordered batch assembler size: **16 blocks**.
- Default per-peer transport window: **16 blocks**.
- Default global lifecycle/in-flight limit: **16 blocks**.
- Default prospective candidate capacity: **16 blocks**.
- Verifier ingress queue: **16 blocks** (the verifier queue cannot accumulate multiple full batches).
- Environment overrides for per-peer, global in-flight, and prospective capacity are hard-capped at **16**.
- The verifier coordinator remains serial: `dispatch_and_publish()` completes the entire current batch and publishes it downstream before the coordinator can dispatch the next batch. Therefore there is **never a second verification batch in flight**.

The canonical-head recovery path remains allowed to use its existing special head claim semantics so a missing parent cannot deadlock a full speculative window.
