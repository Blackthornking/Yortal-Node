# YORTAL v0.31 pipeline stall fix

Implemented the head-of-line and CPU-budget fixes identified from v0.31 telemetry.

## Changes

1. **Head-of-line recovery works even when the head is already verifying.**
   The watchdog no longer treats `verifying_starts` as a reason to disable recovery.
   A leased head older than 8 seconds is re-leased, including when its verifier is
   stalled. Recovery never skips a height.

2. **Lease-generation stale-result barrier.**
   Re-leasing increments the scheduler generation. A verifier result is accepted
   only when its `(RangeId, generation)` is still current. Late results from the
   old verifier are discarded and cannot enter the canonical buffer.

3. **Generation-aware verification tracking.**
   Verification state is keyed by start height plus lease ID/generation, so a stale
   verifier cannot clear the tracking entry belonging to its replacement. A new
   generation of the same range is allowed to queue normally.

4. **Commit CPU split is protected from the adaptive sampler.**
   While `commit_active` is true, the 500 ms sampler does not overwrite the stage
   budget. The permanent ordered committer retains one slot, one validation worker
   remains active, and the remaining YORTAL CPU budget is assigned to script work.
   On an 8-core device this is 1 Android reserve + 1 commit + 1 validation + 5 script.

5. **Race protection around commit ownership.**
   The sampler re-checks `commit_active` after changing the normal budget and
   immediately restores the commit split if ownership changed during that update.

## Consensus safety

No block is skipped and no state transition is moved outside the ordered commit
barrier. Recovery only changes which peer/generation supplies the same height range.
A stale generation cannot publish a commit candidate.
