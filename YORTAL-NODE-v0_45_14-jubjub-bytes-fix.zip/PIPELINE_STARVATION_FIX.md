# Pipeline starvation / head-of-line fix

This patch addresses the freeze where sync falls to a 16-block window, leaves only
one range in flight, and the canonical committer stops receiving input after a
peer closes or stalls.

Changes:
- Partition the adaptive lookahead window across multiple independent network
  ranges instead of making one range consume the whole window.
- Keep at least two in-flight network opportunities under non-emergency pressure;
  only emergency pressure may reduce this to one.
- Hedge the ordered head range after the normal 20-second timeout even when the
  validation buffer is empty. An empty buffer is itself a starvation condition.
- Run planning/hedging from the 500 ms adaptive watchdog so recovery does not
  depend on a peer session reaching its planning call.
- Correct peer-load accounting when a stalled lease is requeued.
- Preserve exactly one permanent canonical commit worker and all existing
  consensus ordering barriers.

Expected 8-core behavior remains:
  Android reserve: 1
  canonical committer: 1
  validation: adaptive, with at least 1 during commit
  script budget: remaining CPU slots

No consensus ordering rule was changed.
