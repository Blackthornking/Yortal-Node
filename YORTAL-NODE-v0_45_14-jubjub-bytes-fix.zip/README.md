# YORTAL v0.24 — Rust-only Ycash node

See `CONSENSUS_V0.24_RUST_ONLY.md` and `tests/CONSENSUS_RULE_AUDIT.md` for the consensus rewrite and audit.

## v0.23 concurrent sync

The node now uses concurrent multi-peer block-range workers with parallel validation, ordered canonical commits, lease retry/quarantine, and adaptive resource feedback. Headers remain serialized through the canonical consensus path. See `V0.23_CONCURRENT_PIPELINE.md`.

# Ycash Android Node — Rust Full v0.3

This stage moves the project from a placeholder consensus boundary to an explicit, strict Ycash 4.5.0
consensus oracle integration and differential-testing plan.

## Security rule

The Rust node does not invent consensus rules. Until the Ycash 4.5.0 native consensus core is linked and
historically differential-tested, consensus validation remains fail-closed.

## Why this stage matters

Ycash 4.5.0 fixed an insufficiently checked block vulnerability involving the `fChecked` validation cache.
The strict bridge therefore uses `ProofVerifier::Strict()` and `CheckBlock` with proof, merkle, and transaction
checks enabled.

## Modern architecture

The node follows the useful separation demonstrated by modern Rust nodes: chain types, consensus, state,
networking and orchestration are independent layers. This makes Android resource management and testing easier.

## Next release gate

- Link the bridge against the pinned Ycash 4.5.0 native core.
- Compile for aarch64-linux-android.
- Run the complete differential suite.
- Replay historical Ycash blocks.
- Synchronize against Ycash mainnet.
- Only then enable the Rust node as a validating network peer.


## v0.5
Chain-state engine added: cumulative-work selection, fork discovery, rollback paths, and undo records.

## v0.6
Synchronization engine primitives: bounded block scheduling, header tracking, work selection, and request lifecycle.

## v0.7
Live Ycash mainnet wire/connectivity foundation with bounded message framing and peer scoring.

## v0.8
Live TCP transport runtime, message receive/checksum path, version/getheaders serialization, and read-only connectivity probe.

## v0.8 UI
Basic Android test UI added with node status, peer/height/sync placeholders, start/stop controls, and a real TCP connectivity test for Ycash mainnet port 8833.

## v0.9 Real UI telemetry
Android UI now polls a localhost `/status` endpoint for node status, peer count, height, sync state, and message. Rust defines the JSON status contract.

## v0.10
Node-owned localhost telemetry endpoint wired to Android UI.

## v0.11
Live shared node-state telemetry wired to the Android UI, including peer count, committed height, headers height, and derived sync percentage.

## Development roadmap
See `REMAINING_STAGES.md` for the remaining implementation stages and `DEVELOPMENT_STATUS.md` for current status.


## Node Monitor v0.20
The Android UI is a dedicated node-only operator dashboard. Wallet/lightwallet UI controls are removed from the Activity. The dashboard exposes chain progress, peers, pipeline window/in-flight work, validation queue, headers/sec, blocks/sec, download throughput, receive throughput, validation latency and database commit latency. See `NODE_DASHBOARD_PIPELINE_V0.20.md`.

## v0.25 consensus stage
The node validates external Sapling parameter files and verifies Sapling output proofs in the Rust consensus commit gate. Sapling spends now use ZIP-243 transaction SIGHASH, persistent anchor/nullifier state, spend proofs, spend-auth signatures, output proofs, and binding-signature verification at the ordered commit boundary. Sprout JoinSplits and transparent UTXO/script validation remain separate fail-closed gates. No wallet keys are used.

# Adaptive Pipeline Stall Fix

## Problem
A single critical DB/CPU sample could bypass the EWMA and force the adaptive
controller to `(1 worker, 1 inflight)`. With only one range in flight, a peer
handshake failure could leave the fetch side at 0 headers/s until the hedge
watchdog released the range.

## Fix
- Normal adaptive budgets now use the EWMA (`effective`) pressure signal.
- The emergency `(1,1)` floor is no longer selected from one raw sample.
- Critical pressure must be observed for 3 consecutive samples before the
  emergency floor is enabled.
- A non-critical sample immediately clears the critical streak, allowing the
  controller to recover from the emergency state without changing consensus
  ordering or canonical commit ownership.
- Regression tests cover transient critical pressure, sustained critical
  pressure, and recovery.

This deliberately changes scheduling/backpressure only. It does not change
validation rules, canonical commit order, lease-generation checks, or consensus
state-transition logic.

## Expected behavior

Single 213 ms DB write+commit sample:

`raw=critical -> EWMA rises -> normal bounded budget reduction`

rather than:

`raw=critical -> immediate (1,1) -> one peer failure -> producer stall`

Three consecutive critical samples:

`critical x3 -> emergency (1,1)`

Then one non-critical sample clears the emergency streak; the EWMA continues
to provide gradual recovery rather than an immediate full reset.
