# v0.45.12 — RedJubjub batch fixes, merged onto v0.45.11

Review of the v0.45.10 RedJubjub batch patch found two bugs. Neither could
accept an invalid block (the individual verifier stays authoritative), but
together they made every batch fail and switched batching off entirely.

1. Wrong challenge. Sapling signs M = vk || sighash and RedJubjub's challenge
   is c = H*(Rbar || M). The batch computed H*(Rbar || vk || M), hashing vk
   twice, so every valid signature failed the batch equation.
2. Success reported as failure. `RedJubjubBatch::verify` returned
   Err(all tags) when the batch PASSED (empty `failed` list fell into the
   mismatch branch).

Effect before the fix: every 16-block batch failed, was bisected, every
transaction was re-verified individually, each counted as a batch mismatch,
and after 3 mismatches `disable_batching()` turned off Groth16 batching too.

Also:
- The signature batch and the Groth16 batch now run in parallel (rayon::join)
  on the verifier pool.
- New tests: a fully valid batch returns Ok; the challenge matches the
  reference verifier with the real Sapling vk || sighash message layout.
- Merged onto v0.45.11 (strict entry, 4 verifiers, 2 state workers,
  ordered commit), which the uploaded v0.45.10 patch did not include.
