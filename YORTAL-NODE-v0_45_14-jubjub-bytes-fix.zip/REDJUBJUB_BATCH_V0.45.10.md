# RedJubjub SpendAuth / BindingSig batching — v0.45.10

This patch adds a project-owned RedJubjub batch accumulator to the existing
Sapling verification pipeline without adding a standalone RedJubjub crate.

## What changed

- `crates/ycash-crypto/src/redjubjub_batch.rs`
  - Parses signatures with the existing `zcash_primitives::redjubjub` types.
  - Computes the consensus RedJubjub challenge using BLAKE2b-512 with
    `Zcash_RedJubjubH` personalization.
  - Accumulates both `SpendAuthSig` and `BindingSig` items.
  - Uses separate `-sum(z*s)` coefficients for the SpendAuth and Binding
    generators, then combines R and verification-key terms in one Jubjub MSM.
  - Uses fresh non-zero 128-bit random batch coefficients.
  - Uses a windowed Pippenger MSM.
  - Bisects a failed batch and falls back to the existing individual
    `PublicKey::verify` equation to identify exact failing transaction tags.

- `crates/ycash-crypto/src/batch.rs`
  - `SaplingBatch` now owns the RedJubjub accumulator beside the existing
    Groth16 proof accumulators.
  - `SaplingBatchTx::check_spend` queues SpendAuth signatures after parsing and
    small-order checks instead of verifying each one immediately.
  - `SaplingBatchTx::final_check` queues BindingSig after the value-balance key
    and message are derived.
  - Worker-local batches rebase signature tags together with proof tags.
  - `SaplingBatch::verify` verifies signatures and Groth16 proofs for the same
    canonical transaction batch and returns the union of failing transaction
    tags.
  - Adds `redjubjub_batch_stats()` telemetry access.

- `crates/ycash-crypto/src/verify.rs` and `rustzcash.rs`
  - The FFI/reference path remains independent: it verifies RedJubjub signatures
    individually and verifies Groth16 proofs individually.
  - This is the authoritative fallback for consensus batch failures.

- `crates/consensus/src/lib.rs`
  - Documents that SpendAuth, BindingSig, and Groth16 are deferred into the
    canonical batch.
  - Exposes RedJubjub batch statistics.

## Pipeline

4 Rayon workers prepare transactions concurrently -> canonical 16-block batch ->
RedJubjub SpendAuth + BindingSig aggregate -> Groth16 proof batch -> ordered
consensus result -> commit.

A signature batch failure is a locator hint only. The consensus layer re-runs the
original individual verifier on affected transactions, so the aggregate path is
not itself the final consensus authority.

## Compatibility

No new cryptographic dependency was added. The patch uses the existing
`zcash_primitives::redjubjub` parser and `PublicKey::verify` implementation while
implementing the batch accumulator and MSM locally.

The batch equation preserves the Sapling RedJubjub parameterizations: SpendAuth
and Binding use distinct generators and therefore retain separate generator
coefficients inside the shared MSM.
