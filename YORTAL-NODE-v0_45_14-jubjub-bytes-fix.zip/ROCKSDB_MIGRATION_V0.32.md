# YORTAL v0.32 — RocksDB state backend

SQLite is gone. `crates/state` now stores canonical state in RocksDB, using the
same engine, version and layout style as Zebra 6.3.0 (`zebra-state`'s finalized
state): one column family per logical index, big-endian height keys, and one
atomic `WriteBatch` per ordered commit.

Consensus is untouched. Every rule listed under "CONSENSUS RULES THAT MUST NOT
CHANGE" in `Yortal_RocksDB_Without_Affecting_Ycash_Consensus.txt` lives in
`crates/consensus`, `crates/script` and `BlockConnector`, and none of those
files changed except where a lookup's *engine* changed.

## Layering (unchanged shape, new bottom layer)

```
Consensus (block/tx/script/shielded rules, network upgrades)
        |
State transition (apply_block: UTXO, nullifier, tree changes)
        |
Ordered canonical committer (one writer, height N -> N+1 -> N+2)
        |
RocksDB (persistence / index / cache)
```

`prepare_commit_batch()` does every consensus and state-transition step against
a **RocksDB snapshot** and returns an immutable mutation plan.
`apply_prepared_commit()` turns that plan into **one WriteBatch** and writes it.
Validation workers never mutate canonical state; the committer never validates.

## Column families

| Column family | Key | Value | Replaces |
|---|---|---|---|
| `meta` | ascii name | bytes | `meta` table |
| `block_by_hash` | hash | height, prev, work, canonical | `blocks` row minus raw |
| `block_raw_by_hash` | hash | raw block | `blocks.raw` |
| `block_txids_by_hash` | hash | txid ‖ txid ‖ … | (new) rollback index |
| `hash_by_height` | height BE | hash | `blocks.main_chain=1` |
| `header_by_hash` | hash | height, prev, time, bits, work, raw | `headers` |
| `header_hash_by_height` | height BE | hash | `headers.main_chain=1` |
| `tx_by_txid` | txid | block hash ‖ raw tx | `txs` |
| `utxo_by_outpoint` | txid ‖ vout BE | value, height, coinbase, spent_height, script | `utxos` |
| `utxo_loc_by_height` | height BE ‖ outpoint | — | `utxos_height` index |
| `utxo_loc_by_spent_height` | spent height BE ‖ outpoint | — | `utxos_spent_height` index |
| `sapling_nullifiers` | nullifier | height ‖ block hash | `nullifiers` |
| `sapling_nullifier_by_block` | block hash ‖ nullifier | — | `nullifiers_block_hash` |
| `sapling_note_commitment_tree` | block hash | root, height, frontier | `sapling_roots` |
| `sapling_anchors` | root | lowest canonical height BE | `sapling_roots_root_main_height` |
| `sprout_nullifiers` | nullifier | height | `sprout_nullifiers` |
| `sprout_nullifier_by_height` | height BE ‖ nullifier | — | `sprout_nullifiers_height` |
| `sprout_block_state` | block hash | height, root, value pools, frontier | `block_state` |
| `sprout_anchors` | root | lowest height ‖ frontier | `block_state_sprout_root_height` |

Two secondary indexes carry the queries SQL used to answer with a WHERE clause:

* `SELECT … WHERE root=? AND main_chain=1 AND height < H` becomes a point lookup
  on `sapling_anchors`, because the stored value is the **lowest** canonical
  height at which that root appeared. If the lowest occurrence is below `H`, an
  occurrence below `H` exists; if it is at or above `H`, every occurrence is.
* BIP30's `SELECT COUNT(*) … WHERE txid=?` is a short prefix scan: all outputs
  of one txid share a 32-byte key prefix.

The "unspent as of the batch's first height" predicate is unchanged:
`height < H AND (spent_height IS NULL OR spent_height >= H)`, now evaluated in
`CoinRec::unspent_as_of`.

## Atomicity and crash recovery

One commit = one `WriteBatch` containing, in order:

1. rollback of any state at or above the fork height (reorg only),
2. block metadata, raw blocks, transactions, Sapling trees and anchors,
3. Sapling nullifiers,
4. the prepared UTXO delta and the prepared Sprout delta,
5. pruning of outputs spent deeper than the 100-block reorg window,
6. **the canonical tip marker and Sapling frontier**.

Steps 1–6 become visible together, so the tip never describes state that is not
there and state is never present without its tip. WAL is on with `sync=false`,
matching the old `journal_mode=WAL; synchronous=NORMAL`: an Android process kill
cannot lose a committed batch.

On restart, the canonical tip is read from the `hash_by_height` index — the
state actually on disk — not from a downloaded-height marker, so "last
downloaded" and "last committed" stay separate exactly as the design requires.

A reorg is now genuinely atomic: the old backend demoted rows and deleted
indexes in a write transaction; the new one stages every deletion into the same
batch as the new blocks, so there is no window where a half-reorged anchor set
is visible.

## Memory tuning (this is a phone)

* global memtable budget 96 MB (`set_db_write_buffer_size`) — without this, 19
  column families each reserve their own write buffers,
* shared 64 MB LRU block cache across all families,
* 16 MB write buffers for hot families (UTXO, tx, raw blocks), 4 MB elsewhere,
* LZ4 only, ribbon filters (both as in Zebra), 2 background jobs, 512 open files.

## Build requirements (new)

RocksDB is C++ compiled from source by `librocksdb-sys` and bound by `bindgen`,
so the Android cross-build needs more than a Rust toolchain.
`tools/build-android-arm64.sh` now sets all of it up and fails early with a
clear message if something is missing:

* **libclang on the host** (`apt-get install -y clang libclang-dev`), for bindgen;
* `BINDGEN_EXTRA_CLANG_ARGS` with the NDK target triple and sysroot, or bindgen
  parses RocksDB's headers against the host libc;
* `AR`/`RANLIB` from the NDK's LLVM toolchain;
* `-static-libstdc++` plus an empty `CXXSTDLIB`, so no `libc++_shared.so` has to
  be shipped alongside the executable that ships as
  `jniLibs/arm64-v8a/libycashandroidnode.so`.

Expect several minutes for the first build and a noticeably larger binary
(statically linked RocksDB + libc++ typically adds 10–20 MB before stripping).

If the workspace dependency fails to resolve a bindgen backend, add the feature
explicitly:

```toml
rocksdb = { version = "0.24", default-features = false, features = ["lz4", "bindgen-runtime"] }
```

## App-side changes

* `NodeService` now passes `ycash-node.rocksdb` (a **directory**) as
  `YCASH_NODE_DB`; the node's own defaults changed to match.
* `MainActivity`'s database size stat sums the directory instead of reading one
  file's length.
* Chain export: a RocksDB checkpoint is a directory, so `/export` now streams a
  single uncompressed **tar** of a checkpoint (`ycash-chain-height-N.tar`),
  which the app still zips on the fly. The checkpoint uses hard links where
  possible, so it neither copies the chain nor stalls the committer.
* Dashboard field names (`last_sqlite_commit_us`, `sql_write_ms`, …) are kept so
  the JSON contract does not break; they now measure the WriteBatch stages. The
  UI label reads "RocksDB COMMIT".

## Migration

There is no SQLite → RocksDB data migration. The state is re-syncable, and
converting it would mean trusting rows written by a different engine's schema.
If `YCASH_NODE_DB` points at an existing *file* (an old `ycash-node.sqlite`), it
is renamed to `<path>.sqlite-legacy` and a fresh RocksDB directory is created in
its place, so an upgraded app starts instead of failing to open its database.

## What still needs doing before release

1. **Compile and run the test suite** — this change was written without a Rust
   toolchain available, so it has not been through `cargo check`.
2. Sync a device from genesis past the first Sapling-heavy range and compare the
   committed tip hash at several heights against the previous SQLite build
   (point 9/10 of the migration plan: same block sequence, same logical state).
3. Force a reorg on a test branch and confirm: rollback + extension in one
   batch, anchors and nullifiers of the rolled-back branch gone, outputs spent
   by rolled-back blocks unspent again.
4. Kill the process mid-sync (`adb shell am force-stop`) repeatedly and confirm
   the node resumes from the committed tip, not the downloaded tip.
5. Watch RSS on an 8-core/6 GB device; if RocksDB's memory is too generous,
   `TOTAL_MEMTABLE_MB` and `BLOCK_CACHE_MB` in `crates/state/src/db.rs` are the
   two knobs.

## Compile-fix pass: where to look first

The code was written without a toolchain available, so it has not been through
`cargo check`. A manual audit pass covered field-disjoint borrows in `Writer`,
partial moves in `CoinRec`/`Coin` construction, closure capture lifetimes in
`prepare_commit_batch`, and array→slice coercions at call sites. These are the
spots most likely still to need a small adjustment, all of them in
`crates/state/src/db.rs`:

1. **Feature resolution.** If Cargo complains that no bindgen backend is
   selected, add `"bindgen-runtime"` to the `rocksdb` features in the workspace
   manifest.
2. **Snapshot API names.** `ReadView` uses `snapshot.get_cf(...)` and
   `snapshot.iterator_cf(...)`. If either is missing in the resolved
   rust-rocksdb version, the equivalent is a `ReadOptions` with
   `set_snapshot(&snap)` passed to `get_cf_opt` / `iterator_cf_opt`.
3. **`Cache::new_lru_cache`** returns `Cache` in 0.21+; older releases returned
   `Result<Cache, Error>`.
4. **`BlockBasedOptions::set_ribbon_filter`** — dropping this line costs nothing
   but filter efficiency if the signature differs.
5. **`matches!(name.as_str(), CF_UTXO | …)`** uses `&'static str` consts as
   patterns. If that trips over const-pattern rules, replace it with
   `[CF_UTXO, …].contains(&name.as_str())`.

Everything outside `db.rs` uses only std and the crate's own types, so a failure
there is more likely a genuine logic mistake than an API mismatch.

## Two behaviour notes

* **`transaction_count()`** is now a counter in `meta`, incremented per
  committed transaction and decremented on rollback, not a `COUNT(*)`. RocksDB
  has no cheap exact count. A reorg that re-commits the same txids can drift the
  figure slightly; it feeds the dashboard's `txs_indexed` stat only.
* **Spent-output pruning** keeps a `utxo_prune_floor` marker so each commit
  scans only the newly expired slice of the spent-height index instead of
  re-walking the tombstones left by every earlier prune. A rollback lowers the
  floor to the fork height.

## Android link step: C++ runtime

`librocksdb-sys` emits a bare `cargo:rustc-link-lib=stdc++` for any target whose
triple contains "linux" — which includes `aarch64-linux-android`, where that
resolves to a stub defining none of libc++'s symbols. rustc also links with
`-nodefaultlibs`, so the clang driver contributes no C++ runtime of its own and
`-static-libstdc++` is a no-op. The result is a wall of undefined
`std::__ndk1::*` and `__cxxabiv1::*` symbols.

`tools/build-android-arm64.sh` therefore names the NDK runtime explicitly:

```
-C link-arg=-lc++_static -C link-arg=-lc++abi -C link-arg=-lunwind
```

Order matters. LLD resolves static archives in command-line order, and rustc
places `link-arg`s last, after every rlib — which is exactly where these need to
be. `-lunwind` follows `-lc++abi` because libc++abi pulls in `_Unwind_*` itself.
The linked result has no `libc++_shared.so` dependency, which the workflow
asserts with `readelf -d` after the build.
