# YORTAL v0.30.5 — Script Parallel Bottleneck Instrumentation

## Purpose
Instrument the existing consensus-neutral transparent-script parallel verification path without changing validation rules or ordered state mutation.

## New measurements
- per-worker wall time (up to 4 workers)
- per-worker summed input execution time
- per-worker input count
- parent-side spawn/setup time
- join/wait time
- max/min worker span

## Interpretation
`Script parallel verification` remains the wall-clock duration of the parallel section. `Script input work` is the sum of per-input timings and can exceed wall time. Worker wall spans expose load imbalance. Spawn/setup and join/wait expose orchestration overhead.

No consensus behavior, script flags, input order, state mutation order, or worker cap was changed. The instrumentation is diagnostic only.
