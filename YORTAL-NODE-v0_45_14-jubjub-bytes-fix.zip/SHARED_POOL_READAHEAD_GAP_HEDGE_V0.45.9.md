# v0.45.9 — one shared 4-worker pool, UTXO read-ahead, gap hedging

## Fixed pipeline layout
    network → 1 assembler (full 16-block batches, 4 ready)
            → shared pool, 4 workers (one job per block + script checks)
            → 1 state-preparation worker
            → 1 commit worker (publication only)

## 1. One shared pool (chainstate.rs, batch.rs, verifier.rs, lib.rs)
- `ycash_state::chainstate::shared_pool()` is the only Rayon pool for pure
  parallel work. Width = `verifier_workers` (default 4), fixed by
  `configure_shared_pool` in `SyncEngine::start` before first use.
  Threads are named `yortal-work-0..3`.
- Block verification: one pool job per block (was 4 fixed slices of 4).
  Proof queues are merged in height order; the global Sapling batch and the
  isolation fallback run on the same pool. A panic in any block's job
  rejects the whole batch.
- Transparent script checks from state preparation use the same pool, so
  idle verifier threads pick them up. Ordered UTXO/Sprout/Sapling mutation
  stays on the single preparation thread.
- `SCRIPT_WORKERS` / `YORTAL_SCRIPT_WORKERS` no longer size a pool.

## 2. UTXO read-ahead (verifier.rs, state/lib.rs, chainstate.rs)
While batch N publishes, the preparation worker takes batch N+1 if it is
already verified (non-blocking `try_recv`) and reads its input coins from
RocksDB. Safety rules:
- coins spent by batch N are never read ahead (snapshot may predate N's write);
- only positive results are kept; coins created by N are read normally;
- the hint is bound to N+1's first height and parent hash, used only when
  preparation runs on exactly that tip, consumed once, and cleared on any
  reset or failed publication;
- skipped entirely if batch N's spend set is unknown.
Log lines: `[READAHEAD] read ...` and `[READAHEAD] batch from ... resolved ...`.
Read-ahead hits also count as `utxo_cache_hits`.

## 3. Gap hedging (lib.rs, downloader.rs, sync_coordinator.rs)
If the assembler waits on the same missing height for 4s
(`GAP_HEDGE_DELAY`) and it is an outstanding request, the watchdog moves it to
another connected peer, which gets a 2s priority window. A late delivery from
the first peer is still accepted. Canonical head (tip+1) recovery is unchanged.
The 20s starvation valve remains as the last resort. Log: `[INTAKE] gap ...`.

## Not added: parent-link check in the assembler
Blocks are accepted only if their hash equals the requested header hash, and
that hash covers the previous-block field. The parent link is therefore
already guaranteed by the header chain; a second check would be a no-op.

## Assembler
Unchanged: releases only complete contiguous 16-block batches, keeps 4 ready.
The only short batch is the chain-end flush, which fires only when every
block up to the validated header tip is in hand.
