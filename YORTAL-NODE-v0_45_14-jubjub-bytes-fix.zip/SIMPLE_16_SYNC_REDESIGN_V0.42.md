# YORTAL v0.42 — simple bounded 16-block sync

## Research conclusion

The old YORTAL implementation had accumulated several overlapping schedulers:
range leasing, prospective buffering, verifier partitioning, micro-batches, and a
separate coordinator. That complexity is not required for consensus correctness.

Zebra's current architecture supports the key principle we retain: expensive
context-free/cryptographic verification can run out of order, while contextual
state validation and canonical publication remain in chain order. Zebra explicitly
separates consensus verification from the state service and keeps ancestor-dependent
checks at the ordered state boundary.

Ycash/zcashd remains the compatibility reference for the wire and consensus rules.
The Ycash network implementation in this project retains its hard per-peer
`MAX_BLOCKS_IN_TRANSIT_PER_PEER = 16` rule.

## New live design

```text
Ycash peers
   │
   ├── max 16 outstanding block requests / peer
   │
   ▼
bounded verifier queue: 64 blocks (4 × 16)
   │
   ▼
N cryptographic verifier workers
   │    (same existing consensus/crypto verifier)
   │
   ▼
verified results indexed by height
   │
   ▼
ordered gate: wait only for canonical tip + 1 .. + 16
   │
   ▼
state-dependent consensus preparation
   │
   ▼
one atomic 16-block canonical publication
```

### What was removed from the live path

- verifier slice/range partitioning;
- 16-block semantic coordinator;
- speculative cross-block verification scheduler;
- separate proof micro-batch scheduler at the pipeline layer;
- duplicate live batch assembler/coordinator responsibilities.

The old `batch.rs` helper remains only as source compatibility/test code; it is
not used by the new live verifier path.

### What is deliberately retained

- Ycash wire/network behavior and peer limits;
- exact 16 blocks per peer in-flight rule;
- four 16-blocks of bounded verifier backpressure;
- the existing cryptographic/consensus verifier implementation;
- ordered canonical state transitions;
- exact 16-block atomic publication;
- Ycash consensus rules, including contextual UTXO/script/state checks.

### Why this should be faster and safer

The expensive verifier no longer waits for a full 16-block batch and no longer
partitions work through a second scheduling layer. Workers pull individual blocks
from one bounded queue, which naturally keeps all cores busy when blocks are
available. The ordered commit boundary still prevents state races and consensus
reordering.

A 64-block queue is intentionally bounded: it provides four 16-block windows of
waiting work without allowing unbounded RAM growth. Increasing it is not part of
this change.

## Consensus safety rule

The redesign changes scheduling only. It must not change any consensus result.
A block is accepted only if the existing Ycash verifier accepts it, and canonical
state is still advanced only in strict height order through the existing state
commit machinery.
