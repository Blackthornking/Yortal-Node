# YORTAL v0.30.1 — ordered state-validation instrumentation

This build adds fine-grained telemetry inside the ordered `State::commit_blocks_batch` state-validation phase. The purpose is diagnosis only: consensus ordering and validation rules are unchanged.

## Logged stages

`[DBPIPE] stage=STATE_VALIDATED` now reports:

- `parent_state_ms` — loading canonical Sapling/Sprout parent state.
- `block_parse_ms` — decoding the raw block envelope/transactions.
- `tx_parse_us` — transaction parsing/cloning time, in microseconds.
- `tx_connect_ms` — total transparent/Sprout transaction connection time.
  - `sigops_ms`
  - `bip30_ms` and `bip30_checks`
  - `utxo_lookup_ms` and `utxo_lookups`
  - `sprout_req_ms`
  - `value_ms`
  - `script_ms` and `script_checks`
  - `coin_state_ms`
  - `sprout_apply_ms`
- `sapling_validate_ms` — Sapling state validation as a whole.
  - `sapling_anchor_ms` and `sapling_anchor_queries`
  - `sapling_nullifier_ms` and `sapling_nullifier_queries`
  - `sapling_tree_ms` — Sapling work after subtracting the measured anchor/nullifier lookup time.
- `block_finalize_ms` — per-block connector/treestate finalization.

The existing `state_validate_ms` remains the wall-clock total for the complete ordered state-validation transaction, so the detailed stages can be compared against the real elapsed total.

## Android dashboard

The status API exposes the latest batch's detailed fields, and the Android node screen displays them under **STATE VALIDATION BREAKDOWN**. This makes the next performance sample directly actionable without requiring access to logcat.

## Consensus safety

Instrumentation only measures elapsed time and counts. It does not skip, reorder, cache-away, or weaken any consensus check. The existing Sapling proof verification/anchor/nullifier/tree logic remains in the same ordered commit path.
