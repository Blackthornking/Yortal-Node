# v0.45.11 — strict batch entry, 4 verifiers, 2 state workers, ordered commit

    network → 1 assembler ── entry check ──► 4 verifiers (verify only)
            → 2 state workers (together) ── order check ──► 1 atomic commit

## 1. Entry: only an ordered batch with its parent (verifier.rs `batch_entry_error`)
Before a batch leaves the assembler it must be 16 ascending heights, each
block's parent the block before it, and the first block's parent the validated
header directly below. Otherwise the whole batch is handed back to the
downloader and the gate keeps waiting at the same height. Log: `[INTAKE] ... refused`.

## 2. Verifiers: 4 threads, verification only (batch.rs, verifier.rs)
Own pool `yortal-verify-0..3`. Nothing else runs on it.
Per 16-block batch:
- each block is parsed and its per-transaction checks run on one of the 4
  (structure, Sapling spend-auth and binding signatures, JoinSplit signature);
- every Sapling Groth16 proof from all 16 blocks goes into ONE batch and is
  verified with ONE combined pairing check (Spend + Output keys share one
  final exponentiation);
- blocks are verified one by one only if that batch fails, to find the bad one.

## 3. State stage: 2 workers together (chainstate.rs, verifier.rs, lib.rs)
Pool `yortal-state-0..1` (`STATE_WORKERS = 2`). Worker 0 runs the ordered
UTXO/Sprout/Sapling walk; transparent script checks run on worker 1, and
worker 0 joins the script work whenever it waits (`wait_helping`). The
four verifiers never touch this work.

## 4. Commit: in order or not at all (verifier.rs `publication_order_error`)
Right before the atomic write: first height = canonical tip + 1, first
block's parent = canonical tip hash, every block's parent = the previous
block, heights strictly ascending. Otherwise publication is refused and the
pipeline resets from the tip.
