# YORTAL v0.33 telemetry wiring audit

This patch makes the Android dashboard consume the real v0.33 sync/commit metrics instead of reusing block counters as range counters.

## Commit telemetry

The ordered state service now publishes, only after a successful RocksDB publication:

- `commit_batches`: one count per successful canonical publication batch
- `committed_blocks`: exact number of canonical blocks published
- `commit_total_us`: cumulative full ordered commit time
- `last_commit_total_us`: full ordered time for the most recent successful commit
- `last_commit_unix`: wall-clock time of the most recent successful commit
- `last_commit_timing`: the authoritative `CommitTiming` record from `State`

The dashboard maps these to `db_commits`, `db_commit_ms_total`, `last_commit_total_us`, `last_commit_unix`, and all detailed state/DB/script timing fields.

## Validation telemetry

Semantic verification now publishes:

- successful semantic-verified block count
- cumulative semantic verification wall time
- last semantic verification group time
- highest semantic-verified height

Contextual validation publishes its highest verified height and the most recent contextual preparation time.

## Pipeline-stage heights

The API now exposes independent stage heights:

`headers_height -> download_height -> semantic_verified_height -> contextual_verified_height -> canonical height`

This makes it possible to identify exactly where a sync is stalled.

## Transport telemetry

The dashboard now distinguishes blocks from ranges. The current downloader is a streaming block requester, not a range-completion scheduler.

- in-flight blocks = actual outstanding P2P block requests
- prospective blocks = actual candidates waiting at the ordered state gate
- validation queue = actual semantic verifier queue
- commit batches = actual successful canonical WriteBatch publications
- expired requests = actual transport timeouts/releases
- invalid blocks = actual semantic/contextual validation failures

The old `completed_ranges = committed_blocks` alias is no longer used by the Android UI.

## Detailed commit telemetry

The dashboard receives the existing `State::CommitTiming` values for state validation, transaction connection, script verification, Sapling tree work, RocksDB write staging, atomic commit, rollback, cache hits, and worker-level script timing arrays.

No telemetry field is used as a consensus input.
