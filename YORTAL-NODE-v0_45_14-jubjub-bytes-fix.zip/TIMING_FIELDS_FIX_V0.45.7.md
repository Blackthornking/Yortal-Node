# YORTAL v0.45.7 — fix for the v0.45.6 build failure

## CI failure (v0.45.6-sighash-buffer)
```
error[E0609]: no field `p2sh_sigops_us` on type `&mut ConnectTiming`
  --> crates/state/src/chainstate.rs:1177
error[E0609]: no field `script_queue_us` on type `&mut ConnectTiming`
  --> crates/state/src/chainstate.rs:1248
error: could not compile `ycash-state` (lib) due to 4 previous errors
```

## Cause
The two new timers were added to `CommitTiming` (state/src/lib.rs) and to the
`[DBPIPE]` log line, and the connector (state/src/chainstate.rs) writes to them,
but the connector accumulates into a different struct, `ConnectTiming`, which never
got the fields. `ConnectTiming` is what gets summed into `CommitTiming` per block,
so the chain is: connector -> ConnectTiming -> (merge) -> CommitTiming -> [DBPIPE].

## Fix
* `ConnectTiming`: added `p2sh_sigops_us` and `script_queue_us`.
* `State::prepare_commit_batch_owned` merge block: both fields are now summed from
  `connect_timing` into `timing` (the `CommitTiming`), so the `[DBPIPE]` values are
  real instead of always 0.
* Both are also added to `connector_named_us`. They are measured inside the
  per-transaction total, so leaving them out would have counted the same time again
  as `connector_other_us` (the "unattributed residual").

No behaviour change beyond the timers; consensus code untouched.

## Not compiled here
`cargo` is unavailable in the packaging environment. The failing crate stopped the
build before `ycash-node` and `ycash-android-node` were type-checked, so nothing in
those crates (the v0.45 intake gate / strict reset redesign, downloader late-arrival
handling, header throttling in main.rs and sync_coordinator.rs) has ever been seen
by the compiler. They were read line by line for name resolution, moves/borrows,
channel types and format-string arity and no errors were found, but expect that the
next CI run may still surface something there.
