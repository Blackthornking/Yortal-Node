# YORTAL v0.43 — two workers after cryptographic verification

The live sync path now has three functional stages:

1. **Cryptographic verifier pool** — the preserved `semantic_verify()` implementation remains the only parallel cryptographic consensus verifier. It consumes the bounded verifier queue.
2. **One expensive state-preparation worker** — reorders verified results into the exact next 16-block sequence and performs the expensive contextual/UTXO/script preparation using `prepare_commit_batch_owned()`.
3. **One canonical commit worker** — performs only `apply_prepared_commit()`: canonical tip/parent recheck and the atomic RocksDB publication. It does not parse transactions, discover UTXOs, execute scripts, verify proofs, or perform other expensive consensus work.

The preparation worker waits for a commit acknowledgement before preparing the next batch. This is intentional: preparing batch N+1 against a snapshot that predates publication of batch N would create a stale mutation plan. The acknowledgement preserves the canonical-state dependency while keeping the commit role isolated and minimal.

The cryptographic result queue remains four 16-block windows (64 entries), while the exact canonical batch size remains 16. Per-peer block request capacity remains 16.

The old separate state-service thread is no longer started by `SyncEngine`; the active path has exactly one expensive post-verification worker and one canonical post-verification writer.
