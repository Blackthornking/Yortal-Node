# Yortal v0.33 — TXID reuse patch

This patch removes two redundant transaction-ID hash passes from the ordered
state path.

## Changes

- Batch UTXO prefetch now reuses the TXID already carried in `BlockCommit.txs`.
- Ordered commit now reuses the same carried TXID instead of calling
  `ycash_chain::txid(rawtx)` again.
- Before reusing the carried TXID, commit checks that the carried transaction
  bytes exactly match the transaction parsed from the raw block. This preserves
  the binding between the validated TXID and the transaction being connected.
- Added an explicit transaction-count check before indexing `b.txs` by commit
  transaction index.
- Removed unused `Condvar` and `Mutex` imports from `chainstate.rs`.
- Added `tools/verify-txid-reuse.sh` as a source-level regression check.

## Consensus behavior

The stateless verifier remains the owner of the TXID calculation. The Merkle
root and block/header validation are unchanged. This optimization only avoids
re-hashing an already validated transaction when the ordered state stage needs
its TXID for UTXO/output registration and transaction connection.

## Verification

Run:

```bash
tools/verify-txid-reuse.sh
cargo test --workspace --all-targets
```

The local patch environment does not have Cargo installed, so the full Rust
workspace test must be run in the project's CI/build environment.
