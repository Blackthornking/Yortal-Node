# YORTAL v0.30.1 — YDF consensus validation + full-verify CI

Implemented from the Ycash mainnet ycashd chain parameters.

## 1. YDF reward validation

- Added the canonical 48-entry Ycash YDF recipient table.
- Uses the ycashd monthly rotation interval of 17,917 blocks.
- Decodes the mainnet `s1...` Base58Check addresses (version `0x1c28`) and constructs the exact P2PKH script used by ycashd.
- During the mandatory YDF period `[570000, 2275000)`, every coinbase must contain an output paying exactly `block_subsidy(height) / 5` to the height-selected YDF script.
- This is a presence check, matching the ycashd validation pattern; miner outputs can still include transaction fees.
- Outside the mandate interval no YDF output is required by this rule.

## 2. Full verification in CI

- CI now exports `YCASH_FULL_VERIFY=1`.
- The Rust regression-test step explicitly asserts the setting before running the workspace tests.
- This prevents the historical assume-valid checkpoint shortcut from being used by a consensus replay/CI runtime.

## Source reference

The Ycash mainnet chain parameters define the 570,000 activation, 2,275,000 mandate end, 17,917-block address rotation, and 48 recipient addresses. ycashd's validation pattern checks for the height-selected reward script and `GetBlockSubsidy(height) / 5`.
