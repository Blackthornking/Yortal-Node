# Yodel One: verify-only Groth16 + parent-safe batch design

## Scope

This patch changes the YORTAL node's default verifier so the consensus verification path does not depend on Bellman or `zcash_proofs`. BLS12-381 field/curve arithmetic remains provided by the existing `bls12_381` and `group` crates; the Groth16 proof decoding, verifying-key decoding, prepared verifying key, pairing equation, public-input packing, and randomized batch equation are implemented locally in `crates/ycash-crypto/src/groth16.rs`.

Bellman and `zcash_proofs` are **removed entirely** (v0.36.7): no dependency, no `prover` feature, no proving FFI. See `BELLMAN_REMOVED_V0.36.7.md`.

## Research basis

The implementation was checked against the Groth16 verifier structure used by Bellman and the Zcash-era parameter encoding: a verifying key contains `alpha_g1`, `beta_g1`, `beta_g2`, `gamma_g2`, `delta_g1`, `delta_g2`, and `IC`; the serialized key writes those points uncompressed followed by the big-endian `IC` count and uncompressed `IC` points. Verification prepares `-gamma`, `-delta`, precomputes `e(alpha,beta)`, forms `L = IC_0 + sum(x_j IC_{j+1})`, and checks the three-term pairing equation.

The Sprout public-input path was also checked against the pinned Zcash/Ycash implementation: the input bytes are concatenated in the historical order and passed through the legacy `bytes_to_bits` (MSB-first per byte) followed by multipacking. This is deliberately separate from Sapling, whose circuit inputs are already field elements derived from the encoded coordinates/commitments.

The batch equation follows standard randomized linear combination: for fresh non-zero random scalars `r_i`, it checks

`product e(r_i A_i, B_i) * e(sum r_i L_i, -gamma) * e(sum r_i C_i, -delta) = e(alpha,beta)^(sum r_i)`.

The randomizers come from the OS RNG and are independent of chain data. A failing multi-item batch is only a locator signal; the implementation bisects it, and singleton leaves use the exact per-proof equation so the final failure decision is deterministic.

## Parent invariant

A transaction Groth16 proof does **not** prove block ancestry. It proves the statement encoded by its circuit. Therefore the node cannot obtain a missing-parent guarantee merely by changing the transaction proof equation.

Yodel One now enforces the ancestry invariant before any Groth16 work can enter the live block path:

1. The verification coordinator reads the canonical `(tip_height, tip_hash)` and defines `expected_height = tip_height + 1`.
2. If the first received block is not exactly `expected_height`, the coordinator waits; it does not start from the lowest received height.
3. The first block must name the canonical `tip_hash` as its `prev_hash`.
4. Every subsequent block must be exactly one height higher and name the immediately previous block's requested hash as its parent.
5. `SyncEngine::commit_batch` repeats the same check immediately before semantic/Groth16 verification, so a direct caller cannot bypass the coordinator.
6. The state service already performs a final ordered parent check before canonical publication, providing a third barrier at the state boundary.

This makes a received child at `h+1` unable to progress merely because the `h` block is absent from the local batch. The batch stays pending and the downloader's missing-height list continues to identify the missing lowest height.

## Non-blocking scheduling

The transport window remains 48 blocks, but the peer I/O path no longer waits
for that entire window to fill. Received blocks are submitted to an asynchronous
verifier coordinator. The coordinator will dispatch the first contiguous prefix
starting at canonical+1 as soon as it exists, up to 8 blocks per verification
micro-batch. If height `h+2` arrives before `h+1`, it remains buffered and cannot
be verified or committed ahead of `h+1`; the gap therefore stalls only the
verification frontier, not the network socket or the rest of the download loop.

## Proof batching

There are two batch widths with different purposes:

- the active transport/verification window is 16 blocks;
- the four verifier workers split that window for parallel non-pairing preparation;
- the deferred Sapling proofs from all four slices are merged into one global proof batch before pairing.

Sapling spend and output proofs use separate verifying keys because their circuits have different public-input counts. `IC` terms are regrouped in the scalar field before variable-base group work, reducing the fixed-base part of the batch from `N * (k+1)` scalar multiplications to `k+1` for a batch of `N` proofs.

## Failure behavior

A malformed proof or invalid pairing result never becomes a positive verdict. For a failed batch, the implementation isolates failing proofs/transactions and the consensus layer keeps its original per-transaction authoritative verification path for the final result.

A missing verifying key is also a failure, not an assumption of validity.

Transport lifecycle claims are released on ancestry rejection, malformed headers, state-read failure, and proof/semantic rejection to avoid turning a missing-parent condition into a permanent in-flight leak.

## What this does not claim

This patch does not create a new cryptographic proof that commits block headers and parent hashes inside a Groth16 circuit. Doing that requires a new Yodel One circuit, a new proving/verifying key ceremony or key-generation process, and a new consensus statement defining the batch commitment. The current patch deliberately avoids pretending an existing Sapling/Sprout transaction proof contains that statement.

The implemented guarantee is a protocol-level consensus barrier: no detached or gapped block batch is allowed to enter Groth16 verification or the canonical state pipeline.

## Validation status

Static source checks were completed on the edited tree, including changed call-site/signature checks, brace/parenthesis balance, tests added for first-parent gaps and canonical attachment, and confirmation that no Bellman/`zcash_proofs` reference remains anywhere in the source or manifests (`tools/verify-no-bellman.sh`).

A full `cargo check` / `cargo test` could not be executed in this environment because `cargo`, `rustc`, and `rustfmt` are not installed. The ZIP should therefore be compiled and tested on the project's normal Rust/Android build environment before deployment or consensus activation.
