# YORTAL v0.30.2 — Ycash/Zcash consensus-safe tree + database optimization

## Scope

This patch applies the Ycash-compatible state/database recommendations while deliberately **excluding the Sapling verifier**. Yodel's new verifier remains behind the existing consensus validation boundary.

## Implemented

### 1. Sapling frontier / empty roots

- Precompute the 33 Sapling empty-subtree roots once per process.
- Reuse those roots during every block-root calculation.
- Keep the append-only 32-level frontier model unchanged.
- Memoize the final root until the frontier changes.
- Invalidate the root cache on every append.
- Do not serialize the cache; only consensus frontier state is persisted.
- Added a differential test against the previous recursive empty-subtree reference algorithm across boundary counts up to 1023 commitments.

The consensus hash inputs are unchanged. The optimization removes repeated reconstruction of deterministic empty subtrees.

### 2. Deep telemetry

Added:

- `sapling_empty_hashes_avoided`
- `sapling_root_cache_hits`

Existing per-level root/empty/hash telemetry remains available. The dashboard now displays the avoided empty-subtree work and root-cache hits.

### 3. SQLite / database path

- Retain WAL mode and prepared statements.
- Increase the read-only companion connection cache and keep it query-only.
- Add composite indexes matching the consensus anchor/root lookup predicates:
  - `sapling_roots(root, main_chain, height)`
  - `block_state(sprout_root, height)`
- Replace remaining `INSERT OR REPLACE` metadata/block/header writes with UPSERTs where practical, avoiding implicit delete+insert work.
- Keep normal forward extension separate from reorganization cleanup.
- Keep ordered state mutation and the single SQLite commit deterministic.

### 4. Consensus ordering

No state mutation was parallelized. The required sequence remains:

`fetch → validate → ordered state transition → ordered DB commit`

The verifier is not replaced or upgraded by this patch.

## Expected performance effect

The former root calculation rebuilt an empty subtree from level 0 for every empty frontier slot. At depth 32 this is quadratic in the number of empty levels. The new implementation performs the 32 root-combination hashes only, while empty subtree constants are initialized once.

The exact improvement must be measured on ARM64 using the same chain/batch workload as the previous telemetry build.

## Release gate

Before calling the build consensus-complete:

1. Run the workspace Rust test suite in CI.
2. Run the Sapling optimized-vs-reference differential tests.
3. Sync historical Ycash blocks from genesis.
4. Verify every committed Sapling root against the Ycash/reference result.
5. Verify restart/reload of the persisted frontier.
6. Verify normal forward DB commits and a reorg test separately.
7. Run the Android ARM64 build and runtime test.
8. Confirm the new telemetry shows `empty_hashes_avoided > 0` for sparse frontiers and that actual empty-subtree hash counts are zero during optimized root construction.
