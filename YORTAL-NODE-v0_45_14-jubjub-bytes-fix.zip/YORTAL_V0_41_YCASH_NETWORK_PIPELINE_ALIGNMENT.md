# YORTAL v0.41 — Ycash-style network/pipeline alignment

This release aligns the transport layer with the documented Bitcoin/Ycash-derived
P2P flow-control model while preserving YORTAL's required exact 16-block
canonical sequence.

Implemented:
- 16 blocks in transit per peer.
- 1,024-block forward download window constant.
- 1,000-item GETDATA cap.
- 50,000-item INV cap.
- 2,000-header GETHEADERS locator cap.
- 2s default block-stalling interval and 64s maximum ceiling.
- Headers-first gating remains in force: blocks are not requested until headers
  are available.
- Transport remains separate from consensus validation.

Important distinction:
Ycash/Bitcoin-style downloading allows 16 blocks per peer and a much larger
forward download window. YORTAL still intentionally keeps its canonical
verification/commit lifecycle at exactly one 16-block H+1..H+16 sequence.
That preserves the previously required consensus pipeline invariant rather than
changing consensus behavior merely to match a reference implementation.

The database/canonical writer remains atomic; network tuning does not make state
publication non-atomic.
