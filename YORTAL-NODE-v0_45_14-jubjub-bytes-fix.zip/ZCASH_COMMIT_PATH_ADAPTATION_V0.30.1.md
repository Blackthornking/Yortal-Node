# YORTAL v0.30.1 — Zcash-inspired commit-path adaptation

## Purpose

This patch adapts the ordered YORTAL state commit path using storage/transaction
patterns found in Zcash/librustzcash, without changing consensus ordering or
moving canonical writes to multiple workers.

## Implemented

### 1. Separate consensus preparation from the SQLite WRITE transaction

`State::commit_blocks_batch()` now performs the expensive state preparation
against a SQLite read transaction first:

- block/header consistency checks
- parsed transaction reuse
- transparent UTXO connection
- BIP30 checks
- Sapling anchor/nullifier checks
- Sapling frontier advancement
- Sprout state advancement
- per-block tree/frontier preparation

Only after the complete batch has passed does YORTAL open its SQLite WRITE
transaction.

This prevents proof/state/UTXO computation from occupying the write transaction
for the duration of the batch.

The `State` database mutex remains held for both phases, so the canonical state
cannot be modified by another YORTAL writer between preparation and commit.

### 2. Preserve one atomic canonical write

The write phase remains one transaction containing:

- block rows
- transaction rows
- Sapling root/frontier rows
- nullifiers
- UTXO changes
- Sprout changes
- canonical tip
- final Sapling frontier

A failure in the write phase therefore rolls the complete batch back.

### 3. Keep tree work batched in memory

YORTAL already advanced the Sapling consensus state in memory and persisted the
prepared per-block roots/frontiers during the single write transaction. This
patch preserves that design rather than introducing per-leaf database writes.

The expensive tree/state advancement is now outside the SQLite WRITE
transaction.

### 4. Reduce UTXO B-tree churn

The UTXO flush path now uses SQLite UPSERT rather than
`INSERT OR REPLACE`. `REPLACE` can delete and recreate a conflicting row,
causing unnecessary index/B-tree churn. UPSERT updates the existing primary-key
row in place.

## Consensus safety

No consensus rule was intentionally changed.

The following remain ordered and atomic:

- UTXO connection
- transaction validity
- Sapling state transition
- nullifier handling
- anchor/root handling
- Sprout state
- canonical-chain state
- database commit

Parallel validation remains upstream. Canonical state is still committed by
one ordered committer.

## Measurement

`[DBPIPE]` timing should now be interpreted as:

- `state_validate_ms`: expensive preparation before the write transaction
- `begin_ms`: opening the SQLite write transaction
- `rollback_ms`: reorganization-only cleanup
- `sql_write_ms`: block/tx/root SQL
- `index_write_ms`: indexed/nullifier SQL
- `db_write_ms`: complete write phase before SQLite commit
- `sqlite_commit_ms`: SQLite COMMIT itself
- `total_ms`: complete commit operation

The most important comparison is whether `db_write_ms` and
`sqlite_commit_ms` fall after moving state preparation outside the write
transaction.

## Deliberately not changed

- 16-block commit default
- ordered canonical commit
- bounded commit buffer
- YORTAL verifier behavior
- Sapling consensus rules
- SQLite `WAL`
- SQLite `synchronous=NORMAL`

Increasing the commit batch should be considered only after measuring this
change.

