# Yortal v0.33 — Zebra-style transparent UTXO overlay

The ordered commit path builds an in-memory overlay for every spendable transparent output created by the commit batch. Each entry records block height and transaction index.

Resolution order: earlier in-batch output overlay, prepared/cache entry, then one deduplicated RocksDB MultiGet for persistent misses. Future/self outputs are never exposed as spendable state.

Telemetry: `utxo_batch_input_count`, `utxo_batch_unique_inputs`, `utxo_batch_local_hits`, `utxo_db_lookup_us`, and `utxo_db_lookup_keys`.
