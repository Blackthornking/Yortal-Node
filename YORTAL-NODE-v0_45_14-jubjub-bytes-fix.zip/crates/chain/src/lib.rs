use anyhow::{bail, Result};
use byteorder::{LittleEndian, ReadBytesExt};
use sha2::{Digest, Sha256};
use std::io::{Cursor, Read};

pub const MAINNET_MAGIC: [u8; 4] = [0x24, 0xe9, 0x27, 0x64];
pub const MAINNET_PORT: u16 = 8833;
pub const NETWORK: &str = "main";
pub const YCASH_FORK_HEIGHT: u64 = 570_000;
pub const MAX_HEADERS_RESULTS: usize = 160;
pub const MAX_BLOCK_SIZE: usize = 2 * 1024 * 1024;
pub const GENESIS_HASH_DISPLAY: &str = "00040fe8ec8471911baa1db1266ea15dd06b4a8a5c453883c000b031973dce08";

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct BlockHeader {
    pub version: u32,
    pub prev: [u8; 32],
    pub merkle: [u8; 32],
    pub light_client_root: [u8; 32],
    pub time: u32,
    pub bits: u32,
    pub nonce: [u8; 32],
    pub solution: Vec<u8>,
}

impl BlockHeader {
    pub fn serialize(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(108 + 32 + 5 + self.solution.len());
        out.extend_from_slice(&self.version.to_le_bytes());
        out.extend_from_slice(&self.prev);
        out.extend_from_slice(&self.merkle);
        out.extend_from_slice(&self.light_client_root);
        out.extend_from_slice(&self.time.to_le_bytes());
        out.extend_from_slice(&self.bits.to_le_bytes());
        out.extend_from_slice(&self.nonce);
        write_compact_size(self.solution.len() as u64, &mut out);
        out.extend_from_slice(&self.solution);
        out
    }

    pub fn pow_input(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(108);
        out.extend_from_slice(&self.version.to_le_bytes());
        out.extend_from_slice(&self.prev);
        out.extend_from_slice(&self.merkle);
        out.extend_from_slice(&self.light_client_root);
        out.extend_from_slice(&self.time.to_le_bytes());
        out.extend_from_slice(&self.bits.to_le_bytes());
        out
    }

    pub fn hash(&self) -> [u8; 32] {
        let serialized = self.serialize();
        let a = Sha256::digest(&serialized);
        let b = Sha256::digest(a);
        let mut h = [0u8; 32];
        h.copy_from_slice(&b);
        h
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Block {
    pub header: BlockHeader,
    pub txs: Vec<Vec<u8>>,
}

pub fn write_compact_size(n: u64, out: &mut Vec<u8>) {
    match n {
        0..=252 => out.push(n as u8),
        253..=65_535 => { out.push(253); out.extend_from_slice(&(n as u16).to_le_bytes()); }
        65_536..=0xffff_ffff => { out.push(254); out.extend_from_slice(&(n as u32).to_le_bytes()); }
        _ => { out.push(255); out.extend_from_slice(&n.to_le_bytes()); }
    }
}

pub fn read_compact_size(c: &mut Cursor<&[u8]>) -> Result<u64> {
    let n = c.read_u8()?;
    Ok(match n {
        0..=252 => n as u64,
        253 => { let v=c.read_u16::<LittleEndian>()? as u64; if v<253 { bail!("non-canonical compact size") } v },
        254 => { let v=c.read_u32::<LittleEndian>()? as u64; if v<65_536 { bail!("non-canonical compact size") } v },
        255 => { let v=c.read_u64::<LittleEndian>()?; if v<4_294_967_296 { bail!("non-canonical compact size") } v },
    })
}

pub fn read_bytes(c: &mut Cursor<&[u8]>, max: usize) -> Result<Vec<u8>> {
    let n = read_compact_size(c)? as usize;
    if n > max { bail!("field too large: {n}") }
    let mut v = vec![0; n];
    c.read_exact(&mut v)?;
    Ok(v)
}

pub fn expected_solution_len(height: u64) -> usize {
    if height >= YCASH_FORK_HEIGHT { 400 } else { 1344 }
}

pub fn read_header_at(c: &mut Cursor<&[u8]>, height: u64) -> Result<BlockHeader> {
    let version = c.read_u32::<LittleEndian>()?;
    let mut prev = [0; 32]; c.read_exact(&mut prev)?;
    let mut merkle = [0; 32]; c.read_exact(&mut merkle)?;
    let mut light_client_root = [0; 32]; c.read_exact(&mut light_client_root)?;
    let time = c.read_u32::<LittleEndian>()?;
    let bits = c.read_u32::<LittleEndian>()?;
    let mut nonce = [0; 32]; c.read_exact(&mut nonce)?;
    let solution = read_bytes(c, expected_solution_len(height))?;
    if solution.len() != expected_solution_len(height) {
        bail!("invalid Equihash solution length {} at height {}", solution.len(), height);
    }
    Ok(BlockHeader { version, prev, merkle, light_client_root, time, bits, nonce, solution })
}

fn tx_hash(tx:&[u8])->[u8;32]{let a=Sha256::digest(tx);let b=Sha256::digest(a);let mut o=[0u8;32];o.copy_from_slice(&b);o}
pub fn txid(tx:&[u8])->[u8;32]{tx_hash(tx)}
pub fn merkle_root(txs:&[Vec<u8>])->[u8;32]{if txs.is_empty(){return [0u8;32]}let mut layer:Vec<[u8;32]>=txs.iter().map(|t|tx_hash(t)).collect();while layer.len()>1{let mut next=Vec::with_capacity((layer.len()+1)/2);let mut i=0;while i<layer.len(){let r=if i+1<layer.len(){layer[i+1]}else{layer[i]};let mut d=Vec::with_capacity(64);d.extend_from_slice(&layer[i]);d.extend_from_slice(&r);let a=Sha256::digest(&d);let b=Sha256::digest(a);let mut h=[0u8;32];h.copy_from_slice(&b);next.push(h);i+=2;}layer=next;}layer[0]}

fn read_var_count(c:&mut Cursor<&[u8]>, max:usize, what:&str)->Result<usize>{
    let n=read_compact_size(c)?;
    if n>max as u64 { bail!("{what} count {n} exceeds limit {max}") }
    Ok(n as usize)
}

pub fn merkle_root_with_mutation(txs:&[Vec<u8>])->([u8;32], bool){
    if txs.is_empty(){return ([0u8;32],false)}
    let mut layer:Vec<[u8;32]>=txs.iter().map(|t|tx_hash(t)).collect();
    let mut mutated=false;
    while layer.len()>1{
        let mut next=Vec::with_capacity((layer.len()+1)/2);
        let mut i=0;
        while i<layer.len(){
            if i+1<layer.len() && layer[i]==layer[i+1] { mutated=true; }
            let r=if i+1<layer.len(){layer[i+1]}else{layer[i]};
            let mut d=Vec::with_capacity(64);
            d.extend_from_slice(&layer[i]); d.extend_from_slice(&r);
            let a=Sha256::digest(&d); let b=Sha256::digest(a);
            let mut h=[0u8;32]; h.copy_from_slice(&b); next.push(h); i+=2;
        }
        layer=next;
    }
    (layer[0],mutated)
}


#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TransparentInput {
    pub prev_txid: [u8;32],
    pub prev_index: u32,
    pub script_sig: Vec<u8>,
    pub sequence: u32,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TransparentOutput {
    pub value: i64,
    pub script_pubkey: Vec<u8>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SaplingSpend {
    pub cv: [u8;32],
    pub anchor: [u8;32],
    pub nullifier: [u8;32],
    pub rk: [u8;32],
    pub zkproof: [u8;192],
    pub spend_auth_sig: [u8;64],
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SaplingOutput {
    pub cv: [u8;32],
    pub cmu: [u8;32],
    pub ephemeral_key: [u8;32],
    pub enc_ciphertext: [u8;580],
    pub out_ciphertext: [u8;80],
    pub zkproof: [u8;192],
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct JoinSplit {
    pub raw: Vec<u8>,
    pub vpub_old: i64,
    pub vpub_new: i64,
    pub anchor: [u8;32],
    pub nullifiers: [[u8;32];2],
    pub commitments: [[u8;32];2],
    pub ephemeral_key: [u8;32],
    pub random_seed: [u8;32],
    pub macs: [[u8;32];2],
    pub proof: Vec<u8>,
    pub ciphertexts: [[u8;601];2],
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParsedTransaction {
    pub raw: Vec<u8>,
    pub version: u32,
    pub overwintered: bool,
    pub version_group_id: Option<u32>,
    pub vin: Vec<TransparentInput>,
    pub vout: Vec<TransparentOutput>,
    pub lock_time: u32,
    pub expiry_height: Option<u32>,
    pub value_balance: i64,
    pub sapling_spends: Vec<SaplingSpend>,
    pub sapling_outputs: Vec<SaplingOutput>,
    pub joinsplits: Vec<JoinSplit>,
    pub joinsplit_pubkey: Option<[u8;32]>,
    pub joinsplit_sig: Option<[u8;64]>,
    pub binding_sig: Option<[u8;64]>,
}

fn read_array<const N: usize>(c:&mut Cursor<&[u8]>) -> Result<[u8;N]> {
    let mut out=[0u8;N];
    c.read_exact(&mut out)?;
    Ok(out)
}

fn read_tx_input(c:&mut Cursor<&[u8]>) -> Result<TransparentInput> {
    Ok(TransparentInput {
        prev_txid: read_array(c)?,
        prev_index: c.read_u32::<LittleEndian>()?,
        script_sig: read_bytes(c, 100_000)?,
        sequence: c.read_u32::<LittleEndian>()?,
    })
}

fn read_tx_output(c:&mut Cursor<&[u8]>) -> Result<TransparentOutput> {
    Ok(TransparentOutput {
        value: c.read_i64::<LittleEndian>()?,
        script_pubkey: read_bytes(c, 100_000)?,
    })
}

fn read_sapling_spend(c:&mut Cursor<&[u8]>) -> Result<SaplingSpend> {
    Ok(SaplingSpend {
        cv: read_array(c)?,
        anchor: read_array(c)?,
        nullifier: read_array(c)?,
        rk: read_array(c)?,
        zkproof: read_array(c)?,
        spend_auth_sig: read_array(c)?,
    })
}

fn read_sapling_output(c:&mut Cursor<&[u8]>) -> Result<SaplingOutput> {
    Ok(SaplingOutput {
        cv: read_array(c)?,
        cmu: read_array(c)?,
        ephemeral_key: read_array(c)?,
        enc_ciphertext: read_array(c)?,
        out_ciphertext: read_array(c)?,
        zkproof: read_array(c)?,
    })
}

fn read_joinsplit(c:&mut Cursor<&[u8]>, version:u32) -> Result<JoinSplit> {
    let start=c.position() as usize;
    let vpub_old=c.read_i64::<LittleEndian>()?;
    let vpub_new=c.read_i64::<LittleEndian>()?;
    let anchor=read_array(c)?;
    let nullifiers=[read_array(c)?,read_array(c)?];
    let commitments=[read_array(c)?,read_array(c)?];
    let ephemeral_key=read_array(c)?;
    let random_seed=read_array(c)?;
    let macs=[read_array(c)?,read_array(c)?];
    let proof_len=if version>=4 {192} else {296};
    let mut proof=vec![0u8;proof_len]; c.read_exact(&mut proof)?;
    let mut ciphertexts=[[0u8;601];2];
    c.read_exact(&mut ciphertexts[0])?; c.read_exact(&mut ciphertexts[1])?;
    let end=c.position() as usize;
    // v4 JoinSplits use the same field layout but Groth proof replaces PHGR.
    // The fixed wire size is still 1698 bytes; v1-v3 is 1802 bytes.
    let expected=if version>=4{1698}else{1802};
    if end-start!=expected { bail!("JoinSplit size mismatch: {} != {}",end-start,expected); }
    Ok(JoinSplit{raw:c.get_ref()[start..end].to_vec(),vpub_old,vpub_new,anchor,nullifiers,commitments,ephemeral_key,random_seed,macs,proof,ciphertexts})
}

/// Consume and fully parse one Ycash v1/v2/v3/v4 transaction.
pub fn parse_transaction(c:&mut Cursor<&[u8]>) -> Result<ParsedTransaction> {
    let start=c.position() as usize;
    let header=c.read_u32::<LittleEndian>()?;
    let overwintered=(header & 0x8000_0000)!=0;
    let version=header & 0x7fff_ffff;
    if version==0 || version>4 { bail!("unsupported Ycash transaction version {version}") }

    let version_group_id=if overwintered { Some(c.read_u32::<LittleEndian>()?) } else { None };
    if let Some(group)=version_group_id {
        let expected=match version {3=>0x03c4_8270,4=>0x892f_2085,_=>0};
        if expected==0 || group!=expected {
            bail!("invalid transaction version/group {:08x}/{:08x}",version,group)
        }
    } else if version>2 {
        bail!("non-overwintered transaction version {version} is invalid")
    }

    let vin_n=read_var_count(c,10_000,"vin")?;
    let mut vin=Vec::with_capacity(vin_n);
    for _ in 0..vin_n { vin.push(read_tx_input(c)?); }

    let vout_n=read_var_count(c,10_000,"vout")?;
    let mut vout=Vec::with_capacity(vout_n);
    for _ in 0..vout_n { vout.push(read_tx_output(c)?); }

    let lock_time=c.read_u32::<LittleEndian>()?;
    let expiry_height=if overwintered { Some(c.read_u32::<LittleEndian>()?) } else { None };

    let mut value_balance=0i64;
    let mut sapling_spends=Vec::new();
    let mut sapling_outputs=Vec::new();
    if version==4 {
        value_balance=c.read_i64::<LittleEndian>()?;
        let n=read_var_count(c,10_000,"sapling spends")?;
        sapling_spends.reserve(n);
        for _ in 0..n { sapling_spends.push(read_sapling_spend(c)?); }
        let n=read_var_count(c,10_000,"sapling outputs")?;
        sapling_outputs.reserve(n);
        for _ in 0..n { sapling_outputs.push(read_sapling_output(c)?); }
    }

    let mut joinsplits=Vec::new();
    let mut joinsplit_pubkey=None;
    let mut joinsplit_sig=None;
    if version>=2 {
        let n=read_var_count(c,10_000,"joinsplits")?;
        joinsplits.reserve(n);
        for _ in 0..n { joinsplits.push(read_joinsplit(c,version)?); }
        if n>0 {
            joinsplit_pubkey=Some(read_array(c)?);
            joinsplit_sig=Some(read_array(c)?);
        }
    }

    let binding_sig=if version==4 && (!sapling_spends.is_empty() || !sapling_outputs.is_empty()) {
        Some(read_array(c)?)
    } else { None };

    let end=c.position() as usize;
    Ok(ParsedTransaction {
        raw:c.get_ref()[start..end].to_vec(),
        version, overwintered, version_group_id, vin, vout, lock_time,
        expiry_height, value_balance, sapling_spends, sapling_outputs,
        joinsplits, joinsplit_pubkey, joinsplit_sig, binding_sig,
    })
}

pub fn read_transaction(c:&mut Cursor<&[u8]>) -> Result<Vec<u8>> {
    Ok(parse_transaction(c)?.raw)
}

pub fn read_block_at_height(raw: &[u8], height: u64) -> Result<Block> {
    if raw.len() > MAX_BLOCK_SIZE { bail!("block exceeds 2 MiB protocol limit") }
    let mut c = Cursor::new(raw);
    let header = read_header_at(&mut c, height)?;
    let tx_count=read_var_count(&mut c, 50_000, "transaction")?;
    if tx_count==0 { bail!("block has zero transactions") }
    let mut txs=Vec::with_capacity(tx_count);
    for _ in 0..tx_count {
        txs.push(read_transaction(&mut c)?);
    }
    if c.position() as usize != raw.len() { bail!("trailing bytes after final transaction") }
    if merkle_root(&txs)!=header.merkle { bail!("transaction merkle root mismatch") }
    Ok(Block { header, txs })
}

pub fn read_block(raw: &[u8]) -> Result<Block> { read_block_at_height(raw, 1) }

pub fn genesis_hash_internal() -> [u8; 32] {
    let bytes = hex::decode(GENESIS_HASH_DISPLAY).expect("valid genesis hash");
    let mut out = [0u8; 32];
    for i in 0..32 { out[i] = bytes[31 - i]; }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn genesis_hash_is_internal_order() {
        assert_eq!(genesis_hash_internal()[0], 0x08);
        assert_eq!(genesis_hash_internal()[31], 0x00);
    }

    #[test]
    fn parses_minimal_v1_transaction() {
        let raw = [1u8,0,0,0, 0, 0, 0,0,0,0];
        let mut c=Cursor::new(raw.as_slice());
        let tx=read_transaction(&mut c).unwrap();
        assert_eq!(tx, raw);
        assert_eq!(c.position(), raw.len() as u64);
    }

    #[test]
    fn parses_minimal_v4_transaction() {
        let mut raw=Vec::new();
        raw.extend_from_slice(&0x80000004u32.to_le_bytes());
        raw.extend_from_slice(&0x892f2085u32.to_le_bytes());
        raw.push(0); // vin
        raw.push(0); // vout
        raw.extend_from_slice(&0u32.to_le_bytes()); // locktime
        raw.extend_from_slice(&0u32.to_le_bytes()); // expiry
        raw.extend_from_slice(&0i64.to_le_bytes()); // value balance
        raw.push(0); // spends
        raw.push(0); // outputs
        raw.push(0); // joinsplits
        let mut c=Cursor::new(raw.as_slice());
        let tx=read_transaction(&mut c).unwrap();
        assert_eq!(tx, raw);
        assert_eq!(c.position(), raw.len() as u64);
    }
}
