use num_bigint::BigUint;
use num_traits::{One, Zero};
use sha2::{Digest, Sha256};
use ycash_chain::{Block, BlockHeader, ParsedTransaction, YCASH_FORK_HEIGHT};
use std::sync::OnceLock;
use std::cell::Cell;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ConsensusError { Invalid(String), Contextual(String) }

#[derive(Debug, Clone, Copy)]
pub struct Context { pub height:u64, pub prev_height:u64, pub median_time_past:u32 }

#[derive(Clone, Debug)]
pub struct SaplingConsensusState {
    pub count: u64,
    pub frontier: [Option<[u8;32]>; 32],
    root_cache: Cell<Option<[u8;32]>>,
}

/// Fine-grained telemetry for the Sapling note-commitment root calculation.
///
/// `level_us[level]` covers the work performed at that Merkle level while
/// constructing the root, including the root hash and (when the frontier slot
/// is empty) the empty-subtree construction. `empty_level_us` isolates the
/// recursively rebuilt empty-subtree hashes, which is useful for detecting
/// repeated empty-tree work. These counters are diagnostic only and do not
/// alter consensus state or hashing inputs.
#[derive(Clone, Debug, Default)]
pub struct SaplingRootTiming {
    pub total_us: u64,
    pub level_us: [u64; 32],
    pub level_hashes: [u64; 32],
    pub empty_us: [u64; 32],
    pub empty_hashes: [u64; 32],
    pub root_hash_us: [u64; 32],
    pub root_hashes: [u64; 32],
    pub empty_hashes_avoided: u64,
    pub root_cache_hit: bool,
}

impl SaplingRootTiming {
    pub fn empty_total_us(&self) -> u64 {
        self.empty_us.iter().copied().sum()
    }
    pub fn root_hash_total_us(&self) -> u64 {
        self.root_hash_us.iter().copied().sum()
    }
}

impl SaplingConsensusState {
    pub fn new() -> Self {
        Self { count: 0, frontier: [None; 32], root_cache: Cell::new(None) }
    }
    /// Stable binary encoding used for crash-safe persistence in the node DB.
    pub fn encode(&self) -> Vec<u8> {
        let mut out=Vec::with_capacity(8+32*33);
        out.extend_from_slice(&self.count.to_le_bytes());
        for slot in &self.frontier {
            match slot {
                Some(v) => { out.push(1); out.extend_from_slice(v); }
                None => { out.push(0); out.extend_from_slice(&[0u8;32]); },
            }
        }
        out
    }
    pub fn decode(mut b:&[u8]) -> Result<Self,ConsensusError> {
        if b.len()!=8+32*33 { return Err(ConsensusError::Invalid("invalid Sapling frontier state length".into())); }
        let mut c=[0u8;8]; c.copy_from_slice(&b[..8]); b=&b[8..];
        let count=u64::from_le_bytes(c);
        if count > (1u64<<32) { return Err(ConsensusError::Invalid("invalid Sapling commitment count".into())); }
        let mut frontier=[None;32];
        for i in 0..32 {
            let present=b[0]; b=&b[1..];
            if present==1 { let mut v=[0u8;32]; v.copy_from_slice(&b[..32]); b=&b[32..]; frontier[i]=Some(v); }
            else if present!=0 { return Err(ConsensusError::Invalid("invalid Sapling frontier slot".into())); }
            else { b=&b[32..]; }
        }
        Ok(Self{count,frontier,root_cache:Cell::new(None)})
    }

    /// Ycash-compatible deterministic empty subtree roots. These are computed
    /// exactly once per process and then reused by every root calculation.
    /// This removes the repeated O(depth^2) empty-subtree reconstruction that
    /// previously dominated block-root time, without changing any consensus
    /// hash input.
    fn empty_roots() -> &'static [[u8;32]; 33] {
        static ROOTS: OnceLock<[[u8;32]; 33]> = OnceLock::new();
        ROOTS.get_or_init(|| {
            let mut roots = [[0u8;32]; 33];
            roots[0] = ycash_crypto::sapling_uncommitted_leaf();
            for level in 0..32 {
                roots[level + 1] = ycash_crypto::sapling_merkle_hash(level, roots[level], roots[level]);
            }
            roots
        })
    }

    fn empty(level:usize)->[u8;32]{ Self::empty_roots()[level] }

    /// Compute the exact same root as `root()`, while recording the cost of
    /// every Merkle level. Empty subtree roots are precomputed once, and the
    /// final root is memoized until the frontier changes.
    pub fn root_with_timing(&self) -> ([u8;32], SaplingRootTiming) {
        let started = std::time::Instant::now();
        let mut t = SaplingRootTiming::default();
        let empty = Self::empty_roots();
        let mut node = empty[0];

        if let Some(cached) = self.root_cache.get() {
            t.root_cache_hit = true;
            t.total_us = started.elapsed().as_micros() as u64;
            return (cached, t);
        }

        for level in 0..32 {
            let level_started = std::time::Instant::now();
            if let Some(left) = self.frontier[level] {
                let hash_started = std::time::Instant::now();
                node = ycash_crypto::sapling_merkle_hash(level, left, node);
                let us = hash_started.elapsed().as_micros() as u64;
                t.root_hash_us[level] = t.root_hash_us[level].saturating_add(us);
                t.root_hashes[level] += 1;
                t.level_hashes[level] += 1;
            } else {
                // Empty subtree roots are consensus constants for this tree.
                // No recursive hashing is required here; record the work avoided
                // so the dashboard can quantify the optimization.
                t.empty_hashes_avoided = t.empty_hashes_avoided.saturating_add(level as u64);
                let hash_started = std::time::Instant::now();
                node = ycash_crypto::sapling_merkle_hash(level, node, empty[level]);
                let us = hash_started.elapsed().as_micros() as u64;
                t.root_hash_us[level] = t.root_hash_us[level].saturating_add(us);
                t.root_hashes[level] += 1;
                t.level_hashes[level] += 1;
            }
            t.level_us[level] = t.level_us[level].saturating_add(level_started.elapsed().as_micros() as u64);
        }
        self.root_cache.set(Some(node));
        t.total_us = started.elapsed().as_micros() as u64;
        (node, t)
    }

    pub fn root(&self)->[u8;32]{
        if let Some(root) = self.root_cache.get() { return root; }
        let empty = Self::empty_roots();
        let mut node=empty[0];
        for level in 0..32 {
            if let Some(left)=self.frontier[level] {
                node=ycash_crypto::sapling_merkle_hash(level,left,node);
            } else {
                node=ycash_crypto::sapling_merkle_hash(level,node,empty[level]);
            }
        }
        self.root_cache.set(Some(node));
        node
    }

    pub fn append(&mut self, leaf:[u8;32])->Result<(),ConsensusError>{
        if self.count >= (1u64<<32){return Err(ConsensusError::Invalid("Sapling note commitment tree is full".into()));}
        let mut node=leaf; let mut n=self.count;
        for level in 0..32 {
            if (n&1)==0 {self.frontier[level]=Some(node);break}
            let left=self.frontier[level].take().ok_or_else(||ConsensusError::Invalid("Sapling frontier corruption".into()))?;
            node=ycash_crypto::sapling_merkle_hash(level,left,node); n>>=1;
        }
        self.count+=1; self.root_cache.set(None); Ok(())
    }
}

pub fn validate_sapling_transaction_state(
    tx:&ParsedTransaction,
    height:u64,
    state:&mut SaplingConsensusState,
    anchor_exists: impl Fn(&[u8;32])->bool,
    nullifier_exists: impl Fn(&[u8;32])->bool,
)->Result<(),ConsensusError>{
    validate_sapling_transaction_state_opts(tx,height,state,anchor_exists,nullifier_exists,true)
}

/// `verify_proofs=false` is only for blocks whose Sapling proofs and signatures
/// already passed `validate_for_commit_opts` / `validate_for_commit_batched`
/// (the parallel verify stage). Anchors, nullifiers and the note tree are
/// always checked here.
pub fn validate_sapling_transaction_state_opts(
    tx:&ParsedTransaction,
    height:u64,
    state:&mut SaplingConsensusState,
    anchor_exists: impl Fn(&[u8;32])->bool,
    nullifier_exists: impl Fn(&[u8;32])->bool,
    verify_proofs:bool,
)->Result<(),ConsensusError>{
    if tx.sapling_spends.is_empty() && tx.sapling_outputs.is_empty() { return Ok(()); }
    if tx.version != 4 { return Err(ConsensusError::Invalid("Sapling components require v4 transaction".into())); }
    let mut local=std::collections::HashSet::new();
    for spend in &tx.sapling_spends {
        if !local.insert(spend.nullifier) || nullifier_exists(&spend.nullifier) {return Err(ConsensusError::Invalid("Sapling nullifier already spent".into()));}
        if !anchor_exists(&spend.anchor) {return Err(ConsensusError::Invalid("Sapling anchor is not an earlier block final treestate root".into()));}
    }
    if verify_proofs {
        verify_sapling_transaction_proofs(tx,height)?;
    }
    for output in &tx.sapling_outputs {state.append(output.cmu)?;}
    Ok(())
}

pub const BLOSSOM_HEIGHT:u64=1_100_000;
pub const POW_AVERAGING_WINDOW:usize=17;
pub const POW_MEDIAN_BLOCK_SPAN:usize=11;
pub const POW_ADJUSTMENT_BLOCK_SPAN:usize=28;
pub const POW_DAMPING_FACTOR:i64=4;
pub const POW_MAX_ADJUST_UP:i64=16;
pub const POW_MAX_ADJUST_DOWN:i64=32;
pub const PRE_BLOSSOM_SPACING:i64=150;
pub const POST_BLOSSOM_SPACING:i64=75;
/// Ycash 4.5.0 reference implementation 4.5.0 chain.h: MAX_FUTURE_BLOCK_TIME_MTP = 90*60*2 (Ycash doubled Zcash's 90 min).
pub const MAX_FUTURE_BLOCK_TIME_MTP:u32=90*60*2;
/// Ycash 4.5.0 reference implementation 4.5.0 chain.h: MAX_FUTURE_BLOCK_TIME_LOCAL = 2*60*60*2.
pub const MAX_FUTURE_BLOCK_TIME_LOCAL:u64=2*60*60*2;
/// Genesis (chainparams.cpp): nTime=1477641360, nBits=1f07ffff. Needed for MTP/difficulty at low heights.
pub const GENESIS_TIME:u32=1_477_641_360;
pub const GENESIS_BITS:u32=0x1f07ffff;
pub const OVERWINTER_HEIGHT:u64=347_500;
pub const SAPLING_HEIGHT:u64=419_200;
pub const Ycash_HEIGHT:u64=570_000;
pub const HEARTWOOD_HEIGHT:u64=1_100_003;
pub const CANOPY_HEIGHT:u64=1_100_006;
pub const YDF_MANDATE_END_HEIGHT:u64=2_275_000;
pub const MAX_MONEY:i64=2_100_000_000_000_000;
pub const MAX_TX_SIZE_BEFORE_SAPLING:usize=100_000;
pub const MAX_TX_SIZE_AFTER_SAPLING:usize=2_000_000;
pub const MAX_BLOCK_SIZE:usize=2_000_000;
pub const MAX_BLOCK_SIGOPS:u64=20_000;
pub const COINBASE_MATURITY:u64=100;
pub const TX_EXPIRY_HEIGHT_THRESHOLD:u32=500_000_000;
pub const OVERWINTER_VERSION_GROUP_ID:u32=0x03c4_8270;
pub const SAPLING_VERSION_GROUP_ID:u32=0x892f_2085;
pub const SPROUT_BRANCH_ID:u32=0x0000_0000;
pub const OVERWINTER_BRANCH_ID:u32=0x5ba8_1b19;
pub const SAPLING_BRANCH_ID:u32=0x76b8_09bb;
pub const Ycash_BRANCH_ID:u32=0x374d_694f;
pub const BLOSSOM_BRANCH_ID:u32=0x8e47_1bd6;
pub const HEARTWOOD_BRANCH_ID:u32=0x6631_4da3;
pub const CANOPY_BRANCH_ID:u32=0x19bd_2d2f;

const POW_LIMIT_HEX:&str="0007ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff";

fn pow_limit()->BigUint{BigUint::parse_bytes(POW_LIMIT_HEX.as_bytes(),16).unwrap()}
fn compact_to_big(bits:u32)->Result<BigUint,ConsensusError>{let size=(bits>>24) as usize;let mant=bits&0x007f_ffff;if mant==0||(bits&0x0080_0000)!=0{return Err(ConsensusError::Invalid("negative/zero compact target".into()))}let mut v=BigUint::from(mant as u64);if size<=3{v >>= 8*(3-size)}else{v <<= 8*(size-3)}Ok(v)}
pub fn compact_to_target(bits:u32)->Result<[u8;32],ConsensusError>{let v=compact_to_big(bits)?;let b=v.to_bytes_be();if b.len()>32{return Err(ConsensusError::Invalid("compact target overflow".into()))}let mut out=[0u8;32];out[32-b.len()..].copy_from_slice(&b);Ok(out)}
fn big_to_compact(v:&BigUint)->u32{if v.is_zero(){return 0}let mut size=v.to_bytes_be().len() as u32;let mut compact:u32;if size<=3{compact=(v.clone()<<(8*(3-size))).to_u32_digits().first().copied().unwrap_or(0)}else{compact=(v>> (8*(size-3))).to_u32_digits().first().copied().unwrap_or(0)}if compact&0x0080_0000!=0{compact>>=8;size+=1}(size<<24)|(compact&0x007f_ffff)}
fn median_time(headers:&[BlockHeader],start_height:u64,end_height:u64)->u32{let first=end_height.saturating_sub((POW_MEDIAN_BLOCK_SPAN-1) as u64).max(start_height);let a=(first-start_height) as usize;let b=(end_height-start_height+1) as usize;if b>headers.len(){return headers.last().map(|h|h.time).unwrap_or(0)}let mut t:Vec<u32>=headers[a..b].iter().map(|h|h.time).collect();t.sort_unstable();t[t.len()/2]}
fn target_spacing(height:u64)->i64{if height>=BLOSSOM_HEIGHT{POST_BLOSSOM_SPACING}else{PRE_BLOSSOM_SPACING}}

pub fn expected_nbits(history:&[BlockHeader],history_start_height:u64,next_height:u64,candidate_time:u32)->Result<u32,ConsensusError>{
    let limit=pow_limit();
    if history.is_empty(){return Ok(big_to_compact(&limit));}
    let prev=&history[history.len()-1];
    // Ycash fork difficulty bootstrap, exactly as Ycash 4.5.0 reference implementation 4.5.0.
    if next_height>=YCASH_FORK_HEIGHT && next_height<YCASH_FORK_HEIGHT+POW_AVERAGING_WINDOW as u64{
        let spacing=target_spacing(next_height) as u32;
        let delta=candidate_time.saturating_sub(prev.time) as i64;
        let divisor=if delta>(spacing*12) as i64{64}else if delta>(spacing*6) as i64{128}else if delta>(spacing*2) as i64{256}else{0};
        if divisor!=0{return Ok(big_to_compact(&(limit/BigUint::from(divisor as u32))));}
    }
    let last_height=history_start_height+history.len() as u64-1;
    // Ycash 4.5.0 reference implementation: walk 17 blocks back from pindexLast; if that walks off genesis (last < 17) use powLimit.
    if last_height<POW_AVERAGING_WINDOW as u64 || history.len()<POW_AVERAGING_WINDOW{return Ok(big_to_compact(&limit));}
    let start=history.len()-POW_AVERAGING_WINDOW;
    let mut total=BigUint::zero();
    for h in &history[start..]{total+=compact_to_big(h.bits)?;}
    let mean=&total / BigUint::from(POW_AVERAGING_WINDOW as u32);
    let spacing=target_spacing(next_height);
    let avg_span=spacing*POW_AVERAGING_WINDOW as i64;
    let min_span=avg_span*(100-POW_MAX_ADJUST_UP)/100;
    let max_span=avg_span*(100+POW_MAX_ADJUST_DOWN)/100;
    let last_mtp=median_time(history,history_start_height,last_height) as i64;
    // pindexFirst is 17 blocks before pindexLast (was off by one: last-16).
    let first_height=last_height-POW_AVERAGING_WINDOW as u64;
    if first_height<history_start_height{return Err(ConsensusError::Contextual("difficulty history too short".into()))}
    let first_mtp=median_time(history,history_start_height,first_height) as i64;
    let actual=last_mtp-first_mtp;
    let mut bounded=avg_span+(actual-avg_span)/POW_DAMPING_FACTOR;
    if bounded<min_span{bounded=min_span}if bounded>max_span{bounded=max_span}
    let mut new_target=(mean/BigUint::from(avg_span as u64))*BigUint::from(bounded as u64);
    if new_target>limit{new_target=limit}
    Ok(big_to_compact(&new_target))
}

fn cmp_be(a:&[u8;32],b:&[u8;32])->std::cmp::Ordering{for i in 0..32{if a[i]!=b[i]{return a[i].cmp(&b[i])}}std::cmp::Ordering::Equal}
pub fn header_hash(header:&BlockHeader)->[u8;32]{header.hash()}
pub fn block_proof(bits:u32)->Result<[u8;32],ConsensusError>{let target=compact_to_big(bits)?;let mut denom=&target+BigUint::one();let numerator=(BigUint::one()<<256usize);let proof=numerator/denom;let b=proof.to_bytes_be();if b.len()>32{return Err(ConsensusError::Invalid("block proof overflow".into()))}let mut out=[0u8;32];out[32-b.len()..].copy_from_slice(&b);Ok(out)}
pub fn add_work(a:&[u8;32],b:&[u8;32])->[u8;32]{let mut out=[0u8;32];let mut carry=0u16;for i in (0..32).rev(){let x=a[i] as u16;let y=b[i] as u16;let z=x+y+carry;out[i]=(z&0xff) as u8;carry=z>>8;}out}
pub fn minimum_chain_work()->[u8;32]{let bytes=hex::decode("0000000000000000000000000000000000000000000000000152d8660f9d781c").unwrap();let mut out=[0u8;32];out.copy_from_slice(&bytes);out}
pub fn check_pow(header:&BlockHeader,height:u64)->Result<(),ConsensusError>{let(n,k,sol_len)=if height>=YCASH_FORK_HEIGHT{(192,7,400)}else{(200,9,1344)};if header.solution.len()!=sol_len{return Err(ConsensusError::Invalid(format!("wrong Equihash solution length at height {height}")))}let target=compact_to_target(header.bits)?;let limit=compact_to_target(big_to_compact(&pow_limit()))?;if cmp_be(&target,&limit)==std::cmp::Ordering::Greater{return Err(ConsensusError::Invalid("target exceeds Ycash PoW limit".into()))}equihash::is_valid_solution(n,k,&header.pow_input(),&header.nonce,&header.solution).map_err(|e|ConsensusError::Invalid(format!("invalid Equihash {n},{k}: {e:?}")))?;let raw=header.hash();let mut numeric=[0u8;32];for i in 0..32{numeric[i]=raw[31-i]}if cmp_be(&numeric,&target)==std::cmp::Ordering::Greater{return Err(ConsensusError::Invalid("header hash above target".into()))}Ok(())}

pub fn validate_header(header:&BlockHeader,height:u64,prev:&BlockHeader,mtp:u32,history_start_height:u64,history:&[BlockHeader])->Result<(),ConsensusError>{validate_header_opts(header,height,prev,mtp,history_start_height,history,true)}
/// Identical rule set to `validate_header`. `run_pow=false` exists only for the
/// parallel header stage: the caller MUST have already run `check_pow` on this
/// exact header (on a worker thread) and rejected the batch if it failed.
/// No rule is removed -- the Equihash/target check just runs on another core.
pub fn validate_header_opts(header:&BlockHeader,height:u64,prev:&BlockHeader,mtp:u32,history_start_height:u64,history:&[BlockHeader],run_pow:bool)->Result<(),ConsensusError>{if header.prev!=prev.hash(){return Err(ConsensusError::Contextual("previous hash mismatch".into()))}if header.time<=mtp{return Err(ConsensusError::Contextual("timestamp is not greater than median-time-past".into()))}if header.version<4{return Err(ConsensusError::Invalid("block nVersion < 4".into()))}if height>=2&&header.time>mtp.saturating_add(MAX_FUTURE_BLOCK_TIME_MTP){return Err(ConsensusError::Contextual("time-too-far-ahead-of-mtp (MTP + 3h)".into()))}let now=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d|d.as_secs()).unwrap_or(0);if header.time as u64>now+MAX_FUTURE_BLOCK_TIME_LOCAL{return Err(ConsensusError::Contextual("time-too-new (local clock + 4h)".into()))}let expected=expected_nbits(history,history_start_height,height,header.time)?;if header.bits!=expected{return Err(ConsensusError::Contextual(format!("unexpected nBits at height {height}: got {:08x}, expected {:08x}",header.bits,expected)))}if run_pow{check_pow(header,height)}else{Ok(())}}

use std::io::Cursor;

mod params;
pub use params::ShieldedParams;
pub mod sapling;
pub use sapling::{sapling_transaction_sighash,sapling_sighash,NOT_AN_INPUT,SIGHASH_ALL};
pub mod sprout;
pub use sprout::{SproutTree, SPROUT_TREE_DEPTH};

fn branch_id(height:u64)->u32{
    if height>=CANOPY_HEIGHT { CANOPY_BRANCH_ID }
    else if height>=HEARTWOOD_HEIGHT { HEARTWOOD_BRANCH_ID }
    else if height>=BLOSSOM_HEIGHT { BLOSSOM_BRANCH_ID }
    else if height>=Ycash_HEIGHT { Ycash_BRANCH_ID }
    else if height>=SAPLING_HEIGHT { SAPLING_BRANCH_ID }
    else if height>=OVERWINTER_HEIGHT { OVERWINTER_BRANCH_ID }
    else { SPROUT_BRANCH_ID }
}

pub fn consensus_branch_id(height:u64)->u32 { branch_id(height) }

pub fn money_range(v:i64)->bool { (0..=MAX_MONEY).contains(&v) }

pub fn is_coinbase(tx:&ParsedTransaction)->bool {
    tx.vin.len()==1 && tx.vin[0].prev_txid == [0u8;32] && tx.vin[0].prev_index == u32::MAX
}

fn check_tx_without_proofs(tx:&ParsedTransaction, height:u64, is_mined:bool)->Result<(),ConsensusError>{
    if !tx.overwintered && tx.version < 1 {
        return Err(ConsensusError::Invalid("bad-txns-version-too-low".into()));
    }
    if tx.overwintered {
        if tx.version < 3 { return Err(ConsensusError::Invalid("bad-tx-overwinter-version-too-low".into())); }
        let g=tx.version_group_id.ok_or_else(||ConsensusError::Invalid("missing version group".into()))?;
        if g!=OVERWINTER_VERSION_GROUP_ID && g!=SAPLING_VERSION_GROUP_ID {
            return Err(ConsensusError::Invalid("bad-tx-version-group-id".into()));
        }
        if tx.expiry_height.unwrap_or(0)>=TX_EXPIRY_HEIGHT_THRESHOLD {
            return Err(ConsensusError::Invalid("bad-tx-expiry-height-too-high".into()));
        }
    }
    if tx.vin.is_empty() && tx.joinsplits.is_empty() && tx.sapling_spends.is_empty() {
        return Err(ConsensusError::Invalid("bad-txns-vin-empty".into()));
    }
    if tx.vout.is_empty() && tx.joinsplits.is_empty() && tx.sapling_outputs.is_empty() {
        return Err(ConsensusError::Invalid("bad-txns-vout-empty".into()));
    }
    let size_limit=if height>=SAPLING_HEIGHT{MAX_TX_SIZE_AFTER_SAPLING}else{MAX_TX_SIZE_BEFORE_SAPLING};
    if tx.raw.len()>size_limit { return Err(ConsensusError::Invalid("bad-txns-oversize".into())); }

    let mut value_out=0i64;
    for o in &tx.vout {
        if !money_range(o.value) { return Err(ConsensusError::Invalid("bad-txns-vout-value".into())); }
        value_out=value_out.checked_add(o.value).ok_or_else(||ConsensusError::Invalid("bad-txns-txouttotal-toolarge".into()))?;
        if !money_range(value_out){return Err(ConsensusError::Invalid("bad-txns-txouttotal-toolarge".into()));}
    }
    if tx.sapling_spends.is_empty() && tx.sapling_outputs.is_empty() && tx.value_balance!=0 {
        return Err(ConsensusError::Invalid("bad-txns-valuebalance-nonzero".into()));
    }
    if tx.value_balance.abs()>MAX_MONEY { return Err(ConsensusError::Invalid("bad-txns-valuebalance-toolarge".into())); }
    if tx.value_balance<=0 {
        value_out=value_out.checked_add(-tx.value_balance).ok_or_else(||ConsensusError::Invalid("bad-txns-txouttotal-toolarge".into()))?;
        if !money_range(value_out){return Err(ConsensusError::Invalid("bad-txns-txouttotal-toolarge".into()));}
    }
    let mut value_in=0i64;
    for js in &tx.joinsplits {
        if !money_range(js.vpub_old)||!money_range(js.vpub_new){
            return Err(ConsensusError::Invalid("bad-txns-vpub-toolarge".into()));
        }
        if js.vpub_old!=0 && js.vpub_new!=0 {
            return Err(ConsensusError::Invalid("bad-txns-vpubs-both-nonzero".into()));
        }
        value_out=value_out.checked_add(js.vpub_old).ok_or_else(||ConsensusError::Invalid("bad-txns-txouttotal-toolarge".into()))?;
        value_in=value_in.checked_add(js.vpub_new).ok_or_else(||ConsensusError::Invalid("bad-txns-txintotal-toolarge".into()))?;
        if !money_range(value_out)||!money_range(value_in){return Err(ConsensusError::Invalid("bad-txns-value-range".into()));}
    }
    if tx.value_balance>=0 {
        value_in=value_in.checked_add(tx.value_balance).ok_or_else(||ConsensusError::Invalid("bad-txns-txintotal-toolarge".into()))?;
        if !money_range(value_in){return Err(ConsensusError::Invalid("bad-txns-txintotal-toolarge".into()));}
    }

    let mut inputs=std::collections::HashSet::new();
    for i in &tx.vin {
        let k=(i.prev_txid,i.prev_index);
        if !inputs.insert(k){return Err(ConsensusError::Invalid("bad-txns-inputs-duplicate".into()));}
    }
    let mut js_nfs=std::collections::HashSet::new();
    for js in &tx.joinsplits {
        for nf in js.nullifiers {
            if !js_nfs.insert(nf){return Err(ConsensusError::Invalid("bad-joinsplits-nullifiers-duplicate".into()));}
        }
    }
    let mut sap_nfs=std::collections::HashSet::new();
    for s in &tx.sapling_spends {
        if !sap_nfs.insert(s.nullifier){return Err(ConsensusError::Invalid("bad-spend-description-nullifiers-duplicate".into()));}
    }

    if is_coinbase(tx) {
        if !tx.joinsplits.is_empty(){return Err(ConsensusError::Invalid("bad-cb-has-joinsplits".into()));}
        if !tx.sapling_spends.is_empty(){return Err(ConsensusError::Invalid("bad-cb-has-spend-description".into()));}
        let n=tx.vin[0].script_sig.len();
        if n<2 || n>100 {return Err(ConsensusError::Invalid("bad-cb-length".into()));}
    } else {
        for i in &tx.vin {
            if i.prev_txid==[0u8;32] && i.prev_index==u32::MAX {
                return Err(ConsensusError::Invalid("bad-txns-prevout-null".into()));
            }
        }
    }

    // Transaction version/upgrade context from Ycash 4.5.0.
    if height<OVERWINTER_HEIGHT {
        if tx.overwintered { return Err(ConsensusError::Contextual("tx-overwinter-not-active".into())); }
    } else {
        if !tx.overwintered { return Err(ConsensusError::Contextual("tx-overwintered-flag-not-set".into())); }
        let expiry=tx.expiry_height.ok_or_else(||ConsensusError::Contextual("missing expiry height".into()))?;
        if u64::from(expiry)<height && expiry!=0 { return Err(ConsensusError::Contextual("tx-overwinter-expired".into())); }
        if height<SAPLING_HEIGHT {
            if tx.version!=3 || tx.version_group_id!=Some(OVERWINTER_VERSION_GROUP_ID) {
                return Err(ConsensusError::Contextual("bad-overwinter-version-group".into()));
            }
        } else {
            if tx.version!=4 || tx.version_group_id!=Some(SAPLING_VERSION_GROUP_ID) {
                return Err(ConsensusError::Contextual("bad-sapling-version-group".into()));
            }
        }
    }

    // Ycash 4.5.0 has NU5 disabled on mainnet. Reject every post-NU5 encoding.
    if tx.version>4 { return Err(ConsensusError::Contextual("future transaction version is disabled on Ycash mainnet".into())); }

    // A block transaction must be final at its block height. Ycash uses block time
    // for locktime (no LOCKTIME_MEDIAN_TIME_PAST flag in ContextualCheckBlock).
    // The full locktime/sequence interpreter is applied by the transparent input stage.
    let _=is_mined;
    Ok(())
}


use std::path::Path;

pub fn initialize_checked_shielded_verifier(params: &ShieldedParams) -> Result<([u8;32],[u8;32],Option<[u8;32]>), ConsensusError> {
    let hashes = params.verify_files().map_err(ConsensusError::Invalid)?;
    initialize_shielded_verifier(&params.spend, &params.output, params.sprout.as_deref())?;
    Ok(hashes)
}

pub fn initialize_shielded_verifier(
    sapling_spend_params:&Path,
    sapling_output_params:&Path,
    sprout_params:Option<&Path>,
)->Result<(),ConsensusError>{
    ycash_crypto::init_zksnark_params(sapling_spend_params,sapling_output_params,sprout_params)
        .map_err(|e|ConsensusError::Invalid(format!("shielded verifier init failed: {e:?}")))
}

pub fn verify_sapling_output_proofs(
    tx:&ParsedTransaction,
)->Result<(),ConsensusError>{
    if tx.sapling_outputs.is_empty(){return Ok(());}
    let mut verifier=ycash_crypto::SaplingVerifier::new()
        .map_err(|e|ConsensusError::Invalid(format!("shielded verifier unavailable: {e:?}")))?;
    for o in &tx.sapling_outputs {
        verifier.check_output(o.cv,o.cmu,o.ephemeral_key,o.zkproof)
            .map_err(|e|ConsensusError::Invalid(format!("invalid Sapling output proof: {e:?}")))?;
    }
    Ok(())
}

/// Exact prefix emitted by ycashd's `CScript() << nHeight`.
pub fn coinbase_height_prefix(height:u64)->Vec<u8>{
    assert!(height>0,"coinbase height must be positive");
    if height<=16 { return vec![0x50+height as u8]; }
    let n=ycash_script::num::encode(height as i64);
    let mut out=Vec::with_capacity(1+n.len());
    out.push(n.len() as u8);
    out.extend_from_slice(&n);
    out
}

/// Validate all block-local consensus rules that do not require UTXO or shielded
/// proof state. This is deliberately strict: an invalid condition is an error,
/// never a warning or an "accepted for now" result.
pub fn check_context(block:&Block,ctx:Context)->Result<(),ConsensusError>{
    if ctx.height!=ctx.prev_height+1 {return Err(ConsensusError::Contextual("non-contiguous height".into()));}
    let mut tx_count_prefix=Vec::new();
    ycash_chain::write_compact_size(block.txs.len() as u64, &mut tx_count_prefix);
    let block_wire=block.header.serialize().len()+tx_count_prefix.len()+block.txs.iter().map(|t|t.len()).sum::<usize>();
    if block_wire>MAX_BLOCK_SIZE {return Err(ConsensusError::Invalid("bad-blk-length".into()));}
    if block.txs.is_empty(){return Err(ConsensusError::Invalid("bad-cb-missing".into()));}
    if block.header.time<=ctx.median_time_past{return Err(ConsensusError::Contextual("block time not greater than median-time-past".into()));}
    check_pow(&block.header,ctx.height)?;
    let parsed:Vec<ParsedTransaction>=block.txs.iter().map(|raw|{
        let mut c=Cursor::new(raw.as_slice());
        ycash_chain::parse_transaction(&mut c).map_err(|e|ConsensusError::Invalid(format!("tx parse: {e}")))
    }).collect::<Result<_,_>>()?;
    if !is_coinbase(&parsed[0]) {return Err(ConsensusError::Invalid("bad-cb-missing".into()));}
    for tx in parsed.iter().skip(1) {if is_coinbase(tx){return Err(ConsensusError::Invalid("bad-cb-multiple".into()));}}
    for tx in &parsed {check_tx_without_proofs(tx,ctx.height,true)?;}
    for tx in &parsed {if !is_final_tx(tx,ctx.height,block.header.time){return Err(ConsensusError::Invalid("bad-txns-nonfinal".into()));}}
    if parsed[0].vin[0].script_sig.len() < 2 {return Err(ConsensusError::Invalid("bad-cb-length".into()));}

    // BIP34/Ycash coinbase height encoding. This must match ycashd's
    // `CScript() << nHeight` exactly, including OP_1..OP_16 for heights
    // 1..16. The previous implementation encoded height 1 as a one-byte
    // data push (`01`) instead of ycashd's `OP_1` (`51`), causing a clean
    // genesis-first sync to fail immediately with `bad-cb-height`.
    let enc=coinbase_height_prefix(ctx.height);
    if parsed[0].vin[0].script_sig.len()<enc.len() || parsed[0].vin[0].script_sig[..enc.len()]!=enc[..] {
        let actual=&parsed[0].vin[0].script_sig;
        return Err(ConsensusError::Invalid(format!(
            "bad-cb-height expected={} expected_prefix={:02x?} actual_prefix={:02x?}",
            ctx.height, enc, &actual[..actual.len().min(enc.len().max(8))]
        )));
    }

    // CVE-2012-2459 merkle mutation check.
    let (root,mutated)=ycash_chain::merkle_root_with_mutation(&block.txs);
    if root!=block.header.merkle {return Err(ConsensusError::Invalid("bad-txnmrklroot".into()));}
    if mutated {return Err(ConsensusError::Invalid("bad-txns-duplicate".into()));}

    // Pre-Ycash founders reward and post-Ycash 5% YDF mandate are consensus
    // rules. Script/address matching is handled by the reward validator.
    if ctx.height>0 {
        validate_coinbase_reward(&parsed[0],ctx.height)?;
    }
    Ok(())
}

/// Full transaction/block entry point. Proofs and transparent spends are
/// fail-closed: callers must supply the chain-state verifier for inputs,
/// nullifiers, scripts and shielded proofs before committing.
pub fn validate_for_commit(raw:&[u8],ctx:Context)->Result<Block,ConsensusError>{
    validate_for_commit_opts(raw,ctx,false)
}

/// Prefix of every error returned because *this node* has no backend for a
/// rule yet (transparent scripts/UTXOs, Sprout JoinSplits) -- as opposed to the
/// block actually being invalid. Callers must not blame or drop the peer for it.
pub const UNSUPPORTED_PREFIX:&str="node-unsupported: ";

/// `assume_valid`: the block is at or below a hard-coded checkpoint whose
/// header hash matches our PoW-verified header chain. Like ycashd's
/// checkpoints, script/JoinSplit checks are skipped there; PoW, merkle,
/// coinbase, size and Sapling proof checks still run.
pub fn validate_for_commit_opts(raw:&[u8],ctx:Context,assume_valid:bool)->Result<Block,ConsensusError>{
    validate_for_commit_inner(raw,ctx,assume_valid,None)
}

/// Same rules as `validate_for_commit_opts`, but Sapling Groth16 proofs are
/// queued in `batch` instead of verified one by one. The block is only valid
/// once `batch.finish()` also returns `Ok`. If batching is disabled this is
/// exactly `validate_for_commit_opts`.
pub fn validate_for_commit_batched(raw:&[u8],ctx:Context,assume_valid:bool,batch:&mut ProofBatch)->Result<Block,ConsensusError>{
    Ok(validate_for_commit_batched_with_parsed(raw,ctx,assume_valid,batch)?.0)
}

/// Batched commit validation returning the already-parsed transactions.
/// Callers that subsequently perform stateful validation can carry these
/// parsed transactions forward instead of decoding every transaction twice.
pub fn validate_for_commit_batched_with_parsed(raw:&[u8],ctx:Context,assume_valid:bool,batch:&mut ProofBatch)->Result<(Block,Vec<ParsedTransaction>),ConsensusError>{
    if ycash_crypto::batching_enabled() {
        validate_for_commit_inner_parsed(raw,ctx,assume_valid,Some(batch))
    } else {
        validate_for_commit_inner_parsed(raw,ctx,assume_valid,None)
    }
}

fn validate_for_commit_inner(raw:&[u8],ctx:Context,assume_valid:bool,mut batch:Option<&mut ProofBatch>)->Result<Block,ConsensusError>{
    Ok(validate_for_commit_inner_parsed(raw,ctx,assume_valid,batch)?.0)
}

fn validate_for_commit_inner_parsed(raw:&[u8],ctx:Context,assume_valid:bool,mut batch:Option<&mut ProofBatch>)->Result<(Block,Vec<ParsedTransaction>),ConsensusError>{
    let block=ycash_chain::read_block_at_height(raw,ctx.height).map_err(|e|ConsensusError::Invalid(e.to_string()))?;
    check_context(&block,ctx)?;
    // Stateless per-transaction checks that ycashd runs in CheckBlock /
    // ContextualCheckBlock. Everything that needs chain state -- transparent
    // inputs and scripts, fees, coinbase amount, Sprout/Sapling anchors and
    // nullifiers, value pools -- runs in strict height order in
    // `ycash_state::State::commit_blocks_batch`.
    let parsed:Vec<ParsedTransaction>=block.txs.iter().map(|raw|{
        let mut c=Cursor::new(raw.as_slice());
        ycash_chain::parse_transaction(&mut c).map_err(|e|ConsensusError::Invalid(e.to_string()))
    }).collect::<Result<_,_>>()?;
    for tx in &parsed {
        if !tx.joinsplits.is_empty() {
            match batch.as_deref_mut() {
                Some(b) => {
                    b.queue_joinsplit_sig(tx,ctx.height)?;
                    verify_joinsplit_proofs(tx,ctx.height,assume_valid)?;
                }
                None => verify_joinsplits(tx,ctx.height,assume_valid)?,
            }
        }
        if !tx.sapling_spends.is_empty() || !tx.sapling_outputs.is_empty() {
            if !ycash_crypto::sapling_params_loaded() {
                return Err(ConsensusError::Invalid(format!("{UNSUPPORTED_PREFIX}Sapling parameters (sapling-spend.params, sapling-output.params) are not loaded")));
            }
        }
        match batch.as_deref_mut() {
            Some(b) => b.queue_transaction(tx,ctx.height)?,
            None => verify_sapling_transaction_proofs(tx,ctx.height)?,
        }
    }
    Ok((block, parsed))
}

/// Batched Sapling cryptographic verification for a run of blocks.
///
/// Encoding and small-order checks run during queueing. SpendAuthSig, BindingSig,
/// and Groth16 proofs are deferred into the canonical batch and verified in
/// `finish`. Any rejection -- eager or from the batch -- is re-checked with
/// the original single-proof verifier (`verify_sapling_transaction_proofs`),
/// and THAT result is final. The batch path can therefore only speed up
/// acceptance of valid blocks; it can never be the sole reason a block is
/// rejected. Repeated disagreement disables batching for the process.
pub struct ProofBatch {
    batch: ycash_crypto::SaplingBatch,
    queued: Vec<(u64, ParsedTransaction)>,
    /// Every joinSplitSig of the window, checked with one Ed25519 batch.
    /// Tags index `joinsplit_heights`.
    joinsplit_sigs: ycash_crypto::Ed25519BatchVerifier,
    joinsplit_heights: Vec<u64>,
}

/// (batches verified, proofs in them, batches with at least one failing proof)
pub fn batch_stats()->(u64,u64,u64){ ycash_crypto::batch_stats() }

/// (RedJubjub signature batches verified, signatures in them, batches that failed)
pub fn redjubjub_batch_stats()->(u64,u64,u64){ ycash_crypto::redjubjub_batch_stats() }

static BATCH_MISMATCHES: std::sync::atomic::AtomicU32 = std::sync::atomic::AtomicU32::new(0);
const BATCH_MISMATCH_LIMIT: u32 = 3;

fn note_batch_mismatch(height:u64, stage:&str){
    let n=BATCH_MISMATCHES.fetch_add(1,std::sync::atomic::Ordering::Relaxed)+1;
    eprintln!("[BATCH] stage=MISMATCH height={height} where={stage} count={n} (single-proof verifier accepted what the batch path rejected)");
    if n>=BATCH_MISMATCH_LIMIT {
        ycash_crypto::disable_batching();
        eprintln!("[BATCH] stage=DISABLED after {n} mismatches; using single-proof verification");
    }
}

impl Default for ProofBatch { fn default()->Self{ Self::new() } }

impl ProofBatch {
    pub fn new()->Self {
        Self {
            batch: ycash_crypto::SaplingBatch::new(),
            queued: Vec::new(),
            joinsplit_sigs: ycash_crypto::Ed25519BatchVerifier::new(),
            joinsplit_heights: Vec::new(),
        }
    }

    /// Queue a transaction's joinSplitSig (ZIP 215) for the window's Ed25519
    /// batch instead of verifying it on its own.
    pub fn queue_joinsplit_sig(&mut self, tx:&ParsedTransaction, height:u64)->Result<(),ConsensusError>{
        let pubkey=tx.joinsplit_pubkey.ok_or_else(||ConsensusError::Invalid("JoinSplit transaction missing joinSplitPubKey".into()))?;
        let sig=tx.joinsplit_sig.ok_or_else(||ConsensusError::Invalid("JoinSplit transaction missing joinSplitSig".into()))?;
        let sighash=sapling_transaction_sighash(tx,height)?;
        let tag=self.joinsplit_heights.len() as u64;
        self.joinsplit_heights.push(height);
        self.joinsplit_sigs.queue(pubkey,sig,sighash.to_vec(),tag);
        Ok(())
    }

    /// joinSplitSigs waiting in the Ed25519 batch.
    pub fn joinsplit_signatures(&self)->usize { self.joinsplit_sigs.len() }

    /// Merge a worker-local batch into the canonical batch for the complete
    /// verification window. Worker-local transaction tags are rebased so the
    /// final batch can still isolate the exact transaction on failure.
    pub fn append(&mut self, mut other: ProofBatch) {
        let js_offset = self.joinsplit_heights.len() as u64;
        self.joinsplit_heights.extend(other.joinsplit_heights.drain(..));
        self.joinsplit_sigs.append_with_offset(std::mem::take(&mut other.joinsplit_sigs), js_offset);
        let offset = self.queued.len() as u64;
        self.queued.extend(other.queued.drain(..));
        // The crypto batch owns its proof tags, so rebase them by the same
        // transaction offset before combining the deferred Groth16 work.
        self.batch.append_with_offset(other.batch, offset);
    }

    /// Number of Groth16 proofs waiting in the batch.
    pub fn proofs(&self)->usize { self.batch.len() }
    pub fn spend_proofs(&self)->usize { self.batch.spend_count() }
    pub fn output_proofs(&self)->usize { self.batch.output_count() }

    pub fn queue_transaction(&mut self, tx:&ParsedTransaction, height:u64)->Result<(),ConsensusError>{
        if tx.sapling_spends.is_empty() && tx.sapling_outputs.is_empty() { return Ok(()); }
        let eager=(||->Result<ycash_crypto::SaplingBatchTx,()>{
            if tx.version != 4 { return Err(()); }
            let sighash=sapling_transaction_sighash(tx,height).map_err(|_|())?;
            let mut btx=ycash_crypto::SaplingBatchTx::new();
            let mut local=std::collections::HashSet::new();
            for spend in &tx.sapling_spends {
                if !local.insert(spend.nullifier) { return Err(()); }
                btx.check_spend(&spend.cv,&spend.anchor,&spend.nullifier,&spend.rk,&spend.zkproof,&spend.spend_auth_sig,&sighash).map_err(|_|())?;
            }
            for output in &tx.sapling_outputs {
                btx.check_output(&output.cv,&output.cmu,&output.ephemeral_key,&output.zkproof).map_err(|_|())?;
            }
            let sig=tx.binding_sig.ok_or(())?;
            btx.final_check(tx.value_balance,&sig,&sighash).map_err(|_|())?;
            Ok(btx)
        })();
        match eager {
            Ok(btx)=>{
                let tag=self.queued.len() as u64;
                self.queued.push((height,tx.clone()));
                self.batch.push(tag,btx);
                Ok(())
            }
            Err(())=>{
                // Authoritative path; returns the exact original error.
                verify_sapling_transaction_proofs(tx,height)?;
                note_batch_mismatch(height,"eager");
                Ok(())
            }
        }
    }

    /// Verify every queued proof. On failure returns the height of the first
    /// block holding an invalid transaction and the original verifier's error.
    pub fn finish(self)->Result<(),(u64,ConsensusError)>{
        let ProofBatch{batch,queued,joinsplit_sigs,joinsplit_heights}=self;
        // Ed25519 first: one combined check for every joinSplitSig in the
        // window. Reported tags are confirmed by the single ZIP 215 check,
        // which is the consensus rule, so they are final.
        if let Err(tags)=joinsplit_sigs.verify() {
            let height=tags.iter().filter_map(|t| joinsplit_heights.get(*t as usize).copied()).min().unwrap_or(0);
            return Err((height,ConsensusError::Invalid("bad-txns-invalid-joinsplit-signature".into())));
        }
        match batch.verify() {
            Ok(())=>Ok(()),
            Err(tags)=>{
                let mut first:Option<(u64,ConsensusError)>=None;
                for tag in tags {
                    let Some((height,tx))=queued.get(tag as usize) else { continue };
                    match verify_sapling_transaction_proofs(tx,*height) {
                        Err(e)=>{ if first.as_ref().map(|(h,_)|*height<*h).unwrap_or(true) { first=Some((*height,e)); } }
                        Ok(())=>note_batch_mismatch(*height,"groth16"),
                    }
                }
                match first { Some(x)=>Err(x), None=>Ok(()) }
            }
        }
    }
}

/// joinSplitSig (always, like ContextualCheckTransaction) and Sprout proofs
/// (CheckTransaction). ycashd never verifies pre-Sapling PHGR/BCTV14 proofs
/// ("we checkpoint after Sapling activation"), and skips Groth16 proofs for
/// blocks under its last checkpoint (`fExpensiveChecks`), which is what
/// `assume_valid` mirrors.
pub fn verify_joinsplits(tx:&ParsedTransaction,height:u64,assume_valid:bool)->Result<(),ConsensusError>{
    verify_joinsplit_sig(tx,height)?;
    verify_joinsplit_proofs(tx,height,assume_valid)
}

/// joinSplitSig alone (ZIP 215), checked on its own.
pub fn verify_joinsplit_sig(tx:&ParsedTransaction,height:u64)->Result<(),ConsensusError>{
    let pubkey=tx.joinsplit_pubkey.ok_or_else(||ConsensusError::Invalid("JoinSplit transaction missing joinSplitPubKey".into()))?;
    let sig=tx.joinsplit_sig.ok_or_else(||ConsensusError::Invalid("JoinSplit transaction missing joinSplitSig".into()))?;
    let sighash=sapling_transaction_sighash(tx,height)?;
    if !ycash_crypto::ed25519_verify_zip215(&pubkey,&sig,&sighash) {
        return Err(ConsensusError::Invalid("bad-txns-invalid-joinsplit-signature".into()));
    }
    Ok(())
}

/// Sprout JoinSplit proofs (everything in `verify_joinsplits` except the
/// signature, which the batched path queues separately).
pub fn verify_joinsplit_proofs(tx:&ParsedTransaction,height:u64,assume_valid:bool)->Result<(),ConsensusError>{
    let _ = height;
    let pubkey=tx.joinsplit_pubkey.ok_or_else(||ConsensusError::Invalid("JoinSplit transaction missing joinSplitPubKey".into()))?;
    if assume_valid { return Ok(()); }
    // JSDescription uses a Groth16 proof iff the tx is overwintered v4+.
    if !(tx.overwintered && tx.version>=4) { return Ok(()); }
    if !ycash_crypto::sprout_params_loaded() {
        return Err(ConsensusError::Invalid(format!("{UNSUPPORTED_PREFIX}Sprout Groth16 parameters (sprout-groth16.params) are not loaded")));
    }
    for js in &tx.joinsplits {
        let proof:[u8;192]=js.proof.as_slice().try_into()
            .map_err(|_|ConsensusError::Invalid("Groth16 JoinSplit proof has wrong length".into()))?;
        let hsig=sprout::h_sig(&js.random_seed,&js.nullifiers,&pubkey);
        let ok=ycash_crypto::sprout_verify(
            &proof,&js.anchor,&hsig,&js.macs[0],&js.macs[1],
            &js.nullifiers[0],&js.nullifiers[1],&js.commitments[0],&js.commitments[1],
            js.vpub_old as u64,js.vpub_new as u64,
        );
        if !ok { return Err(ConsensusError::Invalid("bad-txns-joinsplit-verification-failed".into())); }
    }
    Ok(())
}

/// `IsFinalTx(tx, nHeight, block.GetBlockTime())`.
pub fn is_final_tx(tx:&ParsedTransaction,height:u64,block_time:u32)->bool{
    if tx.lock_time==0 { return true; }
    let lock=tx.lock_time as i64;
    let cutoff=if lock<TX_EXPIRY_HEIGHT_THRESHOLD as i64 { height as i64 } else { block_time as i64 };
    if lock<cutoff { return true; }
    tx.vin.iter().all(|i|i.sequence==u32::MAX)
}

pub const SUBSIDY_SLOW_START_INTERVAL:u64=20_000;
pub const SUBSIDY_SLOW_START_SHIFT:u64=SUBSIDY_SLOW_START_INTERVAL/2;
pub const PRE_BLOSSOM_HALVING_INTERVAL:u64=840_000;
pub const BLOSSOM_POW_TARGET_SPACING_RATIO:u64=2;
pub const POST_BLOSSOM_HALVING_INTERVAL:u64=PRE_BLOSSOM_HALVING_INTERVAL*BLOSSOM_POW_TARGET_SPACING_RATIO;
pub const COIN:i64=100_000_000;

fn halving(height:u64)->u64{
    if height>=BLOSSOM_HEIGHT {
        let scaled=(BLOSSOM_HEIGHT-SUBSIDY_SLOW_START_SHIFT)*BLOSSOM_POW_TARGET_SPACING_RATIO+(height-BLOSSOM_HEIGHT);
        scaled/POST_BLOSSOM_HALVING_INTERVAL
    } else {
        (height-SUBSIDY_SLOW_START_SHIFT)/PRE_BLOSSOM_HALVING_INTERVAL
    }
}

/// `GetBlockSubsidy` (ZIP 208), unchanged in ycashd 4.5.0.
pub fn block_subsidy(height:u64)->i64{
    let mut subsidy:i64=COIN*25/2;
    if height<SUBSIDY_SLOW_START_SHIFT {
        subsidy/=SUBSIDY_SLOW_START_INTERVAL as i64;
        return subsidy*height as i64;
    } else if height<SUBSIDY_SLOW_START_INTERVAL {
        subsidy/=SUBSIDY_SLOW_START_INTERVAL as i64;
        return subsidy*(height as i64+1);
    }
    let h=halving(height);
    if h>=64 { return 0; }
    if height>=BLOSSOM_HEIGHT { (subsidy/BLOSSOM_POW_TARGET_SPACING_RATIO as i64)>>h } else { subsidy>>h }
}

/// `CTransaction::GetValueOut`: transparent outputs + max(-valueBalance,0) + vpub_old.
pub fn tx_value_out(tx:&ParsedTransaction)->Result<i64,ConsensusError>{
    let bad=||ConsensusError::Invalid("bad-txns-txouttotal-toolarge".into());
    let mut v:i64=0;
    for o in &tx.vout {
        v=v.checked_add(o.value).ok_or_else(bad)?;
        if !money_range(o.value)||!money_range(v) { return Err(bad()); }
    }
    if tx.value_balance<=0 {
        let x=tx.value_balance.checked_neg().ok_or_else(bad)?;
        v=v.checked_add(x).ok_or_else(bad)?;
        if !money_range(x)||!money_range(v) { return Err(bad()); }
    }
    for js in &tx.joinsplits {
        v=v.checked_add(js.vpub_old).ok_or_else(bad)?;
        if !money_range(js.vpub_old)||!money_range(v) { return Err(bad()); }
    }
    Ok(v)
}

/// `CTransaction::GetShieldedValueIn`: max(valueBalance,0) + vpub_new.
pub fn tx_shielded_value_in(tx:&ParsedTransaction)->Result<i64,ConsensusError>{
    let bad=||ConsensusError::Invalid("bad-txns-inputvalues-outofrange".into());
    let mut v:i64=0;
    if tx.value_balance>=0 {
        v=v.checked_add(tx.value_balance).ok_or_else(bad)?;
        if !money_range(tx.value_balance)||!money_range(v) { return Err(bad()); }
    }
    for js in &tx.joinsplits {
        v=v.checked_add(js.vpub_new).ok_or_else(bad)?;
        if !money_range(js.vpub_new)||!money_range(v) { return Err(bad()); }
    }
    Ok(v)
}

/// Verify Sapling cryptographic proofs without making claims about the chain's
/// historical note tree. Anchor/nullifier membership is stateful and is checked
/// by `ycash_state::State::commit_blocks_batch` against the canonical ancestor.
pub fn verify_sapling_transaction_proofs(
    tx:&ParsedTransaction,
    height:u64,
)->Result<(),ConsensusError>{
    if tx.sapling_spends.is_empty() && tx.sapling_outputs.is_empty() { return Ok(()); }
    if tx.version != 4 { return Err(ConsensusError::Invalid("Sapling components require v4 transaction".into())); }
    let sighash=sapling_transaction_sighash(tx,height)?;
    let mut verifier=ycash_crypto::SaplingVerifier::new()
        .map_err(|e|ConsensusError::Invalid(format!("Sapling verifier unavailable: {e:?}")))?;
    let mut local=std::collections::HashSet::new();
    for spend in &tx.sapling_spends {
        if !local.insert(spend.nullifier) {
            return Err(ConsensusError::Invalid("Sapling nullifier duplicated in transaction".into()));
        }
        verifier.check_spend(
            spend.cv,spend.anchor,spend.nullifier,spend.rk,spend.zkproof,
            spend.spend_auth_sig,sighash
        ).map_err(|e|ConsensusError::Invalid(format!("invalid Sapling spend: {e:?}")))?;
    }
    for output in &tx.sapling_outputs {
        verifier.check_output(output.cv,output.cmu,output.ephemeral_key,output.zkproof)
            .map_err(|e|ConsensusError::Invalid(format!("invalid Sapling output: {e:?}")))?;
    }
    if !tx.sapling_spends.is_empty() || !tx.sapling_outputs.is_empty() {
        let sig=tx.binding_sig.ok_or_else(||ConsensusError::Invalid("missing Sapling binding signature".into()))?;
        verifier.final_check(tx.value_balance,sig,sighash)
            .map_err(|e|ConsensusError::Invalid(format!("invalid Sapling binding signature: {e:?}")))?;
    }
    Ok(())
}

// Ycash mainnet YDF recipient addresses from ycashd chainparams.cpp.
// Each address is the monthly rotating P2PKH recipient. The mainnet address
// version is 0x1c28 ("s1"), and ycashd constructs a P2PKH script from it.
const YDF_ADDRESS_CHANGE_INTERVAL:u64 = 17_917;
const YDF_MAINNET_ADDRESSES:[&str;48] = [
    "s1hfWJ4ej1H3s8XCUb7YnrU68K64AsGVUHE", "s1iZaRoYtafWspcieQxg6hhaU4DfZyAdGQf", "s1RSr6xec6Cc98emM4cdq45rkVekHMjRWbw", "s1RsqYeweoKVepivLPLsiajE8c6khu5UKhS",
    "s1MNmqMWyV4nMWE4oDb1nqJs7haJrv9QTKp", "s1RP95ESdcu33gMtU7deLW9TP6yDZncjRQ7", "s1h8W7xQbiU8Zxu21Zcg82NByjkWMcEbNtX", "s1PVcdfcrJrDCmXxgSTGuKGSNhwSYZ51XKJ",
    "s1PkV5nFkgQN4EGuTtEcmm4CxeBVx2L5HHv", "s1jiVSTfMaFUrWnf17BGc416oomHbut58Ue", "s1Zr2KdHtnK2zNSMQDrAVv3KU51mgDbqgwe", "s1QkY6tmBHPZacXPMPmsjP37Kxgs5mcgcAn",
    "s1Xu76ZmGDENdLFAiuj5iMdp1RA4hWSNieq", "s1bdiEnfBYaEgrt2TmnY3ZHmdhg5AEw9tjN", "s1asM9Ui4U13GjmLoAhvfK6J5QihemQR9Pk", "s1QhTSXYu4K1cTNomN27wiep9WC9HBZjrxJ",
    "s1j3Ef2qCNjwRAM18BgwsPAZFzZ475BWM5S", "s1QZibiN7iqVCfVBES9Gn7e3o5psxRKtpwE", "s1fdiDZHkzp8K8UajpVwYUdyFeb6jNVyoKv", "s1iMShbVRH1eCGxK2ZoLMDn5o9NcwXkNPVF",
    "s1YtUXAMt8m31gGeP5m3Y53B1wrMk3FFigJ", "s1gy9aqWUihGRjZa3vqc7136vqTGNAWyefF", "s1NNozrex18HZqcHCGpGoSRkj8hqHLEPaVC", "s1NYNDdqthMf7D7sZbnLGuecDtXb48Ne2bf",
    "s1P7UJ9Wp7jstJPUbvMSRVFjN8tfQueQSK3", "s1RDeyH7xg8y9veb9XfAmtKzrMTjFS14c4T", "s1NmH6MNXU19xoHjUfpQpb4dEMSy1Wbs9tC", "s1UnFL2yrZapMKmB5EqaBKpogZmnXLUgELB",
    "s1XT3W1sLFdgmGoecQbPdJbjUDMurW8CFA2", "s1gyVwgangQxLCAcm8VS4SWqXDqeohNg7hd", "s1k3eWbqnbVM1xtZEDc81UbFdwXgXNnbtdH", "s1Wr6eAh3gZWwBVRZcND9YCzdNfR9cARkD4",
    "s1dtjp2KHWZ6qF2LvgNiEwjJV2dA2c6y75V", "s1cjQf9kmjQdTmnn6mbBaesHMNLt2JqjyEV", "s1URQeusSoi7fkgyAwCshFzobUzmLGH4U3b", "s1Z9YqM2h48HUf8kcSHS89q4Z6Bg9xua3kA",
    "s1TLmZzMDsDhYfh4vpY7NpRB4kao2UEEqKu", "s1QEWvfC1uifDfi78NY7cArw9xLEja7QAZR", "s1b4kfW9WMUtd2H7X4C64KLzqPWdMPXRMtS", "s1cHTXzCXhKYAX7sY7D8YGcmopjN8Yngoju",
    "s1QKjMQDeF9FLVo2sL8m11VC4ZA18s61s2K", "s1gV8D561ZpmaZVxG176cQM1bMFMnHLvujE", "s1caQmLCYVDZegcMoBckHD2RXjBh7ikpj2j", "s1Y63AsWsJTk5t5nSZfaFcFWmtfnFUUAu2V",
    "s1Y2U4GsfZdP9LAbC97GAmSdihBX5FU9gQn", "s1bPYWZMXzyN2ML2vswDiCckmas775QFs2Q", "s1erG25RcWYCiBPbT7khTU4ULhzm8jJZ7pv", "s1kYEiPdFZ3oV389q2MmSYY932qPF1ygVtx",
];

fn base58_decode_check(s:&str)->Result<Vec<u8>,ConsensusError>{
    const ALPHABET:&[u8;58]=b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
    let mut n=BigUint::zero();
    for c in s.bytes(){
        let pos=ALPHABET.iter().position(|&x| x==c).ok_or_else(||ConsensusError::Invalid("invalid YDF base58 address".into()))?;
        n = n*58u8 + BigUint::from(pos as u64);
    }
    let mut raw=n.to_bytes_be();
    let leading=s.bytes().take_while(|&c|c==b'1').count();
    if leading>0 {
        let mut pref=vec![0u8;leading];
        pref.extend_from_slice(&raw);
        raw=pref;
    }
    if raw.len()!=26 { return Err(ConsensusError::Invalid("invalid YDF address length".into())); }
    let checksum=Sha256::digest(Sha256::digest(&raw[..22]));
    if raw[22..26]!=checksum[..4] { return Err(ConsensusError::Invalid("invalid YDF address checksum".into())); }
    if raw[0] != 0x1c || raw[1] != 0x28 { return Err(ConsensusError::Invalid("invalid YDF mainnet address prefix".into())); }
    Ok(raw[2..22].to_vec())
}

fn ydf_script_at_height(height:u64)->Result<Vec<u8>,ConsensusError>{
    if height<Ycash_HEIGHT || height>=YDF_MANDATE_END_HEIGHT {
        return Err(ConsensusError::Invalid("YDF is not mandatory at this height".into()));
    }
    let index=((height-Ycash_HEIGHT)/YDF_ADDRESS_CHANGE_INTERVAL) as usize % YDF_MAINNET_ADDRESSES.len();
    let hash160=base58_decode_check(YDF_MAINNET_ADDRESSES[index])?;
    let mut script=Vec::with_capacity(25);
    script.extend_from_slice(&[0x76,0xa9,0x14]); // OP_DUP OP_HASH160 PUSH20
    script.extend_from_slice(&hash160);
    script.extend_from_slice(&[0x88,0xac]); // OP_EQUALVERIFY OP_CHECKSIG
    Ok(script)
}

fn validate_coinbase_reward(tx:&ParsedTransaction,height:u64)->Result<(),ConsensusError>{
    // ycashd's mandatory YDF rule: during the mandate period the coinbase
    // must contain an output paying exactly one fifth (5%) of the block
    // subsidy to the height-selected YDF P2PKH script. This is a presence
    // check, matching ycashd; miner outputs may also contain transaction fees.
    if height>=Ycash_HEIGHT && height<YDF_MANDATE_END_HEIGHT {
        let expected_script=ydf_script_at_height(height)?;
        let expected_amount=block_subsidy(height)/5;
        if !tx.vout.iter().any(|o|o.value==expected_amount && o.script_pubkey==expected_script) {
            return Err(ConsensusError::Invalid(format!(
                "cb-no-ydf-reward height={} expected_amount={} expected_script={:02x?}",
                height,expected_amount,expected_script
            )));
        }
    }
    Ok(())
}


#[cfg(test)]
mod strict_rule_tests {
    use super::*;

    #[test]
    fn sapling_root_deep_timing_preserves_consensus_root() {
        let mut state = SaplingConsensusState::new();
        for i in 0..40u8 {
            let mut leaf = [0u8; 32];
            leaf[0] = i;
            state.append(leaf).unwrap();
        }
        let (measured, timing) = state.root_with_timing();
        let expected = state.root();
        assert_eq!(expected, measured);
        assert!(timing.total_us > 0);
        assert_eq!(timing.level_hashes.iter().sum::<u64>(), 32);
        assert!(timing.empty_hashes_avoided > 0);
        assert_eq!(timing.empty_hashes.iter().sum::<u64>(), 0);
        assert!(state.root_with_timing().1.root_cache_hit);
    }

    #[test]
    fn optimized_sapling_root_matches_reference_frontier_algorithm() {
        fn reference_root(state: &SaplingConsensusState) -> [u8;32] {
            let mut empty = [[0u8;32]; 33];
            empty[0] = ycash_crypto::sapling_uncommitted_leaf();
            for level in 0..32 {
                empty[level + 1] = ycash_crypto::sapling_merkle_hash(level, empty[level], empty[level]);
            }
            let mut node = empty[0];
            for level in 0..32 {
                node = match state.frontier[level] {
                    Some(left) => ycash_crypto::sapling_merkle_hash(level, left, node),
                    None => ycash_crypto::sapling_merkle_hash(level, node, empty[level]),
                };
            }
            node
        }

        for count in [0usize, 1, 2, 3, 31, 32, 33, 40, 63, 64, 65, 127, 128, 129, 1023] {
            let mut state = SaplingConsensusState::new();
            for i in 0..count {
                let mut leaf = [0u8;32];
                leaf[..8].copy_from_slice(&(i as u64).to_le_bytes());
                state.append(leaf).unwrap();
            }
            assert_eq!(state.root(), reference_root(&state), "root mismatch at count {count}");
        }
    }

    #[test]
    fn ycash_mainnet_upgrade_boundaries_are_exact() {
        assert_eq!(consensus_branch_id(0), SPROUT_BRANCH_ID);
        assert_eq!(consensus_branch_id(347_500), OVERWINTER_BRANCH_ID);
        assert_eq!(consensus_branch_id(419_200), SAPLING_BRANCH_ID);
        assert_eq!(consensus_branch_id(570_000), Ycash_BRANCH_ID);
        assert_eq!(consensus_branch_id(1_100_000), BLOSSOM_BRANCH_ID);
        assert_eq!(consensus_branch_id(1_100_003), HEARTWOOD_BRANCH_ID);
        assert_eq!(consensus_branch_id(1_100_006), CANOPY_BRANCH_ID);
    }

    #[test]
    fn ydf_address_schedule_and_script_are_canonical() {
        let script0=ydf_script_at_height(Ycash_HEIGHT).unwrap();
        assert_eq!(script0.len(),25);
        assert_eq!(&script0[..3], &[0x76,0xa9,0x14]);
        assert_eq!(&script0[23..], &[0x88,0xac]);
        assert_eq!(ydf_script_at_height(Ycash_HEIGHT+YDF_ADDRESS_CHANGE_INTERVAL).unwrap().len(),25);
        assert!(ydf_script_at_height(YDF_MANDATE_END_HEIGHT).is_err());
        assert_eq!(block_subsidy(570_000)/5, 250_000_000);
    }

    #[test]
    fn block_subsidy_matches_zip208() {
        assert_eq!(block_subsidy(1), 62_500);
        assert_eq!(block_subsidy(9_999), 62_500*9_999);
        assert_eq!(block_subsidy(10_000), 62_500*10_001);
        assert_eq!(block_subsidy(20_000), 1_250_000_000);
        assert_eq!(block_subsidy(849_999), 1_250_000_000);
        assert_eq!(block_subsidy(850_000), 625_000_000);
        assert_eq!(block_subsidy(BLOSSOM_HEIGHT), 312_500_000);
    }

    #[test]
    fn money_and_size_limits_match_reference() {
        assert!(money_range(0));
        assert!(money_range(MAX_MONEY));
        assert!(!money_range(MAX_MONEY + 1));
        assert_eq!(MAX_BLOCK_SIZE, 2_000_000);
        assert_eq!(MAX_BLOCK_SIGOPS, 20_000);
        assert_eq!(MAX_TX_SIZE_BEFORE_SAPLING, 100_000);
    }
}

#[cfg(test)]
mod tests{use super::*;#[test]fn compact_roundtrip_limit(){let b=big_to_compact(&pow_limit());assert_eq!(b,0x1f07ffff);let _=compact_to_target(b).unwrap();}}

#[cfg(test)]
mod sapling_state_tests {
    use super::*;

    #[test]
    fn frontier_roundtrip_is_lossless() {
        let mut s=SaplingConsensusState::new();
        s.append([7u8;32]).unwrap();
        s.append([8u8;32]).unwrap();
        let encoded=s.encode();
        let restored=SaplingConsensusState::decode(&encoded).unwrap();
        assert_eq!(s.count, restored.count);
        assert_eq!(s.frontier, restored.frontier);
        assert_eq!(s.root(), restored.root());
    }

    #[test]
    fn empty_leaf_comes_from_librustzcash() {
        let leaf=ycash_crypto::sapling_uncommitted_leaf();
        assert_ne!(leaf, [0u8;32]);
        let mut s=SaplingConsensusState::new();
        assert_eq!(s.root(), s.root());
    }

    #[test]
    fn root_cache_invalidates_on_append() {
        let mut s = SaplingConsensusState::new();
        let first = s.root();
        assert!(s.root_with_timing().1.root_cache_hit);
        s.append([9u8; 32]).unwrap();
        let after = s.root_with_timing();
        assert!(!after.1.root_cache_hit);
        assert_ne!(first, after.0);
        assert_eq!(after.1.level_hashes.iter().sum::<u64>(), 32);
    }
}

#[cfg(test)]
mod coinbase_height_tests {
    use super::coinbase_height_prefix;
    #[test]
    fn matches_ycashd_cscript_height_encoding() {
        assert_eq!(coinbase_height_prefix(1), vec![0x51]);
        assert_eq!(coinbase_height_prefix(16), vec![0x60]);
        assert_eq!(coinbase_height_prefix(17), vec![0x01,0x11]);
        assert_eq!(coinbase_height_prefix(127), vec![0x01,0x7f]);
        assert_eq!(coinbase_height_prefix(128), vec![0x02,0x80,0x00]);
        assert_eq!(coinbase_height_prefix(0x7fffff), vec![0x03,0xff,0xff,0x7f]);
        assert_eq!(coinbase_height_prefix(0x800000), vec![0x04,0x00,0x00,0x80,0x00]);
    }
}
