//! Signature hashes used by consensus. The implementation lives in
//! `ycash-script` (one canonical copy shared by scripts, joinSplitSig and
//! Sapling binding/spend-auth signatures).
//!
//! The previous local copy had two divergences from ycashd 4.5.0 that the
//! shared implementation fixes: Overwinter (v3) hashes must not include the
//! Sapling fields, and ZIP 143/243 SIGHASH_SINGLE without a matching output
//! hashes a zero `hashOutputs` (the "1" bug value is legacy-only, and even
//! there ycashd rejects rather than signing it).

use ycash_chain::ParsedTransaction;
use crate::{consensus_branch_id, ConsensusError};

pub use ycash_script::sighash::{SIGHASH_ALL, SIGHASH_ANYONECANPAY, SIGHASH_NONE, SIGHASH_SINGLE};
pub const NOT_AN_INPUT: usize = usize::MAX;

pub fn sapling_sighash(
    tx: &ParsedTransaction,
    hash_type: u32,
    input_index: Option<usize>,
    spent_value: Option<i64>,
    spent_script: Option<&[u8]>,
    height: u64,
) -> Result<[u8; 32], ConsensusError> {
    let input_index = input_index.filter(|i| *i != NOT_AN_INPUT);
    if input_index.is_some() && (spent_value.is_none() || spent_script.is_none()) {
        return Err(ConsensusError::Invalid("transparent sighash missing scriptCode or spent value".into()));
    }
    ycash_script::signature_hash(
        tx,
        spent_script.unwrap_or(&[]),
        input_index,
        hash_type,
        spent_value.unwrap_or(0),
        consensus_branch_id(height),
        None,
    )
    .ok_or_else(|| ConsensusError::Invalid("signature hash undefined for this input/hash type".into()))
}

/// `SignatureHash(CScript(), tx, NOT_AN_INPUT, SIGHASH_ALL, 0, branchId)`:
/// the message for joinSplitSig, Sapling spendAuthSig and bindingSig.
pub fn sapling_transaction_sighash(tx: &ParsedTransaction, height: u64) -> Result<[u8; 32], ConsensusError> {
    sapling_sighash(tx, SIGHASH_ALL, None, None, None, height)
}
