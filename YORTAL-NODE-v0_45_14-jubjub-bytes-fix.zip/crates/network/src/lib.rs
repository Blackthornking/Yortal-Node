use anyhow::{bail,Result};
use tokio::{io::{AsyncReadExt,AsyncWriteExt},net::TcpStream};
use ycash_wire::{frame,parse_header};

pub const PROTOCOL_VERSION:i32=270_013;
pub const MAX_MESSAGE_SIZE:u32=2*1024*1024;

pub async fn handshake(addr:&str)->Result<()> {
    let mut s=TcpStream::connect(addr).await?;
    s.write_all(&frame("version",&version_payload())).await?;
    let mut h=[0u8;24];s.read_exact(&mut h).await?;
    let (cmd,len,sum)=parse_header(&h)?;if len>MAX_MESSAGE_SIZE{bail!("message too large")}
    let mut p=vec![0;len as usize];s.read_exact(&mut p).await?;
    let _=(cmd,sum,p);
    Ok(())
}
fn version_payload()->Vec<u8>{let mut v=Vec::with_capacity(128);v.extend_from_slice(&PROTOCOL_VERSION.to_le_bytes());v.extend_from_slice(&1u64.to_le_bytes());v.extend_from_slice(&0i64.to_le_bytes());v.extend_from_slice(&0u64.to_le_bytes());v.extend_from_slice(&[0u8;16]);v.extend_from_slice(&8833u16.to_be_bytes());v.extend_from_slice(&1u64.to_le_bytes());v.extend_from_slice(&[0u8;16]);v.extend_from_slice(&0u16.to_be_bytes());v.extend_from_slice(&1u64.to_le_bytes());v.push(0);v.extend_from_slice(&0i32.to_le_bytes());v.push(1);v}
