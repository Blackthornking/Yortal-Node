//! Ordered batch pipeline.
//!
//! The canonical publication unit is exactly [`BATCH_BLOCKS`] blocks. The active
//! verifier path receives only complete contiguous batches from the intake gate;
//! state-dependent preparation and canonical publication still require the exact
//! contiguous N+1 .. N+16 window and publish it atomically in height order.
//!
//! The older helper types below remain useful for deterministic partition tests
//! and compatibility; the live `VerifierPool` scheduler receives only complete
//! assembled batches and reassembles verified results by height before publication.

use std::collections::BTreeMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Mutex;

use anyhow::Result;
use rayon::prelude::*;
use ycash_consensus::ProofBatch;
use ycash_state::prospective::SemanticBlock;

use crate::verifier::{verify_into_batch, RawBlock};

/// Blocks per batch, through every stage.
pub const BATCH_BLOCKS: usize = crate::PIPELINE_BATCH_SIZE;

/// Collects arrivals until a full contiguous batch exists.
///
/// Arrivals are unordered by nature: peers answer at different speeds and a
/// hedged head can arrive twice. The assembler turns that back into a strict
/// sequence, so no later stage ever sees a gap.
pub struct BatchAssembler {
    pending: Mutex<BTreeMap<u64, RawBlock>>,
    batch: usize,
}

impl BatchAssembler {
    pub fn new(batch: usize) -> Self {
        Self { pending: Mutex::new(BTreeMap::new()), batch: batch.max(1) }
    }

    pub fn len(&self) -> usize {
        self.pending.lock().map(|p| p.len()).unwrap_or(0)
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Forget everything. Part of a sync restart.
    pub fn clear(&self) -> Vec<[u8; 32]> {
        let Ok(mut pending) = self.pending.lock() else { return Vec::new() };
        let hashes = pending.values().map(|b| b.request.hash).collect();
        pending.clear();
        hashes
    }

    /// Drop anything at or below a height the chain has already passed.
    pub fn prune_below(&self, height: u64) -> Vec<[u8; 32]> {
        let Ok(mut pending) = self.pending.lock() else { return Vec::new() };
        let stale: Vec<u64> = pending.range(..height).map(|(h, _)| *h).collect();
        stale.iter().filter_map(|h| pending.remove(h)).map(|b| b.request.hash).collect()
    }

    /// Heights inside the current batch window that have not arrived.
    ///
    /// This is the authoritative "what is missing" list: the downloader asks
    /// for exactly these, and the batch cannot be released until the list is
    /// empty. A missing parent therefore cannot persist -- it is, by
    /// construction, always the first entry here and always being requested.
    pub fn missing_heights(&self, next_height: u64) -> Vec<u64> {
        let Ok(pending) = self.pending.lock() else { return Vec::new() };
        (0..self.batch as u64)
            .map(|offset| next_height + offset)
            .filter(|h| !pending.contains_key(h))
            .collect()
    }

    /// Offer an arrival. Returns a batch only once heights
    /// `next_height ..= next_height + batch - 1` are all present.
    ///
    /// A duplicate replaces the stored copy rather than being rejected: both
    /// are the same block by hash.
    pub fn offer(&self, block: RawBlock, next_height: u64) -> Option<Vec<RawBlock>> {
        let mut pending = self.pending.lock().ok()?;
        if block.request.height < next_height {
            return None;
        }
        pending.insert(block.request.height, block);
        Self::take_contiguous(&mut pending, next_height, self.batch)
    }

    /// Store an arrival without releasing anything.
    ///
    /// This is what the intake gate uses: it stores, then drains every batch
    /// that is now complete with `release_ready`. Keeping the two apart is what
    /// lets one arrival complete several consecutive batches.
    ///
    /// Returns false if the block is below the barrier and was not stored; the
    /// caller owns its lifecycle claim and must release it.
    pub fn insert(&self, block: RawBlock, next_height: u64) -> bool {
        let Ok(mut pending) = self.pending.lock() else { return false };
        if block.request.height < next_height {
            return false;
        }
        pending.insert(block.request.height, block);
        true
    }

    /// Remove and return the block held for `height`, if any.
    pub fn take(&self, height: u64) -> Option<RawBlock> {
        let mut pending = self.pending.lock().ok()?;
        pending.remove(&height)
    }

    /// Drop the `count` highest-held blocks and return their hashes.
    ///
    /// A liveness valve, not part of normal operation. Blocks furthest from the
    /// tip are the least useful thing the gate is holding, and dropping them
    /// gives their lifecycle claims back so the height the gate is actually
    /// waiting for can be requested again.
    pub fn drop_highest(&self, count: usize) -> Vec<[u8; 32]> {
        let Ok(mut pending) = self.pending.lock() else { return Vec::new() };
        let victims: Vec<u64> = pending.keys().rev().take(count).copied().collect();
        victims.iter().filter_map(|h| pending.remove(h)).map(|b| b.request.hash).collect()
    }

    /// Release the next complete batch already held, without offering a new
    /// block. One arrival can complete several consecutive batches; this is how
    /// the caller drains the rest.
    pub fn release_ready(&self, next_height: u64) -> Option<Vec<RawBlock>> {
        let mut pending = self.pending.lock().ok()?;
        Self::take_contiguous(&mut pending, next_height, self.batch)
    }

    /// Release a short run. Used at the chain tip, where a full batch will
    /// never arrive because there are no more blocks to fill it.
    pub fn flush_partial(&self, next_height: u64) -> Option<Vec<RawBlock>> {
        let mut pending = self.pending.lock().ok()?;
        let available = Self::contiguous_len(&pending, next_height);
        if available == 0 {
            return None;
        }
        Self::take_contiguous(&mut pending, next_height, available)
    }

    fn contiguous_len(pending: &BTreeMap<u64, RawBlock>, next_height: u64) -> usize {
        let mut count = 0usize;
        let mut height = next_height;
        while pending.contains_key(&height) {
            count += 1;
            height += 1;
        }
        count
    }

    fn take_contiguous(
        pending: &mut BTreeMap<u64, RawBlock>,
        next_height: u64,
        want: usize,
    ) -> Option<Vec<RawBlock>> {
        if want == 0 || Self::contiguous_len(pending, next_height) < want {
            return None;
        }
        let mut batch = Vec::with_capacity(want);
        for offset in 0..want as u64 {
            batch.push(pending.remove(&(next_height + offset))?);
        }
        Some(batch)
    }
}

/// One verifier's slice of a batch.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Slice {
    /// Verifier index, 0-based. Slice `i` always holds lower heights than
    /// slice `i+1`.
    pub verifier: usize,
    pub start: usize,
    pub end: usize,
}

/// Split `len` blocks across `workers` verifiers as contiguous slices.
///
/// The remainder goes to the earliest verifiers, so sizes differ by at most
/// one and the lowest heights are never the ones left waiting.
pub fn split_slices(len: usize, workers: usize) -> Vec<Slice> {
    if len == 0 {
        return Vec::new();
    }
    let workers = workers.max(1).min(len);
    let base = len / workers;
    let extra = len % workers;
    let mut slices = Vec::with_capacity(workers);
    let mut start = 0usize;
    for verifier in 0..workers {
        let size = base + usize::from(verifier < extra);
        if size == 0 {
            continue;
        }
        slices.push(Slice { verifier, start, end: start + size });
        start += size;
    }
    slices
}

/// Result of verifying one batch.
#[derive(Debug, Clone, Copy, Default)]
pub struct SaplingBatchTelemetry {
    /// Number of contiguous blocks represented by the global cryptographic batch.
    pub blocks: u64,
    /// Total deferred Groth16 proofs in the batch.
    pub proofs: u64,
    /// Sapling Spend Groth16 proofs.
    pub spend_proofs: u64,
    /// Sapling Output Groth16 proofs.
    pub output_proofs: u64,
    /// Time spent in the global Sapling proof verifier, including any failure
    /// isolation triggered by a rejected randomized batch.
    pub verify_us: u64,
}

pub struct VerifiedBatch {
    /// Semantically verified blocks, in height order.
    pub blocks: Vec<SemanticBlock>,
    /// The first failure, if any: (height, reason).
    pub rejected: Option<(u64, String)>,
    /// Runtime-only telemetry for the global Sapling proof batch.
    pub sapling: SaplingBatchTelemetry,
}

/// Verify a whole 16-block window: one pool job per block, then one global
/// cryptographic Sapling batch spanning the entire window.
///
/// Every block is its own job on the shared worker pool, so the pool's threads
/// take blocks as they free up and interleave with transparent script checks
/// from the state-preparation stage instead of holding a fixed 4-block slice.
/// Each job queues its block's proofs; the queues are merged in height order
/// and verified once, on the same pool.
pub fn verify_batch_in_order(
    pool: &rayon::ThreadPool,
    active: &AtomicU64,
    blocks: Vec<RawBlock>,
    assume_valid: bool,
) -> VerifiedBatch {
    // A panic inside one block's job is caught and becomes a missing result,
    // which rejects the whole batch below — never a partial batch.
    let per_block: Vec<Option<(Result<SemanticBlock>, ProofBatch)>> = pool.install(|| {
        blocks
            .par_iter()
            .map(|block| {
                let _busy = BusyWorker::enter(active);
                std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                    let mut proofs = ProofBatch::new();
                    let result = verify_into_batch(clone_raw(block), assume_valid, &mut proofs);
                    (result, proofs)
                }))
                .ok()
            })
            .collect()
    });

    if per_block.iter().any(|r| r.is_none()) {
        return VerifiedBatch {
            blocks: Vec::new(),
            rejected: Some((
                blocks.first().map(|b| b.request.height).unwrap_or(0),
                "verifier worker failed before completing the batch".into(),
            )),
            sapling: SaplingBatchTelemetry { blocks: blocks.len() as u64, ..Default::default() },
        };
    }

    // Merge every block's queue in height order before pairing. Tags are
    // rebased by ProofBatch::append(), so a failing proof still maps back to
    // its original transaction for deterministic fallback.
    let mut results: Vec<Result<SemanticBlock>> = Vec::with_capacity(per_block.len());
    let mut proofs = ProofBatch::new();
    for (result, block_proofs) in per_block.into_iter().flatten() {
        results.push(result);
        proofs.append(block_proofs);
    }

    let sapling_blocks = blocks.len() as u64;
    let sapling_proofs = proofs.proofs() as u64;
    let sapling_spends = proofs.spend_proofs() as u64;
    let sapling_outputs = proofs.output_proofs() as u64;
    let mut sapling_verify_us = 0u64;
    if proofs.proofs() > 0 {
        let sapling_started = std::time::Instant::now();
        let finished = {
            let _busy = BusyWorker::enter(active);
            pool.install(|| proofs.finish())
        };
        if let Err((height, reason)) = finished {
            sapling_verify_us = sapling_started.elapsed().as_micros() as u64;
            eprintln!(
                "[VERIFY] global 16-block proof batch rejected at height {height} ({reason:?}); isolating {} blocks",
                blocks.len()
            );
            let singles: Vec<Result<SemanticBlock>> = pool.install(|| {
                blocks
                    .par_iter()
                    .map(|block| {
                        let _busy = BusyWorker::enter(active);
                        std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| verify_single(block, assume_valid)))
                            .unwrap_or_else(|_| Err(anyhow::anyhow!("verifier worker panicked during proof isolation")))
                    })
                    .collect()
            });
            let mut isolated = Vec::with_capacity(blocks.len());
            let mut rejected = None;
            for (index, result) in singles.into_iter().enumerate() {
                match result {
                    Ok(block) => isolated.push(block),
                    Err(e) => {
                        let height = blocks.get(index).map(|b| b.request.height).unwrap_or(0);
                        rejected = Some((height, e.to_string()));
                        break;
                    }
                }
            }
            return VerifiedBatch {
                blocks: isolated,
                rejected,
                sapling: SaplingBatchTelemetry {
                    blocks: sapling_blocks,
                    proofs: sapling_proofs,
                    spend_proofs: sapling_spends,
                    output_proofs: sapling_outputs,
                    verify_us: sapling_verify_us,
                },
            };
        }
        sapling_verify_us = sapling_started.elapsed().as_micros() as u64;
    }

    // Reassemble in exact height order, stopping at the first non-proof
    // consensus rejection.
    let mut out = Vec::with_capacity(results.len());
    let mut rejected = None;
    for (index, result) in results.into_iter().enumerate() {
        match result {
            Ok(block) => out.push(block),
            Err(e) => {
                let height = blocks.get(index).map(|b| b.request.height).unwrap_or(0);
                rejected = Some((height, e.to_string()));
                break;
            }
        }
    }
    VerifiedBatch {
        blocks: out,
        rejected,
        sapling: SaplingBatchTelemetry {
            blocks: sapling_blocks,
            proofs: sapling_proofs,
            spend_proofs: sapling_spends,
            output_proofs: sapling_outputs,
            verify_us: sapling_verify_us,
        },
    }
}

/// Counts one verifier as busy for as long as it is alive. Drop runs on unwind
/// as well, so a panicking slice can never leave the live count stuck high.
struct BusyWorker<'a>(&'a AtomicU64);

impl<'a> BusyWorker<'a> {
    fn enter(counter: &'a AtomicU64) -> Self {
        counter.fetch_add(1, Ordering::Relaxed);
        Self(counter)
    }
}

impl Drop for BusyWorker<'_> {
    fn drop(&mut self) {
        let _ = self.0.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |v| Some(v.saturating_sub(1)));
    }
}

/// Build the cryptographic verifier pool: exactly `workers` named threads,
/// created once for the life of the process, used for verification only.
pub fn build_verifier_pool(workers: usize) -> Result<rayon::ThreadPool> {
    rayon::ThreadPoolBuilder::new()
        .num_threads(workers.max(1))
        .thread_name(|i| format!("yortal-verify-{i}"))
        .build()
        .map_err(|e| anyhow::anyhow!("failed to build verifier pool: {e}"))
}

/// One verifier's work: its slice is prepared in height order and its deferred
/// Groth16 proofs are returned to the coordinator without performing pairing.
#[allow(dead_code)]
fn verify_slice(chunk: &[RawBlock], assume_valid: bool) -> (Vec<Result<SemanticBlock>>, ProofBatch) {
    let mut proofs = ProofBatch::new();
    let mut out: Vec<Result<SemanticBlock>> = Vec::with_capacity(chunk.len());
    for block in chunk {
        out.push(verify_into_batch(clone_raw(block), assume_valid, &mut proofs));
    }
    (out, proofs)
}

fn verify_single(block: &RawBlock, assume_valid: bool) -> Result<SemanticBlock> {
    let mut proofs = ProofBatch::new();
    let verified = verify_into_batch(clone_raw(block), assume_valid, &mut proofs)?;
    if proofs.proofs() > 0 {
        if let Err((height, reason)) = proofs.finish() {
            return Err(anyhow::anyhow!("block {height}: {reason:?}"));
        }
    }
    Ok(verified)
}

fn clone_raw(block: &RawBlock) -> RawBlock {
    RawBlock {
        request: block.request.clone(),
        raw: block.raw.clone(),
        source_peer: block.source_peer.clone(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn slices_are_contiguous_ordered_and_cover_the_batch() {
        for workers in 1..=8 {
            let slices = split_slices(BATCH_BLOCKS, workers);
            assert_eq!(slices[0].start, 0);
            assert_eq!(slices.last().unwrap().end, BATCH_BLOCKS);
            for pair in slices.windows(2) {
                assert_eq!(pair[0].end, pair[1].start);
                assert!(pair[0].verifier < pair[1].verifier);
            }
            let total: usize = slices.iter().map(|s| s.end - s.start).sum();
            assert_eq!(total, BATCH_BLOCKS);
        }
    }

    #[test]
    fn four_verifiers_split_sixteen_evenly() {
        let slices = split_slices(16, 4);
        assert_eq!(slices.len(), 4);
        for slice in &slices {
            assert_eq!(slice.end - slice.start, 4);
        }
    }

    #[test]
    fn a_remainder_goes_to_the_earliest_verifiers() {
        let sizes: Vec<usize> = split_slices(50, 4).iter().map(|s| s.end - s.start).collect();
        assert_eq!(sizes, vec![13, 13, 12, 12]);
    }

    #[test]
    fn assembler_will_not_release_a_batch_while_the_first_parent_is_missing() {
        fn raw(height: u64, hash: u8, prev: u8) -> RawBlock {
            let mut bytes = vec![0u8; 140];
            bytes[4..36].copy_from_slice(&[prev; 32]);
            RawBlock {
                request: crate::downloader::BlockRequest {
                    height,
                    hash: [hash; 32],
                    work: [0u8; 32],
                    median_time_past: 0,
                },
                raw: bytes,
                source_peer: "test".into(),
            }
        }

        let assembler = BatchAssembler::new(2);
        assert!(assembler.offer(raw(2, 2, 1), 1).is_none());
        let batch = assembler.offer(raw(1, 1, 0), 1).expect("parent arrival unlocks the contiguous window");
        assert_eq!(batch.iter().map(|b| b.request.height).collect::<Vec<_>>(), vec![1, 2]);
    }

    #[test]
    fn assembler_drains_consecutive_complete_batches() {
        fn raw(height: u64) -> RawBlock {
            RawBlock {
                request: crate::downloader::BlockRequest {
                    height,
                    hash: [height as u8; 32],
                    work: [0u8; 32],
                    median_time_past: 0,
                },
                raw: vec![0u8; 140],
                source_peer: "test".into(),
            }
        }

        // Batch 2 (heights 17..=32) is complete first; batch 1 completes last.
        let assembler = BatchAssembler::new(BATCH_BLOCKS);
        for height in 17..=(2 * BATCH_BLOCKS as u64) {
            assert!(assembler.offer(raw(height), 1).is_none());
        }
        for height in 2..=BATCH_BLOCKS as u64 {
            assert!(assembler.offer(raw(height), 1).is_none());
        }
        let first = assembler.offer(raw(1), 1).expect("batch 1 is complete");
        assert_eq!(first.len(), BATCH_BLOCKS);
        // Batch 2 is already complete and must be releasable with no new arrival.
        let second = assembler.release_ready(1 + BATCH_BLOCKS as u64).expect("batch 2 is complete");
        assert_eq!(second.first().unwrap().request.height, 1 + BATCH_BLOCKS as u64);
        assert!(assembler.release_ready(1 + 2 * BATCH_BLOCKS as u64).is_none());
        assert!(assembler.take(1).is_none());
    }

    #[test]
    fn assembler_requires_all_sixteen_before_release() {
        fn raw(height: u64) -> RawBlock {
            RawBlock {
                request: crate::downloader::BlockRequest {
                    height,
                    hash: [height as u8; 32],
                    work: [0u8; 32],
                    median_time_past: 0,
                },
                raw: vec![0u8; 140],
                source_peer: "test".into(),
            }
        }

        let assembler = BatchAssembler::new(BATCH_BLOCKS);
        for height in (2..=BATCH_BLOCKS as u64).rev() {
            assert!(assembler.offer(raw(height), 1).is_none());
        }
        let batch = assembler.offer(raw(1), 1).expect("all sixteen arrivals release exactly one batch");
        assert_eq!(batch.len(), BATCH_BLOCKS);
        assert_eq!(batch.first().unwrap().request.height, 1);
        assert_eq!(batch.last().unwrap().request.height, BATCH_BLOCKS as u64);
        assert!(batch.windows(2).all(|w| w[1].request.height == w[0].request.height + 1));
    }

    #[test]
    fn insert_never_releases_until_the_whole_window_is_present() {
        fn raw(height: u64) -> RawBlock {
            RawBlock {
                request: crate::downloader::BlockRequest {
                    height,
                    hash: [height as u8; 32],
                    work: [0u8; 32],
                    median_time_past: 0,
                },
                raw: vec![0u8; 140],
                source_peer: "test".into(),
            }
        }

        // The gate's contract: fifteen of sixteen is nothing at all.
        let assembler = BatchAssembler::new(BATCH_BLOCKS);
        for height in 1..BATCH_BLOCKS as u64 {
            assert!(assembler.insert(raw(height), 1));
            assert!(assembler.release_ready(1).is_none());
        }
        assert_eq!(assembler.missing_heights(1), vec![BATCH_BLOCKS as u64]);
        assert!(assembler.insert(raw(BATCH_BLOCKS as u64), 1));
        let batch = assembler.release_ready(1).expect("the sixteenth arrival completes the batch");
        assert_eq!(batch.len(), BATCH_BLOCKS);
        assert!(batch.windows(2).all(|w| w[1].request.height == w[0].request.height + 1));
        assert!(assembler.is_empty());
        // Below the barrier is not stored; its claim belongs to the caller.
        assert!(!assembler.insert(raw(3), 17));
    }

    #[test]
    fn assembler_does_not_start_from_the_lowest_received_height() {
        fn raw(height: u64) -> RawBlock {
            RawBlock {
                request: crate::downloader::BlockRequest {
                    height,
                    hash: [height as u8; 32],
                    work: [0u8; 32],
                    median_time_past: 0,
                },
                raw: vec![0u8; 140],
                source_peer: "test".into(),
            }
        }

        let assembler = BatchAssembler::new(3);
        assert!(assembler.offer(raw(5), 4).is_none());
        assert_eq!(assembler.len(), 1);
    }
}
