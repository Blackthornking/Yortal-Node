//! Deterministic transport/lifecycle regression for the missing-parent path.
//! This deliberately exercises the same registry used by real peer sessions:
//! peer A owns the exact head, A is considered stalled, the watchdog reassigns
//! to B, and lifecycle ownership remains globally bounded.

use std::time::Duration;
use ycash_node::{HeadPhase, HeadStatus, InFlightRegistry};

#[test]
fn blocked_peer_head_is_reassigned_and_late_delivery_is_safe() {
    let registry = InFlightRegistry::new(8);
    let head = [0x11; 32];
    registry.set_head_target(100, head);
    assert!(registry.claim_head(head, "peer-a", true));
    assert!(matches!(registry.head_status(&head), HeadStatus::Transport { ref owner, .. } if owner == "peer-a"));
    std::thread::sleep(Duration::from_millis(1));
    assert_eq!(registry.steal_stale_head(&head, "peer-b", Duration::ZERO, true), Some("peer-a".into()));
    assert!(matches!(registry.head_status(&head), HeadStatus::Transport { ref owner, .. } if owner == "peer-b"));
    assert!(!registry.adopt_arrival(&head, "peer-a"));
    assert!(registry.mark_verifying(&head));
    assert_eq!(registry.head_tracker().snapshot().unwrap().phase, HeadPhase::Verifying);
    assert!(registry.mark_verified(&head));
    assert!(registry.mark_queued(&head));
    assert_eq!(registry.head_tracker().snapshot().unwrap().phase, HeadPhase::Queued);
    registry.release(&head);
    assert_eq!(registry.head_tracker().snapshot().unwrap().phase, HeadPhase::Free);
}

#[test]
fn free_head_can_be_reserved_without_socket_io() {
    let registry = InFlightRegistry::new(8);
    let head = [0x22; 32];
    registry.set_head_target(101, head);
    assert!(registry.reserve_head(head, "peer-b", true));
    assert!(matches!(registry.head_status(&head), HeadStatus::Reserved { ref owner, .. } if owner == "peer-b"));
    assert!(registry.claim_head(head, "peer-b", true));
    assert!(matches!(registry.head_status(&head), HeadStatus::Transport { ref owner, .. } if owner == "peer-b"));
}
