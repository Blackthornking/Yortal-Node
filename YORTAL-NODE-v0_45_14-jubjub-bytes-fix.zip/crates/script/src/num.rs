//! `CScriptNum` from ycashd 4.5.0 `script/script.h`.

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct ScriptNum(pub i64);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ScriptNumError;

pub const DEFAULT_MAX_NUM_SIZE: usize = 4;

impl ScriptNum {
    pub fn from_bytes(v: &[u8], require_minimal: bool, max_num_size: usize) -> Result<Self, ScriptNumError> {
        if v.len() > max_num_size {
            return Err(ScriptNumError);
        }
        if require_minimal && !v.is_empty() {
            let last = v[v.len() - 1];
            if last & 0x7f == 0 && (v.len() <= 1 || v[v.len() - 2] & 0x80 == 0) {
                return Err(ScriptNumError);
            }
        }
        Ok(ScriptNum(decode(v)))
    }

    pub fn getint(&self) -> i32 {
        if self.0 > i32::MAX as i64 {
            i32::MAX
        } else if self.0 < i32::MIN as i64 {
            i32::MIN
        } else {
            self.0 as i32
        }
    }

    pub fn to_bytes(&self) -> Vec<u8> {
        encode(self.0)
    }
}

fn decode(v: &[u8]) -> i64 {
    if v.is_empty() {
        return 0;
    }
    let mut result: i64 = 0;
    for (i, b) in v.iter().enumerate() {
        result |= (*b as i64) << (8 * i);
    }
    let last = v.len() - 1;
    if v[last] & 0x80 != 0 {
        return -(result & !(0x80i64 << (8 * last)));
    }
    result
}

pub fn encode(value: i64) -> Vec<u8> {
    if value == 0 {
        return Vec::new();
    }
    let neg = value < 0;
    let mut abs = value.unsigned_abs();
    let mut out = Vec::new();
    while abs > 0 {
        out.push((abs & 0xff) as u8);
        abs >>= 8;
    }
    let last = out.len() - 1;
    if out[last] & 0x80 != 0 {
        out.push(if neg { 0x80 } else { 0 });
    } else if neg {
        out[last] |= 0x80;
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn roundtrip() {
        for v in [0i64, 1, -1, 127, 128, -128, 255, 256, -255, 0x7fff_ffff, -0x7fff_ffff, 1 << 32] {
            assert_eq!(decode(&encode(v)), v, "value {v}");
        }
        assert_eq!(encode(-1), vec![0x81]);
        assert_eq!(encode(128), vec![0x80, 0x00]);
        assert!(ScriptNum::from_bytes(&[0x00], true, 4).is_err());
        assert!(ScriptNum::from_bytes(&[0x80, 0x00], true, 4).is_ok());
        assert!(ScriptNum::from_bytes(&[1, 2, 3, 4, 5], false, 4).is_err());
    }
}
