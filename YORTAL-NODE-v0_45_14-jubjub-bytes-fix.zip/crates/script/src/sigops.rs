//! Script classification and signature-operation counting
//! (`CScript::GetSigOpCount`, `IsPayToScriptHash`, `IsPushOnly`,
//! `IsUnspendable`, `GetLegacySigOpCount`).

use crate::opcodes::{self as op, get_op};
use ycash_chain::ParsedTransaction;

pub fn is_pay_to_script_hash(script: &[u8]) -> bool {
    script.len() == 23 && script[0] == op::OP_HASH160 && script[1] == 0x14 && script[22] == op::OP_EQUAL
}

pub fn is_push_only(script: &[u8]) -> bool {
    let mut pc = 0;
    while pc < script.len() {
        match get_op(script, &mut pc) {
            Some((opcode, _)) if opcode <= op::OP_16 => {}
            _ => return false,
        }
    }
    true
}

/// Outputs that can never be spent are not added to the UTXO set.
pub fn is_unspendable(script: &[u8]) -> bool {
    (!script.is_empty() && script[0] == op::OP_RETURN) || script.len() > op::MAX_SCRIPT_SIZE
}

pub fn sig_op_count(script: &[u8], accurate: bool) -> u32 {
    let mut n = 0u32;
    let mut pc = 0;
    let mut last = op::OP_INVALIDOPCODE;
    while pc < script.len() {
        let Some((opcode, _)) = get_op(script, &mut pc) else { break };
        if opcode == op::OP_CHECKSIG || opcode == op::OP_CHECKSIGVERIFY {
            n += 1;
        } else if opcode == op::OP_CHECKMULTISIG || opcode == op::OP_CHECKMULTISIGVERIFY {
            if accurate && (op::OP_1..=op::OP_16).contains(&last) {
                n += (last - (op::OP_1 - 1)) as u32;
            } else {
                n += op::MAX_PUBKEYS_PER_MULTISIG as u32;
            }
        }
        last = opcode;
    }
    n
}

/// `CScript::GetSigOpCount(const CScript& scriptSig)` for a P2SH scriptPubKey.
pub fn p2sh_sig_op_count(script_pubkey: &[u8], script_sig: &[u8]) -> u32 {
    if !is_pay_to_script_hash(script_pubkey) {
        return sig_op_count(script_pubkey, true);
    }
    let mut pc = 0;
    let mut data: &[u8] = &[];
    while pc < script_sig.len() {
        match get_op(script_sig, &mut pc) {
            Some((opcode, push)) if opcode <= op::OP_16 => data = push,
            _ => return 0,
        }
    }
    sig_op_count(data, true)
}

pub fn legacy_sig_op_count(tx: &ParsedTransaction) -> u32 {
    let mut n = 0u32;
    for i in &tx.vin {
        n = n.saturating_add(sig_op_count(&i.script_sig, false));
    }
    for o in &tx.vout {
        n = n.saturating_add(sig_op_count(&o.script_pubkey, false));
    }
    n
}
