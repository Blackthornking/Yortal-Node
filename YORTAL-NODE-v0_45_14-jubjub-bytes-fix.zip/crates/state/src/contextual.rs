//! Contextual consensus validation: the entry point, not the rules.
//!
//! Every contextual rule -- parent linkage, input existence and maturity,
//! value-in/value-out, fees, BIP30, Sprout state, Sapling anchors and
//! nullifiers, tree and frontier updates, chain roots, value-pool accounting,
//! and every height-gated network-upgrade rule -- lives where it already lived,
//! in [`crate::chainstate`] and [`State::prepare_commit_batch`]. The pipeline
//! rewrite deliberately did not touch any of it.
//!
//! This module exists so the boundary is explicit in the code: the verifier
//! calls exactly one function to obtain a prepared state transition, and the
//! canonical publication phase receives only that prepared result.

use anyhow::Result;

use crate::{BlockCommit, PreparedCommit, State};

/// Whether the state needed to contextually validate a block extending
/// `parent` at `height` is present and canonical.
///
/// A child whose parent state is missing waits; it is never validated against
/// the wrong parent.
pub fn parent_state_available(state: &State, parent: &[u8; 32], height: u64) -> Result<bool> {
    if height == 0 {
        return Ok(false);
    }
    if height == 1 {
        return Ok(*parent == ycash_chain::genesis_hash_internal());
    }
    Ok(state.canonical_hash_at(height - 1)? == Some(*parent))
}

/// Run contextual consensus validation for an ancestry-ordered run of blocks
/// and return the prepared state transition. This is a verifier-phase operation;
/// canonical publication must consume the returned plan without revalidation.
///
/// The blocks must be contiguous and in height order, each naming its
/// predecessor. Height-dependent rules are resolved from each block's own
/// height inside the consensus layer, never from the size or shape of this run.
pub fn prepare(state: &State, blocks: &[BlockCommit]) -> Result<PreparedCommit> {
    state.prepare_commit_batch(blocks)
}
