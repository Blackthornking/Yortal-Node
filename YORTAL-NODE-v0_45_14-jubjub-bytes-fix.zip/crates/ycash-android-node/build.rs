fn main() {
    let protoc = protoc_bin_vendored::protoc_bin_path().expect("failed to find vendored protoc");
    std::env::set_var("PROTOC", protoc);
    tonic_build::configure()
        .build_server(true)
        .build_client(false)
        .compile(&["proto/service.proto"], &["proto"])
        .expect("failed to compile lightwallet gRPC proto");
}
