// Ed25519 (joinSplitSig) verification, ZIP-215 rules, via the project's own
// dependency-free `yortal-ed25519` crate. The node only ever verifies, so the
// former key-generation and signing entry points (unused) were removed along
// with the ed25519-zebra dependency.

use libc::{c_uchar, size_t};
use std::slice;

#[no_mangle]
pub extern "C" fn ed25519_verify(
    vk: *const [u8; 32],
    signature: *const [u8; 64],
    msg: *const c_uchar,
    msg_len: size_t,
) -> bool {
    let vk = match unsafe { vk.as_ref() } {
        Some(vk) => vk,
        None => return false,
    };
    let signature = match unsafe { signature.as_ref() } {
        Some(sig) => sig,
        None => return false,
    };
    let msg = if msg_len == 0 { &[][..] } else { unsafe { slice::from_raw_parts(msg, msg_len) } };
    yortal_ed25519::verify(vk, msg, signature).is_ok()
}
