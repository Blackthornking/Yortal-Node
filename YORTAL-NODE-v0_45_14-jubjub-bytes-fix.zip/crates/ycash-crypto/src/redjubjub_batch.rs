//! Project-owned batch verification for Sapling RedJubjub signatures.
//!
//! This is deliberately built on the existing `zcash_primitives::redjubjub`
//! parsing and single-signature verification primitives rather than adding a
//! second RedJubjub dependency. The batch equation is the standard RedDSA
//! randomized equation, with separate accumulated generator terms for the
//! SpendAuth and Binding parameterizations.
//!
//! A batch failure is treated only as a locator hint. The implementation
//! bisects and re-verifies singleton items with the existing RedJubjub
//! `PublicKey::verify` path, so callers get exact failing transaction tags.

use std::convert::TryInto;
use std::sync::atomic::{AtomicU64, Ordering};

use blake2b_simd::Params as Blake2bParams;
use jubjub::Fr;
use rand_core::{OsRng, RngCore};
use zcash_primitives::{
    constants::{SPENDING_KEY_GENERATOR, VALUE_COMMITMENT_RANDOMNESS_GENERATOR},
    redjubjub::{PublicKey, Signature},
};

#[derive(Copy, Clone, Debug, Eq, PartialEq)]
pub(crate) enum RedJubjubKind {
    SpendAuth,
    Binding,
}

#[derive(Clone)]
pub(crate) struct RedJubjubBatchItem {
    kind: RedJubjubKind,
    vk: jubjub::ExtendedPoint,
    sig: [u8; 64],
    msg: [u8; 64],
    r: jubjub::ExtendedPoint,
    s: Fr,
    challenge: Fr,
    tag: u64,
}

impl RedJubjubBatchItem {
    pub(crate) fn new(
        kind: RedJubjubKind,
        vk: jubjub::ExtendedPoint,
        sig_bytes: &[u8; 64],
        msg: &[u8; 64],
    ) -> Result<Self, ()> {
        // Use the pinned RedJubjub parser first so the batch path inherits the
        // same canonical signature encoding rules as the legacy verifier.
        Signature::read(&sig_bytes[..]).map_err(|_| ())?;

        let r_bytes: [u8; 32] = sig_bytes[..32].try_into().map_err(|_| ())?;
        let r_affine = crate::de_ct(jubjub::AffinePoint::from_bytes(r_bytes)).ok_or(())?;
        let r = jubjub::ExtendedPoint::from(r_affine);
        let s_bytes: [u8; 32] = sig_bytes[32..].try_into().map_err(|_| ())?;
        let s = crate::de_ct(Fr::from_bytes(&s_bytes)).ok_or(())?;

        // Sapling signs M = vk || sighash, and RedJubjub's challenge is
        // c = H*(Rbar || M). `msg` already starts with the verification key,
        // so it must not be hashed in a second time.
        let challenge = redjubjub_challenge(&r_bytes, msg);

        Ok(Self {
            kind,
            vk,
            sig: *sig_bytes,
            msg: *msg,
            r,
            s,
            challenge,
            tag: 0,
        })
    }

    pub(crate) fn with_tag(mut self, tag: u64) -> Self {
        self.tag = tag;
        self
    }

    pub(crate) fn kind(&self) -> RedJubjubKind {
        self.kind
    }

    pub(crate) fn tag(&self) -> u64 {
        self.tag
    }

    fn verify_single(&self) -> bool {
        let Ok(sig) = Signature::read(&self.sig[..]) else { return false; };
        let vk = PublicKey(self.vk.clone());
        let generator = match self.kind {
            RedJubjubKind::SpendAuth => SPENDING_KEY_GENERATOR,
            RedJubjubKind::Binding => VALUE_COMMITMENT_RANDOMNESS_GENERATOR,
        };
        vk.verify(&self.msg, &sig, generator)
    }
}

/// Own batch accumulator for Sapling SpendAuthSig and BindingSig verification.
///
/// The accumulator intentionally permits both signature parameterizations in
/// one MSM. They use different RedJubjub generators, so each type gets its own
/// `-sum(z*s)` generator coefficient, while R and verification-key terms share
/// the same Jubjub group MSM.
#[derive(Default)]
pub(crate) struct RedJubjubBatch {
    items: Vec<RedJubjubBatchItem>,
}

static SIGNATURE_BATCHES_RUN: AtomicU64 = AtomicU64::new(0);
static SIGNATURES_BATCHED: AtomicU64 = AtomicU64::new(0);
static SIGNATURE_BATCH_FAILURES: AtomicU64 = AtomicU64::new(0);

impl RedJubjubBatch {
    pub(crate) fn new() -> Self {
        Self::default()
    }

    pub(crate) fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    pub(crate) fn len(&self) -> usize {
        self.items.len()
    }

    pub(crate) fn push(&mut self, item: RedJubjubBatchItem) {
        self.items.push(item);
    }

    pub(crate) fn into_items(self) -> impl Iterator<Item = RedJubjubBatchItem> {
        self.items.into_iter()
    }

    pub(crate) fn append_with_offset(&mut self, mut other: Self, offset: u64) {
        for item in other.items.iter_mut() {
            item.tag = item.tag.saturating_add(offset);
        }
        self.items.extend(other.items);
    }

    /// Verify every queued signature with the original per-signature equation.
    /// This remains the authoritative fallback path when the aggregate path is
    /// rejected or suspected of disagreeing with the legacy verifier.
    pub(crate) fn verify_individual(&self) -> Result<(), Vec<u64>> {
        let mut failed = Vec::new();
        for item in &self.items {
            if !item.verify_single() {
                failed.push(item.tag);
            }
        }
        failed.sort_unstable();
        failed.dedup();
        if failed.is_empty() { Ok(()) } else { Err(failed) }
    }

    /// Returns exact transaction tags owning one or more invalid signatures.
    pub(crate) fn verify(&self) -> Result<(), Vec<u64>> {
        if self.items.is_empty() {
            return Ok(());
        }

        if crate::batch::batching_enabled() == false {
            return self.verify_individual();
        }

        SIGNATURE_BATCHES_RUN.fetch_add(1, Ordering::Relaxed);
        SIGNATURES_BATCHED.fetch_add(self.items.len() as u64, Ordering::Relaxed);

        let refs: Vec<&RedJubjubBatchItem> = self.items.iter().collect();
        if verify_set(&refs) {
            return Ok(());
        }
        SIGNATURE_BATCH_FAILURES.fetch_add(1, Ordering::Relaxed);
        let mut failed = Vec::new();
        isolate_set(&refs, &mut failed);

        if failed.is_empty() {
            // An aggregate failure that cannot be reproduced by singleton
            // checks is a batch-implementation mismatch. Force authoritative
            // re-checking of every owning transaction instead of accepting it.
            let mut tags: Vec<u64> = self.items.iter().map(|item| item.tag()).collect();
            tags.sort_unstable();
            tags.dedup();
            Err(tags)
        } else {
            failed.sort_unstable();
            failed.dedup();
            Err(failed)
        }
    }

    pub(crate) fn stats() -> (u64, u64, u64) {
        (
            SIGNATURE_BATCHES_RUN.load(Ordering::Relaxed),
            SIGNATURES_BATCHED.load(Ordering::Relaxed),
            SIGNATURE_BATCH_FAILURES.load(Ordering::Relaxed),
        )
    }

    pub(crate) fn failed_kind(&self, tags: &[u64]) -> Option<RedJubjubKind> {
        self.items
            .iter()
            .find(|item| tags.contains(&item.tag))
            .map(|item| item.kind())
    }
}

/// c = H*(Rbar || M), exactly as `zcash_primitives::redjubjub::PublicKey::verify`.
fn redjubjub_challenge(r_bytes: &[u8; 32], msg: &[u8; 64]) -> Fr {
    let hash = Blake2bParams::new()
        .hash_length(64)
        .personal(b"Zcash_RedJubjubH")
        .to_state()
        .update(r_bytes)
        .update(msg)
        .finalize();
    Fr::from_bytes_wide(hash.as_array())
}

/// Check the standard randomized RedDSA batch equation using a single MSM.
///
/// For each item i, choose an independent non-zero 128-bit `z_i` and check:
///
/// `h * (-sum(z*s)*P + sum(z*R) + sum(z*c*VK)) == O`.
fn verify_set(items: &[&RedJubjubBatchItem]) -> bool {
    if items.is_empty() {
        return true;
    }
    if items.len() == 1 {
        return items[0].verify_single();
    }

    let mut rng = OsRng;
    let mut spend_s = Fr::from(0u64);
    let mut binding_s = Fr::from(0u64);
    let mut points = Vec::with_capacity(2 + items.len() * 2);
    let mut scalars = Vec::with_capacity(points.capacity());

    for item in items {
        let z = randomizer(&mut rng);
        match item.kind {
            RedJubjubKind::SpendAuth => spend_s += z * item.s,
            RedJubjubKind::Binding => binding_s += z * item.s,
        }
        points.push(item.r.clone());
        scalars.push(z);
        points.push(item.vk.clone());
        scalars.push(z * item.challenge);
    }

    // The two parameterizations have different subgroup generators but share
    // the same Jubjub group, so both fixed-generator terms can participate in
    // the same MSM.
    points.push(SPENDING_KEY_GENERATOR.into());
    scalars.push(-spend_s);
    points.push(VALUE_COMMITMENT_RANDOMNESS_GENERATOR.into());
    scalars.push(-binding_s);

    let check = msm(&points, &scalars).mul_by_cofactor();
    bool::from(check.is_identity())
}

fn isolate_set(items: &[&RedJubjubBatchItem], failed: &mut Vec<u64>) {
    if items.is_empty() {
        return;
    }
    if items.len() == 1 {
        if !items[0].verify_single() {
            failed.push(items[0].tag());
        }
        return;
    }

    if verify_set(items) {
        return;
    }

    let mid = items.len() / 2;
    isolate_set(&items[..mid], failed);
    isolate_set(&items[mid..], failed);
}

fn randomizer(rng: &mut OsRng) -> Fr {
    loop {
        // This samples a scalar uniformly from the non-zero 128-bit range,
        // which is the soundness domain specified for RedDSA batch checking.
        let mut bytes = [0u8; 32];
        rng.fill_bytes(&mut bytes[..16]);
        if bytes[..16].iter().any(|b| *b != 0) {
            return Fr::from_bytes(&bytes).unwrap();
        }
    }
}

/// Variable-base Pippenger MSM over Jubjub. All points/scalars are public
/// verification inputs, so variable-time bucket assignment is acceptable here.
fn msm(points: &[jubjub::ExtendedPoint], scalars: &[Fr]) -> jubjub::ExtendedPoint {
    debug_assert_eq!(points.len(), scalars.len());
    if points.is_empty() {
        return jubjub::ExtendedPoint::identity();
    }

    const WINDOW_BITS: usize = 5;
    const BUCKETS: usize = 1 << WINDOW_BITS;
    const SCALAR_BITS: usize = 252;
    const WINDOWS: usize = (SCALAR_BITS + WINDOW_BITS - 1) / WINDOW_BITS;

    let scalar_bytes: Vec<[u8; 32]> = scalars.iter().map(|s| s.to_bytes()).collect();
    let mut acc = jubjub::ExtendedPoint::identity();

    for window in (0..WINDOWS).rev() {
        if window != WINDOWS - 1 {
            for _ in 0..WINDOW_BITS {
                acc = acc.double();
            }
        }

        let mut buckets = vec![jubjub::ExtendedPoint::identity(); BUCKETS];
        let shift = window * WINDOW_BITS;

        for (point, bytes) in points.iter().zip(scalar_bytes.iter()) {
            let digit = scalar_window(bytes, shift);
            if digit != 0 {
                buckets[digit] += point.clone();
            }
        }

        let mut running = jubjub::ExtendedPoint::identity();
        for bucket in (1..BUCKETS).rev() {
            running += buckets[bucket].clone();
            acc += running.clone();
        }
    }

    acc
}

fn scalar_window(bytes: &[u8; 32], shift: usize) -> usize {
    let mut out = 0usize;
    for bit in 0..5 {
        let bit_index = shift + bit;
        if bit_index < 256 {
            let byte = bit_index / 8;
            let offset = bit_index % 8;
            out |= (((bytes[byte] >> offset) & 1) as usize) << bit;
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_item(kind: RedJubjubKind, secret: Fr, nonce: Fr, msg: [u8; 64], tag: u64) -> RedJubjubBatchItem {
        let generator = match kind {
            RedJubjubKind::SpendAuth => SPENDING_KEY_GENERATOR,
            RedJubjubKind::Binding => VALUE_COMMITMENT_RANDOMNESS_GENERATOR,
        };
        let vk: jubjub::ExtendedPoint = (generator * secret).into();
        let r: jubjub::ExtendedPoint = (generator * nonce).into();
        let r_bytes = jubjub::AffinePoint::from(r).to_bytes();
        let c = redjubjub_challenge(&r_bytes, &msg);
        let s = nonce + c * secret;

        let mut sig = [0u8; 64];
        sig[..32].copy_from_slice(&r_bytes);
        sig[32..].copy_from_slice(&s.to_bytes());

        RedJubjubBatchItem::new(kind, vk, &sig, &msg)
            .unwrap()
            .with_tag(tag)
    }

    #[test]
    fn mixed_spendauth_and_binding_batch_matches_single_verification() {
        let mut msg_a = [0u8; 64];
        let mut msg_b = [0u8; 64];
        msg_a.fill(0x11);
        msg_b.fill(0x22);

        let spend = make_item(RedJubjubKind::SpendAuth, Fr::from(7u64), Fr::from(11u64), msg_a, 3);
        let binding = make_item(RedJubjubKind::Binding, Fr::from(13u64), Fr::from(17u64), msg_b, 4);

        assert!(spend.verify_single());
        assert!(binding.verify_single());

        let refs = vec![&spend, &binding];
        assert!(verify_set(&refs));
    }

    #[test]
    fn a_fully_valid_batch_is_accepted() {
        let mut batch = RedJubjubBatch::new();
        for i in 0..8u64 {
            let mut msg = [0u8; 64];
            msg.fill(i as u8 + 1);
            let kind = if i % 2 == 0 { RedJubjubKind::SpendAuth } else { RedJubjubKind::Binding };
            batch.push(make_item(kind, Fr::from(100 + i), Fr::from(200 + i), msg, i));
        }
        assert_eq!(batch.verify(), Ok(()));
    }

    #[test]
    fn challenge_matches_reference_verifier_for_sapling_message_layout() {
        // M = vk || sighash, as Sapling builds it.
        let secret = Fr::from(41u64);
        let nonce = Fr::from(43u64);
        let vk: jubjub::ExtendedPoint = (SPENDING_KEY_GENERATOR * secret).into();
        let mut msg = [0u8; 64];
        msg[..32].copy_from_slice(&jubjub::AffinePoint::from(vk).to_bytes());
        msg[32..].fill(0x5a);
        let item = make_item(RedJubjubKind::SpendAuth, secret, nonce, msg, 1);
        assert!(item.verify_single());
        let refs = vec![&item, &item];
        assert!(verify_set(&refs));
    }

    #[test]
    fn invalid_item_is_isolated_to_its_transaction_tag() {
        let mut msg_a = [0u8; 64];
        let mut msg_b = [0u8; 64];
        msg_a.fill(0x31);
        msg_b.fill(0x42);

        let good = make_item(RedJubjubKind::Binding, Fr::from(19u64), Fr::from(23u64), msg_a, 9);
        let mut bad = make_item(RedJubjubKind::Binding, Fr::from(29u64), Fr::from(31u64), msg_b, 10);
        bad.msg[0] ^= 1;

        let refs = vec![&good, &bad];
        assert!(!verify_set(&refs));
        let mut failed = Vec::new();
        isolate_set(&refs, &mut failed);
        assert_eq!(failed, vec![10]);
    }

    #[test]
    fn pippenger_matches_direct_scalar_multiplication() {
        let points = vec![
            jubjub::ExtendedPoint::from(SPENDING_KEY_GENERATOR) * Fr::from(3u64),
            jubjub::ExtendedPoint::from(SPENDING_KEY_GENERATOR) * Fr::from(5u64),
            jubjub::ExtendedPoint::from(VALUE_COMMITMENT_RANDOMNESS_GENERATOR) * Fr::from(7u64),
        ];
        let scalars = vec![Fr::from(13u64), Fr::from(17u64), Fr::from(19u64)];
        let mut expected = jubjub::ExtendedPoint::identity();
        for (p, s) in points.iter().zip(scalars.iter()) {
            expected += *p * *s;
        }
        assert_eq!(msm(&points, &scalars), expected);
    }
}
