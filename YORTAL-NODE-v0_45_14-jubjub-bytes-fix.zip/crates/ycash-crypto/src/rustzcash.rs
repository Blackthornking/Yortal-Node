//! Rust cryptographic verification primitives used by the Ycash node.
//!
//! This module is internal to the Ycash node and is not a public API.

// Catch documentation errors caused by code changes.
#![deny(broken_intra_doc_links)]
// Clippy has a default-deny lint to prevent dereferencing raw pointer arguments
// in a non-unsafe function. However, declaring a function as unsafe has the
// side-effect that the entire function body is treated as an unsafe {} block,
// and rustc will not enforce full safety checks on the parts of the function
// that would otherwise be safe.
//
// The functions in this crate are all for FFI usage, so it's obvious to the
// caller (which is only ever zcashd) that the arguments must satisfy the
// necessary assumptions. We therefore ignore this lint to retain the benefit of
// explicitly annotating the parts of each function that must themselves satisfy
// assumptions of underlying code.
//
// See https://github.com/rust-lang/rfcs/pull/2585 for more background.
#![allow(clippy::not_unsafe_ptr_arg_deref)]

// The node build is verify-only. There is no proving stack: Groth16
// verification is implemented locally in `groth16.rs`.
use blake2s_simd::Params as Blake2sParams;
use group::{cofactor::CofactorGroup, GroupEncoding};
use libc::{c_uchar, size_t};
use rand_core::{OsRng, RngCore};
use std::path::Path;
use std::slice;
use std::sync::OnceLock;
use subtle::CtOption;

#[cfg(not(target_os = "windows"))]
use std::ffi::OsStr;
#[cfg(not(target_os = "windows"))]
use std::os::unix::ffi::OsStrExt;

#[cfg(target_os = "windows")]
use std::ffi::OsString;
#[cfg(target_os = "windows")]
use std::os::windows::ffi::OsStringExt;

use zcash_primitives::{
    block::equihash,
    constants::{CRH_IVK_PERSONALIZATION, PROOF_GENERATION_KEY_GENERATOR, SPENDING_KEY_GENERATOR},
    note_encryption::sapling_ka_agree,
    primitives::{Diversifier, Note, Rseed, ViewingKey},
    redjubjub,
    sapling::{merkle_hash, spend_sig},
    zip32,
};

use zcash_history::{Entry as MMREntry, NodeData as MMRNodeData, Tree as MMRTree};

mod blake2b;
mod ed25519;
mod metrics_ffi;
mod redjubjub_batch;
mod tracing_ffi;

#[cfg(test)]
mod tests;

/// Verifying keys parsed with our own reader from the front of the parameter
/// files. Only these verification keys are loaded; no proving vectors are read
/// or retained.
static SAPLING_SPEND_VERIFYING_KEY: OnceLock<groth16::VerifyingKey> = OnceLock::new();
static SAPLING_OUTPUT_VERIFYING_KEY: OnceLock<groth16::VerifyingKey> = OnceLock::new();
static SPROUT_VERIFYING_KEY: OnceLock<groth16::VerifyingKey> = OnceLock::new();

/// Prepared verify-only keys. These contain only the invariant pairing work.
static SAPLING_SPEND_PREPARED_KEY: OnceLock<groth16::PreparedVerifyingKey> = OnceLock::new();
static SAPLING_OUTPUT_PREPARED_KEY: OnceLock<groth16::PreparedVerifyingKey> = OnceLock::new();
static SPROUT_PREPARED_KEY: OnceLock<groth16::PreparedVerifyingKey> = OnceLock::new();

/// The Sapling spend verifying key, if the parameters have been loaded.
pub fn sapling_spend_verifying_key() -> Option<&'static groth16::VerifyingKey> {
    SAPLING_SPEND_VERIFYING_KEY.get()
}

/// The Sapling output verifying key, if the parameters have been loaded.
pub fn sapling_output_verifying_key() -> Option<&'static groth16::VerifyingKey> {
    SAPLING_OUTPUT_VERIFYING_KEY.get()
}

pub fn sapling_spend_prepared_verifying_key() -> Option<&'static groth16::PreparedVerifyingKey> {
    let vk = sapling_spend_verifying_key()?;
    Some(SAPLING_SPEND_PREPARED_KEY.get_or_init(|| groth16::PreparedVerifyingKey::new(vk)))
}

pub fn sapling_output_prepared_verifying_key() -> Option<&'static groth16::PreparedVerifyingKey> {
    let vk = sapling_output_verifying_key()?;
    Some(SAPLING_OUTPUT_PREPARED_KEY.get_or_init(|| groth16::PreparedVerifyingKey::new(vk)))
}

/// Converts CtOption<t> into Option<T>
fn de_ct<T>(ct: CtOption<T>) -> Option<T> {
    if ct.is_some().into() {
        Some(ct.unwrap())
    } else {
        None
    }
}

/// Reads an FsRepr from a [u8; 32]
/// and multiplies it by the given base.
fn fixed_scalar_mult(from: &[u8; 32], p_g: &jubjub::SubgroupPoint) -> jubjub::SubgroupPoint {
    // We only call this with `from` being a valid jubjub::Scalar.
    let f = jubjub::Scalar::from_bytes(from).unwrap();

    p_g * f
}

/// Loads the zk-SNARK parameters into memory and saves paths as necessary.
/// Only called once.
#[no_mangle]
pub extern "C" fn librustzcash_init_zksnark_params(
    #[cfg(not(target_os = "windows"))] spend_path: *const u8,
    #[cfg(target_os = "windows")] spend_path: *const u16,
    spend_path_len: usize,
    #[cfg(not(target_os = "windows"))] output_path: *const u8,
    #[cfg(target_os = "windows")] output_path: *const u16,
    output_path_len: usize,
    #[cfg(not(target_os = "windows"))] sprout_path: *const u8,
    #[cfg(target_os = "windows")] sprout_path: *const u16,
    sprout_path_len: usize,
) {
    #[cfg(not(target_os = "windows"))]
    let (spend_path, output_path, sprout_path) = {
        (
            OsStr::from_bytes(unsafe { slice::from_raw_parts(spend_path, spend_path_len) }),
            OsStr::from_bytes(unsafe { slice::from_raw_parts(output_path, output_path_len) }),
            if sprout_path.is_null() {
                None
            } else {
                Some(OsStr::from_bytes(unsafe {
                    slice::from_raw_parts(sprout_path, sprout_path_len)
                }))
            },
        )
    };

    #[cfg(target_os = "windows")]
    let (spend_path, output_path, sprout_path) = {
        (
            OsString::from_wide(unsafe { slice::from_raw_parts(spend_path, spend_path_len) }),
            OsString::from_wide(unsafe { slice::from_raw_parts(output_path, output_path_len) }),
            if sprout_path.is_null() {
                None
            } else {
                Some(OsString::from_wide(unsafe {
                    slice::from_raw_parts(sprout_path, sprout_path_len)
                }))
            },
        )
    };

    let (spend_path, output_path, sprout_path) = (
        Path::new(&spend_path),
        Path::new(&output_path),
        sprout_path.as_ref().map(|p| Path::new(p)),
    );

    // The node reads only the compact verifying-key prefixes; the full proving
    // vectors in the parameter files are never touched.
    match groth16::read_verifying_key_file(spend_path) {
        Ok(vk) => { let _ = SAPLING_SPEND_VERIFYING_KEY.set(vk); }
        Err(e) => eprintln!("[PARAMS] could not read the Sapling spend verifying key: {e}"),
    }
    match groth16::read_verifying_key_file(output_path) {
        Ok(vk) => { let _ = SAPLING_OUTPUT_VERIFYING_KEY.set(vk); }
        Err(e) => eprintln!("[PARAMS] could not read the Sapling output verifying key: {e}"),
    }
    if let Some(path) = sprout_path {
        match groth16::read_verifying_key_file(path) {
            Ok(vk) => { let _ = SPROUT_VERIFYING_KEY.set(vk); }
            Err(e) => eprintln!("[PARAMS] could not read the Sprout verifying key: {e}"),
        }
    }
}

/// Writes the "uncommitted" note value for empty leaves of the Merkle tree.
///
/// `result` must be a valid pointer to 32 bytes which will be written.
#[no_mangle]
pub extern "C" fn librustzcash_tree_uncommitted(result: *mut [c_uchar; 32]) {
    let tmp = Note::uncommitted().to_bytes();

    // Should be okay, caller is responsible for ensuring the pointer
    // is a valid pointer to 32 bytes that can be mutated.
    let result = unsafe { &mut *result };
    *result = tmp;
}

/// Computes a merkle tree hash for a given depth. The `depth` parameter should
/// not be larger than 62.
///
/// `a` and `b` each must be of length 32, and must each be scalars of BLS12-381.
///
/// The result of the merkle tree hash is placed in `result`, which must also be
/// of length 32.
#[no_mangle]
pub extern "C" fn librustzcash_merkle_hash(
    depth: size_t,
    a: *const [c_uchar; 32],
    b: *const [c_uchar; 32],
    result: *mut [c_uchar; 32],
) {
    // Should be okay, because caller is responsible for ensuring
    // the pointers are valid pointers to 32 bytes.
    let tmp = merkle_hash(depth, unsafe { &*a }, unsafe { &*b });

    // Should be okay, caller is responsible for ensuring the pointer
    // is a valid pointer to 32 bytes that can be mutated.
    let result = unsafe { &mut *result };
    *result = tmp;
}

#[no_mangle] // ToScalar
pub extern "C" fn librustzcash_to_scalar(input: *const [c_uchar; 64], result: *mut [c_uchar; 32]) {
    // Should be okay, because caller is responsible for ensuring
    // the pointer is a valid pointer to 32 bytes, and that is the
    // size of the representation
    let scalar = jubjub::Scalar::from_bytes_wide(unsafe { &*input });

    let result = unsafe { &mut *result };

    *result = scalar.to_bytes();
}

#[no_mangle]
pub extern "C" fn librustzcash_ask_to_ak(ask: *const [c_uchar; 32], result: *mut [c_uchar; 32]) {
    let ask = unsafe { &*ask };
    let ak = fixed_scalar_mult(ask, &SPENDING_KEY_GENERATOR);

    let result = unsafe { &mut *result };

    *result = ak.to_bytes();
}

#[no_mangle]
pub extern "C" fn librustzcash_nsk_to_nk(nsk: *const [c_uchar; 32], result: *mut [c_uchar; 32]) {
    let nsk = unsafe { &*nsk };
    let nk = fixed_scalar_mult(nsk, &PROOF_GENERATION_KEY_GENERATOR);

    let result = unsafe { &mut *result };

    *result = nk.to_bytes();
}

#[no_mangle]
pub extern "C" fn librustzcash_crh_ivk(
    ak: *const [c_uchar; 32],
    nk: *const [c_uchar; 32],
    result: *mut [c_uchar; 32],
) {
    let ak = unsafe { &*ak };
    let nk = unsafe { &*nk };

    let mut h = Blake2sParams::new()
        .hash_length(32)
        .personal(CRH_IVK_PERSONALIZATION)
        .to_state();
    h.update(ak);
    h.update(nk);
    let mut h = h.finalize().as_ref().to_vec();

    // Drop the last five bits, so it can be interpreted as a scalar.
    h[31] &= 0b0000_0111;

    let result = unsafe { &mut *result };

    result.copy_from_slice(&h);
}

#[no_mangle]
pub extern "C" fn librustzcash_check_diversifier(diversifier: *const [c_uchar; 11]) -> bool {
    let diversifier = Diversifier(unsafe { *diversifier });
    diversifier.g_d().is_some()
}

#[no_mangle]
pub extern "C" fn librustzcash_ivk_to_pkd(
    ivk: *const [c_uchar; 32],
    diversifier: *const [c_uchar; 11],
    result: *mut [c_uchar; 32],
) -> bool {
    let ivk = de_ct(jubjub::Scalar::from_bytes(unsafe { &*ivk }));
    let diversifier = Diversifier(unsafe { *diversifier });
    if let (Some(ivk), Some(g_d)) = (ivk, diversifier.g_d()) {
        let pk_d = g_d * ivk;

        let result = unsafe { &mut *result };

        *result = pk_d.to_bytes();

        true
    } else {
        false
    }
}

/// Test generation of commitment randomness
#[test]
fn test_gen_r() {
    let mut r1 = [0u8; 32];
    let mut r2 = [0u8; 32];

    // Verify different r values are generated
    librustzcash_sapling_generate_r(&mut r1);
    librustzcash_sapling_generate_r(&mut r2);
    assert_ne!(r1, r2);

    // Verify r values are valid in the field
    let _ = jubjub::Scalar::from_bytes(&r1).unwrap();
    let _ = jubjub::Scalar::from_bytes(&r2).unwrap();
}

/// Generate uniformly random scalar in Jubjub. The result is of length 32.
#[no_mangle]
pub extern "C" fn librustzcash_sapling_generate_r(result: *mut [c_uchar; 32]) {
    // create random 64 byte buffer
    let mut rng = OsRng;
    let mut buffer = [0u8; 64];
    rng.fill_bytes(&mut buffer);

    // reduce to uniform value
    let r = jubjub::Scalar::from_bytes_wide(&buffer);
    let result = unsafe { &mut *result };
    *result = r.to_bytes();
}

// Private utility function to get Note from C parameters
fn priv_get_note(
    diversifier: *const [c_uchar; 11],
    pk_d: *const [c_uchar; 32],
    value: u64,
    rcm: *const [c_uchar; 32],
) -> Result<Note, ()> {
    let diversifier = Diversifier(unsafe { *diversifier });
    let g_d = diversifier.g_d().ok_or(())?;

    let pk_d = de_ct(jubjub::ExtendedPoint::from_bytes(unsafe { &*pk_d })).ok_or(())?;

    let pk_d = de_ct(pk_d.into_subgroup()).ok_or(())?;

    // Deserialize randomness
    // If this is after ZIP 212, the caller has calculated rcm, and we don't need to call
    // Note::derive_esk, so we just pretend the note was using this rcm all along.
    let rseed = Rseed::BeforeZip212(de_ct(jubjub::Scalar::from_bytes(unsafe { &*rcm })).ok_or(())?);

    let note = Note {
        value,
        g_d,
        pk_d,
        rseed,
    };

    Ok(note)
}

/// Compute a Sapling nullifier.
///
/// The `diversifier` parameter must be 11 bytes in length.
/// The `pk_d`, `r`, `ak` and `nk` parameters must be of length 32.
/// The result is also of length 32 and placed in `result`.
/// Returns false if `diversifier` or `pk_d` is not valid.
#[no_mangle]
pub extern "C" fn librustzcash_sapling_compute_nf(
    diversifier: *const [c_uchar; 11],
    pk_d: *const [c_uchar; 32],
    value: u64,
    rcm: *const [c_uchar; 32],
    ak: *const [c_uchar; 32],
    nk: *const [c_uchar; 32],
    position: u64,
    result: *mut [c_uchar; 32],
) -> bool {
    let note = match priv_get_note(diversifier, pk_d, value, rcm) {
        Ok(p) => p,
        Err(_) => return false,
    };

    let ak = match de_ct(jubjub::ExtendedPoint::from_bytes(unsafe { &*ak })) {
        Some(p) => p,
        None => return false,
    };

    let ak = match de_ct(ak.into_subgroup()) {
        Some(ak) => ak,
        None => return false,
    };

    let nk = match de_ct(jubjub::ExtendedPoint::from_bytes(unsafe { &*nk })) {
        Some(p) => p,
        None => return false,
    };

    let nk = match de_ct(nk.into_subgroup()) {
        Some(nk) => nk,
        None => return false,
    };

    let vk = ViewingKey { ak, nk };
    let nf = note.nf(&vk, position);
    let result = unsafe { &mut *result };
    result.copy_from_slice(&nf.0);

    true
}

/// Compute a Sapling commitment.
///
/// The `diversifier` parameter must be 11 bytes in length.
/// The `pk_d` and `r` parameters must be of length 32.
/// The result is also of length 32 and placed in `result`.
/// Returns false if `diversifier` or `pk_d` is not valid.
#[no_mangle]
pub extern "C" fn librustzcash_sapling_compute_cmu(
    diversifier: *const [c_uchar; 11],
    pk_d: *const [c_uchar; 32],
    value: u64,
    rcm: *const [c_uchar; 32],
    result: *mut [c_uchar; 32],
) -> bool {
    let note = match priv_get_note(diversifier, pk_d, value, rcm) {
        Ok(p) => p,
        Err(_) => return false,
    };

    let result = unsafe { &mut *result };
    *result = note.cmu().to_bytes();

    true
}

/// Computes \[sk\] \[8\] P for some 32-byte point P, and 32-byte Fs.
///
/// If P or sk are invalid, returns false. Otherwise, the result is written to
/// the 32-byte `result` buffer.
#[no_mangle]
pub extern "C" fn librustzcash_sapling_ka_agree(
    p: *const [c_uchar; 32],
    sk: *const [c_uchar; 32],
    result: *mut [c_uchar; 32],
) -> bool {
    // Deserialize p
    let p = match de_ct(jubjub::ExtendedPoint::from_bytes(unsafe { &*p })) {
        Some(p) => p,
        None => return false,
    };

    // Deserialize sk
    let sk = match de_ct(jubjub::Scalar::from_bytes(unsafe { &*sk })) {
        Some(p) => p,
        None => return false,
    };

    // Compute key agreement
    let ka = sapling_ka_agree(&sk, &p);

    // Produce result
    let result = unsafe { &mut *result };
    *result = ka.to_bytes();

    true
}

/// Compute g_d = GH(diversifier) and returns false if the diversifier is
/// invalid. Computes \[esk\] g_d and writes the result to the 32-byte `result`
/// buffer. Returns false if `esk` is not a valid scalar.
#[no_mangle]
pub extern "C" fn librustzcash_sapling_ka_derivepublic(
    diversifier: *const [c_uchar; 11],
    esk: *const [c_uchar; 32],
    result: *mut [c_uchar; 32],
) -> bool {
    let diversifier = Diversifier(unsafe { *diversifier });

    // Compute g_d from the diversifier
    let g_d = match diversifier.g_d() {
        Some(g) => g,
        None => return false,
    };

    // Deserialize esk
    let esk = match de_ct(jubjub::Scalar::from_bytes(unsafe { &*esk })) {
        Some(p) => p,
        None => return false,
    };

    let p = g_d * esk;

    let result = unsafe { &mut *result };
    *result = p.to_bytes();

    true
}

/// Validates the provided Equihash solution against the given parameters, input
/// and nonce.
#[no_mangle]
pub extern "C" fn librustzcash_eh_isvalid(
    n: u32,
    k: u32,
    input: *const c_uchar,
    input_len: size_t,
    nonce: *const c_uchar,
    nonce_len: size_t,
    soln: *const c_uchar,
    soln_len: size_t,
) -> bool {
    if (k >= n) || (n % 8 != 0) || (soln_len != (1 << k) * ((n / (k + 1)) as usize + 1) / 8) {
        return false;
    }
    let rs_input = unsafe { slice::from_raw_parts(input, input_len) };
    let rs_nonce = unsafe { slice::from_raw_parts(nonce, nonce_len) };
    let rs_soln = unsafe { slice::from_raw_parts(soln, soln_len) };
    equihash::is_valid_solution(n, k, rs_input, rs_nonce, rs_soln).is_ok()
}

/// Creates a Sapling verification context. Please free this when you're done.
#[no_mangle]
pub extern "C" fn librustzcash_sapling_verification_ctx_init() -> *mut verify::SaplingVerificationContext {
    if !sapling_params_loaded() { return std::ptr::null_mut(); }
    let ctx = Box::new(verify::SaplingVerificationContext::new());

    Box::into_raw(ctx)
}

/// Frees a Sapling verification context returned from
/// [`librustzcash_sapling_verification_ctx_init`].
#[no_mangle]
pub extern "C" fn librustzcash_sapling_verification_ctx_free(ctx: *mut verify::SaplingVerificationContext) {
    drop(unsafe { Box::from_raw(ctx) });
}

const GROTH_PROOF_SIZE: usize = 48 // π_A
    + 96 // π_B
    + 48; // π_C

/// Check the validity of a Sapling Spend description, accumulating the value
/// commitment into the verify-only context. Groth16 pairing is deferred until
/// `librustzcash_sapling_final_check` so callers can batch proofs.
#[no_mangle]
pub extern "C" fn librustzcash_sapling_check_spend(
    ctx: *mut verify::SaplingVerificationContext,
    cv: *const [c_uchar; 32],
    anchor: *const [c_uchar; 32],
    nullifier: *const [c_uchar; 32],
    rk: *const [c_uchar; 32],
    zkproof: *const [c_uchar; GROTH_PROOF_SIZE],
    spend_auth_sig: *const [c_uchar; 64],
    sighash_value: *const [c_uchar; 32],
) -> bool {
    if ctx.is_null()
        || cv.is_null()
        || anchor.is_null()
        || nullifier.is_null()
        || rk.is_null()
        || zkproof.is_null()
        || spend_auth_sig.is_null()
        || sighash_value.is_null()
    {
        return false;
    }
    unsafe {
        (&mut *ctx).check_spend(
            &*cv,
            &*anchor,
            &*nullifier,
            &*rk,
            &*zkproof,
            &*spend_auth_sig,
            &*sighash_value,
        )
    }
}

/// Check the validity of a Sapling Output description, accumulating the value
/// commitment into the verify-only context. Groth16 pairing is deferred.
#[no_mangle]
pub extern "C" fn librustzcash_sapling_check_output(
    ctx: *mut verify::SaplingVerificationContext,
    cv: *const [c_uchar; 32],
    cm: *const [c_uchar; 32],
    epk: *const [c_uchar; 32],
    zkproof: *const [c_uchar; GROTH_PROOF_SIZE],
) -> bool {
    if ctx.is_null() || cv.is_null() || cm.is_null() || epk.is_null() || zkproof.is_null() {
        return false;
    }
    unsafe { (&mut *ctx).check_output(&*cv, &*cm, &*epk, &*zkproof) }
}

/// Finally checks the validity of the entire Sapling transaction given
/// valueBalance and the binding signature. Pairings are performed only after
/// the transaction-level non-pairing checks have passed.
#[no_mangle]
pub extern "C" fn librustzcash_sapling_final_check(
    ctx: *mut verify::SaplingVerificationContext,
    value_balance: i64,
    binding_sig: *const [c_uchar; 64],
    sighash_value: *const [c_uchar; 32],
) -> bool {
    if ctx.is_null() || binding_sig.is_null() || sighash_value.is_null() {
        return false;
    }
    unsafe { (&mut *ctx).final_check(value_balance, &*binding_sig, &*sighash_value) }
}

/// Sprout JoinSplit proof verification using the verify-only Groth16 core.
#[no_mangle]
pub extern "C" fn librustzcash_sprout_verify(
    proof: *const [c_uchar; GROTH_PROOF_SIZE],
    rt: *const [c_uchar; 32],
    h_sig: *const [c_uchar; 32],
    mac1: *const [c_uchar; 32],
    mac2: *const [c_uchar; 32],
    nf1: *const [c_uchar; 32],
    nf2: *const [c_uchar; 32],
    cm1: *const [c_uchar; 32],
    cm2: *const [c_uchar; 32],
    vpub_old: u64,
    vpub_new: u64,
) -> bool {
    let (proof, rt, h_sig, mac1, mac2, nf1, nf2, cm1, cm2) = unsafe { (
        &*proof, &*rt, &*h_sig, &*mac1, &*mac2, &*nf1, &*nf2, &*cm1, &*cm2,
    ) };
    let mut public_input = Vec::with_capacity((32 * 8) + 16);
    public_input.extend_from_slice(rt);
    public_input.extend_from_slice(h_sig);
    public_input.extend_from_slice(nf1);
    public_input.extend_from_slice(mac1);
    public_input.extend_from_slice(nf2);
    public_input.extend_from_slice(mac2);
    public_input.extend_from_slice(cm1);
    public_input.extend_from_slice(cm2);
    public_input.extend_from_slice(&vpub_old.to_le_bytes());
    public_input.extend_from_slice(&vpub_new.to_le_bytes());
    let proof = match groth16::Proof::read(proof) { Ok(p) => p, Err(_) => return false };
    let inputs = match groth16::bytes_to_multipacking(&public_input) { Ok(v) => v, Err(_) => return false };
    let Some(vk) = SPROUT_VERIFYING_KEY.get() else { return false };
    let pvk = SPROUT_PREPARED_KEY.get_or_init(|| groth16::PreparedVerifyingKey::new(vk));
    pvk.verify(&proof, &inputs).is_ok()
}

/// Computes the signature for each Spend description, given the key `ask`, the
/// re-randomization `ar`, the 32-byte sighash `sighash`, and an output `result`
/// buffer of 64-bytes for the signature.
///
/// This function will fail if the provided `ask` or `ar` are invalid.
#[no_mangle]
pub extern "C" fn librustzcash_sapling_spend_sig(
    ask: *const [c_uchar; 32],
    ar: *const [c_uchar; 32],
    sighash: *const [c_uchar; 32],
    result: *mut [c_uchar; 64],
) -> bool {
    // The caller provides the re-randomization of `ak`.
    let ar = match de_ct(jubjub::Scalar::from_bytes(unsafe { &*ar })) {
        Some(p) => p,
        None => return false,
    };

    // The caller provides `ask`, the spend authorizing key.
    let ask = match redjubjub::PrivateKey::read(&(unsafe { &*ask })[..]) {
        Ok(p) => p,
        Err(_) => return false,
    };

    // Initialize secure RNG
    let mut rng = OsRng;

    // Do the signing
    let sig = spend_sig(ask, ar, unsafe { &*sighash }, &mut rng);

    // Write out the signature
    sig.write(&mut (unsafe { &mut *result })[..])
        .expect("result should be 64 bytes");

    true
}

/// Derive the master ExtendedSpendingKey from a seed.
#[no_mangle]
pub extern "C" fn librustzcash_zip32_xsk_master(
    seed: *const c_uchar,
    seedlen: size_t,
    xsk_master: *mut [c_uchar; 169],
) {
    let seed = unsafe { std::slice::from_raw_parts(seed, seedlen) };

    let xsk = zip32::ExtendedSpendingKey::master(seed);

    xsk.write(&mut (unsafe { &mut *xsk_master })[..])
        .expect("should be able to serialize an ExtendedSpendingKey");
}

/// Derive a child ExtendedSpendingKey from a parent.
#[no_mangle]
pub extern "C" fn librustzcash_zip32_xsk_derive(
    xsk_parent: *const [c_uchar; 169],
    i: u32,
    xsk_i: *mut [c_uchar; 169],
) {
    let xsk_parent = zip32::ExtendedSpendingKey::read(&unsafe { *xsk_parent }[..])
        .expect("valid ExtendedSpendingKey");
    let i = zip32::ChildIndex::from_index(i);

    let xsk = xsk_parent.derive_child(i);

    xsk.write(&mut (unsafe { &mut *xsk_i })[..])
        .expect("should be able to serialize an ExtendedSpendingKey");
}

/// Derive a child ExtendedFullViewingKey from a parent.
#[no_mangle]
pub extern "C" fn librustzcash_zip32_xfvk_derive(
    xfvk_parent: *const [c_uchar; 169],
    i: u32,
    xfvk_i: *mut [c_uchar; 169],
) -> bool {
    let xfvk_parent = zip32::ExtendedFullViewingKey::read(&unsafe { *xfvk_parent }[..])
        .expect("valid ExtendedFullViewingKey");
    let i = zip32::ChildIndex::from_index(i);

    let xfvk = match xfvk_parent.derive_child(i) {
        Ok(xfvk) => xfvk,
        Err(_) => return false,
    };

    xfvk.write(&mut (unsafe { &mut *xfvk_i })[..])
        .expect("should be able to serialize an ExtendedFullViewingKey");

    true
}

/// Derive a PaymentAddress from an ExtendedFullViewingKey.
#[no_mangle]
pub extern "C" fn librustzcash_zip32_xfvk_address(
    xfvk: *const [c_uchar; 169],
    j: *const [c_uchar; 11],
    j_ret: *mut [c_uchar; 11],
    addr_ret: *mut [c_uchar; 43],
) -> bool {
    let xfvk = zip32::ExtendedFullViewingKey::read(&unsafe { *xfvk }[..])
        .expect("valid ExtendedFullViewingKey");
    let j = zip32::DiversifierIndex(unsafe { *j });

    let addr = match xfvk.address(j) {
        Ok(addr) => addr,
        Err(_) => return false,
    };

    let j_ret = unsafe { &mut *j_ret };
    let addr_ret = unsafe { &mut *addr_ret };

    j_ret.copy_from_slice(&(addr.0).0);
    addr_ret.copy_from_slice(&addr.1.to_bytes());

    true
}

fn construct_mmr_tree(
    // Consensus branch id
    cbranch: u32,
    // Length of tree in array representation
    t_len: u32,

    // Indices of provided tree nodes, length of p_len+e_len
    ni_ptr: *const u32,
    // Provided tree nodes data, length of p_len+e_len
    n_ptr: *const [c_uchar; zcash_history::MAX_ENTRY_SIZE],

    // Peaks count
    p_len: size_t,
    // Extra nodes loaded (for deletion) count
    e_len: size_t,
) -> Result<MMRTree, &'static str> {
    let (indices, nodes) = unsafe {
        (
            slice::from_raw_parts(ni_ptr, p_len + e_len),
            slice::from_raw_parts(n_ptr, p_len + e_len),
        )
    };

    let mut peaks: Vec<_> = indices
        .iter()
        .zip(nodes.iter())
        .map(
            |(index, node)| match MMREntry::from_bytes(cbranch, &node[..]) {
                Ok(entry) => Ok((*index, entry)),
                Err(_) => Err("Invalid encoding"),
            },
        )
        .collect::<Result<_, _>>()?;
    let extra = peaks.split_off(p_len);

    Ok(MMRTree::new(t_len, peaks, extra))
}

#[no_mangle]
pub extern "system" fn librustzcash_mmr_append(
    // Consensus branch id
    cbranch: u32,
    // Length of tree in array representation
    t_len: u32,
    // Indices of provided tree nodes, length of p_len
    ni_ptr: *const u32,
    // Provided tree nodes data, length of p_len
    n_ptr: *const [c_uchar; zcash_history::MAX_ENTRY_SIZE],
    // Peaks count
    p_len: size_t,
    // New node pointer
    nn_ptr: *const [u8; zcash_history::MAX_NODE_DATA_SIZE],
    // Return of root commitment
    rt_ret: *mut [u8; 32],
    // Return buffer for appended leaves, should be pre-allocated of ceiling(log2(t_len)) length
    buf_ret: *mut [c_uchar; zcash_history::MAX_NODE_DATA_SIZE],
) -> u32 {
    let new_node_bytes: &[u8; zcash_history::MAX_NODE_DATA_SIZE] = unsafe {
        match nn_ptr.as_ref() {
            Some(r) => r,
            None => {
                return 0;
            } // Null pointer passed, error
        }
    };

    let mut tree = match construct_mmr_tree(cbranch, t_len, ni_ptr, n_ptr, p_len, 0) {
        Ok(t) => t,
        _ => {
            return 0;
        } // error
    };

    let node = match MMRNodeData::from_bytes(cbranch, &new_node_bytes[..]) {
        Ok(node) => node,
        _ => {
            return 0;
        } // error
    };

    let appended = match tree.append_leaf(node) {
        Ok(appended) => appended,
        _ => {
            return 0;
        }
    };

    let return_count = appended.len();

    let root_node = tree
        .root_node()
        .expect("Just added, should resolve always; qed");
    unsafe {
        *rt_ret = root_node.data().hash();

        for (idx, next_buf) in slice::from_raw_parts_mut(buf_ret, return_count as usize)
            .iter_mut()
            .enumerate()
        {
            tree.resolve_link(appended[idx])
                .expect("This was generated by the tree and thus resolvable; qed")
                .data()
                .write(&mut &mut next_buf[..])
                .expect("Write using cursor with enough buffer size cannot fail; qed");
        }
    }

    return_count as u32
}

#[no_mangle]
pub extern "system" fn librustzcash_mmr_delete(
    // Consensus branch id
    cbranch: u32,
    // Length of tree in array representation
    t_len: u32,
    // Indices of provided tree nodes, length of p_len+e_len
    ni_ptr: *const u32,
    // Provided tree nodes data, length of p_len+e_len
    n_ptr: *const [c_uchar; zcash_history::MAX_ENTRY_SIZE],
    // Peaks count
    p_len: size_t,
    // Extra nodes loaded (for deletion) count
    e_len: size_t,
    // Return of root commitment
    rt_ret: *mut [u8; 32],
) -> u32 {
    let mut tree = match construct_mmr_tree(cbranch, t_len, ni_ptr, n_ptr, p_len, e_len) {
        Ok(t) => t,
        _ => {
            return 0;
        } // error
    };

    let truncate_len = match tree.truncate_leaf() {
        Ok(v) => v,
        _ => {
            return 0;
        } // Error
    };

    unsafe {
        *rt_ret = tree
            .root_node()
            .expect("Just generated without errors, root should be resolving")
            .data()
            .hash();
    }

    truncate_len
}

#[no_mangle]
pub extern "system" fn librustzcash_mmr_hash_node(
    cbranch: u32,
    n_ptr: *const [u8; zcash_history::MAX_NODE_DATA_SIZE],
    h_ret: *mut [u8; 32],
) -> u32 {
    let node_bytes: &[u8; zcash_history::MAX_NODE_DATA_SIZE] = unsafe {
        match n_ptr.as_ref() {
            Some(r) => r,
            None => return 1,
        }
    };

    let node = match MMRNodeData::from_bytes(cbranch, &node_bytes[..]) {
        Ok(n) => n,
        _ => return 1, // error
    };

    unsafe {
        *h_ret = node.hash();
    }

    0
}

#[no_mangle]
pub extern "C" fn librustzcash_getrandom(buf: *mut u8, buf_len: usize) {
    let buf = unsafe { slice::from_raw_parts_mut(buf, buf_len) };
    OsRng.fill_bytes(buf);
}

mod verify;
pub use verify::{init_zksnark_params, ProofError, SaplingVerifier};

/// Verify-only Groth16 core used by the node.
pub mod groth16;
pub use groth16::{validate_chain_links, ChainLink, ChainLinkError};

mod batch;
pub use batch::{batch_stats, batching_enabled, disable_batching, redjubjub_batch_stats, SaplingBatch, SaplingBatchTx};

/// Compute a Sapling Merkle parent using the exact librustzcash Sapling
/// personalization/domain separation. This is exposed to the node state
/// engine so consensus state does not need any wallet/viewing keys.
pub fn sapling_merkle_hash(depth: usize, a: [u8;32], b: [u8;32]) -> [u8;32] {
    merkle_hash(depth, &a, &b)
}

/// Exact Sapling uncommitted leaf used by the consensus tree.
pub fn sapling_uncommitted_leaf() -> [u8;32] {
    let mut out = [0u8; 32];
    unsafe { librustzcash_tree_uncommitted(&mut out); }
    out
}

/// True once `init_zksnark_params` has loaded the Sapling verifying keys.
/// Sapling verification must not be attempted before this: the underlying
/// librustzcash calls `expect()` on the keys and would abort the process.
pub fn sapling_params_loaded() -> bool {
    sapling_spend_verifying_key().is_some() && sapling_output_verifying_key().is_some()
}

/// True once the Sprout Groth16 verifying key has been loaded.
pub fn sprout_params_loaded() -> bool {
    SPROUT_VERIFYING_KEY.get().is_some()
}

/// Safe wrapper for Sprout (post-Sapling, Groth16) JoinSplit proof
/// verification. Returns false if the Sprout parameters are not loaded.
pub fn sprout_verify(
    proof: &[u8; 192],
    rt: &[u8; 32],
    h_sig: &[u8; 32],
    mac1: &[u8; 32],
    mac2: &[u8; 32],
    nf1: &[u8; 32],
    nf2: &[u8; 32],
    cm1: &[u8; 32],
    cm2: &[u8; 32],
    vpub_old: u64,
    vpub_new: u64,
) -> bool {
    if !sprout_params_loaded() { return false; }
    librustzcash_sprout_verify(
        proof, rt, h_sig, mac1, mac2, nf1, nf2, cm1, cm2, vpub_old, vpub_new,
    )
}

/// Ed25519 verification with the ZIP 215 rules ycashd uses for
/// `joinSplitSig` (project-owned, dependency-free `yortal-ed25519`).
pub fn ed25519_verify_zip215(vk: &[u8; 32], sig: &[u8; 64], msg: &[u8]) -> bool {
    ed25519::ed25519_verify(vk, sig, msg.as_ptr(), msg.len())
}

/// Batch verifier for `joinSplitSig`: all Ed25519 signatures of a 16-block
/// window checked with one combined equation (see `yortal-ed25519`).
pub use yortal_ed25519::BatchVerifier as Ed25519BatchVerifier;
