# yortal-ed25519 (v0.4.0)

Ed25519 signature verification for YORTAL with **no dependencies**: only the
Rust standard library. SHA-512, arithmetic mod 2^255-19, arithmetic mod the
group order, Edwards point arithmetic and the batch equation are all in this
crate; batch randomness comes from `/dev/urandom`.

Rules: ZIP-215 (non-canonical A/R accepted, S < l required, hash over the
bytes as received, cofactored equation). Single `verify` is the consensus
rule; `BatchVerifier` checks many signatures with one combined equation
(random 128-bit weights, repeated keys merged) and pins down exactly which
ones are invalid by bisection to single checks.

Not included from v0.3.0: the HEEA path (it rejected about half of all valid
signatures and needed an external big-integer crate) and the adaptive batch
sizer (the node always batches per 16 blocks).

Verification only; never handles secret keys. Variable-time on public data.

Tests: `cargo test -p yortal-ed25519` — 38 vectors (12 ZIP-215 edge cases,
2 RFC 8032, 24 generated incl. repeated keys and 3 invalid), SHA-512 KATs,
batch/bisection/tag checks.
