//! Arithmetic modulo p = 2^255 - 19 in five 51-bit limbs.
//!
//! Every operation leaves limbs below 2^52, so a product of two limbs fits
//! comfortably in u128 even after the multiply-by-19 folding.

const MASK: u64 = (1u64 << 51) - 1;

/// 16 * p, limb by limb. Added before subtracting so limbs never go negative.
const SIXTEEN_P0: u64 = 36_028_797_018_963_664; // 16 * (2^51 - 19)
const SIXTEEN_PI: u64 = 36_028_797_018_963_952; // 16 * (2^51 - 1)

#[derive(Clone, Copy, Debug)]
pub(crate) struct Fe(pub(crate) [u64; 5]);

fn load8(b: &[u8; 32], i: usize) -> u64 {
    let mut x = [0u8; 8];
    x.copy_from_slice(&b[i..i + 8]);
    u64::from_le_bytes(x)
}

fn carry(mut l: [u64; 5]) -> Fe {
    let c = l[0] >> 51;
    l[0] &= MASK;
    l[1] += c;
    let c = l[1] >> 51;
    l[1] &= MASK;
    l[2] += c;
    let c = l[2] >> 51;
    l[2] &= MASK;
    l[3] += c;
    let c = l[3] >> 51;
    l[3] &= MASK;
    l[4] += c;
    let c = l[4] >> 51;
    l[4] &= MASK;
    l[0] += c * 19;
    Fe(l)
}

#[inline]
fn m(x: u64, y: u64) -> u128 {
    (x as u128) * (y as u128)
}

impl Fe {
    pub(crate) const ZERO: Fe = Fe([0, 0, 0, 0, 0]);
    pub(crate) const ONE: Fe = Fe([1, 0, 0, 0, 0]);

    /// Load 255 bits, little-endian; bit 255 is ignored. Values >= p are
    /// accepted unchanged (ZIP-215 accepts non-canonical encodings) and are
    /// reduced by later arithmetic.
    pub(crate) fn from_bytes(b: &[u8; 32]) -> Fe {
        let w0 = load8(b, 0);
        let w1 = load8(b, 8);
        let w2 = load8(b, 16);
        let w3 = load8(b, 24);
        Fe([
            w0 & MASK,
            ((w0 >> 51) | (w1 << 13)) & MASK,
            ((w1 >> 38) | (w2 << 26)) & MASK,
            ((w2 >> 25) | (w3 << 39)) & MASK,
            (w3 >> 12) & MASK,
        ])
    }

    /// Canonical 32-byte encoding (fully reduced below p).
    pub(crate) fn to_bytes(&self) -> [u8; 32] {
        let mut l = carry(carry(self.0).0).0;
        // q = 1 exactly when the value is >= p.
        let mut q = (l[0] + 19) >> 51;
        q = (l[1] + q) >> 51;
        q = (l[2] + q) >> 51;
        q = (l[3] + q) >> 51;
        q = (l[4] + q) >> 51;
        l[0] += 19 * q;
        l[1] += l[0] >> 51;
        l[0] &= MASK;
        l[2] += l[1] >> 51;
        l[1] &= MASK;
        l[3] += l[2] >> 51;
        l[2] &= MASK;
        l[4] += l[3] >> 51;
        l[3] &= MASK;
        l[4] &= MASK;
        let w = [
            l[0] | (l[1] << 51),
            (l[1] >> 13) | (l[2] << 38),
            (l[2] >> 26) | (l[3] << 25),
            (l[3] >> 39) | (l[4] << 12),
        ];
        let mut out = [0u8; 32];
        for i in 0..4 {
            out[i * 8..i * 8 + 8].copy_from_slice(&w[i].to_le_bytes());
        }
        out
    }

    pub(crate) fn add(&self, o: &Fe) -> Fe {
        let a = self.0;
        let b = o.0;
        carry([a[0] + b[0], a[1] + b[1], a[2] + b[2], a[3] + b[3], a[4] + b[4]])
    }

    pub(crate) fn sub(&self, o: &Fe) -> Fe {
        let a = self.0;
        let b = o.0;
        carry([
            a[0] + SIXTEEN_P0 - b[0],
            a[1] + SIXTEEN_PI - b[1],
            a[2] + SIXTEEN_PI - b[2],
            a[3] + SIXTEEN_PI - b[3],
            a[4] + SIXTEEN_PI - b[4],
        ])
    }

    pub(crate) fn neg(&self) -> Fe {
        Fe::ZERO.sub(self)
    }

    pub(crate) fn mul(&self, o: &Fe) -> Fe {
        let a = self.0;
        let b = o.0;
        let b1_19 = b[1] * 19;
        let b2_19 = b[2] * 19;
        let b3_19 = b[3] * 19;
        let b4_19 = b[4] * 19;
        let c0 = m(a[0], b[0]) + m(a[1], b4_19) + m(a[2], b3_19) + m(a[3], b2_19) + m(a[4], b1_19);
        let c1 = m(a[0], b[1]) + m(a[1], b[0]) + m(a[2], b4_19) + m(a[3], b3_19) + m(a[4], b2_19);
        let c2 = m(a[0], b[2]) + m(a[1], b[1]) + m(a[2], b[0]) + m(a[3], b4_19) + m(a[4], b3_19);
        let c3 = m(a[0], b[3]) + m(a[1], b[2]) + m(a[2], b[1]) + m(a[3], b[0]) + m(a[4], b4_19);
        let c4 = m(a[0], b[4]) + m(a[1], b[3]) + m(a[2], b[2]) + m(a[3], b[1]) + m(a[4], b[0]);

        let c1 = c1 + (c0 >> 51);
        let r0 = (c0 as u64) & MASK;
        let c2 = c2 + (c1 >> 51);
        let r1 = (c1 as u64) & MASK;
        let c3 = c3 + (c2 >> 51);
        let r2 = (c2 as u64) & MASK;
        let c4 = c4 + (c3 >> 51);
        let r3 = (c3 as u64) & MASK;
        let top = c4 >> 51;
        let r4 = (c4 as u64) & MASK;
        let r0 = (r0 as u128) + top * 19;
        let r1 = r1 + (r0 >> 51) as u64;
        let r0 = (r0 as u64) & MASK;
        Fe([r0, r1, r2, r3, r4])
    }

    pub(crate) fn square(&self) -> Fe {
        self.mul(self)
    }

    /// self^e for a little-endian 256-bit exponent (public exponents only).
    pub(crate) fn pow(&self, e: &[u8; 32]) -> Fe {
        let mut r = Fe::ONE;
        for i in (0..256).rev() {
            r = r.square();
            if (e[i / 8] >> (i % 8)) & 1 == 1 {
                r = r.mul(self);
            }
        }
        r
    }

    pub(crate) fn equals(&self, o: &Fe) -> bool {
        self.to_bytes() == o.to_bytes()
    }

    pub(crate) fn is_zero(&self) -> bool {
        self.to_bytes() == [0u8; 32]
    }

    /// "Negative" in the Ed25519 sense: the canonical value is odd.
    pub(crate) fn is_negative(&self) -> bool {
        self.to_bytes()[0] & 1 == 1
    }
}

/// d = -121665 / 121666
pub(crate) const D_BYTES: [u8; 32] = [
    0xa3, 0x78, 0x59, 0x13, 0xca, 0x4d, 0xeb, 0x75, 0xab, 0xd8, 0x41, 0x41, 0x4d, 0x0a, 0x70, 0x00,
    0x98, 0xe8, 0x79, 0x77, 0x79, 0x40, 0xc7, 0x8c, 0x73, 0xfe, 0x6f, 0x2b, 0xee, 0x6c, 0x03, 0x52,
];
/// 2 * d
pub(crate) const D2_BYTES: [u8; 32] = [
    0x59, 0xf1, 0xb2, 0x26, 0x94, 0x9b, 0xd6, 0xeb, 0x56, 0xb1, 0x83, 0x82, 0x9a, 0x14, 0xe0, 0x00,
    0x30, 0xd1, 0xf3, 0xee, 0xf2, 0x80, 0x8e, 0x19, 0xe7, 0xfc, 0xdf, 0x56, 0xdc, 0xd9, 0x06, 0x24,
];
/// sqrt(-1)
pub(crate) const SQRT_M1_BYTES: [u8; 32] = [
    0xb0, 0xa0, 0x0e, 0x4a, 0x27, 0x1b, 0xee, 0xc4, 0x78, 0xe4, 0x2f, 0xad, 0x06, 0x18, 0x43, 0x2f,
    0xa7, 0xd7, 0xfb, 0x3d, 0x99, 0x00, 0x4d, 0x2b, 0x0b, 0xdf, 0xc1, 0x4f, 0x80, 0x24, 0x83, 0x2b,
];
/// (p - 5) / 8
pub(crate) const P58_BYTES: [u8; 32] = [
    0xfd, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x0f,
];
