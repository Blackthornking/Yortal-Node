//! Dependency-free ZIP-215 Ed25519 signature verification for YORTAL.
//!
//! Uses only the Rust standard library: its own SHA-512, field arithmetic
//! modulo 2^255-19, scalar arithmetic modulo the group order, Edwards point
//! arithmetic, and randomness read from the operating system (`/dev/urandom`).
//! It verifies public data only and never handles secret keys.
//!
//! ZIP-215 rules (Zcash consensus for Ed25519 since Canopy):
//! * A and R may use non-canonical encodings and are decoded as given;
//! * S must be canonical (S < l);
//! * k = SHA-512(R_bytes || A_bytes || M) mod l, over the bytes as received;
//! * the check is cofactored: [8]([S]B - R - [k]A) = 0.
//!
//! Batch verification is the Zcash protocol's procedure: independent random
//! z_i in 1..2^128-1 and a single combined check
//! [8]( -[sum z_i S_i]B + sum [z_i]R_i + sum [z_i k_i]A_i ) = 0,
//! with the A terms of repeated keys merged. Single verification is the
//! consensus rule; a failed batch is resolved to exact items by bisection
//! down to single checks.

mod field;
mod point;
mod scalar;
mod sha512;

use point::Point;
use scalar::Scalar;
use std::collections::HashMap;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum VerifyError {
    BadPublicKey,
    BadSignatureR,
    NonCanonicalS,
    EquationFailure,
    RandomnessFailure,
}

impl std::fmt::Display for VerifyError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{self:?}")
    }
}

impl std::error::Error for VerifyError {}

/// SHA-512 of the concatenation of `parts` (exposed for tests and tooling).
pub fn sha512(parts: &[&[u8]]) -> [u8; 64] {
    sha512::sha512(parts)
}

struct Prepared {
    key: [u8; 32],
    a: Point,
    r: Point,
    s: Scalar,
    k: Scalar,
}

fn prepare(public_key: &[u8; 32], message: &[u8], signature: &[u8; 64]) -> Result<Prepared, VerifyError> {
    let a = Point::decompress(public_key).ok_or(VerifyError::BadPublicKey)?;
    let mut r_bytes = [0u8; 32];
    r_bytes.copy_from_slice(&signature[..32]);
    let r = Point::decompress(&r_bytes).ok_or(VerifyError::BadSignatureR)?;
    let mut s_bytes = [0u8; 32];
    s_bytes.copy_from_slice(&signature[32..]);
    let s = Scalar::from_canonical_bytes(&s_bytes).ok_or(VerifyError::NonCanonicalS)?;
    let k = Scalar::from_bytes_wide(&sha512::sha512(&[&r_bytes, public_key, message]));
    Ok(Prepared { key: *public_key, a, r, s, k })
}

fn check_single(p: &Prepared) -> Result<(), VerifyError> {
    // [8]([S]B + [k](-A) + (-R)) = 0
    let q = Point::multiscalar(
        &[p.s, p.k, Scalar::ONE],
        &[Point::basepoint(), p.a.neg(), p.r.neg()],
    );
    if q.mul_by_cofactor().is_identity() {
        Ok(())
    } else {
        Err(VerifyError::EquationFailure)
    }
}

/// Verify one signature under ZIP-215. This is the consensus rule.
pub fn verify(public_key: &[u8; 32], message: &[u8], signature: &[u8; 64]) -> Result<(), VerifyError> {
    check_single(&prepare(public_key, message, signature)?)
}

/// Source of batch coefficients: the operating system's CSPRNG.
struct OsRandom(std::fs::File);

impl OsRandom {
    fn open() -> Result<Self, VerifyError> {
        std::fs::File::open("/dev/urandom").map(OsRandom).map_err(|_| VerifyError::RandomnessFailure)
    }

    /// Uniform in 1..2^128-1, independent of the batch contents.
    fn coefficient(&mut self) -> Result<Scalar, VerifyError> {
        use std::io::Read;
        loop {
            let mut b = [0u8; 16];
            self.0.read_exact(&mut b).map_err(|_| VerifyError::RandomnessFailure)?;
            let v = u128::from_le_bytes(b);
            if v != 0 {
                return Ok(Scalar::from_u128(v));
            }
        }
    }
}

/// One combined check over already-decoded items.
fn check_batch(items: &[&Prepared], rng: &mut OsRandom) -> Result<bool, VerifyError> {
    if items.is_empty() {
        return Ok(true);
    }
    if items.len() == 1 {
        return Ok(check_single(items[0]).is_ok());
    }
    let mut b_coeff = Scalar::ZERO;
    let mut scalars = Vec::with_capacity(items.len() * 2 + 1);
    let mut points = Vec::with_capacity(items.len() * 2 + 1);
    let mut key_index: HashMap<[u8; 32], usize> = HashMap::with_capacity(items.len());
    let mut key_terms: Vec<(Point, Scalar)> = Vec::with_capacity(items.len());

    for p in items {
        let z = rng.coefficient()?;
        b_coeff = b_coeff.add(&z.mul(&p.s));
        scalars.push(z);
        points.push(p.r);
        let zk = z.mul(&p.k);
        match key_index.get(&p.key) {
            Some(&i) => key_terms[i].1 = key_terms[i].1.add(&zk),
            None => {
                key_index.insert(p.key, key_terms.len());
                key_terms.push((p.a, zk));
            }
        }
    }
    scalars.push(b_coeff);
    points.push(Point::basepoint().neg());
    for (a, c) in key_terms {
        if !c.is_zero() {
            scalars.push(c);
            points.push(a);
        }
    }
    Ok(Point::multiscalar(&scalars, &points).mul_by_cofactor().is_identity())
}

#[derive(Clone, Copy)]
pub struct SignatureInput<'a> {
    pub public_key: &'a [u8; 32],
    pub message: &'a [u8],
    pub signature: &'a [u8; 64],
}

/// Verify a set of signatures with one combined check. Ok only if every
/// signature is valid.
pub fn verify_batch(items: &[SignatureInput<'_>]) -> Result<(), VerifyError> {
    let prepared = items
        .iter()
        .map(|i| prepare(i.public_key, i.message, i.signature))
        .collect::<Result<Vec<_>, _>>()?;
    let refs: Vec<&Prepared> = prepared.iter().collect();
    let mut rng = OsRandom::open()?;
    if check_batch(&refs, &mut rng)? {
        Ok(())
    } else {
        Err(VerifyError::EquationFailure)
    }
}

/// Indices of the invalid signatures in `items` (empty if all are valid).
pub fn find_invalid(items: &[SignatureInput<'_>]) -> Vec<usize> {
    let mut batch = BatchVerifier::new();
    for (i, it) in items.iter().enumerate() {
        batch.queue(*it.public_key, *it.signature, it.message.to_vec(), i as u64);
    }
    match batch.verify() {
        Ok(()) => Vec::new(),
        Err(tags) => tags.into_iter().map(|t| t as usize).collect(),
    }
}

struct Queued {
    public_key: [u8; 32],
    signature: [u8; 64],
    message: Vec<u8>,
    tag: u64,
}

/// Accumulates signatures, each labelled with a caller tag, and verifies them
/// together. Used by the node to check every Ed25519 signature of a 16-block
/// batch at once.
#[derive(Default)]
pub struct BatchVerifier {
    items: Vec<Queued>,
}

impl BatchVerifier {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn len(&self) -> usize {
        self.items.len()
    }

    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    pub fn queue(&mut self, public_key: [u8; 32], signature: [u8; 64], message: Vec<u8>, tag: u64) {
        self.items.push(Queued { public_key, signature, message, tag });
    }

    /// Merge another batch, adding `offset` to each of its tags.
    pub fn append_with_offset(&mut self, other: BatchVerifier, offset: u64) {
        for mut q in other.items {
            q.tag = q.tag.saturating_add(offset);
            self.items.push(q);
        }
    }

    /// Ok if every queued signature is valid; otherwise the sorted, de-duplicated
    /// tags of exactly the invalid ones, each confirmed by a single check.
    pub fn verify(&self) -> Result<(), Vec<u64>> {
        let mut bad = Vec::new();
        let mut prepared: Vec<(u64, Prepared)> = Vec::with_capacity(self.items.len());
        for q in &self.items {
            match prepare(&q.public_key, &q.message, &q.signature) {
                Ok(p) => prepared.push((q.tag, p)),
                Err(_) => bad.push(q.tag),
            }
        }

        let refs: Vec<(u64, &Prepared)> = prepared.iter().map(|(t, p)| (*t, p)).collect();
        match OsRandom::open() {
            Ok(mut rng) => isolate(&refs, &mut rng, &mut bad),
            // Without randomness the batch equation is not sound: fall back to
            // checking every signature on its own.
            Err(_) => {
                for (tag, p) in &refs {
                    if check_single(p).is_err() {
                        bad.push(*tag);
                    }
                }
            }
        }

        if bad.is_empty() {
            Ok(())
        } else {
            bad.sort_unstable();
            bad.dedup();
            Err(bad)
        }
    }
}

fn isolate(items: &[(u64, &Prepared)], rng: &mut OsRandom, bad: &mut Vec<u64>) {
    if items.is_empty() {
        return;
    }
    if items.len() == 1 {
        if check_single(items[0].1).is_err() {
            bad.push(items[0].0);
        }
        return;
    }
    let refs: Vec<&Prepared> = items.iter().map(|(_, p)| *p).collect();
    match check_batch(&refs, rng) {
        Ok(true) => {}
        Ok(false) => {
            let mid = items.len() / 2;
            isolate(&items[..mid], rng, bad);
            isolate(&items[mid..], rng, bad);
        }
        Err(_) => {
            for (tag, p) in items {
                if check_single(p).is_err() {
                    bad.push(*tag);
                }
            }
        }
    }
}
