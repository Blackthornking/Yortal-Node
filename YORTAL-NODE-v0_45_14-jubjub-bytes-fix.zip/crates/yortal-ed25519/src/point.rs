//! Edwards25519 points in extended coordinates (X:Y:Z:T), x = X/Z, y = Y/Z,
//! T = XY/Z, on -x^2 + y^2 = 1 + d x^2 y^2.

use crate::field::{Fe, D2_BYTES, D_BYTES, P58_BYTES, SQRT_M1_BYTES};
use crate::scalar::Scalar;

/// Standard encoding of the Ed25519 base point.
const BASEPOINT_BYTES: [u8; 32] = [
    0x58, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66,
    0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66,
];

#[derive(Clone, Copy, Debug)]
pub(crate) struct Point {
    x: Fe,
    y: Fe,
    z: Fe,
    t: Fe,
}

impl Point {
    pub(crate) fn identity() -> Point {
        Point { x: Fe::ZERO, y: Fe::ONE, z: Fe::ONE, t: Fe::ZERO }
    }

    pub(crate) fn basepoint() -> Point {
        Point::decompress(&BASEPOINT_BYTES).expect("base point encoding is valid")
    }

    /// ZIP-215 decoding: the y coordinate may be non-canonical (>= p), and a
    /// set sign bit with x = 0 is accepted. Rejected only when no x exists.
    pub(crate) fn decompress(b: &[u8; 32]) -> Option<Point> {
        let y = Fe::from_bytes(b);
        let sign = b[31] >> 7;
        let d = Fe::from_bytes(&D_BYTES);
        let yy = y.square();
        let u = yy.sub(&Fe::ONE);
        let v = d.mul(&yy).add(&Fe::ONE);

        // x = u v^3 (u v^7)^((p-5)/8)
        let v3 = v.square().mul(&v);
        let v7 = v3.square().mul(&v);
        let mut x = u.mul(&v3).mul(&u.mul(&v7).pow(&P58_BYTES));

        let vxx = v.mul(&x.square());
        if vxx.equals(&u) {
            // x is a root
        } else if vxx.equals(&u.neg()) {
            x = x.mul(&Fe::from_bytes(&SQRT_M1_BYTES));
        } else {
            return None;
        }
        // Take the non-negative root, then apply the sign bit.
        if x.is_negative() {
            x = x.neg();
        }
        if sign == 1 {
            x = x.neg();
        }
        let t = x.mul(&y);
        Some(Point { x, y, z: Fe::ONE, t })
    }

    /// Unified addition (add-2008-hwcd-3); also correct for doubling.
    pub(crate) fn add(&self, o: &Point) -> Point {
        let a = self.y.sub(&self.x).mul(&o.y.sub(&o.x));
        let b = self.y.add(&self.x).mul(&o.y.add(&o.x));
        let c = self.t.mul(&Fe::from_bytes(&D2_BYTES)).mul(&o.t);
        let d = self.z.add(&self.z).mul(&o.z);
        let e = b.sub(&a);
        let f = d.sub(&c);
        let g = d.add(&c);
        let h = b.add(&a);
        Point { x: e.mul(&f), y: g.mul(&h), z: f.mul(&g), t: e.mul(&h) }
    }

    pub(crate) fn double(&self) -> Point {
        self.add(self)
    }

    pub(crate) fn neg(&self) -> Point {
        Point { x: self.x.neg(), y: self.y, z: self.z, t: self.t.neg() }
    }

    pub(crate) fn mul_by_cofactor(&self) -> Point {
        self.double().double().double()
    }

    pub(crate) fn is_identity(&self) -> bool {
        self.x.is_zero() && self.y.equals(&self.z)
    }

    /// sum(scalars[i] * points[i]) by interleaved double-and-add. Variable
    /// time; only ever used on public verification data.
    pub(crate) fn multiscalar(scalars: &[Scalar], points: &[Point]) -> Point {
        debug_assert_eq!(scalars.len(), points.len());
        let mut acc = Point::identity();
        for bit in (0..253).rev() {
            acc = acc.double();
            for (s, p) in scalars.iter().zip(points.iter()) {
                if s.bit(bit) {
                    acc = acc.add(p);
                }
            }
        }
        acc
    }
}
