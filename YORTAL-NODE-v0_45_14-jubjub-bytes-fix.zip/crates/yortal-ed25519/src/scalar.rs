//! Integers modulo the group order l = 2^252 + 27742317777372353535851937790883648493.
//!
//! Only public values are handled here (verification), so a simple, obviously
//! correct bit-serial reduction is used instead of Barrett/Montgomery tricks.

/// l, little-endian 64-bit limbs.
const L: [u64; 4] = [0x5812_631a_5cf5_d3ed, 0x14de_f9de_a2f7_9cd6, 0, 0x1000_0000_0000_0000];

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Scalar(pub(crate) [u64; 4]);

fn geq(a: &[u64; 4], b: &[u64; 4]) -> bool {
    for i in (0..4).rev() {
        if a[i] != b[i] {
            return a[i] > b[i];
        }
    }
    true
}

fn sub_in_place(a: &mut [u64; 4], b: &[u64; 4]) {
    let mut borrow = 0u64;
    for i in 0..4 {
        let (d1, b1) = a[i].overflowing_sub(b[i]);
        let (d2, b2) = d1.overflowing_sub(borrow);
        a[i] = d2;
        borrow = (b1 | b2) as u64;
    }
}

/// Reduce a little-endian integer of any byte length modulo l, bit by bit.
fn reduce_bytes(bytes: &[u8]) -> [u64; 4] {
    let mut r = [0u64; 4];
    for i in (0..bytes.len() * 8).rev() {
        let bit = ((bytes[i / 8] >> (i % 8)) & 1) as u64;
        // r < l < 2^253, so 2r + 1 < 2^254 cannot overflow 256 bits.
        r[3] = (r[3] << 1) | (r[2] >> 63);
        r[2] = (r[2] << 1) | (r[1] >> 63);
        r[1] = (r[1] << 1) | (r[0] >> 63);
        r[0] = (r[0] << 1) | bit;
        if geq(&r, &L) {
            sub_in_place(&mut r, &L);
        }
    }
    r
}

impl Scalar {
    pub(crate) const ZERO: Scalar = Scalar([0, 0, 0, 0]);
    pub(crate) const ONE: Scalar = Scalar([1, 0, 0, 0]);

    /// A 512-bit hash output reduced modulo l.
    pub(crate) fn from_bytes_wide(b: &[u8; 64]) -> Scalar {
        Scalar(reduce_bytes(b))
    }

    /// Accept only canonical encodings (value < l), as ZIP-215 requires for S.
    pub(crate) fn from_canonical_bytes(b: &[u8; 32]) -> Option<Scalar> {
        let mut limbs = [0u64; 4];
        for i in 0..4 {
            let mut x = [0u8; 8];
            x.copy_from_slice(&b[i * 8..i * 8 + 8]);
            limbs[i] = u64::from_le_bytes(x);
        }
        if geq(&limbs, &L) {
            None
        } else {
            Some(Scalar(limbs))
        }
    }

    pub(crate) fn from_u128(v: u128) -> Scalar {
        // v < 2^128 < l, already reduced.
        Scalar([v as u64, (v >> 64) as u64, 0, 0])
    }

    pub(crate) fn add(&self, o: &Scalar) -> Scalar {
        let mut r = [0u64; 4];
        let mut c = 0u64;
        for i in 0..4 {
            let (s1, c1) = self.0[i].overflowing_add(o.0[i]);
            let (s2, c2) = s1.overflowing_add(c);
            r[i] = s2;
            c = (c1 | c2) as u64;
        }
        // Both inputs < l < 2^253, so the sum < 2^254: no carry out.
        if geq(&r, &L) {
            sub_in_place(&mut r, &L);
        }
        Scalar(r)
    }

    pub(crate) fn mul(&self, o: &Scalar) -> Scalar {
        let mut w = [0u64; 8];
        for i in 0..4 {
            let mut carry: u128 = 0;
            for j in 0..4 {
                let t = (self.0[i] as u128) * (o.0[j] as u128) + (w[i + j] as u128) + carry;
                w[i + j] = t as u64;
                carry = t >> 64;
            }
            w[i + 4] = carry as u64;
        }
        let mut bytes = [0u8; 64];
        for i in 0..8 {
            bytes[i * 8..i * 8 + 8].copy_from_slice(&w[i].to_le_bytes());
        }
        Scalar(reduce_bytes(&bytes))
    }

    pub(crate) fn is_zero(&self) -> bool {
        self.0 == [0, 0, 0, 0]
    }

    #[inline]
    pub(crate) fn bit(&self, i: usize) -> bool {
        (self.0[i / 64] >> (i % 64)) & 1 == 1
    }
}
