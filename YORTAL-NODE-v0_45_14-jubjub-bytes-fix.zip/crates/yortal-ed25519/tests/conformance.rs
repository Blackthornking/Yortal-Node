//! Known-answer tests. Every vector in `vectors.txt` was produced or checked
//! by an independent implementation of the ZIP-215 rules; no external crate
//! is used here either.
//!
//! Line format: `public_key message signature expected kind`
//! (hex; message `-` means empty; expected 1 = valid, 0 = invalid).

use yortal_ed25519::{find_invalid, sha512, verify, verify_batch, BatchVerifier, SignatureInput};

struct Vector {
    pk: [u8; 32],
    msg: Vec<u8>,
    sig: [u8; 64],
    valid: bool,
    kind: String,
}

fn hex(s: &str) -> Vec<u8> {
    if s == "-" {
        return Vec::new();
    }
    (0..s.len() / 2).map(|i| u8::from_str_radix(&s[2 * i..2 * i + 2], 16).unwrap()).collect()
}

fn vectors() -> Vec<Vector> {
    include_str!("vectors.txt")
        .lines()
        .filter(|l| !l.trim().is_empty())
        .map(|l| {
            let f: Vec<&str> = l.split_whitespace().collect();
            Vector {
                pk: hex(f[0]).try_into().unwrap(),
                msg: hex(f[1]),
                sig: hex(f[2]).try_into().unwrap(),
                valid: f[3] == "1",
                kind: f[4].to_string(),
            }
        })
        .collect()
}

fn to_hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{x:02x}")).collect()
}

#[test]
fn sha512_known_answers() {
    assert_eq!(
        to_hex(&sha512(&[b""])),
        "cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e"
    );
    assert_eq!(
        to_hex(&sha512(&[b"abc"])),
        "ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a2192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f"
    );
    let a200 = [b'a'; 200];
    assert_eq!(
        to_hex(&sha512(&[&a200[..77], &a200[77..]])),
        "4b11459c33f52a22ee8236782714c150a3b2c60994e9acee17fe68947a3e6789f31e7668394592da7bef827cddca88c4e6f86e4df7ed1ae6cba71f3e98faee9f"
    );
}

#[test]
fn every_vector_verifies_as_expected() {
    let v = vectors();
    assert_eq!(v.len(), 38);
    for (i, t) in v.iter().enumerate() {
        assert_eq!(verify(&t.pk, &t.msg, &t.sig).is_ok(), t.valid, "vector {i} ({})", t.kind);
    }
}

#[test]
fn batch_reports_exactly_the_invalid_signatures() {
    let v = vectors();
    let mut batch = BatchVerifier::new();
    for (i, t) in v.iter().enumerate() {
        batch.queue(t.pk, t.sig, t.msg.clone(), i as u64);
    }
    let expected: Vec<u64> = v.iter().enumerate().filter(|(_, t)| !t.valid).map(|(i, _)| i as u64).collect();
    assert_eq!(batch.verify(), Err(expected.clone()));

    let inputs: Vec<SignatureInput<'_>> = v
        .iter()
        .map(|t| SignatureInput { public_key: &t.pk, message: &t.msg, signature: &t.sig })
        .collect();
    let found: Vec<u64> = find_invalid(&inputs).into_iter().map(|i| i as u64).collect();
    assert_eq!(found, expected);
}

#[test]
fn all_valid_signatures_pass_as_one_batch() {
    // Includes the ZIP-215 edge cases (small-order and mixed-order points,
    // non-canonical encodings) and repeated keys, which are merged.
    let v: Vec<Vector> = vectors().into_iter().filter(|t| t.valid).collect();
    let mut batch = BatchVerifier::new();
    for (i, t) in v.iter().enumerate() {
        batch.queue(t.pk, t.sig, t.msg.clone(), i as u64);
    }
    assert_eq!(batch.verify(), Ok(()));
    let inputs: Vec<SignatureInput<'_>> = v
        .iter()
        .map(|t| SignatureInput { public_key: &t.pk, message: &t.msg, signature: &t.sig })
        .collect();
    assert!(verify_batch(&inputs).is_ok());
}

#[test]
fn appended_batches_keep_their_tags() {
    let v = vectors();
    let mut first = BatchVerifier::new();
    let mut second = BatchVerifier::new();
    for (i, t) in v.iter().enumerate() {
        if i < 20 {
            first.queue(t.pk, t.sig, t.msg.clone(), i as u64);
        } else {
            second.queue(t.pk, t.sig, t.msg.clone(), (i - 20) as u64);
        }
    }
    first.append_with_offset(second, 20);
    let expected: Vec<u64> = v.iter().enumerate().filter(|(_, t)| !t.valid).map(|(i, _)| i as u64).collect();
    assert_eq!(first.verify(), Err(expected));
}

#[test]
fn empty_batch_is_ok() {
    assert_eq!(BatchVerifier::new().verify(), Ok(()));
    assert!(verify_batch(&[]).is_ok());
}
