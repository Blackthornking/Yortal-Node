#!/usr/bin/env bash
# Build the Rust Android node for arm64-v8a and package it into the Android app.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

command -v cargo >/dev/null 2>&1 || { echo "ERROR: cargo is required" >&2; exit 1; }
command -v rustup >/dev/null 2>&1 || { echo "ERROR: rustup is required" >&2; exit 1; }

TARGET="aarch64-linux-android"
API="${ANDROID_API_LEVEL:-35}"
ABI="arm64-v8a"

# The workflow installs the target with dtolnay/rust-toolchain. Do not blindly
# run `rustup target add` here: on CI that can force an unnecessary network
# operation and fail the build before Cargo emits any useful diagnostics.
INSTALLED_TARGETS="$(rustup target list --installed)"
if ! grep -Fxq "$TARGET" <<< "$INSTALLED_TARGETS"; then
  echo "ERROR: Rust target $TARGET is not installed." >&2
  echo "Installed targets:" >&2
  rustup target list --installed >&2 || true
  exit 1
fi

# Locate the NDK from the standard environment variables or Android SDK layout.
NDK="${ANDROID_NDK_ROOT:-${ANDROID_NDK_HOME:-}}"
if [[ -z "$NDK" && -n "${ANDROID_HOME:-}" && -d "$ANDROID_HOME/ndk" ]]; then
  NDK="$(find "$ANDROID_HOME/ndk" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -1)"
fi
if [[ -z "$NDK" && -n "${ANDROID_SDK_ROOT:-}" && -d "$ANDROID_SDK_ROOT/ndk" ]]; then
  NDK="$(find "$ANDROID_SDK_ROOT/ndk" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -1)"
fi
[[ -n "$NDK" && -d "$NDK" ]] || {
  echo "ERROR: Android NDK not found. Set ANDROID_NDK_ROOT or ANDROID_NDK_HOME." >&2
  exit 1
}

HOST_TAG="linux-x86_64"
if [[ "$(uname -s)" == "Darwin" ]]; then HOST_TAG="darwin-x86_64"; fi
if [[ "$(uname -m)" == "arm64" && "$HOST_TAG" == "darwin-x86_64" && -d "$NDK/toolchains/llvm/prebuilt/darwin-aarch64" ]]; then
  HOST_TAG="darwin-aarch64"
fi
CLANG="$NDK/toolchains/llvm/prebuilt/$HOST_TAG/bin/aarch64-linux-android${API}-clang"
[[ -x "$CLANG" ]] || { echo "ERROR: Android clang not found: $CLANG" >&2; exit 1; }

TOOLCHAIN="$NDK/toolchains/llvm/prebuilt/$HOST_TAG"
SYSROOT="$TOOLCHAIN/sysroot"
[[ -d "$SYSROOT" ]] || { echo "ERROR: NDK sysroot not found: $SYSROOT" >&2; exit 1; }

export CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER="$CLANG"
export CC_aarch64_linux_android="$CLANG"
export CXX_aarch64_linux_android="${CLANG%clang}clang++"
export AR_aarch64_linux_android="$TOOLCHAIN/bin/llvm-ar"
export RANLIB_aarch64_linux_android="$TOOLCHAIN/bin/llvm-ranlib"

# ---------------------------------------------------------------------------
# RocksDB (librocksdb-sys) cross-compilation
# ---------------------------------------------------------------------------
# The state backend is RocksDB, which is C++ compiled from source by the `cc`
# crate and bound by `bindgen`. Three things are needed that a pure-Rust build
# never required:
#
#   1. libclang on the *host*, for bindgen (apt: libclang-dev / clang).
#   2. A sysroot + target triple for bindgen, or it parses RocksDB's headers
#      against the host libc and emits wrong or missing bindings.
#   3. A statically linked libc++. Android's NDK links libc++_shared.so by
#      default; the node is a standalone executable packaged as
#      jniLibs/arm64-v8a/libycashandroidnode.so, so a second shared library
#      would have to be shipped and found at runtime. Static avoids that.
if ! ls /usr/lib/llvm-*/lib/libclang.so* >/dev/null 2>&1 \
   && [[ -z "${LIBCLANG_PATH:-}" ]] \
   && ! command -v clang >/dev/null 2>&1; then
  echo "ERROR: libclang is required to build RocksDB bindings (bindgen)." >&2
  echo "       Install it (Debian/Ubuntu: apt-get install -y clang libclang-dev)" >&2
  echo "       or set LIBCLANG_PATH to the directory containing libclang.so." >&2
  exit 1
fi

export BINDGEN_EXTRA_CLANG_ARGS="--target=aarch64-linux-android${API} --sysroot=$SYSROOT"
# Do not let the cc crate append -lc++_shared; libc++ is linked statically
# below instead.
export CXXSTDLIB=""
export CXXFLAGS_aarch64_linux_android="${CXXFLAGS_aarch64_linux_android:-} -O2 -fPIC -DOS_ANDROID -DROCKSDB_PLATFORM_POSIX -DROCKSDB_LIB_IO_POSIX -Wno-unused-parameter"
export CFLAGS_aarch64_linux_android="${CFLAGS_aarch64_linux_android:-} -O2 -fPIC"
# rustc links with -nodefaultlibs, so the clang driver adds no C++ runtime of
# its own and -static-libstdc++ does nothing. librocksdb-sys also emits a bare
# `-lstdc++` for every target whose triple contains "linux", which on Android
# resolves to a stub that defines none of libc++'s symbols -- hence the
# undefined std::__ndk1::* references at link time. Name the NDK's C++ runtime
# explicitly, and put it AFTER everything that needs it: LLD resolves static
# archives in command-line order, so these have to come last, with libunwind
# after libc++abi for the exception-handling symbols libc++abi itself pulls in.
export CARGO_TARGET_AARCH64_LINUX_ANDROID_RUSTFLAGS="${CARGO_TARGET_AARCH64_LINUX_ANDROID_RUSTFLAGS:-} -C link-arg=-lc++_static -C link-arg=-lc++abi -C link-arg=-lunwind -C link-arg=-Wl,--build-id=none"
# RocksDB is a large C++ build; give it every core once, not per-crate.
export CARGO_BUILD_JOBS="${CARGO_BUILD_JOBS:-$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 4)}"

echo "Building ycash-android-node for $TARGET (API $API) with the RocksDB state backend..."
echo "First build compiles RocksDB from source; expect several minutes."
if ! cargo build --release -p ycash-android-node --target "$TARGET"; then
  echo "ERROR: Cargo failed while building ycash-android-node for $TARGET." >&2
  echo "Rust: $(rustc --version)" >&2
  echo "Cargo: $(cargo --version)" >&2
  echo "Target: $TARGET" >&2
  echo "NDK: $NDK" >&2
  exit 1
fi

BINARY="$ROOT/target/$TARGET/release/ycash-android-node"
BINARY="$BINARY" "$ROOT/tools/package-node-binary.sh"

echo "Android ARM64 native binary is ready for Gradle packaging."
echo "Next: cd android-app && ./gradlew assembleRelease"
