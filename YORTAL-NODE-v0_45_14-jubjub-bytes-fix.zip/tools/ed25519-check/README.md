# Cross-checks for crates/yortal-ed25519

Used to validate the crate without a Rust toolchain.

- `zip215_model.py` — independent Python model of ZIP-215 verification.
- `gen_vectors.py` — produces `crates/yortal-ed25519/tests/vectors.txt`
  (reads the 12 speccheck vectors from the old v0.3.0 test file).
- `mirror.c` — line-by-line C transliteration of the crate's field, scalar,
  point, SHA-512, single and batch code.

Results at v0.45.13: SHA-512 18/18, field ops 312/312, scalar ops 208/208
(all vs Python big integers); all 38 vectors verify as expected; batch
bisection reports exactly the invalid preparable vectors, stable across runs.

    gcc -O2 -o mirror mirror.c
    cut -d' ' -f1-4 ../../crates/yortal-ed25519/tests/vectors.txt | ./mirror
