import hashlib,os,re,sys
exec(open(__import__('os').path.join(__import__('os').path.dirname(__file__),'zip215_model.py')).read().split("src=open")[0])   # field/point model + verify()
def enc(P):
    x,y,z,t=P; zi=pow(z,p-2,p); x,y=x*zi%p,y*zi%p
    return (y|((x&1)<<255)).to_bytes(32,'little')
def keygen(seed):
    hh=hashlib.sha512(seed).digest(); a=int.from_bytes(hh[:32],'little'); a&=(1<<254)-8; a|=1<<254
    return a,hh[32:],enc(mul(a,B))
def sign(key,m):
    a,pre,pk=key
    r=int.from_bytes(hashlib.sha512(pre+m).digest(),'little')%l
    Rb=enc(mul(r,B)); k=int.from_bytes(hashlib.sha512(Rb+pk+m).digest(),'little')%l
    return Rb+((r+k*a)%l).to_bytes(32,'little')
rows=[]
src=open(sys.argv[1]).read()
for m,pk,sig,want in re.findall(r'\("([0-9a-f]+)", "([0-9a-f]+)", "([0-9a-f]+)", (true|false)\)',src):
    rows.append((pk,m,sig,1 if want=='true' else 0,'zip215'))
rows.append(("d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a","-","e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b",1,'rfc1'))
rows.append(("3d4017c3e843895a92b70aa74d1b7ebc9c982ccf2ec4968cc0cd55f12af4660c","72","92a009a9f0d4cab8720e820b5f642540a2b27b5416503f8fb3762223ebdb69da085ac1e43e15996e458f3613d0f11d8c387b2eaeb4302aeeb00d291612bb0c00",1,'rfc2'))
keys=[keygen(bytes([i])*32) for i in range(6)]
for i in range(24):
    key=keys[i%6]; m=hashlib.sha256(b"yortal-%d"%i).digest()+bytes(i)
    sig=bytearray(sign(key,m)); want=1; kind='valid'
    if i==7: sig[40]^=1; want=0; kind='bad-s-bit'
    if i==13: m=m+b'x'; want=0; kind='wrong-msg'  # signed original, verify extended
    if i==19:
        s=int.from_bytes(sig[32:],'little')+l; sig[32:]=s.to_bytes(32,'little'); want=0; kind='s-plus-l'
    rows.append((key[2].hex(), m.hex() if m else "-", bytes(sig).hex(), want, kind))
    assert verify(key[2],m,bytes(sig))==bool(want),(i,kind)
for r in rows: print(*r)
