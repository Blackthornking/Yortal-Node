#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
typedef unsigned __int128 u128;
typedef uint64_t u64; typedef uint8_t u8;
#define MASK ((((u64)1)<<51)-1)
static const u64 SP0=36028797018963664ULL, SPI=36028797018963952ULL;
typedef struct {u64 l[5];} Fe;
static u64 load8(const u8*b,int i){u64 x;memcpy(&x,b+i,8);return x;}
static Fe carry(u64 l[5]){u64 c; c=l[0]>>51;l[0]&=MASK;l[1]+=c; c=l[1]>>51;l[1]&=MASK;l[2]+=c; c=l[2]>>51;l[2]&=MASK;l[3]+=c; c=l[3]>>51;l[3]&=MASK;l[4]+=c; c=l[4]>>51;l[4]&=MASK;l[0]+=c*19; Fe r; memcpy(r.l,l,40); return r;}
static Fe fe_from_bytes(const u8 b[32]){u64 w0=load8(b,0),w1=load8(b,8),w2=load8(b,16),w3=load8(b,24);Fe r={{w0&MASK,((w0>>51)|(w1<<13))&MASK,((w1>>38)|(w2<<26))&MASK,((w2>>25)|(w3<<39))&MASK,(w3>>12)&MASK}};return r;}
static void fe_to_bytes(Fe a,u8 out[32]){u64 t[5];memcpy(t,a.l,40);Fe x=carry(t);memcpy(t,x.l,40);x=carry(t);u64*l=x.l;
 u64 q=(l[0]+19)>>51;q=(l[1]+q)>>51;q=(l[2]+q)>>51;q=(l[3]+q)>>51;q=(l[4]+q)>>51;
 l[0]+=19*q;l[1]+=l[0]>>51;l[0]&=MASK;l[2]+=l[1]>>51;l[1]&=MASK;l[3]+=l[2]>>51;l[2]&=MASK;l[4]+=l[3]>>51;l[3]&=MASK;l[4]&=MASK;
 u64 w[4]={l[0]|(l[1]<<51),(l[1]>>13)|(l[2]<<38),(l[2]>>26)|(l[3]<<25),(l[3]>>39)|(l[4]<<12)};memcpy(out,w,32);}
static Fe fe_add(Fe a,Fe b){u64 t[5];for(int i=0;i<5;i++)t[i]=a.l[i]+b.l[i];return carry(t);}
static Fe fe_sub(Fe a,Fe b){u64 t[5];t[0]=a.l[0]+SP0-b.l[0];for(int i=1;i<5;i++)t[i]=a.l[i]+SPI-b.l[i];return carry(t);}
static const Fe FZERO={{0,0,0,0,0}},FONE={{1,0,0,0,0}};
static Fe fe_neg(Fe a){return fe_sub(FZERO,a);}
#define M(x,y) ((u128)(x)*(u128)(y))
static Fe fe_mul(Fe A,Fe B){u64*a=A.l,*b=B.l;u64 b1=b[1]*19,b2=b[2]*19,b3=b[3]*19,b4=b[4]*19;
 u128 c0=M(a[0],b[0])+M(a[1],b4)+M(a[2],b3)+M(a[3],b2)+M(a[4],b1);
 u128 c1=M(a[0],b[1])+M(a[1],b[0])+M(a[2],b4)+M(a[3],b3)+M(a[4],b2);
 u128 c2=M(a[0],b[2])+M(a[1],b[1])+M(a[2],b[0])+M(a[3],b4)+M(a[4],b3);
 u128 c3=M(a[0],b[3])+M(a[1],b[2])+M(a[2],b[1])+M(a[3],b[0])+M(a[4],b4);
 u128 c4=M(a[0],b[4])+M(a[1],b[3])+M(a[2],b[2])+M(a[3],b[1])+M(a[4],b[0]);
 c1+=c0>>51;u64 r0=((u64)c0)&MASK; c2+=c1>>51;u64 r1=((u64)c1)&MASK; c3+=c2>>51;u64 r2=((u64)c2)&MASK; c4+=c3>>51;u64 r3=((u64)c3)&MASK;
 u128 top=c4>>51;u64 r4=((u64)c4)&MASK; u128 R0=(u128)r0+top*19; r1=r1+(u64)(R0>>51); r0=((u64)R0)&MASK; Fe r={{r0,r1,r2,r3,r4}};return r;}
static Fe fe_sq(Fe a){return fe_mul(a,a);}
static Fe fe_pow(Fe a,const u8 e[32]){Fe r=FONE;for(int i=255;i>=0;i--){r=fe_sq(r);if((e[i/8]>>(i%8))&1)r=fe_mul(r,a);}return r;}
static int fe_eq(Fe a,Fe b){u8 x[32],y[32];fe_to_bytes(a,x);fe_to_bytes(b,y);return memcmp(x,y,32)==0;}
static int fe_iszero(Fe a){u8 x[32],z[32]={0};fe_to_bytes(a,x);return memcmp(x,z,32)==0;}
static int fe_isneg(Fe a){u8 x[32];fe_to_bytes(a,x);return x[0]&1;}
static const u8 D[32]={0xa3,0x78,0x59,0x13,0xca,0x4d,0xeb,0x75,0xab,0xd8,0x41,0x41,0x4d,0x0a,0x70,0x00,0x98,0xe8,0x79,0x77,0x79,0x40,0xc7,0x8c,0x73,0xfe,0x6f,0x2b,0xee,0x6c,0x03,0x52};
static const u8 D2[32]={0x59,0xf1,0xb2,0x26,0x94,0x9b,0xd6,0xeb,0x56,0xb1,0x83,0x82,0x9a,0x14,0xe0,0x00,0x30,0xd1,0xf3,0xee,0xf2,0x80,0x8e,0x19,0xe7,0xfc,0xdf,0x56,0xdc,0xd9,0x06,0x24};
static const u8 SQM1[32]={0xb0,0xa0,0x0e,0x4a,0x27,0x1b,0xee,0xc4,0x78,0xe4,0x2f,0xad,0x06,0x18,0x43,0x2f,0xa7,0xd7,0xfb,0x3d,0x99,0x00,0x4d,0x2b,0x0b,0xdf,0xc1,0x4f,0x80,0x24,0x83,0x2b};
static const u8 P58[32]={0xfd,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x0f};
static const u8 BP[32]={0x58,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x66};
/* scalar */
static const u64 L[4]={0x5812631a5cf5d3edULL,0x14def9dea2f79cd6ULL,0,0x1000000000000000ULL};
typedef struct{u64 l[4];}Sc;
static int geq(const u64*a,const u64*b){for(int i=3;i>=0;i--)if(a[i]!=b[i])return a[i]>b[i];return 1;}
static void subip(u64*a,const u64*b){u64 br=0;for(int i=0;i<4;i++){u64 d1=a[i]-b[i];u64 b1=a[i]<b[i];u64 d2=d1-br;u64 b2=d1<br;a[i]=d2;br=b1|b2;}}
static Sc reduce_bytes(const u8*b,int n){Sc r={{0}};u64*x=r.l;for(int i=n*8-1;i>=0;i--){u64 bit=(b[i/8]>>(i%8))&1;x[3]=(x[3]<<1)|(x[2]>>63);x[2]=(x[2]<<1)|(x[1]>>63);x[1]=(x[1]<<1)|(x[0]>>63);x[0]=(x[0]<<1)|bit;if(geq(x,L))subip(x,L);}return r;}
static int sc_canon(const u8 b[32],Sc*o){memcpy(o->l,b,32);return !geq(o->l,L);}
static Sc sc_add(Sc a,Sc b){Sc r;u64 c=0;for(int i=0;i<4;i++){u64 s1=a.l[i]+b.l[i];u64 c1=s1<a.l[i];u64 s2=s1+c;u64 c2=s2<s1;r.l[i]=s2;c=c1|c2;}if(geq(r.l,L))subip(r.l,L);return r;}
static Sc sc_mul(Sc a,Sc b){u64 w[8]={0};for(int i=0;i<4;i++){u128 c=0;for(int j=0;j<4;j++){u128 t=(u128)a.l[i]*b.l[j]+w[i+j]+c;w[i+j]=(u64)t;c=t>>64;}w[i+4]=(u64)c;}return reduce_bytes((u8*)w,64);}
static int sc_bit(Sc s,int i){return (s.l[i/64]>>(i%64))&1;}
static int sc_iszero(Sc s){return !(s.l[0]|s.l[1]|s.l[2]|s.l[3]);}
/* point */
typedef struct{Fe x,y,z,t;}Pt;
static Pt pt_id(){Pt p={FZERO,FONE,FONE,FZERO};return p;}
static int pt_dec(const u8 b[32],Pt*o){Fe y=fe_from_bytes(b);int sign=b[31]>>7;Fe d=fe_from_bytes(D);Fe yy=fe_sq(y);Fe u=fe_sub(yy,FONE);Fe v=fe_add(fe_mul(d,yy),FONE);
 Fe v3=fe_mul(fe_sq(v),v);Fe v7=fe_mul(fe_sq(v3),v);Fe x=fe_mul(fe_mul(u,v3),fe_pow(fe_mul(u,v7),P58));Fe vxx=fe_mul(v,fe_sq(x));
 if(fe_eq(vxx,u)){}else if(fe_eq(vxx,fe_neg(u))){x=fe_mul(x,fe_from_bytes(SQM1));}else return 0;
 if(fe_isneg(x))x=fe_neg(x); if(sign==1)x=fe_neg(x); o->x=x;o->y=y;o->z=FONE;o->t=fe_mul(x,y);return 1;}
static Pt pt_add(Pt s,Pt o){Fe a=fe_mul(fe_sub(s.y,s.x),fe_sub(o.y,o.x));Fe b=fe_mul(fe_add(s.y,s.x),fe_add(o.y,o.x));Fe c=fe_mul(fe_mul(s.t,fe_from_bytes(D2)),o.t);Fe d=fe_mul(fe_add(s.z,s.z),o.z);
 Fe e=fe_sub(b,a),f=fe_sub(d,c),g=fe_add(d,c),h=fe_add(b,a);Pt r={fe_mul(e,f),fe_mul(g,h),fe_mul(f,g),fe_mul(e,h)};return r;}
static Pt pt_dbl(Pt p){return pt_add(p,p);}
static Pt pt_neg(Pt p){Pt r={fe_neg(p.x),p.y,p.z,fe_neg(p.t)};return r;}
static Pt pt_cof(Pt p){return pt_dbl(pt_dbl(pt_dbl(p)));}
static int pt_isid(Pt p){return fe_iszero(p.x)&&fe_eq(p.y,p.z);}
static Pt msm(Sc*s,Pt*p,int n){Pt acc=pt_id();for(int bit=252;bit>=0;bit--){acc=pt_dbl(acc);for(int i=0;i<n;i++)if(sc_bit(s[i],bit))acc=pt_add(acc,p[i]);}return acc;}
static Pt basept(){Pt b;if(!pt_dec(BP,&b)){printf("BP FAIL\n");exit(1);}return b;}
/* sha512 */
static const u64 K[80]={0x428a2f98d728ae22ULL,0x7137449123ef65cdULL,0xb5c0fbcfec4d3b2fULL,0xe9b5dba58189dbbcULL,0x3956c25bf348b538ULL,0x59f111f1b605d019ULL,0x923f82a4af194f9bULL,0xab1c5ed5da6d8118ULL,0xd807aa98a3030242ULL,0x12835b0145706fbeULL,0x243185be4ee4b28cULL,0x550c7dc3d5ffb4e2ULL,0x72be5d74f27b896fULL,0x80deb1fe3b1696b1ULL,0x9bdc06a725c71235ULL,0xc19bf174cf692694ULL,0xe49b69c19ef14ad2ULL,0xefbe4786384f25e3ULL,0x0fc19dc68b8cd5b5ULL,0x240ca1cc77ac9c65ULL,0x2de92c6f592b0275ULL,0x4a7484aa6ea6e483ULL,0x5cb0a9dcbd41fbd4ULL,0x76f988da831153b5ULL,0x983e5152ee66dfabULL,0xa831c66d2db43210ULL,0xb00327c898fb213fULL,0xbf597fc7beef0ee4ULL,0xc6e00bf33da88fc2ULL,0xd5a79147930aa725ULL,0x06ca6351e003826fULL,0x142929670a0e6e70ULL,0x27b70a8546d22ffcULL,0x2e1b21385c26c926ULL,0x4d2c6dfc5ac42aedULL,0x53380d139d95b3dfULL,0x650a73548baf63deULL,0x766a0abb3c77b2a8ULL,0x81c2c92e47edaee6ULL,0x92722c851482353bULL,0xa2bfe8a14cf10364ULL,0xa81a664bbc423001ULL,0xc24b8b70d0f89791ULL,0xc76c51a30654be30ULL,0xd192e819d6ef5218ULL,0xd69906245565a910ULL,0xf40e35855771202aULL,0x106aa07032bbd1b8ULL,0x19a4c116b8d2d0c8ULL,0x1e376c085141ab53ULL,0x2748774cdf8eeb99ULL,0x34b0bcb5e19b48a8ULL,0x391c0cb3c5c95a63ULL,0x4ed8aa4ae3418acbULL,0x5b9cca4f7763e373ULL,0x682e6ff3d6b2b8a3ULL,0x748f82ee5defb2fcULL,0x78a5636f43172f60ULL,0x84c87814a1f0ab72ULL,0x8cc702081a6439ecULL,0x90befffa23631e28ULL,0xa4506cebde82bde9ULL,0xbef9a3f7b2c67915ULL,0xc67178f2e372532bULL,0xca273eceea26619cULL,0xd186b8c721c0c207ULL,0xeada7dd6cde0eb1eULL,0xf57d4f7fee6ed178ULL,0x06f067aa72176fbaULL,0x0a637dc5a2c898a6ULL,0x113f9804bef90daeULL,0x1b710b35131c471bULL,0x28db77f523047d84ULL,0x32caab7b40c72493ULL,0x3c9ebe0a15c9bebcULL,0x431d67c49c100d4cULL,0x4cc5d4becb3e42b6ULL,0x597f299cfc657e2aULL,0x5fcb6fab3ad6faecULL,0x6c44198c4a475817ULL};
static const u64 H0[8]={0x6a09e667f3bcc908ULL,0xbb67ae8584caa73bULL,0x3c6ef372fe94f82bULL,0xa54ff53a5f1d36f1ULL,0x510e527fade682d1ULL,0x9b05688c2b3e6c1fULL,0x1f83d9abfb41bd6bULL,0x5be0cd19137e2179ULL};
#define ROR(x,n) (((x)>>(n))|((x)<<(64-(n))))
typedef struct{u64 h[8];u8 buf[128];size_t bl;u128 total;}Sha;
static void comp(u64*h,const u8*blk){u64 w[80];for(int i=0;i<16;i++){u64 x=0;for(int j=0;j<8;j++)x=(x<<8)|blk[i*8+j];w[i]=x;}
 for(int i=16;i<80;i++){u64 s0=ROR(w[i-15],1)^ROR(w[i-15],8)^(w[i-15]>>7);u64 s1=ROR(w[i-2],19)^ROR(w[i-2],61)^(w[i-2]>>6);w[i]=w[i-16]+s0+w[i-7]+s1;}
 u64 a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
 for(int i=0;i<80;i++){u64 s1=ROR(e,14)^ROR(e,18)^ROR(e,41);u64 ch=(e&f)^(~e&g);u64 t1=hh+s1+ch+K[i]+w[i];u64 s0=ROR(a,28)^ROR(a,34)^ROR(a,39);u64 mj=(a&b)^(a&c)^(b&c);u64 t2=s0+mj;hh=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2;}
 h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;h[5]+=f;h[6]+=g;h[7]+=hh;}
static void sh_init(Sha*s){memcpy(s->h,H0,64);s->bl=0;s->total=0;}
static void sh_upd(Sha*s,const u8*d,size_t n){s->total+=n;if(s->bl>0){size_t take=128-s->bl<n?128-s->bl:n;memcpy(s->buf+s->bl,d,take);s->bl+=take;d+=take;n-=take;if(s->bl==128){u8 blk[128];memcpy(blk,s->buf,128);comp(s->h,blk);s->bl=0;}}
 while(n>=128){comp(s->h,d);d+=128;n-=128;} if(n){memcpy(s->buf,d,n);s->bl=n;}}
static void sh_upd_nc(Sha*s,const u8*d,size_t n){u128 t=s->total;sh_upd(s,d,n);s->total=t;}
static void sh_fin(Sha*s,u8 out[64]){u128 bits=s->total*8;u8 pad[256]={0};pad[0]=0x80;size_t pl=s->bl<112?112-s->bl:240-s->bl;sh_upd_nc(s,pad,pl);u8 lb[16];for(int i=0;i<16;i++)lb[i]=(u8)(bits>>(8*(15-i)));sh_upd_nc(s,lb,16);if(s->bl!=0){printf("PAD BUG\n");exit(1);}
 for(int i=0;i<8;i++)for(int j=0;j<8;j++)out[i*8+j]=(u8)(s->h[i]>>(8*(7-j)));}
/* verify */
typedef struct{u8 key[32];Pt a,r;Sc s,k;}Prep;
static int prep(const u8 pk[32],const u8*m,size_t ml,const u8 sig[64],Prep*o){if(!pt_dec(pk,&o->a))return 1;if(!pt_dec(sig,&o->r))return 2;if(!sc_canon(sig+32,&o->s))return 3;
 Sha h;sh_init(&h);sh_upd(&h,sig,32);sh_upd(&h,pk,32);sh_upd(&h,m,ml);u8 dg[64];sh_fin(&h,dg);o->k=reduce_bytes(dg,64);memcpy(o->key,pk,32);return 0;}
static int check_single(Prep*p){Sc s[3]={p->s,p->k,{{1,0,0,0}}};Pt pts[3]={basept(),pt_neg(p->a),pt_neg(p->r)};return pt_isid(pt_cof(msm(s,pts,3)));}
static int verify(const u8 pk[32],const u8*m,size_t ml,const u8 sig[64]){Prep p;if(prep(pk,m,ml,sig,&p))return 0;return check_single(&p);}
static FILE*ur;
static Sc coef(){for(;;){u8 b[16];fread(b,1,16,ur);int nz=0;for(int i=0;i<16;i++)nz|=b[i];if(nz){Sc s={{0}};memcpy(s.l,b,16);return s;}}}
static int check_batch(Prep**it,int n){if(n==0)return 1;if(n==1)return check_single(it[0]);
 Sc*sc=malloc(sizeof(Sc)*(2*n+1));Pt*pt=malloc(sizeof(Pt)*(2*n+1));int m=0;Sc b={{0}};
 u8 (*keys)[32]=malloc(32*n);Pt*ka=malloc(sizeof(Pt)*n);Sc*kc=malloc(sizeof(Sc)*n);int nk=0;
 for(int i=0;i<n;i++){Sc z=coef();b=sc_add(b,sc_mul(z,it[i]->s));sc[m]=z;pt[m]=it[i]->r;m++;Sc zk=sc_mul(z,it[i]->k);int f=-1;for(int j=0;j<nk;j++)if(!memcmp(keys[j],it[i]->key,32))f=j;
  if(f>=0)kc[f]=sc_add(kc[f],zk);else{memcpy(keys[nk],it[i]->key,32);ka[nk]=it[i]->a;kc[nk]=zk;nk++;}}
 sc[m]=b;pt[m]=pt_neg(basept());m++;for(int j=0;j<nk;j++)if(!sc_iszero(kc[j])){sc[m]=kc[j];pt[m]=ka[j];m++;}
 int ok=pt_isid(pt_cof(msm(sc,pt,m)));free(sc);free(pt);free(keys);free(ka);free(kc);return ok;}
static void isolate(Prep**it,int*tags,int n,int*bad,int*nb){if(n==0)return;if(n==1){if(!check_single(it[0]))bad[(*nb)++]=tags[0];return;}
 if(check_batch(it,n))return;int mid=n/2;isolate(it,tags,mid,bad,nb);isolate(it+mid,tags+mid,n-mid,bad,nb);}
/* test driver: reads lines "hexpk hexmsg hexsig expect" ; mode */
static int hx(const char*s,u8*o){int n=strlen(s)/2;for(int i=0;i<n;i++)sscanf(s+2*i,"%2hhx",&o[i]);return n;}
int main(int argc,char**argv){ur=fopen("/dev/urandom","rb");
 if(argc>1&&!strcmp(argv[1],"sha")){char line[20000];while(fgets(line,sizeof line,stdin)){line[strcspn(line,"\n")]=0;u8 m[10000];int n=strcmp(line,"-")?hx(line,m):0;Sha h;sh_init(&h);
   /* feed in odd chunks to exercise buffering */ int off=0,step=1;while(off<n){int t=n-off<step?n-off:step;sh_upd(&h,m+off,t);off+=t;step=step*3+1;}
   u8 d[64];sh_fin(&h,d);for(int i=0;i<64;i++)printf("%02x",d[i]);printf("\n");}return 0;}
 if(argc>1&&!strcmp(argv[1],"fe")){ /* lines: hexa hexb -> prints a*b, a+b, a-b, a^(p-2) canonical */
   char a[100],b[100];while(scanf("%s %s",a,b)==2){u8 x[32],y[32],o[32];hx(a,x);hx(b,y);Fe A=fe_from_bytes(x),B=fe_from_bytes(y);
   fe_to_bytes(fe_mul(A,B),o);for(int i=0;i<32;i++)printf("%02x",o[i]);printf(" ");fe_to_bytes(fe_add(A,B),o);for(int i=0;i<32;i++)printf("%02x",o[i]);printf(" ");
   fe_to_bytes(fe_sub(A,B),o);for(int i=0;i<32;i++)printf("%02x",o[i]);printf(" ");fe_to_bytes(A,o);for(int i=0;i<32;i++)printf("%02x",o[i]);printf("\n");}return 0;}
 if(argc>1&&!strcmp(argv[1],"sc")){char a[200],b[200];while(scanf("%s %s",a,b)==2){u8 x[64],y[32];hx(a,x);hx(b,y);Sc A=reduce_bytes(x,64),B;memcpy(B.l,y,32);
   Sc P=sc_mul(A,B),S=sc_add(A,B);u8*pp=(u8*)P.l,*ss=(u8*)S.l,*aa=(u8*)A.l;for(int i=0;i<32;i++)printf("%02x",aa[i]);printf(" ");for(int i=0;i<32;i++)printf("%02x",pp[i]);printf(" ");for(int i=0;i<32;i++)printf("%02x",ss[i]);printf("\n");}return 0;}
 /* default: verify lines, then batch/isolate */
 char pk[100],msg[4000],sig[200];int exp;static Prep P[512];static Prep*PP[512];int tags[512],n=0,bad[512],nb=0,fails=0;static u8 PK[512][32],SG[512][64],MS[512][2000];int ML[512];
 while(scanf("%s %s %s %d",pk,msg,sig,&exp)==4){hx(pk,PK[n]);ML[n]=strcmp(msg,"-")?hx(msg,MS[n]):0;hx(sig,SG[n]);int got=verify(PK[n],MS[n],ML[n],SG[n]);if(got!=exp){printf("MISMATCH item %d got %d want %d\n",n,got,exp);fails++;}
  if(!prep(PK[n],MS[n],ML[n],SG[n],&P[n])){PP[n]=&P[n];}else PP[n]=0; n++;}
 /* batch over preparable items */
 Prep*items[512];int tg[512],m=0;for(int i=0;i<n;i++)if(PP[i]){items[m]=PP[i];tg[m]=i;m++;}
 isolate(items,tg,m,bad,&nb);printf("single mismatches=%d  batch bad tags:",fails);for(int i=0;i<nb;i++)printf(" %d",bad[i]);printf("\n");
 return 0;}
