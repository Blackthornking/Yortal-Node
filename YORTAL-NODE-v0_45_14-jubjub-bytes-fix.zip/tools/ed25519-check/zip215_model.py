import hashlib,re
p=2**255-19; l=2**252+27742317777372353535851937790883648493
d=(-121665*pow(121666,p-2,p))%p; I=pow(2,(p-1)//4,p)
def add(P,Q):
    x1,y1,z1,t1=P; x2,y2,z2,t2=Q
    A=(y1-x1)*(y2-x2)%p;B=(y1+x1)*(y2+x2)%p;C=t1*2*d*t2%p;D=z1*2*z2%p
    E,F,G,H=B-A,D-C,D+C,B+A
    return (E*F%p,G*H%p,F*G%p,E*H%p)
def mul(s,P):
    Q=(0,1,1,0)
    while s:
        if s&1: Q=add(Q,P)
        P=add(P,P); s>>=1
    return Q
def isid(P): x,y,z,t=P; return x%p==0 and (y-z)%p==0
def neg(P): x,y,z,t=P; return (-x%p,y,z,-t%p)
def dec(b):
    n=int.from_bytes(b,'little'); sign=n>>255; y=(n&(2**255-1))%p   # non-canonical y accepted
    u=(y*y-1)%p; v=(d*y*y+1)%p
    x2=u*pow(v,p-2,p)%p
    x=pow(x2,(p+3)//8,p)
    if (x*x-x2)%p: x=x*I%p
    if (x*x-x2)%p: return None
    if x&1!=sign: x=(-x)%p       # x==0 with sign=1 -> stays 0 (dalek behaviour)
    return (x,y,1,x*y%p)
gy=4*pow(5,p-2,p)%p
B=dec(gy.to_bytes(32,'little'))
def verify(pk,m,sig):
    A=dec(pk); R=dec(sig[:32])
    if A is None or R is None: return False
    s=int.from_bytes(sig[32:],'little')
    if s>=l: return False
    k=int.from_bytes(hashlib.sha512(sig[:32]+pk+m).digest(),'little')%l
    Q=add(add(mul(s,B),neg(R)),neg(mul(k,A)))
    return isid(mul(8,Q))
src=open('tests/conformance.rs').read()
vec=re.findall(r'\("([0-9a-f]+)", "([0-9a-f]+)", "([0-9a-f]+)", (true|false)\)',src)
for i,(m,pk,sig,want) in enumerate(vec):
    got=verify(bytes.fromhex(pk),bytes.fromhex(m),bytes.fromhex(sig))
    print(i,got,want,'OK' if str(got).lower()==want else 'MISMATCH')
print('rfc1',verify(bytes.fromhex('d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a'),b'',bytes.fromhex('e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b')))

# --- model of heea::verify_equation, checked against valid signatures ---
import os
def decompose(h):
    if h==0: return (1,0,False)
    r0,r1,t0,t1=l,h,0,1
    lim=1<<128
    while r1!=0:
        if abs(r1)<lim and abs(t1)<lim:
            if t1==0: return None
            return (abs(t1),abs(r1),t1<0)
        q=r0//r1; r0,r1,t0,t1=r1,r0-q*r1,t1,t0-q*t1
    return None
def heea(pk,m,sig):
    A=dec(pk); R=dec(sig[:32]); s=int.from_bytes(sig[32:],'little')
    h=int.from_bytes(hashlib.sha512(sig[:32]+pk+m).digest(),'little')%l
    tau,rho,flip=decompose(h)
    ts=s*tau%l
    sr=tau if flip else (-tau)%l
    sa=rho if flip else (-rho)%l
    Q=add(add(mul(ts,B),mul(sr,R)),mul(sa,A))
    return isid(mul(8,Q))
def sign(seed,m):
    hh=hashlib.sha512(seed).digest(); a=int.from_bytes(hh[:32],'little'); a&=(1<<254)-8; a|=1<<254
    Ap=mul(a,B); x,y,z,t=Ap; zi=pow(z,p-2,p); x,y=x*zi%p,y*zi%p
    pk=(y|((x&1)<<255)).to_bytes(32,'little')
    r=int.from_bytes(hashlib.sha512(hh[32:]+m).digest(),'little')%l
    Rp=mul(r,B); x,y,z,t=Rp; zi=pow(z,p-2,p); x,y=x*zi%p,y*zi%p
    Rb=(y|((x&1)<<255)).to_bytes(32,'little')
    k=int.from_bytes(hashlib.sha512(Rb+pk+m).digest(),'little')%l
    return pk,Rb+((r+k*a)%l).to_bytes(32,'little')
res={True:[0,0],False:[0,0]}
for i in range(40):
    m=os.urandom(16); pk,sig=sign(os.urandom(32),m)
    assert verify(pk,m,sig)
    h=int.from_bytes(hashlib.sha512(sig[:32]+pk+m).digest(),'little')%l
    flip=decompose(h)[2]
    res[flip][0 if heea(pk,m,sig) else 1]+=1
print("heea on VALID sigs: flip=False accept/reject",res[False],"  flip=True accept/reject",res[True])
