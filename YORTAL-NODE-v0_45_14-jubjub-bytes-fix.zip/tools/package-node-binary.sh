#!/usr/bin/env bash
# Install the cross-compiled Android ARM64 node as a packaged native executable.
#
# Android 10+ does not allow an app to chmod + exec a file it created in its own
# private data directory.  Putting the ELF under jniLibs/arm64-v8a makes Gradle/
# PackageManager install it in the app's native-library directory, which is the
# execution path used by NodeService.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${BINARY:?Set BINARY to the built aarch64-linux-android ycash-android-node binary}"
ABI="${ABI:-arm64-v8a}"
DEST_DIR="$ROOT/android-app/app/src/main/jniLibs/$ABI"
DEST="$DEST_DIR/libycashandroidnode.so"

if [[ ! -f "$BINARY" ]]; then
  echo "ERROR: binary does not exist: $BINARY" >&2
  exit 1
fi
if [[ ! -r "$BINARY" ]]; then
  echo "ERROR: binary is not readable: $BINARY" >&2
  exit 1
fi

# The packaged file is deliberately named .so because AGP treats files under
# jniLibs/<ABI>/ as native libraries.  It must still be an EXECUTABLE ELF, not
# a cdylib/shared object and not a text placeholder.
if command -v file >/dev/null 2>&1; then
  desc="$(file -b "$BINARY")"
  case "$desc" in
    *ELF*executable*|*ELF*pie*executable*) ;;
    *) echo "ERROR: BINARY is not an ELF executable: $desc" >&2; exit 1 ;;
  esac
  case "$desc" in
    *aarch64*|*AArch64*|*ARM64*) ;;
    *) echo "ERROR: BINARY is not ARM64/aarch64: $desc" >&2; exit 1 ;;
  esac
fi

mkdir -p "$DEST_DIR"
cp "$BINARY" "$DEST"
chmod 755 "$DEST"

# Never leave the old placeholder beside the real binary.
rm -f "$DEST_DIR/PLACE_BINARY_HERE.md"

echo "Installed Android ARM64 node: $DEST"
