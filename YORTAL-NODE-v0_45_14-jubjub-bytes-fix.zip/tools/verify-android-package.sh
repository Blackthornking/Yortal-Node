#!/usr/bin/env bash
# Fail fast if the Android source tree cannot produce a node-capable APK.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LIB="$ROOT/android-app/app/src/main/jniLibs/arm64-v8a/libycashandroidnode.so"

[[ -f "$LIB" ]] || { echo "FAIL: missing $LIB"; exit 1; }
[[ -x "$LIB" ]] || { echo "FAIL: native node is not executable"; exit 1; }

if command -v file >/dev/null 2>&1; then
  DESC="$(file -b "$LIB")"
  echo "$DESC"
  [[ "$DESC" == *ELF* ]] || { echo "FAIL: not an ELF"; exit 1; }
  [[ "$DESC" == *aarch64* || "$DESC" == *ARM64* ]] || { echo "FAIL: not ARM64"; exit 1; }
  [[ "$DESC" == *executable* || "$DESC" == *pie* ]] || { echo "FAIL: not an executable ELF"; exit 1; }
fi

grep -q "libycashandroidnode.so" "$ROOT/android-app/app/build.gradle"
grep -q "nativeLibraryDir" "$ROOT/android-app/app/src/main/java/com/ycash/androidnode/NodeService.java"
! test -f "$ROOT/android-app/app/src/main/jniLibs/arm64-v8a/PLACE_BINARY_HERE.md"

"$ROOT/tools/verify-script-pool.sh"

echo "PASS: Android ARM64 node package is present, wired to NodeService, and uses the consensus-safe script pool."
