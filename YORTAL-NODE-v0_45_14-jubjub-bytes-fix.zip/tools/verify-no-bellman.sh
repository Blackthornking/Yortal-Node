#!/usr/bin/env bash
# Fails if the removed proving stack creeps back in.
set -euo pipefail
cd "$(dirname "$0")/.."
if grep -rnIE 'bellman|zcash_proofs|feature *= *"prover"|"prover"' \
     --include='*.rs' --include='Cargo.toml' --include='*.sh' --include='*.gradle' --include='*.java' \
     --exclude='verify-no-bellman.sh' crates tools Cargo.toml android-app 2>/dev/null; then
  echo "ERROR: bellman/zcash_proofs/prover reference found." >&2
  exit 1
fi
echo "OK: no bellman / zcash_proofs / prover references."
