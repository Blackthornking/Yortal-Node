#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
G="$ROOT/crates/ycash-crypto/src/groth16.rs"
B="$ROOT/crates/ycash-crypto/src/batch.rs"
C="$ROOT/crates/ycash-crypto/Cargo.toml"

need() {
  local file="$1" pattern="$2" label="$3"
  grep -Eq "$pattern" "$file" || { echo "FAIL: missing $label"; exit 1; }
  echo "PASS: $label"
}

need "$C" '^rayon = "1\.11"$' 'Rayon dependency'
need "$G" 'par_iter\(\)' 'parallel proof preparation'
need "$G" 'rayon::join\(' 'parallel accumulator/preparation joins'
need "$G" 'fn pippenger_msm' 'adaptive Pippenger MSM implementation'
need "$G" 'adaptive_window\(' 'adaptive Pippenger window selection'
need "$G" 'pippenger_msm\(&key\.ic, &scalars\)' 'public-input IC MSM uses Pippenger'
need "$G" 'pippenger_msm\(&points, &scalars\)' 'C accumulator uses Pippenger'
need "$G" 'pub fn verify_pair' 'combined Spend/Output verifier'
need "$G" 'multi_miller_loop\(&terms\)' 'single combined Miller-loop path'
need "$B" 'Batch::verify_pair\(' 'Sapling batch invokes combined verifier'
need "$G" 'pippenger_msm_matches_naive_across_adaptive_sizes' 'Pippenger regression test'

if grep -Eq 'for \(x, base\) in inputs\.iter\(\)\.zip\(self\.ic\[1\.\.\]\.iter\(\)\)' "$G"; then
  echo 'FAIL: old per-public-input scalar multiplication loop remains in batch verifier'
  exit 1
fi

echo 'PASS: no old Bellman-style public-input loop detected'
echo 'Sapling MSM acceleration wiring is structurally verified.'
