//! Disk-backed block read-ahead cache.
//!
//! Network acquisition is allowed to run ahead of the small hot verifier queue.
//! Downloaded blocks are written here and only promoted into the verifier when
//! the hot queue has room. The cache is deliberately non-consensus state: the
//! verifier still validates every block before it can enter the ordered state
//! pipeline.

use std::collections::BTreeMap;
use std::fs::{self, File, OpenOptions};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::sync::Mutex;

use anyhow::{anyhow, Context, Result};

const DEFAULT_MAX_BYTES: u64 = 1024 * 1024 * 1024;
const MAX_ENTRIES: usize = 1024;

#[derive(Default)]
struct Index {
    entries: BTreeMap<u64, ([u8; 32], String)>,
    bytes: u64,
    reserved: u64,
}

pub struct PrefetchCache {
    dir: PathBuf,
    max_bytes: u64,
    index: Mutex<Index>,
}

impl PrefetchCache {
    pub fn open() -> Result<Self> {
        let dir = std::env::var_os("YORTAL_PREFETCH_DIR")
            .map(PathBuf::from)
            .or_else(|| {
                std::env::var_os("YCASH_NODE_DB").map(PathBuf::from).map(|p| {
                    let mut d = p;
                    d.set_extension("prefetch");
                    d
                })
            })
            .unwrap_or_else(|| std::env::temp_dir().join("ycash-yortal-prefetch"));
        fs::create_dir_all(&dir).with_context(|| format!("create prefetch directory {}", dir.display()))?;
        // Prefetch is deliberately ephemeral. Never reuse bytes from an older
        // process after a restart; headers may have changed meanwhile.
        for entry in fs::read_dir(&dir)? {
            let path = entry?.path();
            if path.is_file() { let _ = fs::remove_file(path); }
        }
        let max_bytes = std::env::var("YORTAL_PREFETCH_MAX_MB")
            .ok()
            .and_then(|v| v.parse::<u64>().ok())
            .filter(|v| *v >= 32)
            .map(|mb| mb * 1024 * 1024)
            .unwrap_or(DEFAULT_MAX_BYTES);
        Ok(Self { dir, max_bytes, index: Mutex::new(Index::default()) })
    }

    fn path_for(&self, hash: &[u8; 32]) -> PathBuf {
        self.dir.join(format!("{}.blk", hex(hash)))
    }

    /// Store a complete block atomically. Returns false when the byte budget
    /// would be exceeded; callers can then promote that one block directly to
    /// the bounded hot verifier queue without losing it.
    pub fn put(&self, height: u64, hash: [u8; 32], peer: &str, raw: &[u8]) -> Result<bool> {
        if raw.len() as u64 > self.max_bytes { return Ok(false); }
        let path = self.path_for(&hash);
        let tmp = path.with_extension("tmp");
        let len = raw.len() as u64;
        {
            let mut idx = self.index.lock().unwrap_or_else(|e| e.into_inner());
            if let Some((old_hash, _)) = idx.entries.get(&height).cloned() {
                if old_hash == hash { return Ok(true); }
                let old_path = self.path_for(&old_hash);
                if let Ok(meta) = fs::metadata(&old_path) { idx.bytes = idx.bytes.saturating_sub(meta.len()); }
                let _ = fs::remove_file(old_path);
                idx.entries.remove(&height);
            }
            if idx.entries.len() + 1 > MAX_ENTRIES || idx.bytes.saturating_add(idx.reserved).saturating_add(len) > self.max_bytes {
                return Ok(false);
            }
            idx.reserved = idx.reserved.saturating_add(len);
        }

        let write_result = (|| -> Result<()> {
            let mut f = OpenOptions::new().create_new(true).write(true).open(&tmp)
                .with_context(|| format!("create prefetch temp {}", tmp.display()))?;
            f.write_all(raw)?;
            f.sync_data()?;
            fs::rename(&tmp, &path).with_context(|| format!("install prefetch {}", path.display()))?;
            Ok(())
        })();

        let mut idx = self.index.lock().unwrap_or_else(|e| e.into_inner());
        idx.reserved = idx.reserved.saturating_sub(len);
        if let Err(_) = write_result {
            let _ = fs::remove_file(&tmp);
            let _ = fs::remove_file(&path);
            return Ok(false);
        }
        idx.bytes = idx.bytes.saturating_add(len);
        idx.entries.insert(height, (hash, peer.to_string()));
        Ok(true)
    }

    /// Lowest-height cached entries first, keeping only a small hot window in
    /// RAM. The network horizon can therefore be 1024 while the verifier never
    /// has to hold 1024 full blocks in memory.
    pub fn take_hot(&self, max: usize, canonical_next: u64, hot_end: u64) -> Vec<(u64, [u8; 32], String, Vec<u8>)> {
        let mut idx = self.index.lock().unwrap_or_else(|e| e.into_inner());
        let heights: Vec<u64> = idx.entries.keys()
            .copied()
            .filter(|h| *h >= canonical_next && *h <= hot_end)
            .take(max)
            .collect();
        let mut out = Vec::with_capacity(heights.len());
        for height in heights {
            let Some((hash, peer)) = idx.entries.remove(&height) else { continue };
            let path = self.path_for(&hash);
            match read_file(&path) {
                Ok(raw) => {
                    idx.bytes = idx.bytes.saturating_sub(raw.len() as u64);
                    let _ = fs::remove_file(path);
                    out.push((height, hash, peer, raw));
                }
                Err(_) => {
                    let _ = fs::remove_file(path);
                }
            }
        }
        out
    }

    pub fn remove(&self, height: u64, hash: &[u8; 32]) {
        let mut idx = self.index.lock().unwrap_or_else(|e| e.into_inner());
        if let Some((old_hash, _)) = idx.entries.remove(&height) {
            if &old_hash == hash {
                let path = self.path_for(hash);
                if let Ok(meta) = fs::metadata(&path) { idx.bytes = idx.bytes.saturating_sub(meta.len()); }
                let _ = fs::remove_file(path);
            }
        }
    }

    pub fn len(&self) -> usize { self.index.lock().unwrap_or_else(|e| e.into_inner()).entries.len() }
    pub fn bytes(&self) -> u64 { self.index.lock().unwrap_or_else(|e| e.into_inner()).bytes }
}

fn read_file(path: &Path) -> Result<Vec<u8>> {
    let mut f = File::open(path).with_context(|| format!("open prefetch {}", path.display()))?;
    let len = f.metadata()?.len() as usize;
    let mut raw = Vec::with_capacity(len);
    f.read_to_end(&mut raw)?;
    if raw.len() != len { return Err(anyhow!("short prefetch read")); }
    Ok(raw)
}

fn hex(bytes: &[u8; 32]) -> String {
    const H: &[u8; 16] = b"0123456789abcdef";
    let mut out = String::with_capacity(64);
    for b in bytes { out.push(H[(b >> 4) as usize] as char); out.push(H[(b & 0xf) as usize] as char); }
    out
}
