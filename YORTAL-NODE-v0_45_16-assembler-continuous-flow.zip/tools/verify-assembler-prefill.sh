#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
V="$ROOT/crates/node/src/verifier.rs"
B="$ROOT/crates/node/src/batch.rs"
S="$ROOT/crates/state/src/state_service.rs"
R="$ROOT/crates/ycash-android-node/src/runtime.rs"
C="$ROOT/config/pipeline.toml"

[[ -f "$V" && -f "$B" && -f "$S" && -f "$R" && -f "$C" ]]
grep -q 'pub const PIPELINE_BATCH_SIZE: usize = 16;' "$ROOT/crates/node/src/lib.rs"
grep -q 'pub const INTAKE_READY_BATCHES: usize = 4;' "$ROOT/crates/node/src/lib.rs"
grep -q 'BatchAssembler::new(VERIFICATION_BATCH_SIZE)' "$V"
grep -q 'release_ready(expected_first)' "$V"
grep -q 'batch_entry_error(&intake_state, first_height, &blocks)' "$V"
grep -q 'all(|w| w\[1\].request.height == w\[0\].request.height.saturating_add(1))' "$V"
grep -q 'send(IntakeBatch' "$V"
grep -q 'ready_batches.fetch_add(1, Ordering::AcqRel)' "$V"
grep -q 'ready_batch_target(&dispatch_state, expected_first)' "$V"
! grep -q 'while dispatch_metrics.ready_batches.load(Ordering::Acquire) < target as u64' "$V"
grep -q 'admitted batch .*immediately; ready_batches remaining=.*prefill_target=' "$V"
grep -q 'ready_batches.fetch_sub(1, Ordering::AcqRel)' "$V"
grep -q 'ready_batch_target_for_tip' "$V"
grep -q 'pub ready_batches: AtomicU64' "$S"
grep -q 'pub ready_batch_target: AtomicU64' "$S"
grep -q 'pub ready_batches: u64' "$R"
grep -q 'pub ready_batch_target: u64' "$R"
grep -q '"ready_batches":{}' "$ROOT/crates/ycash-android-node/src/main.rs"
grep -q '"ready_batch_target":{}' "$ROOT/crates/ycash-android-node/src/main.rs"
grep -Eq '^max_blocks_in_flight[[:space:]]*=[[:space:]]*144([[:space:]]*(#.*)?)?$' "$C"
grep -Eq '^max_prospective_blocks[[:space:]]*=[[:space:]]*128([[:space:]]*(#.*)?)?$' "$C"

# The queue remains bounded at four; four is a prefill target, not a hard
# start barrier, so a single ready batch is always allowed to make progress.
grep -q 'sync_channel::<IntakeBatch>(INTAKE_READY_BATCHES)' "$V"

echo 'PASS: 16-block ordered assembler + non-blocking four-batch prefill target enforced'
