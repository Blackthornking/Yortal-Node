# Build fix v0.45.17

Host compile check failed with 3 × E0308 in `ycash-node`.

1. `crates/node/src/downloader.rs` `handoff_status`: the let-else pattern
   destructured a tuple, but `HashMap::get` returns `Option<&(..)>`.
   Now `let Some((Some(owner), since)) = inner.handoff.get(hash) else { .. }`.
2. `crates/node/src/lib.rs` (two sites in the prefetch promoter):
   `PrefetchCache::contiguous_len` returns `usize`, but
   `prefetch_contiguous_blocks` is an `AtomicU64`. Added `as u64`.
3. `crates/node/src/verifier.rs`: removed an unneeded `mut` (warning only).

No behaviour changes.
