//! YORTAL synchronisation engine.
//!
//! ```text
//!   peers            intake gate          ready queue        verify        prepare      commit
//!   ┌────────┐      ┌─────────────┐      ┌───────────┐    ┌─────────┐   ┌────────┐   ┌────────┐
//!   │ blocks │ ───► │ 1 worker    │ ───► │ 4 complete│───►│ 4 crypto│──►│ 1 state│──►│ 1 batch│
//!   │ 16/peer│      │ sort + hold │      │ batches   │    │ workers │   │ worker │   │ writer │
//!   └────────┘      │ until all 16│      └───────────┘    └─────────┘   └────────┘   └────────┘
//!                   └─────────────┘        always ready     all 16      expensive    publish
//!                    no gaps leave                          required     work only    only
//! ```
//!
//! One worker, the intake gate, stands between the network and the pipeline. It
//! sorts unordered arrivals by height and releases a batch only once all 16 of
//! its blocks have been fetched and are in hand, so no stage below it ever sees
//! a gap. Four complete batches are queued behind it, so the verifiers always
//! have a full batch ready.
//!
//! Past the gate the batch is the only unit of work: four verifier workers take
//! its blocks in any order but every result is required before the next batch
//! starts; one worker does the expensive contextual/UTXO/script preparation;
//! one worker publishes the batch atomically and does nothing else.
//!
//! Nothing partial moves and nothing moves alone. If any stage rejects, the
//! whole batch is discarded and every stage resets to the canonical tip, so a
//! height that must be fetched again comes back inside a complete batch like
//! any other.

use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

use anyhow::{anyhow, Result};
use ycash_state::state_service::SyncMetrics;
use ycash_state::State;

pub mod batch;
pub mod downloader;
pub mod peer_manager;
pub mod prefetch;
pub mod verifier;

pub use downloader::{
    BlockAssigner, BlockRequest, HeadLifecycleTracker, HeadPhase, HeadSnapshot, HeadStatus, InFlightRegistry, PeerDownloadSession, MAX_BLOCKS_IN_FLIGHT,
    MAX_BLOCKS_IN_TRANSIT_PER_PEER, REQUEST_TIMEOUT, CANONICAL_PARENT_RETRY_TIMEOUT,
};
pub use peer_manager::{PeerManager, PeerStats};
pub use prefetch::{PrefetchCache, PREFETCH_CAPACITY_BLOCKS};
pub use verifier::{RawBlock, VerifierPool, ASSUME_VALID_HASH_DISPLAY, ASSUME_VALID_HEIGHT};

/// Cryptographic verifier threads. Verification only.
pub const VERIFIER_WORKERS: usize = 4;

/// State-stage threads. After verification these two do everything else
/// together — the ordered UTXO/Sprout/Sapling walk and the transparent script
/// checks — and the batch is then published as one atomic commit.
pub const STATE_WORKERS: usize = 2;

/// Initial delay before the first gap hand-off. Later hedges back off through
/// a bounded 1s -> 2s -> 4s cadence while always selecting a different peer.
pub const GAP_HEDGE_DELAY: Duration = Duration::from_secs(1);
pub const GAP_HEDGE_MAX_DELAY: Duration = Duration::from_secs(4);

/// Blocks per batch, through every stage: intake, verification, state
/// preparation and canonical publication. This is the unit of work.
pub const PIPELINE_BATCH_SIZE: usize = 16;

/// Desired number of complete batches the intake gate tries to keep queued
/// ahead of verification. This is a prefill target, not a hard start barrier:
/// verification begins as soon as one complete batch is ready.
pub const INTAKE_READY_BATCHES: usize = 4;

/// Batches inside the pipeline at once: one being verified, one waiting for the
/// preparation worker, one being prepared/published.
pub const PIPELINE_INFLIGHT_BATCHES: usize = 3;

/// Batches the gate may be assembling while the ready queue is full. Without
/// this the download window fills up with queued and in-pipeline batches and
/// the network sits idle until a commit frees claims.
pub const INTAKE_ASSEMBLY_BATCHES: usize = 1;

/// Network read-ahead horizon. This is deliberately independent of the hot
/// verifier queue: blocks beyond the hot queue are staged on disk. A 2048-block
/// horizon keeps mobile peers busy through short stalls without making the RAM
/// assembler or verifier queue grow with the network window.
pub const BLOCK_DOWNLOAD_WINDOW: usize = 2_048;

/// Full-blocks retained in RAM by the verifier intake channel. The remaining
/// network horizon lives in the disk-backed prefetch cache.
pub const HOT_VERIFIER_QUEUE_CAPACITY: usize = 128;

/// Claim slots held back so the hole in a batch can always be requested.
///
/// This margin is what keeps the pipeline alive, and it must never be zero.
/// Every claimed block sits at a height inside the window, so when the window
/// and the claim capacity are the same number the gate can hoard the entire
/// window while waiting for one missing height — and then there is no claim
/// slot left to ask for it. The gate holds, the verifiers idle, and the node
/// stops for good. One spare batch guarantees the lowest missing heights are
/// always requestable:
///
///   held_by_gate + in_pipeline + in_flight <= BLOCK_DOWNLOAD_WINDOW
///                                          <  VERIFIER_QUEUE_CAPACITY
pub const GAP_RESERVE_BLOCKS: usize = PIPELINE_BATCH_SIZE;

/// Total block lifecycle claims: the download window plus the gap reserve.
pub const VERIFIER_QUEUE_CAPACITY: usize = BLOCK_DOWNLOAD_WINDOW + GAP_RESERVE_BLOCKS;

/// Legacy setting, no longer sizes anything: since v0.45.9 script checks run
/// on the shared `VERIFIER_WORKERS`-wide pool. Kept so configs still parse.
///
/// Script checks are captured by the ordered state-preparation walk and executed
/// asynchronously on the persistent shared pool. This keeps UTXO/Sprout/Sapling
/// mutation ordered while overlapping pure script work with later state work in
/// the same exact 16-block lifecycle window.
pub const SCRIPT_WORKERS: usize = 5;

/// Cores held for roles that must never wait: canonical publication and
/// header/peer I/O.
pub const RESERVED_CORES: usize = 2;

/// Transport and resource settings. None of these is a consensus parameter:
/// the same chain synchronised with any combination of them must produce the
/// same canonical state.
#[derive(Clone, Debug)]
pub struct SyncConfig {
    pub blocks_in_transit_per_peer: usize,
    pub max_blocks_in_flight: usize,
    pub prospective_capacity: usize,
    pub verifier_workers: usize,
    /// Transparent script verification threads.
    pub script_workers: usize,
    pub verifier_queue: usize,
    pub assume_valid: bool,
}

impl SyncConfig {
    /// How far above the canonical tip blocks may be requested.
    ///
    /// Always strictly below `max_blocks_in_flight`, which is the claim
    /// capacity. See `GAP_RESERVE_BLOCKS`: if the two were equal, one missing
    /// height could be starved out by its own lookahead and the node would
    /// stall permanently.
    pub fn download_window(&self) -> usize {
        // One bounded global pipeline. Per-peer limits only divide the window;
        // they never multiply it.
        self.max_blocks_in_flight
            .saturating_sub(GAP_RESERVE_BLOCKS)
            .min(self.prospective_capacity)
            .max(1)
    }
}

impl Default for SyncConfig {
    fn default() -> Self {
        Self {
            blocks_in_transit_per_peer: PIPELINE_BATCH_SIZE,
            max_blocks_in_flight: VERIFIER_QUEUE_CAPACITY,
            prospective_capacity: BLOCK_DOWNLOAD_WINDOW,
            // Default fixed roles: semantic verification has four worker lanes;
            // the canonical writer and Android/header housekeeping retain their
            // reserved roles. Transparent script work uses the persistent Rayon
            // pool concurrently during contextual preparation.
            verifier_workers: VERIFIER_WORKERS,
            script_workers: SCRIPT_WORKERS,
            verifier_queue: HOT_VERIFIER_QUEUE_CAPACITY,
            assume_valid: false,
        }
    }
}

impl SyncConfig {
    /// Read the transport settings from the environment, so they can be changed
    /// on a device without rebuilding. Consensus cannot be changed this way.
    pub fn from_env() -> Self {
        let mut cfg = Self::default();
        if let Some(v) = env_usize("YORTAL_BLOCKS_IN_TRANSIT_PER_PEER") {
            cfg.blocks_in_transit_per_peer = v.clamp(1, PIPELINE_BATCH_SIZE);
        }
        // Claims cover transport, the intake gate, verification, preparation
        // and publication together. The window is derived from the batch
        // structure rather than from the number of peers, so it is not an
        // independent setting: the values below are fixed on purpose, and the
        // environment cannot widen one stage on its own and starve another.
        cfg.blocks_in_transit_per_peer = PIPELINE_BATCH_SIZE;
        cfg.max_blocks_in_flight = VERIFIER_QUEUE_CAPACITY;
        cfg.prospective_capacity = BLOCK_DOWNLOAD_WINDOW;
        cfg.verifier_queue = HOT_VERIFIER_QUEUE_CAPACITY;
        if let Some(v) = env_usize("YORTAL_VERIFY_THREADS") {
            // 0 is the documented automatic mode. Do not clamp it to 1: that
            // silently disabled the device-derived verifier width on Android.
            cfg.verifier_workers = if v == 0 {
                VERIFIER_WORKERS
            } else {
                v.clamp(1, 64)
            };
        }
        cfg.assume_valid = std::env::var("YCASH_ASSUME_VALID").ok().as_deref() == Some("1")
            && std::env::var("YCASH_FULL_VERIFY").ok().as_deref() != Some("1");
        cfg
    }
}

fn env_usize(name: &str) -> Option<usize> {
    std::env::var(name).ok().and_then(|v| v.trim().parse::<usize>().ok())
}

/// Everything the peer threads need, started once per process.
#[derive(Clone)]
pub struct SyncEngine {
    pub state: Arc<State>,
    pub peers: Arc<PeerManager>,
    pub registry: Arc<InFlightRegistry>,
    pub assigner: Arc<BlockAssigner>,
    pub verifiers: VerifierPool,
    pub prefetch: Arc<PrefetchCache>,
    pub metrics: Arc<SyncMetrics>,
    pub config: SyncConfig,
}

impl SyncEngine {
    /// The height the ordered pipeline needs next. Everything is anchored to this
    /// height: the resource window, download requests and verifier frontier.
    pub fn next_height(&self) -> u64 {
        self.state.tip_height().ok().flatten().unwrap_or(0) + 1
    }

    /// Heights in the bounded download window that are not already claimed.
    ///
    /// Verification is intentionally asynchronous now: a block can move from
    /// transport directly into the verifier coordinator without being copied
    /// into a second "16 must be full" assembler. Lifecycle claims are the
    /// source of truth for whether a height is already in transit, waiting in
    /// verification, or held by the preparation/commit stages.
    pub fn missing_heights(&self) -> Vec<u64> {
        let header_tip = self.header_tip();
        let start = self.next_height();
        let end = header_tip.min(start.saturating_add(self.config.download_window().saturating_sub(1) as u64));
        if start > end {
            return Vec::new();
        }

        let hashes = match self.state.header_hashes_range(start, end) {
            Ok(v) => v,
            Err(_) => return Vec::new(),
        };
        (start..=end)
            .filter_map(|height| {
                // header_hashes_range already yields [u8; 32].
                let hash = hashes.get(&height).copied()?;
                (!self.registry.is_claimed(&hash)).then_some(height)
            })
            .collect()
    }

    /// Highest validated header, read from the database rather than from a
    /// counter someone remembered to update.
    ///
    /// The dashboard reported HDR 0 while the chain was at 192 because the
    /// header height was only ever written by the header-sync routine; if that
    /// returned early, the figure stayed stale. Reading state makes it true by
    /// construction.
    pub fn header_tip(&self) -> u64 {
        let tip = self.state.header_height().ok().flatten().unwrap_or(0);
        self.metrics.raise_header_height(tip);
        tip
    }

    /// Whether block download is waiting on the header chain rather than on a
    /// peer. These need opposite responses, so they must not look alike: one
    /// wants another peer asked, the other wants header sync resumed.
    pub fn awaiting_headers(&self) -> bool {
        self.header_tip() < self.next_height()
    }

    /// Start the cryptographic verifier, one expensive state-preparation worker,
    /// and one canonical batch-commit worker.
    pub fn start(state: Arc<State>, config: SyncConfig) -> Result<Self> {
        // Size the script pool with the verifiers rather than letting each
        // assume it owns the device.
        // The state stage's own pool: two workers that do all post-verification
        // work together (ordered state walk + transparent script checks).
        // The four verifiers have a separate pool and do verification only.
        // Must happen before anything first touches the state pool.
        ycash_state::chainstate::configure_shared_pool(STATE_WORKERS);
        ycash_state::chainstate::set_script_worker_budget(STATE_WORKERS);
        let metrics = SyncMetrics::new();
        // One lifecycle registry spans transport, cryptographic verification,
        // expensive state preparation and canonical publication. The dedicated
        // preparation/commit stages release entries only after their batch has
        // been resolved.
        let registry = Arc::new(InFlightRegistry::new(config.max_blocks_in_flight));
        let prefetch = Arc::new(PrefetchCache::open()?);
        let verifiers = VerifierPool::spawn(
            config.verifier_workers,
            config.verifier_queue,
            Arc::clone(&state),
            Arc::clone(&metrics),
            Arc::clone(&registry),
            config.assume_valid,
        )?;
        let assigner = Arc::new(BlockAssigner::new(
            Arc::clone(&state),
            Arc::clone(&registry),
            Arc::clone(&metrics),
            // Strictly *less* than the candidate set can hold.
            //
            // Every claimed block is either in transit or buffered, and every
            // claim lies inside this window, so buffered <= window. Keeping the
            // window below capacity therefore means eviction never happens at
            // all. Setting the two equal — which is what this was — guarantees
            // the opposite: the buffer sits permanently at capacity, every
            // arrival evicts a block, the eviction frees that block's claim,
            // and it is immediately re-requested. The chain still advances, in
            // bursts, while a large share of the bandwidth goes on re-fetching
            // blocks that were thrown away.
            config.download_window(),
        ));
        assigner.rewind_to_canonical()?;
        let peers = Arc::new(PeerManager::new());

        // Network read-ahead is deliberately decoupled from the hot verifier
        // queue. Downloaded blocks live in the bounded disk cache until there
        // is RAM/CPU capacity to promote them. This lets up to 2048 blocks be
        // acquired ahead without retaining the read-ahead reservoir in memory.
        {
            let feeder_state = Arc::clone(&state);
            let feeder_assigner = Arc::clone(&assigner);
            let feeder_registry = Arc::clone(&registry);
            let feeder_cache = Arc::clone(&prefetch);
            let feeder_verifiers = verifiers.clone();
            let feeder_metrics = Arc::clone(&metrics);
            thread::Builder::new()
                .name("yortal-prefetch-promoter".into())
                .spawn(move || loop {
                    // The intake gate owns the canonical promotion frontier.
                    // It advances when a complete 16-block batch is released,
                    // even while that batch is still being verified. Using the
                    // canonical tip here would incorrectly stop at the old tip
                    // and could never promote batch N+1 while batch N was busy.
                    let expected = feeder_metrics.intake_expected_height.load(Ordering::Acquire);
                    let entries = feeder_cache.take_contiguous(
                        expected.max(1),
                        PIPELINE_BATCH_SIZE * INTAKE_READY_BATCHES,
                    );
                    if entries.is_empty() {
                        feeder_metrics.prospective_blocks.store(feeder_cache.len() as u64, Ordering::Relaxed);
                        feeder_metrics.prefetch_blocks.store(feeder_cache.len() as u64, Ordering::Relaxed);
                        feeder_metrics.prefetch_bytes.store(feeder_cache.bytes(), Ordering::Relaxed);
                        feeder_metrics.prefetch_contiguous_blocks.store(
                            feeder_cache.contiguous_len(expected.max(1), PREFETCH_CAPACITY_BLOCKS),
                            Ordering::Relaxed,
                        );
                        thread::sleep(Duration::from_millis(5));
                        continue;
                    }
                    for (height, hash, source_peer, raw) in entries {
                        let request = match feeder_assigner.request_at_height(height) {
                            Ok(Some(req)) if req.hash == hash => req,
                            _ => {
                                feeder_registry.release(&hash);
                                continue;
                            }
                        };
                        if !feeder_registry.mark_prefetched_for_verification(&hash) {
                            feeder_registry.release(&hash);
                            continue;
                        }
                        let block = RawBlock { request, raw, source_peer };
                        if feeder_verifiers.submit(block).is_err() {
                            feeder_registry.release(&hash);
                            break;
                        }
                    }
                    feeder_metrics.prospective_blocks.store(feeder_cache.len() as u64, Ordering::Relaxed);
                    feeder_metrics.prefetch_blocks.store(feeder_cache.len() as u64, Ordering::Relaxed);
                    feeder_metrics.prefetch_bytes.store(feeder_cache.bytes(), Ordering::Relaxed);
                    feeder_metrics.prefetch_contiguous_blocks.store(
                        feeder_cache.contiguous_len(expected.max(1), PREFETCH_CAPACITY_BLOCKS),
                        Ordering::Relaxed,
                    );
                })
                .map_err(|e| anyhow!("failed to start prefetch promoter: {e}"))?;
        }
        if let Ok(Some(tip)) = state.tip_height() {
            metrics
                .canonical_height
                .store(tip, std::sync::atomic::Ordering::Relaxed);
        }
        Ok(Self { state, peers, registry, assigner, verifiers, prefetch, metrics, config })
    }

    /// Per-peer request window.
    pub fn session(&self, peer: &str) -> PeerDownloadSession {
        PeerDownloadSession::new(
            peer,
            Arc::clone(&self.assigner),
            Arc::clone(&self.registry),
            Arc::clone(&self.peers),
            Arc::clone(&self.metrics),
        )
        .with_limit(self.config.blocks_in_transit_per_peer)
    }

    /// Run the transport-level canonical-head watchdog independently of peer
    /// socket loops. This matters on Android because a peer thread can be
    /// blocked in a socket read while the exact tip+1 request is stalled.
    /// Releasing/nominating the claim here does not touch consensus state; the
    /// next responsive peer will pick the head up on its normal request pass.
    pub fn watchdog_head_once(&self) -> Result<bool> {
        let canonical = self.assigner.canonical_height()?;
        let next_height = canonical.saturating_add(1);
        let Some(hash) = self.assigner.header_hash(next_height)? else { return Ok(false) };
        self.registry.set_head_target(next_height, hash);
        match self.registry.head_status(&hash) {
            HeadStatus::Free => {
                // The watchdog is also able to recover a completely unclaimed
                // head. It reserves the hash for a healthy connected peer; the
                // peer's normal assignment pass performs the actual getdata.
                let Some(peer) = self.peers.best_peer() else { return Ok(false) };
                let alternates = self.peers.peer_count() > 1;
                if !self.registry.reserve_head(hash, &peer, alternates) { return Ok(false); }
                self.metrics.set_missing_parent_in_flight(false);
                self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
                self.metrics.mark_parent_retry();
                self.metrics.trace_head(peer, "WATCHDOG_RESERVE", next_height, Some(hash), "head was free; watchdog nominated a peer for recovery");
                let _ = self.assigner.rewind_to_canonical();
                Ok(true)
            }
            HeadStatus::Reserved { .. } => {
                // A peer is already nominated and has not yet issued getdata.
                // The hand-off window is short; if it lapses the head reads as
                // Free again and the next watchdog tick nominates a peer.
                Ok(false)
            }
            HeadStatus::Transport { owner, age } => {
                let timeout = self.registry.head_retry_timeout(&hash, CANONICAL_PARENT_RETRY_TIMEOUT);
                if age < timeout { return Ok(false); }
                let alternate = self.peers.best_alternate(&owner);
                if !self.registry.reassign_head(&hash, &owner, alternate.clone()) { return Ok(false); }
                self.peers.update(&owner, |s| s.timeouts = s.timeouts.saturating_add(1));
                self.metrics.set_missing_parent_in_flight(false);
                self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                self.metrics.expired_requests.fetch_add(1, Ordering::Relaxed);
                self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
                self.metrics.mark_parent_retry();
                self.metrics.trace_head(owner.clone(), "WATCHDOG_REASSIGN", next_height, Some(hash), format!("head request exceeded {}s outside peer loop; next_peer={}", timeout.as_secs(), alternate.as_deref().unwrap_or("none")));
                let _ = self.assigner.rewind_to_canonical();
                Ok(true)
            }
            HeadStatus::Lifecycle { age } => {
                if age < downloader::HEAD_LIFECYCLE_TIMEOUT { return Ok(false); }
                if !self.registry.break_stale_lifecycle(&hash, downloader::HEAD_LIFECYCLE_TIMEOUT) { return Ok(false); }
                let Some(peer) = self.peers.best_peer() else { return Ok(true) };
                let alternates = self.peers.peer_count() > 1;
                let _ = self.registry.reserve_head(hash, &peer, alternates);
                self.metrics.set_missing_parent_in_flight(false);
                self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
                self.metrics.mark_parent_retry();
                self.metrics.trace_head(peer, "WATCHDOG_LIFECYCLE_RECOVERY", next_height, Some(hash), format!("head lifecycle stalled for {}s; lifecycle claim reset", age.as_secs()));
                let _ = self.assigner.rewind_to_canonical();
                Ok(true)
            }
        }
    }

    /// Chase the block the assembler is stuck on with bounded multi-peer
    /// hedging. The first retry fires after 1s, the next after 2s, then 4s;
    /// each hand-off chooses a different healthy peer where possible. A
    /// reservation is also re-routed if the nominated peer never gets far
    /// enough through its socket loop to claim it. The canonical head (tip+1)
    /// is left to `watchdog_head_once`.
    /// `waiting` carries (gap height, delay start, hedge stage).
    pub fn hedge_gap_once(&self, waiting: &mut Option<(u64, Instant, u32)>) -> Result<bool> {
        let gap = self.metrics.dispatch_gap_height.load(Ordering::Relaxed);
        let canonical = self.assigner.canonical_height()?;
        if gap == 0 || gap <= canonical.saturating_add(1) {
            *waiting = None;
            return Ok(false);
        }
        let (first_seen, stage) = match *waiting {
            Some((height, since, stage)) if height == gap => (since, stage),
            _ => {
                *waiting = Some((gap, Instant::now(), 0));
                self.metrics.gap_hedges.store(0, Ordering::Relaxed);
                return Ok(false);
            }
        };
        let delay_secs = GAP_HEDGE_DELAY
            .as_secs()
            .saturating_mul(1u64 << stage.min(2));
        let delay = Duration::from_secs(delay_secs.min(GAP_HEDGE_MAX_DELAY.as_secs()));
        if first_seen.elapsed() < delay {
            return Ok(false);
        }
        let Some(hash) = self.assigner.header_hash(gap)? else { return Ok(false) };

        // Prefer an active transport owner. If the previous hedge only created
        // a reservation, rotate that reservation instead of letting it become
        // a silent dead end.
        let outcome = if let Some(owner) = self.registry.transport_owner(&hash) {
            let Some(alternate) = self.best_gap_peer(&owner, &hash) else { return Ok(false) };
            if !self.registry.reassign_head(&hash, &owner, Some(alternate.clone())) {
                return Ok(false);
            }
            self.peers.update(&owner, |s| s.timeouts = s.timeouts.saturating_add(1));
            format!("transport owner {owner} -> reserved {alternate}")
        } else if let Some((owner, _age)) = self.registry.handoff_status(&hash) {
            let Some(alternate) = self.best_gap_peer(&owner, &hash) else { return Ok(false) };
            if !self.registry.reassign_reserved(&hash, &owner, alternate.clone()) {
                return Ok(false);
            }
            format!("reserved peer {owner} -> reserved {alternate}")
        } else {
            // The request may have arrived between ticks; the next telemetry
            // pass will show the gap disappearing, so do not manufacture a
            // retry here.
            return Ok(false);
        };

        *waiting = Some((gap, Instant::now(), stage.saturating_add(1)));
        self.metrics.gap_hedges.fetch_add(1, Ordering::Relaxed);
        self.metrics.expired_requests.fetch_add(1, Ordering::Relaxed);
        self.metrics.trace_head(
            "gap-watchdog",
            "GAP_HEDGE",
            gap,
            Some(hash),
            format!("gap {gap} still missing after {}s; hedge stage {}: {outcome}", delay.as_secs(), stage.saturating_add(1)),
        );
        eprintln!("[INTAKE] gap {gap} hedge stage {} after {}s: {outcome}", stage.saturating_add(1), delay.as_secs());
        Ok(true)
    }

    fn best_gap_peer(&self, exclude: &str, hash: &[u8; 32]) -> Option<String> {
        self.peers
            .ranked_alternates(exclude)
            .into_iter()
            .find(|peer| !self.registry.recently_failed(hash, peer, downloader::GAP_PEER_COOLDOWN))
    }

    /// Handle one `block` message: match it to an outstanding request, free the
    /// slot and queue it for semantic verification.
    ///
    /// A block nobody asked for is ignored rather than trusted, and an unknown
    /// hash is never counted against the peer's window.
    pub fn on_block_message(&self, session: &mut PeerDownloadSession, raw: Vec<u8>) -> Result<bool> {
        let Some(hash) = block_hash(&raw) else { return Ok(false) };
        let bytes = raw.len();
        let Some(request) = session.on_block(&hash, bytes) else { return Ok(false) };
        let source_peer = session.peer().to_string();

        // The transport slot is now free. Keep the lifecycle claim occupied,
        // but move the raw block to the disk-backed read-ahead cache whenever
        // possible. This is the key separation between the 2048-block network
        // horizon and the much smaller hot verifier queue.
        let cached = self.prefetch.put(request.height, request.hash, &source_peer, &raw)?;
        if cached {
            if self.registry.mark_prefetched(&request.hash) {
                self.metrics.prospective_blocks.store(self.prefetch.len() as u64, Ordering::Relaxed);
                return Ok(true);
            }
            // A late arrival may already have been adopted directly into the
            // verifier lifecycle. Do not leave a second copy in the cache.
            self.prefetch.remove(request.height, &request.hash);
        }

        // Cache full/disabled or a late-arrival claim that was already adopted:
        // promote this one block directly into the bounded hot queue.
        let _ = self.registry.mark_verifying(&request.hash);
        let block = RawBlock { request: request.clone(), raw, source_peer };
        if let Err(e) = self.verifiers.submit(block) {
            self.registry.release(&request.hash);
            return Err(e);
        }
        Ok(true)
    }

    /// Hashes to put in the next `getdata`, refilling the peer's window.
    pub fn next_requests(&self, session: &mut PeerDownloadSession) -> Result<Vec<[u8; 32]>> {
        // The canonical parent is special: later blocks cannot be committed
        // around it, so do not make tip+1 wait for the normal 90s transport
        // timeout. A short head retry lets another peer take over quickly.
        session.retry_canonical_parent(CANONICAL_PARENT_RETRY_TIMEOUT)?;
        session.expire_stale(session.ycash_stall_timeout());

        // Ask for exactly what the current batch is missing, lowest height
        // first. The head is therefore always the first request issued, and no
        // speculative work can occupy the window ahead of it.
        // Headers first: without them there is nothing to request, and the
        // node should say so instead of reporting a missing parent.
        if self.awaiting_headers() {
            self.metrics.set_missing_parent_in_flight(false);
            return Ok(Vec::new());
        }

        let missing = self.missing_heights();
        if missing.is_empty() {
            return Ok(Vec::new());
        }
        session.top_up_heights(&missing)
    }

    /// Record an exact canonical-head transport event for diagnostics.
    pub fn trace_head(&self, peer: impl Into<String>, event: impl Into<String>, height: u64, hash: Option<[u8; 32]>, detail: impl Into<String>) {
        self.metrics.trace_head(peer, event, height, hash, detail);
    }

    /// The active sync path has no separate state-service thread. Header
    /// advancement is observed directly by the downloader/verifier stages, so
    /// there is no gate thread to poke. Kept as a compatibility no-op for
    /// callers that used the old state-gate API.
    pub fn poke(&self) {}
}

/// Block hash: double SHA-256 over the header including its Equihash solution.
pub fn block_hash(raw: &[u8]) -> Option<[u8; 32]> {
    use sha2::{Digest, Sha256};
    let mut cursor = 140usize;
    let solution_len = read_compact_size(raw, &mut cursor)? as usize;
    let end = cursor.checked_add(solution_len)?;
    let header = raw.get(..end)?;
    let digest = Sha256::digest(Sha256::digest(header));
    let mut out = [0u8; 32];
    out.copy_from_slice(&digest);
    Some(out)
}

fn read_compact_size(raw: &[u8], cursor: &mut usize) -> Option<u64> {
    let first = *raw.get(*cursor)?;
    *cursor += 1;
    let value = match first {
        0xfd => {
            let v = u16::from_le_bytes(raw.get(*cursor..*cursor + 2)?.try_into().ok()?) as u64;
            *cursor += 2;
            v
        }
        0xfe => {
            let v = u32::from_le_bytes(raw.get(*cursor..*cursor + 4)?.try_into().ok()?) as u64;
            *cursor += 4;
            v
        }
        0xff => {
            let v = u64::from_le_bytes(raw.get(*cursor..*cursor + 8)?.try_into().ok()?);
            *cursor += 8;
            v
        }
        n => n as u64,
    };
    Some(value)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transport_settings_stay_inside_their_bounds() {
        let cfg = SyncConfig::default();
        assert_eq!(cfg.blocks_in_transit_per_peer, 16);
        assert_eq!(cfg.max_blocks_in_flight, VERIFIER_QUEUE_CAPACITY);
        assert_eq!(cfg.prospective_capacity, BLOCK_DOWNLOAD_WINDOW);
        assert_eq!(cfg.download_window(), BLOCK_DOWNLOAD_WINDOW);
        assert_eq!(cfg.verifier_queue, HOT_VERIFIER_QUEUE_CAPACITY);
        assert_eq!(cfg.verifier_workers, VERIFIER_WORKERS);
        assert_eq!(cfg.script_workers, SCRIPT_WORKERS);
        // Four verifier lanes plus the two reserved roles and one remaining
        // housekeeping slot. The exact runtime CPU availability is device-specific.
        assert_eq!(VERIFIER_WORKERS + RESERVED_CORES + 1, 7);
        assert!(SCRIPT_WORKERS <= VERIFIER_WORKERS + 1);
    }

    #[test]
    fn the_window_covers_every_batch_that_can_hold_claims_at_once() {
        // Queued + in-pipeline + assembling. If the window were any smaller the
        // gate could not fill its ready queue: every claim would already be
        // held by a batch further down the pipeline, and the network would go
        // idle until a commit released some.
        assert_eq!(PIPELINE_BATCH_SIZE, 16);
        assert_eq!(INTAKE_READY_BATCHES, 4);
        assert_eq!(BLOCK_DOWNLOAD_WINDOW, 2_048);
    }

    #[test]
    fn the_claim_capacity_always_exceeds_the_download_window() {
        // The liveness invariant. Every claim sits at a height inside the
        // window, so if capacity == window the gate can hold the whole window
        // waiting for one missing height and leave no slot to request it.
        let cfg = SyncConfig::default();
        assert!(GAP_RESERVE_BLOCKS >= PIPELINE_BATCH_SIZE);
        assert!(VERIFIER_QUEUE_CAPACITY > BLOCK_DOWNLOAD_WINDOW);
        assert!(cfg.download_window() < cfg.max_blocks_in_flight);
        assert_eq!(cfg.max_blocks_in_flight - cfg.download_window(), GAP_RESERVE_BLOCKS);
    }

    #[test]
    fn compact_size_decodes_every_width() {
        let mut c = 0;
        assert_eq!(read_compact_size(&[0x10], &mut c), Some(0x10));
        c = 0;
        assert_eq!(read_compact_size(&[0xfd, 0x01, 0x02], &mut c), Some(0x0201));
        c = 0;
        assert_eq!(read_compact_size(&[0xfe, 1, 0, 0, 0], &mut c), Some(1));
    }
}
