# YORTAL v0.45.16 — assembler / continuous-flow audit

## Finding

The ordered assembler itself was enforcing the correct 16-block ordering, but the
next stage added a throughput-killing admission barrier:

- The assembler could have 3 complete batches ready.
- The fourth batch could be waiting on one missing height.
- The cryptographic dispatcher deliberately refused to consume any of the first
  3 batches until `ready_batches >= 4`.
- This created the exact device state: blocks held in the assembler, a visible
  batch gap, and idle verification despite completed work being available.

The four-batch depth is useful as a prefetch target, but it must not be a start
condition.

## Changes made

### 1. Non-blocking four-batch prefill

The dispatcher now consumes the next complete ordered batch as soon as one exists.
The ready channel remains bounded at four batches, so the assembler still pre-fills
ahead whenever the network is faster than verification.

Old flow:

`network -> assemble 16 -> wait for 64 ready -> verify -> state -> commit`

New flow:

`network -> assemble 16 -> verify immediately -> state -> commit`

while the assembler keeps filling the next ready batches in the background.

### 2. Preserve the hard ordering boundary

The performance change does **not** weaken consensus ordering:

- Normal batches remain exactly 16 blocks.
- Heights must be contiguous and ascending.
- The batch entry parent linkage is checked before release.
- The verifier still requires every result in the batch before the batch advances.
- Canonical publication remains ordered and atomic.
- Only the actual chain tail may be shorter than 16.

### 3. Faster missing-height recovery

The batch-gap hedge delay is reduced from 4s to 2s. A missing height is a hard
head-of-line blocker, so it should be reassigned sooner than ordinary lookahead
work.

The existing no-reservation hand-off remains in place: once a stalled gap claim
is released, another peer can take the lowest missing height without waiting for
a dedicated reservation window.

### 4. CI regression guard

`tools/verify-assembler-prefill.sh` now fails if the old hard four-batch admission
loop is reintroduced. It explicitly checks for immediate batch admission while
retaining the four-batch queue bound.

## Why this fixes the screenshot condition

The screenshot shows a 3/4 ready state with 57 blocks held and a single missing
height. Under the old logic, the three already-complete batches could not run
because the fourth was incomplete.

Under the new logic:

1. Batch N is verified immediately.
2. Batch N+1 is consumed immediately when ready.
3. Batch N+2 is consumed immediately when ready.
4. The assembler can continue holding/filling Batch N+3 while verification is
   already running.
5. If the missing block finally arrives, it completes the prefill queue rather
   than unblocking an otherwise idle verifier.

This turns the four-batch depth into useful read-ahead instead of a barrier.

## Bottleneck assessment

The supplied runtime numbers indicate the old stall was transport/assembly
head-of-line blocking, not database commit capacity. A 28.68 ms full ordered
commit corresponds to roughly 558 blocks/s of commit capacity for 16-block
commits, while the dashboard reported a fetch/batch-gap bottleneck.

Therefore, increasing commit or verifier concurrency would not have solved the
specific stall shown. The correct first optimization is to remove the admission
barrier and shorten missing-height recovery.

## Recommended steady-state architecture

`P2P peers`
`  -> asynchronous block arrivals`
`  -> ordered assembler (16-block contiguous batches)`
`  -> bounded ready queue (target 4, capacity 4)`
`  -> 4-worker cryptographic verification`
`  -> 1 ordered state-preparation worker`
`  -> 1 canonical commit writer`

The stages overlap across different batches, but each individual batch retains
strict height ordering and the commit stage remains canonical and serial.

## Further optimization opportunities

These are secondary because they are not the cause of the screenshot stall:

1. Keep the assembler's current bounded structure. Replacing its `BTreeMap` with a
   fixed-slot ring could remove a little locking/allocation overhead, but that is
   micro-optimization compared with network latency.
2. Measure ready-queue occupancy over time. A persistent 0–1 ready depth means the
   network is the limiter; a persistent 4 means the network is ahead and the
   verifier/state stages should be profiled instead.
3. Keep adaptive gap hedging based on queue starvation. A gap while there are
   zero ready batches should recover more aggressively than a gap while several
   complete batches are already queued.
4. Do not increase the batch size above 16 merely to hide the gap. Larger batches
   would increase proof/verification and retry granularity and would not solve
   a single missing-block head-of-line stall.

## Validation performed in this environment

- `tools/verify-assembler-prefill.sh`: PASS.
- Static diff reviewed for the dispatcher, assembler, gap recovery and CI guard.
- Full Rust compilation/tests could not be run here because the container does
  not have `cargo`/`rustc` installed.
