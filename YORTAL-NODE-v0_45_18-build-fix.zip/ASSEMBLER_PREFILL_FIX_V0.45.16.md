# YORTAL v0.45.16 — assembler four-batch prefill fix

The intake assembler remains the hard ordering boundary before cryptographic verification.

## Enforced invariants

- Normal pipeline batches contain exactly 16 blocks.
- The assembler stores arrivals by height and releases only the exact consecutive
  `next_height .. next_height + 15` sequence.
- Before a batch enters cryptographic verification, the dispatcher requires
  `ready_batches >= 4` during normal operation.
- The ready queue is still bounded to four complete batches; the target is used for
  telemetry/prefill, not to delay progress.
- At a chain tip where fewer than four batches can possibly exist, the watermark
  is reduced to the number of remaining batches. The final short contiguous tail
  remains explicitly marked as `tail` and is the only allowed non-16-block batch.
- Runtime telemetry now exposes `ready_batches` and `ready_batch_target` so the
  Android status endpoint can show the actual prefill state.
- A CI verifier (`tools/verify-assembler-prefill.sh`) checks the key source-level
  invariants and prevents the four-batch watermark from being removed accidentally.

## Steady-state flow

`network -> assembler -> first complete ordered batch -> verification -> state preparation -> commit`, while the assembler continuously pre-fills up to four ready batches ahead.

When one ready batch is consumed, the dispatcher immediately takes the next ready batch if present; the assembler replenishes the queue toward four in the background.
