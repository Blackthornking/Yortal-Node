# Build fix — v0.45.16 prefetch continuous flow

Host compile check failed in `ycash-node` (8 errors). Fixed:

- `crates/node/src/lib.rs`: import `std::thread` and the `anyhow!` macro (drop unused `bail`) for the prefetch promoter thread.
- `crates/node/src/lib.rs` (`missing_heights`): `header_hashes_range` already returns `[u8; 32]`; removed the `hash32` conversion.
- `crates/node/src/downloader.rs` (`assign_heights`): same — hash and work from the range reads are already `[u8; 32]`.
- `crates/node/src/verifier.rs` (`VerifierPool::spawn`): parameter renamed `_queue_depth` → `queue_depth` (it is now used) and `PIPELINE_BATCH_SIZE` qualified as `crate::`.

No behaviour change.
