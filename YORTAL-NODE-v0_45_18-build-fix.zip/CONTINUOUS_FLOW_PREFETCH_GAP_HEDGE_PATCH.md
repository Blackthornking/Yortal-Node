# Continuous-flow prefetch + gap-hedge patch

## Purpose

Fix the recurring Android sync stall where the ordered 16-block assembler waits on one missing height while later blocks accumulate in RAM.

## Pipeline shape

- Consensus batch remains **16 blocks**.
- Four complete 16-block batches remain the normal ready watermark; this is a prefill target, not a start barrier.
- Four persistent cryptographic verifier workers remain unchanged.
- The acquisition reservoir is expanded to **2048 blocks / 2 GiB** and is disk-backed.
- The hot verifier queue remains **128 blocks**; blocks beyond it stay in the disk reservoir.
- The global lifecycle bound is **2064 claims** (2048 read-ahead + 16 gap reserve).
- Each peer remains limited to **16 normal block requests**; the gap may use one priority slot beyond that peer's normal window.

## Gap handling

The assembler promotes only a contiguous run starting at `intake_expected_height`. If one height is missing, later heights remain on disk instead of being promoted to the RAM assembler.

A hard gap is retried through sequential peer hand-off at approximately **1 s, 2 s, and 4 s**. A nominated peer gets a reserved lifecycle hand-off that the socket loop converts into a transport claim, avoiding duplicate lifecycle entries. Peer selection prefers lower timeout counts and lower in-flight load and filters recent hash-specific failures.

## Telemetry

The Android diagnostics now exposes:

- disk prefetch block count and bytes
- contiguous staged blocks ahead of the intake frontier
- current batch-gap age
- cumulative gap hedges

The JSON/status API exposes the same fields for automated diagnostics.

## Validation performed in this environment

- Static assembler/prefetch/gap-hedge verification script passes.
- Shell syntax for the verification script passes.
- Android layout XML parses successfully.
- `config/pipeline.toml` parses successfully and contains the intended 2048/2064/16 settings.
- The Android status JSON `format!` call was structurally checked: 220 `{}` placeholders and 220 format arguments.

A full Rust/Android build was not run because this container does not have `cargo`, `rustc`, `rustfmt`, or `gradle` installed.
