# v0.45.16 — gap-hedge fix (sync crawling at 0.5–3.5 blocks/s)

Device (0.45.15): COM 640, gate holding 114–118 blocks, waiting on one
block (684, then 690) for many seconds; 0.5–3.5 blocks/s on tiny blocks.

Cause (introduced in 0.45.9): when a late block was taken from its peer, it
was reserved for one nominated peer for 2s and every other peer skipped it.
With the window full, the one claim slot freed for that block was taken by a
later height, so nobody could request the missing block until the 20s
starvation valve fired. Head recovery used the same reservation and had the
same problem. 0.45.15 made it worse by hedging every 2s.

Fix:
- No reservation: a released block is simply the lowest unclaimed height, so
  the next peer asking for work takes it first with the freed slot.
- Only the peer that stalled on it is kept off that block, for 5s, and it
  stops rather than skipping ahead, so it cannot take the freed slot either.
- Hedge delay back to 4s; head retry back to 8s (0.45.14 values).
- Header throttle from 0.45.15 kept.
