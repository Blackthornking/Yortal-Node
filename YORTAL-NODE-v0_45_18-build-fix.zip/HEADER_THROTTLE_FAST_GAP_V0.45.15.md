# v0.45.15 — sync speed regression fix

Symptom (0.45.14 on device): HDR 6560 while COM 3472; 122 blocks held in the
16-block gate, 7 in flight, window full (DL = COM + 128), verification idle,
bottleneck FETCH / BATCH GAP, 32 blocks/s live vs 562 blocks/s of commit
capacity. The pipeline was waiting on single late blocks, not on CPU.

1. Header sync throttle restored (sync_coordinator.rs). Unthrottled header
   sync (since 0.45.8) passed header ownership from peer to peer on every
   loop, so some peer was always busy with getheaders round trips while
   holding block requests the gate needed. Headers now run until 2048 ahead
   of the committed tip and resume below 1024 ahead (the old resume point
   was 512 and was blamed for "headers stopping"). Always >= 8x the
   128-block download window.
2. Missing batch block re-requested from another peer after 2s (was 4s).
3. Canonical head (tip+1) retried after 4s (was 8s; still backs off up to 30s
   for repeated failures).
