# YORTAL v0.45.16 — 1024-block continuous acquisition / disk-backed prefetch

## Objective

Keep the network continuously acquiring future blocks without making the consensus pipeline hold thousands of full blocks in RAM.

## Changes

- Network download horizon is now **1024 blocks**.
- Per-peer block request limit remains **16**.
- Global lifecycle claim capacity is **1040** (1024 horizon + 16 gap reserve).
- The verifier hot intake queue is bounded to **128 full blocks**.
- Downloaded blocks are written to an ephemeral, atomic, disk-backed prefetch cache.
- The prefetch cache defaults to **1024 MiB**, configurable with `YORTAL_PREFETCH_MAX_MB`.
- Cache directory is configurable with `YORTAL_PREFETCH_DIR`; otherwise it is derived from `YCASH_NODE_DB`.
- A promoter thread moves only the next hot blocks from disk into the verifier queue.
- Cached blocks are rechecked against the current header hash before promotion.
- Network transport slots are refilled immediately after a block is received.
- Missing-height selection now loads header hashes in bulk instead of performing one DB lookup per height.
- Explicit batch-height assignment now bulk-loads hashes, work, and MTP instead of repeatedly querying the DB for each block.
- Existing four-batch assembler prefill remains a target, not a hard admission barrier.
- The existing 12-peer outbound supervisor is retained; it can supply up to 192 simultaneous per-peer block requests at the 16/peer protocol limit.

## Flow

```text
                 headers
                    |
                    v
             1024-block horizon
                    |
        +-----------+-----------+
        |       up to 12 peers |
        |       16 each        |
        +-----------+-----------+
                    |
                    v
          disk-backed prefetch
                    |
             next 128 hot blocks
                    |
                    v
             ordered assembler
                    |
              exact 16 blocks
                    |
                    v
              4 verifier lanes
                    |
                    v
             ordered state prep
                    |
                    v
              one canonical commit
```

## Why 1024 instead of thousands in RAM?

The current Zcash P2P specification defines a 1024-block download window and a 16-block per-peer in-flight limit. A 1024-block raw-block RAM buffer could consume roughly 2 GiB at a 2 MiB/block worst case. The implementation therefore uses disk staging for the network horizon and keeps only a small hot queue in memory.

## Safety properties

- Download order is not consensus order; all blocks still pass the existing semantic verifier.
- The assembler still releases only contiguous 16-block batches (except the chain tail).
- Canonical state publication remains ordered and serialized.
- The lifecycle registry prevents duplicate requests while a block is transport, prefetched, verifying, verified, or queued.
- A cache entry is only promoted if its hash matches the current header at that height.
- Prefetch is ephemeral and is cleared on process startup to avoid reusing stale bytes after restart.

## Verification performed in this container

- `tools/verify-assembler-prefill.sh` — PASS.
- `tools/verify-ordered-48-batch-v0.34.1.sh` — PASS.
- Full Rust compilation/tests could not be run because this container does not have `cargo`, `rustc`, or `rustfmt` installed.
- The Android packaging verifier requires a built ARM64 native library and therefore was not a valid source-only test in this environment.
