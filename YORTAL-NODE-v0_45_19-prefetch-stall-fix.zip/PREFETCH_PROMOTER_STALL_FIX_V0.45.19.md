# v0.45.19 — prefetch promoter stall fix

## Symptom (live, v0.45.18)
Height 0, "Pipeline: waiting for block 2 to complete the 16-block batch · 1 held · disk 2031 · hedges 0",
contiguous staged ahead 0, last commit "never this run", 0.0 blocks/s. Nothing ever reached commit.

## Cause
The prefetch promoter called `take_contiguous(intake_frontier, 64)`. The frontier (block 1) was
promoted alone because block 2 had not landed yet. From then on block 1 was no longer on disk, so
every later call stopped immediately at height 1 and returned nothing. Block 2 (and 3..2032) arrived
on disk and were never promoted. The gate waited forever for block 2.

The gap hedge could not help: block 2's claim was in the `Prefetched` state, not `Transport` or a
hand-off reservation, so `hedge_gap_once` returned without acting (hedges stayed 0). The download
window was full of prefetched claims, so nothing was fetched either.

## Fix
- `prefetch.rs`: new `take_window(lo, span)` promotes every cached height in `lo..lo+span`, holes
  skipped. Still bounded to 64 blocks ahead of the frontier, so a real hole cannot spill the disk
  reservoir into RAM. New `lowest_from()` for diagnostics. Regression test added.
- `lib.rs` promoter: uses `take_window`; "contiguous staged ahead" now measured from the lowest
  cached height instead of the (already promoted) frontier, so it no longer reads 0 while 2000
  blocks sit on disk.

No consensus changes.
