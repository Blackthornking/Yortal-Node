# Changelog

Detailed per-version notes live in `docs/notes/`.

## 0.45.20 — pipeline reconciler and audit fixes
Gap reconciler repairs lost gap blocks in any lifecycle state; head watchdog
respects blocks held by the gate; head/gap may use two overflow claim slots;
header lead raised to 32768 with adaptive batches; promoter sleeps instead of
polling; real CPU/memory pressure; STALLED state with a stall report; host CI;
versions from BUILD_ID.txt. See `docs/notes/PIPELINE_RECONCILER_AUDIT_FIXES_V0.45.20.md`.

## 0.45.19 — prefetch promoter stall fix
Promoter takes every cached block in the gate's window instead of a run
anchored at an already-promoted frontier (node stuck at height 0 with 2031
blocks on disk). See `docs/notes/PREFETCH_PROMOTER_STALL_FIX_V0.45.19.md`.

## 0.45.18 and earlier
See `docs/notes/` (BUILD_FIX_*, *_V0.45.*, and older phase notes).
