//! Semantic (context-free) verification.
//!
//! Verification owns the expensive consensus work. Context-free checks start
//! as soon as each block reaches the bounded hot intake queue; the network may
//! stage up to 2048 blocks ahead on disk without expanding RAM usage.
//! results are retained by height until the complete exact window is ready. The
//! ordered commit worker then performs state-dependent transaction/script
//! preparation against a consistent snapshot. Only the resulting prepared
//! mutation plan crosses into canonical publication.
//!
//! Canonical publication is deliberately not a validation stage: it only
//! rechecks the prepared parent/tip and atomically writes the prepared state.

use std::collections::BTreeMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::mpsc::{sync_channel, RecvTimeoutError, SyncSender};
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use anyhow::{anyhow, bail, Result};
use ycash_chain::txid;
use ycash_consensus::{validate_for_commit_batched_with_parsed, Context, ProofBatch};
use ycash_state::prospective::SemanticBlock;
use ycash_state::State;
use ycash_state::state_service::SyncMetrics;
use ycash_state::BlockCommit;

use crate::batch::{verify_batch_in_order, BatchAssembler};
use crate::downloader::{BlockRequest, InFlightRegistry};

/// Optional assume-valid checkpoint, carried over unchanged. Full verification
/// is the default; this is used only when YCASH_ASSUME_VALID=1 and the verified
/// header at the checkpoint height matches.
pub const ASSUME_VALID_HEIGHT: u64 = 2_250_000;
pub const ASSUME_VALID_HASH_DISPLAY: &str =
    "000003f98b7497fdcd8a6b6d10a93a887c5d47127e24a9dc3a40cb65754d21e7";

/// Blocks a verifier thread folds into one Groth16 batch.
///
/// The batch identity costs one final exponentiation regardless of how many
/// proofs it holds, so a bigger batch amortises it better. One block per batch
/// wastes that on blocks with few shielded transactions. Grouping is bounded
/// rather than unlimited because a worker only groups what has *already*
/// arrived: it never waits for more blocks, so latency at the chain tip is
/// unchanged.
///
/// This is a scheduling constant. It changes how proofs are grouped for
/// verification, never which proofs must verify.
pub const MAX_BLOCKS_PER_PROOF_BATCH: usize = crate::PIPELINE_BATCH_SIZE;

/// A downloaded block with the header context its verification needs.
#[derive(Debug)]
pub struct RawBlock {
    pub request: BlockRequest,
    pub raw: Vec<u8>,
    /// Peer that supplied the block. Diagnostic provenance only.
    pub source_peer: String,
}

/// Result of one verifier attempt with enough provenance to close the block
/// lifecycle exactly once.
pub struct VerifyOutcome {
    pub height: u64,
    pub hash: [u8; 32],
    pub source_peer: String,
    pub result: Result<SemanticBlock>,
}

/// Work handed from the verifier coordinator to the single ordered commit
/// owner. Keeping this on a dedicated worker prevents the coordinator from
/// blocking on the expensive state-preparation/write path: it can return to
/// multiplexing verifier completions immediately while canonical publication
/// remains strictly serialized. The lifecycle window is still exactly 16.
struct CommitRequest {
    batch_id: u64,
    commits: Vec<BlockCommit>,
    received: BTreeMap<u64, RawBlock>,
}

/// The prev-hash field of a block header, read straight from the wire bytes.
///
/// Header layout: version(4) | prev(32) | merkle(32) | final Sapling root(32) |
/// time(4) | bits(4) | nonce(32) | solution.
pub fn header_prev(raw: &[u8]) -> Result<[u8; 32]> {
    if raw.len() < 36 {
        bail!("block is too short to contain a header");
    }
    let mut prev = [0u8; 32];
    prev.copy_from_slice(&raw[4..36]);
    Ok(prev)
}

/// Run every context-free consensus check for one block.
///
/// This is the same entry point the previous pipeline used, called with the
/// same arguments for the same block; only the surrounding scheduling changed.
pub fn semantic_verify(block: RawBlock, assume_valid: bool) -> Result<SemanticBlock> {
    let RawBlock { request, raw, .. } = block;
    let height = request.height;
    let ctx = Context {
        height,
        prev_height: height.saturating_sub(1),
        median_time_past: request.median_time_past,
    };
    let assume_valid = assume_valid && height <= ASSUME_VALID_HEIGHT;

    // Sapling proofs in one block share a batch: one multi-Miller loop per
    // verifying key rather than one pairing check per proof. A rejection is
    // re-checked by the single-proof verifier, whose result is final.
    let mut proofs = ProofBatch::new();
    let (validated, parsed_txs) = validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, &mut proofs)
        .map_err(|e| anyhow!("block {height}: {e:?}"))?;
    if proofs.proofs() > 0 {
        if let Err((h, e)) = proofs.finish() {
            bail!("block {h}: {e:?}");
        }
    }
    if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
        bail!("block {height}: consensus decoder returned inconsistent transaction data");
    }

    let prev = header_prev(&raw)?;
    let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
    let precomputed_txs: Vec<ycash_script::PrecomputedTxData> =
        parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();

    Ok(SemanticBlock::from_commit(BlockCommit {
        height,
        hash: request.hash,
        prev,
        work: request.work,
        raw,
        txs,
        parsed_txs,
        precomputed_txs,
        proofs_verified: true,
    }))
}

/// Verify a group of blocks, folding every Sapling proof in the group into one
/// batch.
///
/// On batch rejection each block is re-verified on its own. The batch says only
/// that something in the set is bad, never which block, so a batch verdict is
/// never reported as a per-block result.
pub fn verify_group(blocks: Vec<RawBlock>, assume_valid: bool) -> Vec<VerifyOutcome> {
    if blocks.len() == 1 {
        let mut blocks = blocks;
        let block = blocks.remove(0);
        let height = block.request.height;
        let hash = block.request.hash;
        let source_peer = block.source_peer.clone();
        return vec![VerifyOutcome { height, hash, source_peer, result: semantic_verify(block, assume_valid) }];
    }

    let mut batch = ProofBatch::new();
    let mut staged: Vec<Result<SemanticBlock>> = Vec::with_capacity(blocks.len());
    let mut retained: Vec<RawBlock> = Vec::with_capacity(blocks.len());
    for block in blocks {
        let raw_for_retry = RawBlock {
            request: block.request.clone(),
            raw: block.raw.clone(),
            source_peer: block.source_peer.clone(),
        };
        retained.push(raw_for_retry);
        staged.push(verify_into_batch(block, assume_valid, &mut batch));
    }

    if batch.proofs() > 0 {
        if let Err((height, e)) = batch.finish() {
            // Isolate: re-verify every block in the group individually. The
            // lifecycle remains owned throughout this retry; no transport
            // request can be issued for any member while isolation runs.
            eprintln!("[VERIFY] proof batch rejected at height {height} ({e:?}); isolating {} blocks", retained.len());
            return retained
                .into_iter()
                .map(|raw| {
                    let height = raw.request.height;
                    let hash = raw.request.hash;
                    let source_peer = raw.source_peer.clone();
                    VerifyOutcome { height, hash, source_peer, result: semantic_verify(raw, assume_valid) }
                })
                .collect();
        }
    }

    retained
        .into_iter()
        .zip(staged)
        .map(|(raw, result)| VerifyOutcome {
            height: raw.request.height,
            hash: raw.request.hash,
            source_peer: raw.source_peer,
            result,
        })
        .collect()
}

/// Every context-free check for one block except the Groth16 pairing, which is
/// queued into the caller's batch.
pub(crate) fn verify_into_batch(block: RawBlock, assume_valid: bool, batch: &mut ProofBatch) -> Result<SemanticBlock> {
    let RawBlock { request, raw, .. } = block;
    let height = request.height;
    let ctx = Context {
        height,
        prev_height: height.saturating_sub(1),
        median_time_past: request.median_time_past,
    };
    let assume_valid = assume_valid && height <= ASSUME_VALID_HEIGHT;
    let (validated, parsed_txs) = validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, batch)
        .map_err(|e| anyhow!("block {height}: {e:?}"))?;
    if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
        bail!("block {height}: consensus decoder returned inconsistent transaction data");
    }
    let prev = header_prev(&raw)?;
    let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
    let precomputed_txs: Vec<ycash_script::PrecomputedTxData> =
        parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();
    Ok(SemanticBlock::from_commit(BlockCommit {
        height,
        hash: request.hash,
        prev,
        work: request.work,
        raw,
        txs,
        parsed_txs,
        precomputed_txs,
        proofs_verified: true,
    }))
}

/// Strict pipeline reset.
///
/// Every batch carries the epoch it was assembled in. When any stage rejects a
/// block, rejects a batch, or fails to publish, that stage bumps the epoch and
/// records the canonical tip + 1 as the new start. Every other stage then
/// throws away everything it is holding above the tip and starts again from
/// that height.
///
/// This is what makes the pipeline strict. There is no side lane that carries
/// a single block past the intake gate: a height that has to be fetched again
/// comes back through a complete, ordered, full batch exactly like every other
/// height. Nothing partial ever moves.
struct PipelineReset {
    epoch: AtomicU64,
    resume_from: AtomicU64,
    /// Consecutive resets with no successful publication in between. Used only
    /// to stop a deterministic rejection becoming a hot download/verify loop.
    failures: AtomicU64,
}

impl PipelineReset {
    fn new(resume_from: u64) -> Self {
        Self {
            epoch: AtomicU64::new(1),
            resume_from: AtomicU64::new(resume_from),
            failures: AtomicU64::new(0),
        }
    }

    fn epoch(&self) -> u64 {
        self.epoch.load(Ordering::SeqCst)
    }

    fn resume_from(&self) -> u64 {
        self.resume_from.load(Ordering::SeqCst)
    }

    /// Discard everything above `from - 1` and restart every stage there.
    ///
    /// The resume height is stored before the epoch is bumped, so any stage
    /// that observes the new epoch is guaranteed to read the matching height.
    /// Returns how long the caller should pause before continuing.
    fn request(&self, from: u64) -> Duration {
        self.resume_from.store(from, Ordering::SeqCst);
        self.epoch.fetch_add(1, Ordering::SeqCst);
        let streak = self.failures.fetch_add(1, Ordering::SeqCst).saturating_add(1);
        failure_backoff(streak.min(u32::MAX as u64) as u32)
    }

    /// A batch was published: the pipeline is healthy again.
    fn settled(&self) {
        self.failures.store(0, Ordering::SeqCst);
    }
}

/// A complete, contiguous, ordered batch leaving the intake gate.
///
/// Nothing else can reach the verifier workers. A batch that is short one block
/// does not exist as far as the rest of the pipeline is concerned: it stays in
/// the gate until the missing height is fetched.
struct IntakeBatch {
    epoch: u64,
    first_height: u64,
    last_height: u64,
    /// Ascending by height, contiguous, no gaps.
    blocks: Vec<RawBlock>,
    /// Only ever true for the short run at the very end of the chain, where a
    /// full batch cannot exist because there are no further blocks. The run is
    /// still complete and contiguous.
    tail: bool,
}

/// A batch in which every single block passed cryptographic verification.
///
/// A batch with any rejection in it is never built: the whole batch is dropped
/// and the pipeline resets, so the preparation worker can only ever be handed a
/// complete verified sequence.
struct CryptoVerified {
    epoch: u64,
    first_height: u64,
    last_height: u64,
    hashes: Vec<[u8; 32]>,
    blocks: Vec<SemanticBlock>,
}

/// Exact cryptographic verification batch.
///
/// Four shared verifier workers dynamically consume the 16 blocks in this
/// batch. The dispatcher waits for all 16 results before taking the next batch,
/// preserving a hard batch boundary without assigning fixed heights to
/// individual workers.
pub const VERIFICATION_BATCH_SIZE: usize = crate::PIPELINE_BATCH_SIZE;

/// Complete batches the intake gate keeps queued ahead of verification, so the
/// verifier workers always have a full batch waiting when they finish one.
pub const INTAKE_READY_BATCHES: usize = crate::INTAKE_READY_BATCHES;

/// Total block lifecycle claims: the download window. Wide enough to hold the
/// ready queue, the batches inside the pipeline, and one batch being assembled.
pub const VERIFIER_QUEUE_CAPACITY: usize = crate::VERIFIER_QUEUE_CAPACITY;

/// How long the gate waits with no new arrival before it accepts that the run
/// it holds reaches the end of the chain and publishes it short.
const TAIL_FLUSH_DELAY: Duration = Duration::from_secs(3);

/// How often the gate wakes when no block arrives, to notice a reset and to
/// refresh its telemetry.
const INTAKE_POLL: Duration = Duration::from_millis(250);

/// How long the gate tolerates holding a gap with no claim slot left to fetch
/// it before it starts giving slots back. See `crate::GAP_RESERVE_BLOCKS`: the
/// window is sized so this cannot happen, but a stall here is permanent, so the
/// valve stays.
const STARVATION_TIMEOUT: Duration = Duration::from_secs(20);

/// Decrement a counter without ever wrapping below zero. The dashboard's queue
/// figure is diagnostic only, but a wrapped counter would show ~1.8e19 blocks.
pub(crate) fn now_unix_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

fn metrics_set_intake_frontier(metrics: &SyncMetrics, expected_first: u64) {
    metrics.intake_expected_height.store(expected_first, Ordering::Release);
}

fn saturating_dec(counter: &AtomicU64) {
    let _ = counter.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |v| Some(v.saturating_sub(1)));
}

/// Publish the latest pipeline failure for the dashboard. The coordinator shows
/// it only while the canonical tip is still the height recorded here.
fn record_failure(metrics: &SyncMetrics, tip: u64, text: String) {
    let text: String = text.replace('\n', " ").chars().take(300).collect();
    if let Ok(mut slot) = metrics.last_pipeline_failure.lock() {
        *slot = text;
    }
    metrics.last_pipeline_failure_tip.store(tip, Ordering::Relaxed);
}

/// Pause between repeated failures so a deterministic rejection cannot turn
/// into a hot download/verify loop. The first two failures retry immediately;
/// after that the delay doubles from 250 ms up to 15 s. The pipeline is already
/// stalled at that height, so the pause costs nothing.
fn failure_backoff(streak: u32) -> Duration {
    if streak < 3 {
        return Duration::ZERO;
    }
    let shift = (streak - 3).min(6);
    Duration::from_millis(250u64 << shift).min(Duration::from_secs(15))
}

/// Best-effort text for a caught panic payload.
fn panic_text(payload: &(dyn std::any::Any + Send)) -> String {
    if let Some(text) = payload.downcast_ref::<&str>() {
        (*text).to_string()
    } else if let Some(text) = payload.downcast_ref::<String>() {
        text.clone()
    } else {
        "unknown panic".to_string()
    }
}

#[derive(Clone)]
pub struct VerifierPool {
    tx: SyncSender<RawBlock>,
    metrics: Arc<SyncMetrics>,
}

/// Desired prefill depth for the ready queue. This is a throughput target,
/// not a hard admission barrier: verification starts as soon as one complete
/// ordered batch exists, while the assembler keeps filling toward four ahead.
fn ready_batch_target_for_tip(next_height: u64, header_tip: u64) -> usize {
    if header_tip < next_height {
        return 1;
    }
    let remaining = header_tip.saturating_sub(next_height).saturating_add(1);
    let possible = ((remaining.saturating_add(VERIFICATION_BATCH_SIZE as u64 - 1))
        / VERIFICATION_BATCH_SIZE as u64) as usize;
    possible.clamp(1, INTAKE_READY_BATCHES)
}

fn ready_batch_target(state: &State, next_height: u64) -> usize {
    let header_tip = state.header_height().ok().flatten().unwrap_or(0);
    ready_batch_target_for_tip(next_height, header_tip)
}

impl VerifierPool {
    pub fn spawn(
        workers: usize,
        queue_depth: usize,
        chain: Arc<State>,
        metrics: Arc<SyncMetrics>,
        registry: Arc<InFlightRegistry>,
        assume_valid: bool,
    ) -> Result<Self> {
        // Fixed roles, in order:
        //
        //   network ──► intake gate (1 worker, assembles ordered full batches)
        //                  │  queue of INTAKE_READY_BATCHES complete batches
        //                  ▼
        //               dispatcher ──► 4 cryptographic verifier workers
        //                  │  (all 16 results required before the next batch)
        //                  ▼
        //               1 expensive state-preparation worker
        //                  ▼
        //               1 canonical commit worker (publication only)
        //
        // The gate is the hard boundary: verification cannot start on a batch
        // until every one of its 16 blocks has been fetched and is in hand.
        // The four cryptographic verifiers are one persistent Rayon pool,
        // built once here and kept for the life of the process. Previously
        // they were scoped OS threads spawned per 16-block batch and joined
        // at its end, so between batches there were literally no verifier
        // threads, and the dashboard's 4 → 0 was the truth.
        //
        // v0.45.11: this pool does verification and nothing else. Script
        // checks and all other state work belong to the separate two-worker
        // state pool (`ycash_state::chainstate::shared_pool`).
        let workers = if workers == 0 { crate::VERIFIER_WORKERS } else { workers.min(64) };
        let verify_pool: &'static rayon::ThreadPool = Box::leak(Box::new(crate::batch::build_verifier_pool(workers)?));
        let workers = verify_pool.current_num_threads();

        let start_height = match chain.tip_height() {
            Ok(Some(tip)) => tip.saturating_add(1),
            Ok(None) => 1,
            Err(e) => bail!("initial tip read failed: {e}"),
        };
        let reset = Arc::new(PipelineReset::new(start_height));

        let hot_queue = queue_depth.max(crate::PIPELINE_BATCH_SIZE).min(crate::HOT_VERIFIER_QUEUE_CAPACITY);
        let (intake_tx, intake_rx) = sync_channel::<RawBlock>(hot_queue);
        // The ready queue. Four complete batches wait here, so the verifier
        // never has to wait for the network between batches.
        let (dispatch_tx, dispatch_rx) = sync_channel::<IntakeBatch>(INTAKE_READY_BATCHES);
        // One verified batch may wait while the preparation worker is busy, so
        // the verifiers are not idle during state preparation and publication.
        let (verified_tx, verified_rx) = sync_channel::<CryptoVerified>(1);
        let (prepared_tx, prepared_rx) = sync_channel::<PreparedBatch>(1);
        let (commit_ack_tx, commit_ack_rx) = sync_channel::<bool>(1);
        metrics.verifier_workers.store(workers as u64, Ordering::Relaxed);

        // ── Stage 0: the intake gate ────────────────────────────────────────
        //
        // One worker. Arrivals are unordered by nature: peers answer at
        // different speeds. This worker sorts them by height and releases a
        // batch only when heights first..first+15 are ALL present. Up to
        // INTAKE_READY_BATCHES complete batches are queued behind it, so there
        // is always a batch ready for the verifiers.
        let intake_state = Arc::clone(&chain);
        let intake_metrics = Arc::clone(&metrics);
        let intake_registry = Arc::clone(&registry);
        let intake_reset = Arc::clone(&reset);
        thread::Builder::new()
            .name("yortal-16-block-intake-gate".into())
            .spawn(move || {
                let assembler = BatchAssembler::new(VERIFICATION_BATCH_SIZE);
                let mut epoch = intake_reset.epoch();
                let mut expected_first = intake_reset.resume_from();
                let mut tail_since: Option<Instant> = None;
                let mut starved_since: Option<Instant> = None;
                let mut observed_gap = 0u64;
                metrics_set_intake_frontier(&intake_metrics, expected_first);

                loop {
                    let arrival = match intake_rx.recv_timeout(INTAKE_POLL) {
                        Ok(block) => Some(block),
                        Err(RecvTimeoutError::Timeout) => None,
                        Err(RecvTimeoutError::Disconnected) => return,
                    };

                    // 1. Honour a reset before touching anything else.
                    let current = intake_reset.epoch();
                    if current != epoch {
                        epoch = current;
                        expected_first = intake_reset.resume_from();
                        tail_since = None;
                        starved_since = None;
                        observed_gap = 0;
                        metrics_set_intake_frontier(&intake_metrics, expected_first);
                        let dropped = assembler.clear();
                        for hash in &dropped {
                            intake_registry.release(hash);
                            saturating_dec(&intake_metrics.semantic_queue);
                        }
                        intake_metrics.trace_head(
                            "batch-intake",
                            "RESYNC",
                            expected_first,
                            None,
                            format!(
                                "pipeline reset: dropped {} held block(s); reassembling full batches from {}",
                                dropped.len(),
                                expected_first
                            ),
                        );
                    }

                    // 2. File the arrival. Anything below the barrier has
                    //    already gone through as part of a batch.
                    if let Some(block) = arrival {
                        let height = block.request.height;
                        if height < expected_first {
                            intake_registry.release(&block.request.hash);
                            saturating_dec(&intake_metrics.semantic_queue);
                            intake_metrics.duplicate_blocks.fetch_add(1, Ordering::Relaxed);
                        } else {
                            // A second copy of a height already held replaces
                            // the first. If it is the very same block the
                            // lifecycle claim is shared and must stay;
                            // otherwise the older claim is freed.
                            if let Some(old) = assembler.take(height) {
                                if old.request.hash != block.request.hash {
                                    intake_registry.release(&old.request.hash);
                                }
                                saturating_dec(&intake_metrics.semantic_queue);
                            }
                            let hash = block.request.hash;
                            if assembler.insert(block, expected_first) {
                                tail_since = None;
                            } else {
                                // Only reachable if the assembler lock is
                                // poisoned. Never leak the lifecycle claim.
                                intake_registry.release(&hash);
                                saturating_dec(&intake_metrics.semantic_queue);
                            }
                        }
                    }

                    // 3. Release every complete batch now held. One arrival can
                    //    complete several consecutive batches, because later
                    //    batches may already be sitting here waiting only on an
                    //    earlier one.
                    let mut released_any = false;
                    while let Some(blocks) = assembler.release_ready(expected_first) {
                        let first_height = expected_first;
                        let last_height =
                            blocks.last().map(|b| b.request.height).unwrap_or(first_height);
                        // Entry rule: the batch must be 16 ascending heights,
                        // each block's parent the block before it, and the
                        // first block's parent the validated header below the
                        // batch. Anything else never enters the pipeline: the
                        // whole batch is handed back to the downloader and the
                        // gate keeps waiting at the same height.
                        if let Some(reason) = batch_entry_error(&intake_state, first_height, &blocks) {
                            eprintln!("[INTAKE] batch {first_height}..{last_height} refused: {reason}");
                            intake_metrics.trace_head(
                                "batch-intake",
                                "REFUSED",
                                first_height,
                                blocks.first().map(|b| b.request.hash),
                                format!("batch {first_height}..{last_height} refused at entry: {reason}"),
                            );
                            for block in &blocks {
                                intake_registry.release(&block.request.hash);
                                saturating_dec(&intake_metrics.semantic_queue);
                            }
                            break;
                        }
                        expected_first = last_height.saturating_add(1);
                        released_any = true;
                        intake_metrics.trace_head(
                            "batch-intake",
                            "COMPLETE",
                            last_height,
                            blocks.first().map(|b| b.request.hash),
                            format!(
                                "complete ordered batch {}..{} ({} blocks, all fetched) released to verification",
                                first_height,
                                last_height,
                                blocks.len()
                            ),
                        );
                        if dispatch_tx
                            .send(IntakeBatch { epoch, first_height, last_height, blocks, tail: false })
                            .is_err()
                        {
                            return;
                        }
                        intake_metrics.ready_batches.fetch_add(1, Ordering::AcqRel);
                        metrics_set_intake_frontier(&intake_metrics, expected_first);
                    }
                    if released_any {
                        tail_since = None;
                    }

                    // 4. The end of the chain is the one place a full batch can
                    //    never arrive, because there are no further blocks. Once
                    //    the gate holds every remaining height up to the
                    //    validated header tip and nothing new has arrived for a
                    //    moment, release that short run. It is still strictly
                    //    complete and contiguous — no height inside it is
                    //    missing — it is simply shorter than 16.
                    let header_tip = intake_state.header_height().ok().flatten().unwrap_or(0);
                    let held = assembler.len();
                    let at_chain_end = held > 0
                        && header_tip >= expected_first
                        && header_tip
                            < expected_first.saturating_add(VERIFICATION_BATCH_SIZE as u64 - 1)
                        && assembler
                            .missing_heights(expected_first)
                            .into_iter()
                            .all(|h| h > header_tip);
                    if !at_chain_end {
                        tail_since = None;
                    } else {
                        let waiting = *tail_since.get_or_insert_with(Instant::now);
                        if waiting.elapsed() >= TAIL_FLUSH_DELAY {
                            tail_since = None;
                            if let Some(blocks) = assembler.flush_partial(expected_first) {
                                let first_height = expected_first;
                                let last_height = blocks
                                    .last()
                                    .map(|b| b.request.height)
                                    .unwrap_or(first_height);
                                expected_first = last_height.saturating_add(1);
                                intake_metrics.trace_head(
                                    "batch-intake",
                                    "CHAIN_TAIL",
                                    last_height,
                                    blocks.first().map(|b| b.request.hash),
                                    format!(
                                        "end of chain: complete contiguous run {}..{} ({} blocks) released short of {}",
                                        first_height,
                                        last_height,
                                        blocks.len(),
                                        VERIFICATION_BATCH_SIZE
                                    ),
                                );
                                if dispatch_tx
                                    .send(IntakeBatch {
                                        epoch,
                                        first_height,
                                        last_height,
                                        blocks,
                                        tail: true,
                                    })
                                    .is_err()
                                {
                                    return;
                                }
                                intake_metrics.ready_batches.fetch_add(1, Ordering::AcqRel);
                                metrics_set_intake_frontier(&intake_metrics, expected_first);
                            }
                        }
                    }

                    // 5. Telemetry: what the gate holds, and the lowest height
                    //    it is still waiting for the network to deliver.
                    let held = assembler.len();
                    intake_metrics.dispatch_pending.store(held as u64, Ordering::Relaxed);
                    // v0.45.20: publish exactly which heights are held, so the
                    // head watchdog never breaks the claim of a block that is
                    // sitting here waiting for its batch, and the gap
                    // reconciler can tell held from lost.
                    if let Ok(mut published) = intake_metrics.intake_held.lock() {
                        published.clear();
                        published.extend(assembler.held_heights());
                    }
                    intake_metrics.intake_heartbeat_unix_ms.store(now_unix_ms(), Ordering::Relaxed);
                    metrics_set_intake_frontier(&intake_metrics, expected_first);
                    let gap = if held == 0 {
                        0
                    } else {
                        assembler.missing_heights(expected_first).first().copied().unwrap_or(0)
                    };
                    intake_metrics.dispatch_gap_height.store(gap, Ordering::Relaxed);
                    if gap == 0 {
                        observed_gap = 0;
                        intake_metrics.dispatch_gap_since_unix_ms.store(0, Ordering::Relaxed);
                    } else if gap != observed_gap {
                        observed_gap = gap;
                        intake_metrics.dispatch_gap_since_unix_ms.store(now_unix_ms(), Ordering::Relaxed);
                    }

                    // 6. Liveness valve.
                    //
                    // Every lifecycle claim sits at a height inside the download
                    // window, so the gate hoarding the whole window while one
                    // height is missing would leave no claim slot to request
                    // that height: the gate holds, the verifiers idle and the
                    // node never moves again. `crate::GAP_RESERVE_BLOCKS` keeps
                    // the window strictly below the claim capacity so this
                    // cannot arise — but the failure is permanent and silent,
                    // so it is checked rather than assumed. The blocks furthest
                    // from the tip are the least useful thing being held, so
                    // their claims are the ones handed back.
                    if gap == 0 || intake_registry.spare_capacity() > 0 {
                        starved_since = None;
                    } else {
                        let waiting = *starved_since.get_or_insert_with(Instant::now);
                        if waiting.elapsed() >= STARVATION_TIMEOUT {
                            starved_since = None;
                            let freed = assembler.drop_highest(VERIFICATION_BATCH_SIZE);
                            for hash in &freed {
                                intake_registry.release(hash);
                                saturating_dec(&intake_metrics.semantic_queue);
                            }
                            intake_metrics.dispatch_pending
                                .store(assembler.len() as u64, Ordering::Relaxed);
                            eprintln!(
                                "[INTAKE] no claim slot left for missing height {gap}; dropped {} far-ahead block(s)",
                                freed.len()
                            );
                            intake_metrics.trace_head(
                                "batch-intake",
                                "GAP_STARVATION",
                                gap,
                                None,
                                format!(
                                    "held {} block(s) with no claim slot for missing height {}; released {} furthest-ahead block(s)",
                                    held,
                                    gap,
                                    freed.len()
                                ),
                            );
                        }
                    }
                }
            })
            .map_err(|e| anyhow!("failed to start 16-block intake gate: {e}"))?;

        // ── Stage 1: four-way batch verifier ────────────────────────────────
        //
        // The four worker threads are created per 16-block window by
        // `verify_batch_in_order`. They parallelise block parsing, signature
        // checks and proof preparation, then merge their deferred Sapling proof
        // queues before doing the single global Spend/Output batch verification.
        // Keeping the pairing boundary at the 16-block window is the important
        // change: no worker performs an isolated per-slice Groth16 batch.

        // ── Stage 1 dispatcher ──────────────────────────────────────────────
        //
        // Takes one complete batch from the ready queue, hands all of its
        // blocks to the four workers, and waits for EVERY result before taking
        // the next batch. A single rejection anywhere in the batch discards the
        // whole batch and resets the pipeline; a partly-verified batch is never
        // passed on.
        let dispatch_state = Arc::clone(&chain);
        let dispatch_metrics = Arc::clone(&metrics);
        let dispatch_registry = Arc::clone(&registry);
        let dispatch_reset = Arc::clone(&reset);
        let dispatch_pool = verify_pool;
        thread::Builder::new()
            .name("yortal-16-block-batch-dispatch".into())
            .spawn(move || {
                let mut epoch = dispatch_reset.epoch();
                let mut expected_first = dispatch_reset.resume_from();

                loop {
                    // Keep the four-batch prefill as a *target*, not a hard gate.
                    // Waiting for all four before starting verification creates the
                    // exact head-of-line stall seen on device: one missing block in
                    // batch N+4 leaves earlier complete batches idle behind it.
                    // The dispatcher therefore consumes the next complete batch
                    // immediately. The bounded channel still lets the assembler
                    // prefill to four whenever the network is fast enough.
                    let target = ready_batch_target(&dispatch_state, expected_first);
                    dispatch_metrics.ready_batch_target.store(target as u64, Ordering::Release);

                    let batch = match dispatch_rx.recv_timeout(Duration::from_millis(100)) {
                        Ok(batch) => batch,
                        Err(RecvTimeoutError::Timeout) => continue,
                        Err(RecvTimeoutError::Disconnected) => return,
                    };
                    dispatch_metrics.ready_batches.fetch_sub(1, Ordering::AcqRel);

                    let current = dispatch_reset.epoch();
                    if current != epoch {
                        epoch = current;
                        expected_first = dispatch_reset.resume_from();
                    }

                    // Work assembled before a reset is void.
                    if batch.epoch != epoch {
                        for block in &batch.blocks {
                            dispatch_registry.release(&block.request.hash);
                            saturating_dec(&dispatch_metrics.semantic_queue);
                        }
                        continue;
                    }

                    let count = batch.blocks.len();
                    dispatch_metrics.trace_head(
                        "crypto-batch",
                        "READY_POP",
                        batch.last_height,
                        batch.blocks.first().map(|b| b.request.hash),
                        format!(
                            "admitted batch {}..{} immediately; ready_batches remaining={} prefill_target={}",
                            batch.first_height,
                            batch.last_height,
                            dispatch_metrics.ready_batches.load(Ordering::Acquire),
                            dispatch_metrics.ready_batch_target.load(Ordering::Acquire)
                        ),
                    );
                    let shape_ok = count > 0
                        && (count == VERIFICATION_BATCH_SIZE || batch.tail)
                        && batch.first_height == expected_first
                        && batch.blocks.first().map(|b| b.request.height) == Some(batch.first_height)
                        && batch.blocks.last().map(|b| b.request.height) == Some(batch.last_height)
                        && batch
                            .blocks
                            .windows(2)
                            .all(|w| w[1].request.height == w[0].request.height.saturating_add(1));
                    if !shape_ok {
                        // The gate is the only producer, so this is an internal
                        // inconsistency rather than a network condition. Reset
                        // instead of killing the thread: a dead dispatcher
                        // stalls the node permanently.
                        eprintln!(
                            "[VERIFY] rejecting malformed batch {}..{} ({} blocks) at barrier {}",
                            batch.first_height, batch.last_height, count, expected_first
                        );
                        for block in &batch.blocks {
                            dispatch_registry.release(&block.request.hash);
                            saturating_dec(&dispatch_metrics.semantic_queue);
                        }
                        let tip = dispatch_state.tip_height().ok().flatten().unwrap_or(0);
                        let pause = dispatch_reset.request(tip.saturating_add(1));
                        dispatch_metrics.pipeline_retries.fetch_add(1, Ordering::Relaxed);
                        thread::sleep(pause);
                        continue;
                    }

                    dispatch_metrics.trace_head(
                        "crypto-batch",
                        "DISPATCH",
                        batch.last_height,
                        batch.blocks.first().map(|b| b.request.hash),
                        format!(
                            "complete batch {}..{} already in hand; {} blocks; global Sapling proof batch",
                            batch.first_height, batch.last_height, count
                        ),
                    );

                    // Captured before the blocks are moved to the workers:
                    // a rejection has to release every claim in the batch,
                    // including the ones that never produced a result.
                    let batch_hashes: Vec<[u8; 32]> =
                        batch.blocks.iter().map(|b| b.request.hash).collect();
                    let started = Instant::now();
                    let raw_blocks = batch.blocks;
                    // `semantic_active_workers` is maintained by the pool
                    // workers themselves: +1 while a verifier is executing,
                    // -1 when it finishes, so it is the live busy count.
                    let verified_batch = verify_batch_in_order(
                        dispatch_pool,
                        &dispatch_metrics.semantic_active_workers,
                        raw_blocks,
                        assume_valid,
                    );
                    let sapling = verified_batch.sapling;
                    dispatch_metrics.sapling_batch_blocks.store(sapling.blocks, Ordering::Relaxed);
                    dispatch_metrics.sapling_batch_proofs.store(sapling.proofs, Ordering::Relaxed);
                    dispatch_metrics.sapling_batch_spend_proofs.store(sapling.spend_proofs, Ordering::Relaxed);
                    dispatch_metrics.sapling_batch_output_proofs.store(sapling.output_proofs, Ordering::Relaxed);
                    dispatch_metrics.sapling_batch_verify_us.store(sapling.verify_us, Ordering::Relaxed);
                    eprintln!(
                        "[SAPLING-BATCH] sapling_batch_blocks={} sapling_batch_proofs={} sapling_batch_spend_proofs={} sapling_batch_output_proofs={} sapling_batch_verify_us={}",
                        sapling.blocks, sapling.proofs, sapling.spend_proofs, sapling.output_proofs, sapling.verify_us
                    );
                    for _ in 0..count {
                        saturating_dec(&dispatch_metrics.semantic_queue);
                    }
                    let verify_us = started.elapsed().as_micros() as u64;

                    let verified: BTreeMap<u64, SemanticBlock> = verified_batch
                        .blocks
                        .into_iter()
                        .map(|block| (block.height, block))
                        .collect();
                    let mut rejected = verified_batch.rejected;

                    if rejected.is_none() && verified.len() != count {
                        rejected = Some((batch.first_height, "duplicate heights inside one batch".into()));
                    }

                    if let Some((height, reason)) = rejected {
                        // One bad block voids the whole batch. Every block in it
                        // is released and the pipeline restarts from the tip, so
                        // the replacement arrives inside a complete batch rather
                        // than on its own.
                        dispatch_metrics.invalid_blocks.fetch_add(1, Ordering::Relaxed);
                        let tip = dispatch_state.tip_height().ok().flatten().unwrap_or(0);
                        eprintln!("[VERIFY] block {height} rejected: {reason}");
                        record_failure(
                            &dispatch_metrics,
                            tip,
                            format!(
                                "block {height} rejected by verifier: {reason} (batch {}..{} discarded)",
                                batch.first_height, batch.last_height
                            ),
                        );
                        drop(verified);
                        for hash in &batch_hashes {
                            dispatch_registry.release(hash);
                        }
                        let pause = dispatch_reset.request(tip.saturating_add(1));
                        dispatch_metrics.pipeline_retries.fetch_add(1, Ordering::Relaxed);
                        thread::sleep(pause);
                        continue;
                    }

                    // BTreeMap iterates in ascending height order, so the
                    // batch is rebuilt in exactly the order it was assembled.
                    let blocks: Vec<SemanticBlock> = verified.into_values().collect();

                    dispatch_metrics.semantic_batches.fetch_add(1, Ordering::Relaxed);
                    dispatch_metrics.last_semantic_batch_blocks.store(count as u64, Ordering::Relaxed);
                    dispatch_metrics.semantic_verified_blocks.fetch_add(count as u64, Ordering::Relaxed);
                    dispatch_metrics.semantic_verify_total_us.fetch_add(verify_us, Ordering::Relaxed);
                    dispatch_metrics.semantic_verify_us.store(verify_us, Ordering::Relaxed);
                    dispatch_metrics
                        .highest_semantically_verified_height
                        .fetch_max(batch.last_height, Ordering::Relaxed);
                    dispatch_metrics.trace_head(
                        "crypto-batch",
                        "COMPLETE",
                        batch.last_height,
                        None,
                        format!(
                            "all {} blocks of batch {}..{} verified in {}us; next batch released",
                            count, batch.first_height, batch.last_height, verify_us
                        ),
                    );

                    expected_first = batch.last_height.saturating_add(1);
                    if verified_tx
                        .send(CryptoVerified {
                            epoch,
                            first_height: batch.first_height,
                            last_height: batch.last_height,
                            hashes: batch_hashes,
                            blocks,
                        })
                        .is_err()
                    {
                        return;
                    }
                }
            })
            .map_err(|e| anyhow!("failed to start 16-block verification dispatcher: {e}"))?;

        // ── Stage 2: one expensive state-preparation worker ─────────────────
        //
        // All contextual/UTXO/script preparation for one complete batch. It
        // waits for the commit acknowledgement before preparing the next batch,
        // because the next preparation must observe the state the previous
        // batch produced.
        let prepare_state = Arc::clone(&chain);
        let prepare_metrics = Arc::clone(&metrics);
        let prepare_registry = Arc::clone(&registry);
        let prepare_reset = Arc::clone(&reset);
        thread::Builder::new()
            .name("yortal-expensive-state-prepare".into())
            .spawn(move || {
                let mut batch_id = 0u64;
                // A verified batch picked up early for read-ahead while the
                // previous batch was publishing. Processed next, in order.
                let mut carried: Option<CryptoVerified> = None;
                loop {
                    let batch = match carried.take() {
                        Some(batch) => batch,
                        None => match verified_rx.recv() {
                            Ok(batch) => batch,
                            Err(_) => return,
                        },
                    };
                    if batch.epoch != prepare_reset.epoch() {
                        prepare_state.clear_utxo_hint();
                        for hash in &batch.hashes {
                            prepare_registry.release(hash);
                        }
                        continue;
                    }

                    let tip = prepare_state.tip_height().ok().flatten().unwrap_or(0);
                    if batch.first_height != tip.saturating_add(1) {
                        eprintln!(
                            "[PREPARE] batch {}..{} does not start at tip+1 ({}); resetting",
                            batch.first_height,
                            batch.last_height,
                            tip.saturating_add(1)
                        );
                        for hash in &batch.hashes {
                            prepare_registry.release(hash);
                        }
                        let pause = prepare_reset.request(tip.saturating_add(1));
                        prepare_metrics.pipeline_retries.fetch_add(1, Ordering::Relaxed);
                        thread::sleep(pause);
                        continue;
                    }

                    let count = batch.blocks.len();
                    let commits: Vec<BlockCommit> = batch.blocks.into_iter().map(|b| b.commit).collect();
                    // Everything this batch spends. Read-ahead for the next
                    // batch must never include these: its snapshot may land
                    // before this batch's publication. None = unknown, so no
                    // read-ahead is built on this batch.
                    let spent_here = State::spent_outpoints(&commits);
                    prepare_metrics.contextual_active_batches.fetch_add(1, Ordering::Relaxed);
                    let prepare_started = Instant::now();
                    let prepared_result: Result<ycash_state::PreparedCommit> =
                        match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                            // Worker 0 of the two-worker state pool runs the
                            // ordered state walk; script checks spawned by
                            // the walk run on worker 1, and worker 0 joins
                            // them whenever it is waiting.
                            ycash_state::chainstate::shared_pool()
                                .install(|| prepare_state.prepare_commit_batch_owned(commits))
                        })) {
                            Ok(result) => result,
                            Err(payload) => Err(anyhow!("state preparation panicked: {}", panic_text(&*payload))),
                        };
                    prepare_metrics.contextual_active_batches.fetch_sub(1, Ordering::Relaxed);

                    let prepared = match prepared_result {
                        Ok(prepared) => prepared,
                        Err(e) => {
                            prepare_metrics.invalid_blocks.fetch_add(1, Ordering::Relaxed);
                            eprintln!(
                                "[PREPARE] contextual validation rejected batch {batch_id} ({}..{}): {e:#}",
                                batch.first_height, batch.last_height
                            );
                            record_failure(
                                &prepare_metrics,
                                tip,
                                format!(
                                    "batch {}..{} rejected by state preparation: {e:#}",
                                    batch.first_height, batch.last_height
                                ),
                            );
                            for hash in &batch.hashes {
                                prepare_registry.release(hash);
                            }
                            let pause = prepare_reset.request(tip.saturating_add(1));
                            prepare_metrics.pipeline_retries.fetch_add(1, Ordering::Relaxed);
                            thread::sleep(pause);
                            batch_id = batch_id.saturating_add(1);
                            continue;
                        }
                    };

                    let prepare_us = prepare_started.elapsed().as_micros() as u64;
                    prepare_metrics.contextual_prepare_us.store(prepare_us, Ordering::Relaxed);
                    prepare_metrics
                        .highest_contextually_verified_height
                        .fetch_max(batch.last_height, Ordering::Relaxed);

                    if prepared_tx
                        .send(PreparedBatch {
                            batch_id,
                            first_height: batch.first_height,
                            last_height: batch.last_height,
                            blocks: count,
                            hashes: batch.hashes,
                            prepared,
                        })
                        .is_err()
                    {
                        return;
                    }

                    // Publication of this batch is now running on the commit
                    // worker. If the next batch is already verified, use the
                    // wait to read its coins ahead. Never blocks: without a
                    // ready batch this is skipped and nothing changes.
                    if let Some(spent) = spent_here.as_ref() {
                        if let Ok(next) = verified_rx.try_recv() {
                            if next.epoch == prepare_reset.epoch()
                                && next.first_height == batch.last_height.saturating_add(1)
                            {
                                let next_commits: Vec<&BlockCommit> = next.blocks.iter().map(|b| &b.commit).collect();
                                let readahead_started = Instant::now();
                                match prepare_state.prefetch_utxo_hint(&next_commits, spent) {
                                    Ok(n) => eprintln!(
                                        "[READAHEAD] read {} coin(s) for batch {}..{} during publication of {}..{} in {}us",
                                        n,
                                        next.first_height,
                                        next.last_height,
                                        batch.first_height,
                                        batch.last_height,
                                        readahead_started.elapsed().as_micros()
                                    ),
                                    Err(e) => {
                                        prepare_state.clear_utxo_hint();
                                        eprintln!("[READAHEAD] skipped: {e:#}");
                                    }
                                }
                            }
                            carried = Some(next);
                        }
                    }

                    match commit_ack_rx.recv() {
                        Ok(true) => prepare_reset.settled(),
                        Ok(false) => {
                            prepare_state.clear_utxo_hint();
                            // Publication failed. Everything above the tip is
                            // now built on a state that never existed.
                            let tip_now = prepare_state.tip_height().ok().flatten().unwrap_or(0);
                            let pause = prepare_reset.request(tip_now.saturating_add(1));
                            prepare_metrics.pipeline_retries.fetch_add(1, Ordering::Relaxed);
                            thread::sleep(pause);
                        }
                        Err(_) => return,
                    }
                    batch_id = batch_id.saturating_add(1);
                }
            })
            .map_err(|e| anyhow!("failed to start expensive state-preparation worker: {e}"))?;

        // ── Stage 3: one canonical commit worker ────────────────────────────
        //
        // Publication only: apply_prepared_commit rechecks the prepared
        // tip/parent and executes the atomic RocksDB write. No parsing, UTXO
        // discovery, script execution or proof verification happens here.
        let commit_state = Arc::clone(&chain);
        let commit_metrics = Arc::clone(&metrics);
        let commit_registry = Arc::clone(&registry);
        thread::Builder::new()
            .name("yortal-batch-commit".into())
            .spawn(move || {
                while let Ok(batch) = prepared_rx.recv() {
                    let PreparedBatch {
                        batch_id,
                        first_height,
                        last_height,
                        blocks,
                        hashes,
                        prepared,
                    } = batch;
                    let started = Instant::now();
                    let blocks = blocks as u64;
                    // Last gate before canonical state: the batch must be in
                    // strict height order, linked block to block, and sit
                    // directly on the current canonical tip.
                    let result: Result<()> = if let Some(reason) = publication_order_error(&commit_state, &prepared.blocks) {
                        Err(anyhow!("batch not in order for publication: {reason}"))
                    } else {
                        match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                            commit_state.apply_prepared_commit(prepared)
                        })) {
                            Ok(result) => result,
                            Err(payload) => Err(anyhow!("canonical publication panicked: {}", panic_text(&*payload))),
                        }
                    };
                    let committed_ok = result.is_ok();
                    match result {
                        Ok(()) => {
                            let timing = commit_state.last_commit_timing();
                            commit_metrics.database_write_us.store(timing.db_write_us, Ordering::Relaxed);
                            commit_metrics.last_publication_blocks.store(blocks, Ordering::Relaxed);
                            commit_metrics.committed_blocks.fetch_add(blocks, Ordering::Relaxed);
                            commit_metrics.canonical_height.store(last_height, Ordering::Relaxed);
                            commit_metrics.commit_batches.fetch_add(1, Ordering::Relaxed);
                            commit_metrics.commit_total_us.fetch_add(timing.total_us, Ordering::Relaxed);
                            commit_metrics.last_commit_total_us.store(timing.total_us, Ordering::Relaxed);
                            commit_metrics.last_commit_unix.store(
                                std::time::SystemTime::now()
                                    .duration_since(std::time::UNIX_EPOCH)
                                    .map(|d| d.as_secs())
                                    .unwrap_or(0),
                                Ordering::Relaxed,
                            );
                            *commit_metrics.last_commit_timing.lock().unwrap() = timing;
                            commit_metrics.trace_head(
                                "ordered-commit",
                                "COMMITTED",
                                last_height,
                                hashes.last().copied(),
                                format!(
                                    "published {}..{} as one batch of {} in {}us; publication only",
                                    first_height,
                                    last_height,
                                    blocks,
                                    started.elapsed().as_micros()
                                ),
                            );
                            commit_metrics.clear_missing_parent();
                        }
                        Err(e) => {
                            eprintln!("[COMMIT] batch {batch_id} publication failed: {e:#}");
                            commit_metrics.semantic_batch_failures.fetch_add(1, Ordering::Relaxed);
                            let tip_now = commit_state.tip_height().ok().flatten().unwrap_or(0);
                            record_failure(
                                &commit_metrics,
                                tip_now,
                                format!(
                                    "batch {}..{} publication failed: {e:#}",
                                    first_height, last_height
                                ),
                            );
                        }
                    }

                    for hash in &hashes {
                        commit_registry.release(hash);
                    }
                    let _ = commit_ack_tx.send(committed_ok);
                }
            })
            .map_err(|e| anyhow!("failed to start canonical commit worker: {e}"))?;

        Ok(Self { tx: intake_tx, metrics })
    }

    /// Bounded producer backpressure. The download window is sized so the gate
    /// can keep its ready queue full; transport itself remains limited to 16
    /// blocks per peer.
    pub fn submit(&self, block: RawBlock) -> Result<()> {
        self.metrics.semantic_queue.fetch_add(1, Ordering::Relaxed);
        self.tx.send(block).map_err(|_| {
            self.metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
            anyhow!("cryptographic verifier stopped")
        })
    }
}

/// Owned hand-off between the single expensive preparation worker and the
/// single canonical commit worker. Keeping the prepared mutation plan owned is
/// what lets the stages communicate without copying raw block data.
struct PreparedBatch {
    batch_id: u64,
    first_height: u64,
    last_height: u64,
    blocks: usize,
    hashes: Vec<[u8; 32]>,
    prepared: ycash_state::PreparedCommit,
}

/// Why a released batch may not enter the pipeline, if it may not.
fn batch_entry_error(state: &State, first_height: u64, blocks: &[RawBlock]) -> Option<String> {
    if blocks.is_empty() {
        return Some("empty batch".into());
    }
    let mut prev_hash: Option<[u8; 32]> = if first_height > 1 {
        match state.header_hash_by_height(first_height - 1) {
            Ok(Some(h)) if h.len() == 32 => {
                let mut out = [0u8; 32];
                out.copy_from_slice(&h);
                Some(out)
            }
            _ => return Some(format!("no validated header for parent height {}", first_height - 1)),
        }
    } else {
        None
    };
    for (i, block) in blocks.iter().enumerate() {
        let want = first_height + i as u64;
        if block.request.height != want {
            return Some(format!("position {i} holds height {} instead of {want}", block.request.height));
        }
        let parent = match header_prev(&block.raw) {
            Ok(p) => p,
            Err(e) => return Some(format!("height {want}: unreadable header: {e}")),
        };
        if let Some(expected) = prev_hash {
            if parent != expected {
                return Some(format!("height {want} does not build on height {}", want.saturating_sub(1)));
            }
        }
        prev_hash = Some(block.request.hash);
    }
    None
}

/// Why a prepared batch may not be published, if it may not.
fn publication_order_error(state: &State, blocks: &[BlockCommit]) -> Option<String> {
    let Some(first) = blocks.first() else { return Some("empty batch".into()) };
    let tip = match state.tip_height() {
        Ok(tip) => tip,
        Err(e) => return Some(format!("tip unreadable: {e}")),
    };
    let expected_first = tip.map(|t| t.saturating_add(1)).unwrap_or(1);
    if first.height != expected_first {
        return Some(format!("first height {} but canonical tip + 1 is {expected_first}", first.height));
    }
    if tip.is_some() {
        match state.tip_hash() {
            Ok(Some(hash)) if hash.as_slice() == first.prev.as_slice() => {}
            _ => return Some(format!("height {} does not build on the canonical tip", first.height)),
        }
    }
    for pair in blocks.windows(2) {
        if pair[1].height != pair[0].height.saturating_add(1) {
            return Some(format!("height {} follows {}", pair[1].height, pair[0].height));
        }
        if pair[1].prev != pair[0].hash {
            return Some(format!("height {} does not build on height {}", pair[1].height, pair[0].height));
        }
    }
    None
}

/// Default verifier width: leave one core for the ordered state engine and one
/// for the Android UI thread, and never drop below one worker.
pub fn default_verifier_workers() -> usize {
    std::thread::available_parallelism()
        .map(|n| n.get().saturating_sub(2).max(1))
        .unwrap_or(1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn failure_backoff_grows_then_caps() {
        assert_eq!(failure_backoff(1), Duration::ZERO);
        assert_eq!(failure_backoff(2), Duration::ZERO);
        assert_eq!(failure_backoff(3), Duration::from_millis(250));
        assert_eq!(failure_backoff(4), Duration::from_millis(500));
        assert_eq!(failure_backoff(100), Duration::from_secs(15));
    }

    #[test]
    fn queue_counter_never_wraps() {
        let counter = AtomicU64::new(1);
        saturating_dec(&counter);
        saturating_dec(&counter);
        assert_eq!(counter.load(Ordering::Relaxed), 0);
    }

    #[test]
    fn a_reset_moves_every_stage_to_the_same_height() {
        let reset = PipelineReset::new(100);
        assert_eq!(reset.epoch(), 1);
        assert_eq!(reset.resume_from(), 100);
        reset.request(64);
        assert_eq!(reset.epoch(), 2);
        assert_eq!(reset.resume_from(), 64);
        reset.settled();
        assert_eq!(reset.request(64), Duration::ZERO);
    }

    #[test]
    fn repeated_resets_back_off_but_a_publication_clears_the_streak() {
        let reset = PipelineReset::new(1);
        assert_eq!(reset.request(1), Duration::ZERO);
        assert_eq!(reset.request(1), Duration::ZERO);
        assert_eq!(reset.request(1), Duration::from_millis(250));
        reset.settled();
        assert_eq!(reset.request(1), Duration::ZERO);
    }

    #[test]
    fn ready_prefill_target_is_four_when_four_batches_are_possible() {
        assert_eq!(ready_batch_target_for_tip(1, 64), 4);
        assert_eq!(ready_batch_target_for_tip(1, 65), 4);
        assert_eq!(ready_batch_target_for_tip(17, 64), 3);
    }

    #[test]
    fn a_single_ready_batch_is_enough_to_start_progress() {
        // The four-batch value is a desired prefill depth only. The dispatcher
        // must never wait for the target before consuming a complete batch.
        assert_eq!(INTAKE_READY_BATCHES, 4);
        assert!(INTAKE_READY_BATCHES > 1);
    }

    #[test]
    fn ready_watermark_drops_only_at_chain_tip() {
        assert_eq!(ready_batch_target_for_tip(1, 16), 1);
        assert_eq!(ready_batch_target_for_tip(1, 20), 2);
        assert_eq!(ready_batch_target_for_tip(1, 48), 3);
        assert_eq!(ready_batch_target_for_tip(1, 49), 4);
        assert_eq!(ready_batch_target_for_tip(100, 99), 1);
    }

    #[test]
    fn the_ready_queue_holds_four_complete_batches() {
        assert_eq!(VERIFICATION_BATCH_SIZE, 16);
        assert_eq!(INTAKE_READY_BATCHES, 4);
        // The hot pipeline needs only a small contiguous working set. The
        // larger 2048-block window is now the network/disk read-ahead horizon,
        // so it deliberately exceeds the four-batch hot prefill requirement.
        let hot_pipeline_blocks = VERIFICATION_BATCH_SIZE
            * (INTAKE_READY_BATCHES + crate::PIPELINE_INFLIGHT_BATCHES + crate::INTAKE_ASSEMBLY_BATCHES);
        assert_eq!(crate::BLOCK_DOWNLOAD_WINDOW, crate::PREFETCH_CAPACITY_BLOCKS);
        assert!(crate::BLOCK_DOWNLOAD_WINDOW >= hot_pipeline_blocks);
        assert!(VERIFIER_QUEUE_CAPACITY > crate::BLOCK_DOWNLOAD_WINDOW);
    }
}
