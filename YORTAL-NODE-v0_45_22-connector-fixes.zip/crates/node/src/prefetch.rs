//! Disk-backed block read-ahead cache.
//!
//! Network acquisition is allowed to run ahead of the small hot verifier queue.
//! Downloaded blocks are written here and only promoted into the verifier when
//! the hot queue has room. The cache is deliberately non-consensus state: the
//! verifier still validates every block before it can enter the ordered state
//! pipeline.

use std::collections::BTreeMap;
use std::fs::{self, File, OpenOptions};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::sync::{Condvar, Mutex};
use std::time::Duration;

use anyhow::{anyhow, Context, Result};

pub const PREFETCH_CAPACITY_BLOCKS: usize = 2_048;
const DEFAULT_MAX_BYTES: u64 = 2 * 1024 * 1024 * 1024;
const MAX_ENTRIES: usize = PREFETCH_CAPACITY_BLOCKS;

#[derive(Default)]
struct Index {
    entries: BTreeMap<u64, ([u8; 32], String)>,
    bytes: u64,
    reserved: u64,
    /// Bumped on every successful `put`, so the promoter can sleep until
    /// something new lands instead of polling.
    generation: u64,
}

pub struct PrefetchCache {
    dir: PathBuf,
    max_bytes: u64,
    index: Mutex<Index>,
    arrived: Condvar,
}

impl PrefetchCache {
    pub fn open() -> Result<Self> {
        let dir = std::env::var_os("YORTAL_PREFETCH_DIR")
            .map(PathBuf::from)
            .or_else(|| {
                std::env::var_os("YCASH_NODE_DB").map(PathBuf::from).map(|p| {
                    let mut d = p;
                    d.set_extension("prefetch");
                    d
                })
            })
            .unwrap_or_else(|| std::env::temp_dir().join("ycash-yortal-prefetch"));
        fs::create_dir_all(&dir).with_context(|| format!("create prefetch directory {}", dir.display()))?;
        // Prefetch is deliberately ephemeral. Never reuse bytes from an older
        // process after a restart; headers may have changed meanwhile.
        for entry in fs::read_dir(&dir)? {
            let path = entry?.path();
            if path.is_file() { let _ = fs::remove_file(path); }
        }
        let max_bytes = std::env::var("YORTAL_PREFETCH_MAX_MB")
            .ok()
            .and_then(|v| v.parse::<u64>().ok())
            .filter(|v| *v >= 32)
            .map(|mb| mb * 1024 * 1024)
            .unwrap_or(DEFAULT_MAX_BYTES);
        Ok(Self { dir, max_bytes, index: Mutex::new(Index::default()), arrived: Condvar::new() })
    }

    fn path_for(&self, hash: &[u8; 32]) -> PathBuf {
        self.dir.join(format!("{}.blk", hex(hash)))
    }

    /// Store a complete block atomically. Returns false when the byte budget
    /// would be exceeded; callers can then promote that one block directly to
    /// the bounded hot verifier queue without losing it.
    pub fn put(&self, height: u64, hash: [u8; 32], peer: &str, raw: &[u8]) -> Result<bool> {
        if raw.len() as u64 > self.max_bytes { return Ok(false); }
        let path = self.path_for(&hash);
        let tmp = path.with_extension("tmp");
        let len = raw.len() as u64;
        {
            let mut idx = self.index.lock().unwrap_or_else(|e| e.into_inner());
            if let Some((old_hash, _)) = idx.entries.get(&height).cloned() {
                if old_hash == hash { return Ok(true); }
                let old_path = self.path_for(&old_hash);
                if let Ok(meta) = fs::metadata(&old_path) { idx.bytes = idx.bytes.saturating_sub(meta.len()); }
                let _ = fs::remove_file(old_path);
                idx.entries.remove(&height);
            }
            if idx.entries.len() + 1 > MAX_ENTRIES || idx.bytes.saturating_add(idx.reserved).saturating_add(len) > self.max_bytes {
                return Ok(false);
            }
            idx.reserved = idx.reserved.saturating_add(len);
        }

        let write_result = (|| -> Result<()> {
            let mut f = OpenOptions::new().create_new(true).write(true).open(&tmp)
                .with_context(|| format!("create prefetch temp {}", tmp.display()))?;
            f.write_all(raw)?;
            // This directory is an ephemeral read-ahead cache and is deleted on
            // restart, so forcing a storage flush for every block only adds
            // latency to network acquisition without providing consensus or
            // recovery guarantees. The atomic temp-file rename is sufficient.
            fs::rename(&tmp, &path).with_context(|| format!("install prefetch {}", path.display()))?;
            Ok(())
        })();

        let mut idx = self.index.lock().unwrap_or_else(|e| e.into_inner());
        idx.reserved = idx.reserved.saturating_sub(len);
        if let Err(_) = write_result {
            let _ = fs::remove_file(&tmp);
            let _ = fs::remove_file(&path);
            return Ok(false);
        }
        idx.bytes = idx.bytes.saturating_add(len);
        idx.entries.insert(height, (hash, peer.to_string()));
        idx.generation = idx.generation.wrapping_add(1);
        drop(idx);
        self.arrived.notify_all();
        Ok(true)
    }

    /// Promote only a contiguous run beginning at `expected_height`. Blocks
    /// above a hole stay on disk. This is the important separation between the
    /// large network reservoir and the small RAM-side assembler: a missing
    /// height can never cause hundreds of later blocks to spill into RAM.
    pub fn take_contiguous(&self, expected_height: u64, max: usize) -> Vec<(u64, [u8; 32], String, Vec<u8>)> {
        if max == 0 { return Vec::new(); }
        let mut idx = self.index.lock().unwrap_or_else(|e| e.into_inner());
        let mut heights = Vec::with_capacity(max);
        let mut height = expected_height;
        while heights.len() < max {
            if !idx.entries.contains_key(&height) { break; }
            heights.push(height);
            height = height.saturating_add(1);
        }
        let mut out = Vec::with_capacity(heights.len());
        for height in heights {
            let Some((hash, peer)) = idx.entries.remove(&height) else { continue };
            let path = self.path_for(&hash);
            match read_file(&path) {
                Ok(raw) => {
                    idx.bytes = idx.bytes.saturating_sub(raw.len() as u64);
                    let _ = fs::remove_file(path);
                    out.push((height, hash, peer, raw));
                }
                Err(_) => {
                    let _ = fs::remove_file(path);
                }
            }
        }
        out
    }

    /// Promote every cached block with a height in `lo .. lo + span`, lowest
    /// first, skipping holes.
    ///
    /// v0.45.19: the promoter used `take_contiguous(frontier)`, where the
    /// frontier is the first height of the batch the intake gate is still
    /// assembling. Once the frontier block itself had been promoted it was no
    /// longer on disk, so every later call stopped at height `frontier` and
    /// returned nothing: block N+1 could land on disk a second later and stay
    /// there forever while the gate waited for it (seen live as "waiting for
    /// block 2 · 1 held · disk 2031 · hedges 0"). Taking the window instead of
    /// a run from the frontier cannot strand a block, and `span` still bounds
    /// how much can move into RAM ahead of a real hole.
    pub fn take_window(&self, lo: u64, span: usize) -> Vec<(u64, [u8; 32], String, Vec<u8>)> {
        if span == 0 { return Vec::new(); }
        let hi = lo.saturating_add(span as u64);
        let mut idx = self.index.lock().unwrap_or_else(|e| e.into_inner());
        let heights: Vec<u64> = idx.entries.range(lo..hi).map(|(h, _)| *h).collect();
        let mut out = Vec::with_capacity(heights.len());
        for height in heights {
            let Some((hash, peer)) = idx.entries.remove(&height) else { continue };
            let path = self.path_for(&hash);
            match read_file(&path) {
                Ok(raw) => {
                    idx.bytes = idx.bytes.saturating_sub(raw.len() as u64);
                    let _ = fs::remove_file(path);
                    out.push((height, hash, peer, raw));
                }
                Err(_) => {
                    let _ = fs::remove_file(path);
                }
            }
        }
        out
    }

    /// Remove every cached block below `height` and return how many were
    /// removed. Lifecycle claims are not touched: the canonical copy of each
    /// hash is further down the pipeline and owns the claim.
    pub fn prune_below(&self, height: u64) -> usize {
        let mut idx = self.index.lock().unwrap_or_else(|e| e.into_inner());
        let stale: Vec<u64> = idx.entries.range(..height).map(|(h, _)| *h).collect();
        for h in &stale {
            if let Some((hash, _)) = idx.entries.remove(h) {
                let path = self.path_for(&hash);
                if let Ok(meta) = fs::metadata(&path) {
                    idx.bytes = idx.bytes.saturating_sub(meta.len());
                }
                let _ = fs::remove_file(path);
            }
        }
        stale.len()
    }

    /// Lowest cached height at or above `from`, if any. Diagnostics only.
    pub fn lowest_from(&self, from: u64) -> Option<u64> {
        let idx = self.index.lock().unwrap_or_else(|e| e.into_inner());
        idx.entries.range(from..).next().map(|(h, _)| *h)
    }

    /// Number of cached blocks available contiguously from `expected_height`.
    /// Used for live pipeline diagnostics and to prove that a disk-side gap,
    /// not RAM pressure, is the current limiter.
    pub fn contiguous_len(&self, expected_height: u64, max: usize) -> usize {
        if max == 0 { return 0; }
        let idx = self.index.lock().unwrap_or_else(|e| e.into_inner());
        let mut count = 0usize;
        let mut height = expected_height;
        while count < max && idx.entries.contains_key(&height) {
            count += 1;
            height = height.saturating_add(1);
        }
        count
    }

    pub fn remove(&self, height: u64, hash: &[u8; 32]) {
        let mut idx = self.index.lock().unwrap_or_else(|e| e.into_inner());
        if let Some((old_hash, _)) = idx.entries.remove(&height) {
            if &old_hash == hash {
                let path = self.path_for(hash);
                if let Ok(meta) = fs::metadata(&path) { idx.bytes = idx.bytes.saturating_sub(meta.len()); }
                let _ = fs::remove_file(path);
            }
        }
    }

    /// Arrival counter; see [`PrefetchCache::wait_for_arrival`].
    pub fn generation(&self) -> u64 {
        self.index.lock().unwrap_or_else(|e| e.into_inner()).generation
    }

    /// Sleep until a block newer than `seen` lands or `timeout` passes.
    /// Returns immediately if something already arrived since `seen`, so a
    /// caller that read `generation()` before looking cannot miss a wake-up.
    pub fn wait_for_arrival(&self, seen: u64, timeout: Duration) {
        let idx = self.index.lock().unwrap_or_else(|e| e.into_inner());
        if idx.generation != seen {
            return;
        }
        let _ = self
            .arrived
            .wait_timeout(idx, timeout)
            .unwrap_or_else(|e| e.into_inner());
    }

    /// Hash cached for `height`, if any.
    pub fn hash_at(&self, height: u64) -> Option<[u8; 32]> {
        self.index
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .entries
            .get(&height)
            .map(|(hash, _)| *hash)
    }

    pub fn len(&self) -> usize { self.index.lock().unwrap_or_else(|e| e.into_inner()).entries.len() }
    pub fn bytes(&self) -> u64 { self.index.lock().unwrap_or_else(|e| e.into_inner()).bytes }
}

fn read_file(path: &Path) -> Result<Vec<u8>> {
    let mut f = File::open(path).with_context(|| format!("open prefetch {}", path.display()))?;
    let len = f.metadata()?.len() as usize;
    let mut raw = Vec::with_capacity(len);
    f.read_to_end(&mut raw)?;
    if raw.len() != len { return Err(anyhow!("short prefetch read")); }
    Ok(raw)
}

fn hex(bytes: &[u8; 32]) -> String {
    const H: &[u8; 16] = b"0123456789abcdef";
    let mut out = String::with_capacity(64);
    for b in bytes { out.push(H[(b >> 4) as usize] as char); out.push(H[(b & 0xf) as usize] as char); }
    out
}


#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn test_cache() -> (PrefetchCache, PathBuf) {
        let nonce = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let dir = std::env::temp_dir().join(format!("yortal-prefetch-test-{nonce}"));
        fs::create_dir_all(&dir).unwrap();
        let cache = PrefetchCache {
            dir: dir.clone(),
            max_bytes: 1024 * 1024,
            index: Mutex::new(Index::default()),
            arrived: Condvar::new(),
        };
        (cache, dir)
    }

    fn hash(n: u8) -> [u8; 32] { [n; 32] }

    #[test]
    fn promotion_stops_at_the_first_disk_gap() {
        let (cache, dir) = test_cache();
        cache.put(10, hash(10), "a", b"ten").unwrap();
        cache.put(11, hash(11), "a", b"eleven").unwrap();
        cache.put(13, hash(13), "a", b"thirteen").unwrap();

        let promoted = cache.take_contiguous(10, 16);
        assert_eq!(promoted.len(), 2);
        assert_eq!(promoted[0].0, 10);
        assert_eq!(promoted[1].0, 11);
        assert_eq!(cache.len(), 1);
        assert_eq!(cache.contiguous_len(12, 16), 0);
        assert_eq!(cache.contiguous_len(13, 16), 1);

        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn stale_entries_below_the_frontier_are_pruned() {
        let (cache, dir) = test_cache();
        assert!(cache.put(1, hash(1), "p", b"one").unwrap());
        assert!(cache.put(2, hash(2), "p", b"two").unwrap());
        assert!(cache.put(9, hash(9), "p", b"nine").unwrap());
        assert_eq!(cache.prune_below(5), 2);
        assert_eq!(cache.len(), 1);
        assert_eq!(cache.hash_at(9), Some(hash(9)));
        assert_eq!(cache.prune_below(5), 0);
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn arrival_wakes_or_returns_immediately() {
        let (cache, dir) = test_cache();
        let seen = cache.generation();
        assert!(cache.put(5, hash(5), "p", b"five").unwrap());
        let started = std::time::Instant::now();
        // Already advanced: must not sleep for the full timeout.
        cache.wait_for_arrival(seen, Duration::from_secs(5));
        assert!(started.elapsed() < Duration::from_secs(1));
        assert_eq!(cache.hash_at(5), Some(hash(5)));
        assert_eq!(cache.hash_at(6), None);
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn window_promotion_survives_a_promoted_frontier() {
        let (cache, dir) = test_cache();
        // Frontier block arrives alone and is promoted.
        assert!(cache.put(1, hash(1), "p", b"one").unwrap());
        let first = cache.take_window(1, 64);
        assert_eq!(first.iter().map(|e| e.0).collect::<Vec<_>>(), vec![1]);
        // Block 2 and later arrive afterwards. The old contiguous-from-frontier
        // promotion returned nothing here and the node stalled for good.
        assert!(cache.put(2, hash(2), "p", b"two").unwrap());
        assert!(cache.put(3, hash(3), "p", b"three").unwrap());
        assert!(cache.take_contiguous(1, 64).is_empty());
        let next = cache.take_window(1, 64);
        assert_eq!(next.iter().map(|e| e.0).collect::<Vec<_>>(), vec![2, 3]);
        // Nothing beyond the span moves into RAM.
        assert!(cache.put(70, hash(70), "p", b"far").unwrap());
        assert!(cache.take_window(1, 64).is_empty());
        assert_eq!(cache.lowest_from(1), Some(70));
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn capacity_is_two_thousand_forty_eight_blocks() {
        assert_eq!(PREFETCH_CAPACITY_BLOCKS, 2048);
        assert_eq!(MAX_ENTRIES, PREFETCH_CAPACITY_BLOCKS);
        assert_eq!(DEFAULT_MAX_BYTES, 2 * 1024 * 1024 * 1024);
    }
}
