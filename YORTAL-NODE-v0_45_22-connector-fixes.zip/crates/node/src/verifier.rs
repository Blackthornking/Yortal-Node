//! Semantic (context-free) verification.
//!
//! Verification owns the expensive consensus work. Context-free checks start
//! as soon as each block reaches the bounded hot intake queue; the network may
//! stage up to 2048 blocks ahead on disk without expanding RAM usage.
//! Verified results are retained by height only as long as needed to bridge
//! short verification chunks into the next ordered commit window. The ordered
//! state connector then performs state-dependent transaction/script preparation
//! against a consistent snapshot. Only the resulting prepared mutation plan
//! crosses into canonical publication.
//!
//! Canonical publication is deliberately not a validation stage: it only
//! rechecks the prepared parent/tip and atomically writes the prepared state.

use std::collections::BTreeMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::mpsc::{sync_channel, RecvTimeoutError, SyncSender};
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use anyhow::{anyhow, bail, Result};
use ycash_chain::txid;
use ycash_consensus::{validate_for_commit_batched_with_parsed, Context, ProofBatch};
use ycash_state::prospective::SemanticBlock;
use ycash_state::State;
use ycash_state::state_service::SyncMetrics;
use ycash_state::BlockCommit;

use crate::batch::{verify_batch_in_order, BatchAssembler};
use crate::downloader::{BlockRequest, InFlightRegistry};

/// Optional assume-valid checkpoint, carried over unchanged. Full verification
/// is the default; this is used only when YCASH_ASSUME_VALID=1 and the verified
/// header at the checkpoint height matches.
pub const ASSUME_VALID_HEIGHT: u64 = 2_250_000;
pub const ASSUME_VALID_HASH_DISPLAY: &str =
    "000003f98b7497fdcd8a6b6d10a93a887c5d47127e24a9dc3a40cb65754d21e7";

/// Blocks a verifier thread folds into one Groth16 batch.
///
/// The batch identity costs one final exponentiation regardless of how many
/// proofs it holds, so a bigger batch amortises it better. One block per batch
/// wastes that on blocks with few shielded transactions. Grouping is bounded
/// rather than unlimited because a worker only groups what has *already*
/// arrived: it never waits for more blocks, so latency at the chain tip is
/// unchanged.
///
/// This is a scheduling constant. It changes how proofs are grouped for
/// verification, never which proofs must verify.
pub const MAX_BLOCKS_PER_PROOF_BATCH: usize = crate::PIPELINE_BATCH_SIZE;

/// A downloaded block with the header context its verification needs.
#[derive(Debug)]
pub struct RawBlock {
    pub request: BlockRequest,
    pub raw: Vec<u8>,
    /// Peer that supplied the block. Diagnostic provenance only.
    pub source_peer: String,
}

/// Result of one verifier attempt with enough provenance to close the block
/// lifecycle exactly once.
pub struct VerifyOutcome {
    pub height: u64,
    pub hash: [u8; 32],
    pub source_peer: String,
    pub result: Result<SemanticBlock>,
}

/// Work handed from the verifier coordinator to the single ordered commit
/// owner. Keeping this on a dedicated worker prevents the coordinator from
/// blocking on the expensive state-preparation/write path: it can return to
/// multiplexing verifier completions immediately while canonical publication
/// remains strictly serialized. The lifecycle window is still exactly 16.
struct CommitRequest {
    batch_id: u64,
    commits: Vec<BlockCommit>,
    received: BTreeMap<u64, RawBlock>,
}

/// The prev-hash field of a block header, read straight from the wire bytes.
///
/// Header layout: version(4) | prev(32) | merkle(32) | final Sapling root(32) |
/// time(4) | bits(4) | nonce(32) | solution.
pub fn header_prev(raw: &[u8]) -> Result<[u8; 32]> {
    if raw.len() < 36 {
        bail!("block is too short to contain a header");
    }
    let mut prev = [0u8; 32];
    prev.copy_from_slice(&raw[4..36]);
    Ok(prev)
}

/// Run every context-free consensus check for one block.
///
/// This is the same entry point the previous pipeline used, called with the
/// same arguments for the same block; only the surrounding scheduling changed.
pub fn semantic_verify(block: RawBlock, assume_valid: bool) -> Result<SemanticBlock> {
    let RawBlock { request, raw, .. } = block;
    let height = request.height;
    let ctx = Context {
        height,
        prev_height: height.saturating_sub(1),
        median_time_past: request.median_time_past,
    };
    let assume_valid = assume_valid && height <= ASSUME_VALID_HEIGHT;

    // Sapling proofs in one block share a batch: one multi-Miller loop per
    // verifying key rather than one pairing check per proof. A rejection is
    // re-checked by the single-proof verifier, whose result is final.
    let mut proofs = ProofBatch::new();
    let (validated, parsed_txs) = validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, &mut proofs)
        .map_err(|e| anyhow!("block {height}: {e:?}"))?;
    if proofs.proofs() > 0 {
        if let Err((h, e)) = proofs.finish() {
            bail!("block {h}: {e:?}");
        }
    }
    if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
        bail!("block {height}: consensus decoder returned inconsistent transaction data");
    }

    let prev = header_prev(&raw)?;
    let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
    let precomputed_txs: Vec<ycash_script::PrecomputedTxData> =
        parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();

    Ok(SemanticBlock::from_commit(BlockCommit {
        height,
        hash: request.hash,
        prev,
        work: request.work,
        raw,
        txs,
        parsed_txs,
        precomputed_txs,
        proofs_verified: true,
    }))
}

/// Verify a group of blocks, folding every Sapling proof in the group into one
/// batch.
///
/// On batch rejection each block is re-verified on its own. The batch says only
/// that something in the set is bad, never which block, so a batch verdict is
/// never reported as a per-block result.
pub fn verify_group(blocks: Vec<RawBlock>, assume_valid: bool) -> Vec<VerifyOutcome> {
    if blocks.len() == 1 {
        let mut blocks = blocks;
        let block = blocks.remove(0);
        let height = block.request.height;
        let hash = block.request.hash;
        let source_peer = block.source_peer.clone();
        return vec![VerifyOutcome { height, hash, source_peer, result: semantic_verify(block, assume_valid) }];
    }

    let mut batch = ProofBatch::new();
    let mut staged: Vec<Result<SemanticBlock>> = Vec::with_capacity(blocks.len());
    let mut retained: Vec<RawBlock> = Vec::with_capacity(blocks.len());
    for block in blocks {
        let raw_for_retry = RawBlock {
            request: block.request.clone(),
            raw: block.raw.clone(),
            source_peer: block.source_peer.clone(),
        };
        retained.push(raw_for_retry);
        staged.push(verify_into_batch(block, assume_valid, &mut batch));
    }

    if batch.proofs() > 0 {
        if let Err((height, e)) = batch.finish() {
            // Isolate: re-verify every block in the group individually. The
            // lifecycle remains owned throughout this retry; no transport
            // request can be issued for any member while isolation runs.
            eprintln!("[VERIFY] proof batch rejected at height {height} ({e:?}); isolating {} blocks", retained.len());
            return retained
                .into_iter()
                .map(|raw| {
                    let height = raw.request.height;
                    let hash = raw.request.hash;
                    let source_peer = raw.source_peer.clone();
                    VerifyOutcome { height, hash, source_peer, result: semantic_verify(raw, assume_valid) }
                })
                .collect();
        }
    }

    retained
        .into_iter()
        .zip(staged)
        .map(|(raw, result)| VerifyOutcome {
            height: raw.request.height,
            hash: raw.request.hash,
            source_peer: raw.source_peer,
            result,
        })
        .collect()
}

/// Every context-free check for one block except the Groth16 pairing, which is
/// queued into the caller's batch.
pub(crate) fn verify_into_batch(block: RawBlock, assume_valid: bool, batch: &mut ProofBatch) -> Result<SemanticBlock> {
    let RawBlock { request, raw, .. } = block;
    let height = request.height;
    let ctx = Context {
        height,
        prev_height: height.saturating_sub(1),
        median_time_past: request.median_time_past,
    };
    let assume_valid = assume_valid && height <= ASSUME_VALID_HEIGHT;
    let (validated, parsed_txs) = validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, batch)
        .map_err(|e| anyhow!("block {height}: {e:?}"))?;
    if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
        bail!("block {height}: consensus decoder returned inconsistent transaction data");
    }
    let prev = header_prev(&raw)?;
    let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
    let precomputed_txs: Vec<ycash_script::PrecomputedTxData> =
        parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();
    Ok(SemanticBlock::from_commit(BlockCommit {
        height,
        hash: request.hash,
        prev,
        work: request.work,
        raw,
        txs,
        parsed_txs,
        precomputed_txs,
        proofs_verified: true,
    }))
}

/// Strict pipeline reset.
///
/// Every batch carries the epoch it was assembled in. When any stage rejects a
/// block, rejects a batch, or fails to publish, that stage bumps the epoch and
/// records the canonical tip + 1 as the new start. Every other stage then
/// throws away everything it is holding above the tip and starts again from
/// that height.
///
/// This is what makes the pipeline strict. There is no side lane that carries
/// a single block past the intake gate: a height that has to be fetched again
/// comes back through a complete, ordered, full batch exactly like every other
/// height. Nothing partial ever moves.
struct PipelineReset {
    epoch: AtomicU64,
    resume_from: AtomicU64,
    /// Consecutive resets with no successful publication in between. Used only
    /// to stop a deterministic rejection becoming a hot download/verify loop.
    failures: AtomicU64,
}

impl PipelineReset {
    fn new(resume_from: u64) -> Self {
        Self {
            epoch: AtomicU64::new(1),
            resume_from: AtomicU64::new(resume_from),
            failures: AtomicU64::new(0),
        }
    }

    fn epoch(&self) -> u64 {
        self.epoch.load(Ordering::SeqCst)
    }

    fn resume_from(&self) -> u64 {
        self.resume_from.load(Ordering::SeqCst)
    }

    /// Discard everything above `from - 1` and restart every stage there.
    ///
    /// The resume height is stored before the epoch is bumped, so any stage
    /// that observes the new epoch is guaranteed to read the matching height.
    /// Returns how long the caller should pause before continuing.
    fn request(&self, from: u64) -> Duration {
        self.resume_from.store(from, Ordering::SeqCst);
        self.epoch.fetch_add(1, Ordering::SeqCst);
        let streak = self.failures.fetch_add(1, Ordering::SeqCst).saturating_add(1);
        failure_backoff(streak.min(u32::MAX as u64) as u32)
    }

    /// A batch was published: the pipeline is healthy again.
    fn settled(&self) {
        self.failures.store(0, Ordering::SeqCst);
    }
}

/// A contiguous verification chunk leaving the intake gate. It may contain
/// anywhere from 1 to 16 blocks. The state connector, not this structure, owns
/// the 16-block atomic commit boundary.
struct IntakeBatch {
    epoch: u64,
    first_height: u64,
    last_height: u64,
    /// Ascending by height, contiguous, no gaps.
    blocks: Vec<RawBlock>,
}

/// A contiguous chunk in which every block passed cryptographic verification.
/// Chunks are later coalesced into exact atomic commit windows by the ordered
/// state connector.
struct CryptoVerified {
    epoch: u64,
    first_height: u64,
    last_height: u64,
    hashes: Vec<[u8; 32]>,
    blocks: Vec<SemanticBlock>,
}

/// Cryptographic verification batch. The live scheduler admits up to 16 ordered
/// blocks at a time, but it may start with fewer when the bounded fill timer fires.
/// The cryptographic verifier itself still batch-verifies all Sapling proofs that
/// were accumulated across the admitted chunk.
pub const VERIFICATION_BATCH_SIZE: usize = crate::PIPELINE_BATCH_SIZE;

/// Maximum number of blocks in one cryptographic verification group. Keeping this
/// at 16 preserves the existing cross-block Sapling proof batching behavior.
pub const VERIFICATION_MAX_BATCH: usize = VERIFICATION_BATCH_SIZE;

/// Maximum time a partial contiguous run is held waiting for more blocks. This
/// is deliberately small so the verifier stays continuously fed at the chain
/// tip while fast peers normally fill groups to 16 before this expires.
pub const VERIFICATION_FILL_DELAY: Duration = Duration::from_millis(40);

/// Bounded number of verified chunks buffered ahead of the ordered state
/// connector. At 16 blocks/chunk this gives room for 128 verified blocks while
/// still applying deterministic backpressure.
pub const VERIFIED_CHUNK_QUEUE: usize = crate::INTAKE_READY_BATCHES * 2;

/// Complete verifier chunks targeted ahead of the hot frontier. This remains a
/// target rather than an admission barrier.
pub const INTAKE_READY_BATCHES: usize = crate::INTAKE_READY_BATCHES;

/// Total block lifecycle claims: the download window. Wide enough to hold the
/// ready queue, the batches inside the pipeline, and one batch being assembled.
pub const VERIFIER_QUEUE_CAPACITY: usize = crate::VERIFIER_QUEUE_CAPACITY;


/// How often the gate wakes when no block arrives and no partial chunk is
/// waiting, to notice a reset and refresh its telemetry (and heartbeat, which
/// the gap reconciler requires within 2s).
///
/// v0.45.22: v0.45.21 polled every 10ms unconditionally (~100 wake-ups/s while
/// idle) to service the 40ms fill timer. The gate now sleeps exactly until the
/// fill timer is due when a partial chunk is waiting, and 250ms otherwise.
const INTAKE_POLL: Duration = Duration::from_millis(250);

/// How long to wait for the next arrival: until the partial-chunk fill timer
/// is due (never less than 1ms), or the idle poll.
fn intake_wait(fill_since: Option<Instant>) -> Duration {
    match fill_since {
        Some(since) => VERIFICATION_FILL_DELAY
            .saturating_sub(since.elapsed())
            .max(Duration::from_millis(1))
            .min(INTAKE_POLL),
        None => INTAKE_POLL,
    }
}

/// How long the gate tolerates holding a gap with no claim slot left to fetch
/// it before it starts giving slots back. See `crate::GAP_RESERVE_BLOCKS`: the
/// window is sized so this cannot happen, but a stall here is permanent, so the
/// valve stays.
const STARVATION_TIMEOUT: Duration = Duration::from_secs(20);

/// Decrement a counter without ever wrapping below zero. The dashboard's queue
/// figure is diagnostic only, but a wrapped counter would show ~1.8e19 blocks.
pub(crate) fn now_unix_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

fn metrics_set_intake_frontier(metrics: &SyncMetrics, expected_first: u64) {
    metrics.intake_expected_height.store(expected_first, Ordering::Release);
}

fn saturating_dec(counter: &AtomicU64) {
    let _ = counter.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |v| Some(v.saturating_sub(1)));
}

/// Publish the latest pipeline failure for the dashboard. The coordinator shows
/// it only while the canonical tip is still the height recorded here.
fn record_failure(metrics: &SyncMetrics, tip: u64, text: String) {
    let text: String = text.replace('\n', " ").chars().take(300).collect();
    if let Ok(mut slot) = metrics.last_pipeline_failure.lock() {
        *slot = text;
    }
    metrics.last_pipeline_failure_tip.store(tip, Ordering::Relaxed);
}

/// Pause between repeated failures so a deterministic rejection cannot turn
/// into a hot download/verify loop. The first two failures retry immediately;
/// after that the delay doubles from 250 ms up to 15 s. The pipeline is already
/// stalled at that height, so the pause costs nothing.
fn failure_backoff(streak: u32) -> Duration {
    if streak < 3 {
        return Duration::ZERO;
    }
    let shift = (streak - 3).min(6);
    Duration::from_millis(250u64 << shift).min(Duration::from_secs(15))
}

/// Best-effort text for a caught panic payload.
fn panic_text(payload: &(dyn std::any::Any + Send)) -> String {
    if let Some(text) = payload.downcast_ref::<&str>() {
        (*text).to_string()
    } else if let Some(text) = payload.downcast_ref::<String>() {
        text.clone()
    } else {
        "unknown panic".to_string()
    }
}

/// Diagnostic target for the number of verifier chunks that would fit in the
/// currently advertised header horizon. This never gates verification admission.
fn ready_batch_target_for_tip(next_height: u64, header_tip: u64) -> usize {
    if header_tip < next_height {
        return 1;
    }
    let remaining = header_tip.saturating_sub(next_height).saturating_add(1);
    let possible = ((remaining.saturating_add(VERIFICATION_BATCH_SIZE as u64 - 1))
        / VERIFICATION_BATCH_SIZE as u64) as usize;
    possible.clamp(1, INTAKE_READY_BATCHES)
}

#[derive(Clone)]
pub struct VerifierPool {
    tx: SyncSender<RawBlock>,
    metrics: Arc<SyncMetrics>,
}

impl VerifierPool {
    pub fn spawn(
        workers: usize,
        queue_depth: usize,
        chain: Arc<State>,
        metrics: Arc<SyncMetrics>,
        registry: Arc<InFlightRegistry>,
        assume_valid: bool,
    ) -> Result<Self> {
        // Fixed roles, in order:
        //
        //   network ──► ordered intake (contiguous chunks, <=16)
        //                  │
        //                  ▼
        //              persistent Rayon verifier pool (4)
        //                  │ bounded verified-chunk queue
        //                  ▼
        //              ordered state connector (16-block commit assembly)
        //                  │
        //                  ▼
        //              canonical commit worker (publication only)
        //
        // The verifier is intentionally not blocked on a complete 16-block
        // commit window. Only the state connector enforces that atomic boundary.
        // The four cryptographic verifiers are one persistent Rayon pool,
        // built once here and kept for the life of the process. Previously
        // they were scoped OS threads spawned per 16-block batch and joined
        // at its end, so between batches there were literally no verifier
        // threads, and the dashboard's 4 → 0 was the truth.
        //
        // v0.45.11: this pool does verification and nothing else. Script
        // checks and all other state work belong to the separate two-worker
        // state pool (`ycash_state::chainstate::shared_pool`).
        let workers = if workers == 0 { crate::VERIFIER_WORKERS } else { workers.min(64) };
        let verify_pool: &'static rayon::ThreadPool = Box::leak(Box::new(crate::batch::build_verifier_pool(workers)?));
        let workers = verify_pool.current_num_threads();

        let start_height = match chain.tip_height() {
            Ok(Some(tip)) => tip.saturating_add(1),
            Ok(None) => 1,
            Err(e) => bail!("initial tip read failed: {e}"),
        };
        let reset = Arc::new(PipelineReset::new(start_height));

        let hot_queue = queue_depth.max(crate::PIPELINE_BATCH_SIZE).min(crate::HOT_VERIFIER_QUEUE_CAPACITY);
        let (intake_tx, intake_rx) = sync_channel::<RawBlock>(hot_queue);
        // Bounded verifier-chunk queue. It provides backpressure without turning
        // the four-chunk target into a start barrier.
        let (dispatch_tx, dispatch_rx) = sync_channel::<IntakeBatch>(VERIFIED_CHUNK_QUEUE);
        // Verified chunks may wait while ordered state preparation/publication
        // runs. This is what lets verification stay ahead without losing order.
        let (verified_tx, verified_rx) = sync_channel::<CryptoVerified>(VERIFIED_CHUNK_QUEUE);
        let (prepared_tx, prepared_rx) = sync_channel::<PreparedBatch>(1);
        let (commit_ack_tx, commit_ack_rx) = sync_channel::<bool>(1);
        metrics.verifier_workers.store(workers as u64, Ordering::Relaxed);

        // ── Stage 0: continuous ordered intake ──────────────────────────────
        //
        // The intake layer only enforces order. It no longer waits for an entire
        // 16-block commit window. A contiguous prefix is released when it reaches
        // 16 blocks, when the short fill timer expires, or when the chain tail is
        // reached. The downstream verifier therefore starts work continuously.
        let intake_state = Arc::clone(&chain);
        let intake_metrics = Arc::clone(&metrics);
        let intake_registry = Arc::clone(&registry);
        let intake_reset = Arc::clone(&reset);
        thread::Builder::new()
            .name("yortal-continuous-intake".into())
            .spawn(move || {
                let assembler = BatchAssembler::new(VERIFICATION_MAX_BATCH);
                let mut epoch = intake_reset.epoch();
                let mut expected_first = intake_reset.resume_from();
                let mut fill_since: Option<Instant> = None;
                let mut starved_since: Option<Instant> = None;
                let mut observed_gap = 0u64;
                metrics_set_intake_frontier(&intake_metrics, expected_first);

                loop {
                    let arrival = match intake_rx.recv_timeout(intake_wait(fill_since)) {
                        Ok(block) => Some(block),
                        Err(RecvTimeoutError::Timeout) => None,
                        Err(RecvTimeoutError::Disconnected) => return,
                    };

                    let current = intake_reset.epoch();
                    if current != epoch {
                        epoch = current;
                        expected_first = intake_reset.resume_from();
                        fill_since = None;
                        starved_since = None;
                        observed_gap = 0;
                        metrics_set_intake_frontier(&intake_metrics, expected_first);
                        let dropped = assembler.clear();
                        for hash in &dropped {
                            intake_registry.release(hash);
                            saturating_dec(&intake_metrics.semantic_queue);
                        }
                        intake_metrics.trace_head(
                            "continuous-intake",
                            "RESYNC",
                            expected_first,
                            None,
                            format!("pipeline reset: dropped {} held block(s); restarting from {}", dropped.len(), expected_first),
                        );
                    }

                    if let Some(block) = arrival {
                        let height = block.request.height;
                        if height < expected_first {
                            intake_registry.release(&block.request.hash);
                            saturating_dec(&intake_metrics.semantic_queue);
                            intake_metrics.duplicate_blocks.fetch_add(1, Ordering::Relaxed);
                        } else {
                            if let Some(old) = assembler.take(height) {
                                if old.request.hash != block.request.hash {
                                    intake_registry.release(&old.request.hash);
                                }
                                saturating_dec(&intake_metrics.semantic_queue);
                            }
                            let hash = block.request.hash;
                            if assembler.insert(block, expected_first) {
                                fill_since.get_or_insert_with(Instant::now);
                            } else {
                                intake_registry.release(&hash);
                                saturating_dec(&intake_metrics.semantic_queue);
                            }
                        }
                    }

                    // Admit contiguous verification chunks without waiting for the
                    // 16-block commit window. Under a fast stream this naturally
                    // emits 16-block groups; under a slow stream the 40 ms timer
                    // prevents head-of-line waiting from starving the verifier.
                    loop {
                        let available = assembler.contiguous_len_up_to(expected_first, VERIFICATION_MAX_BATCH);
                        if available == 0 {
                            fill_since = None;
                            break;
                        }
                        let header_tip = intake_state.header_height().ok().flatten().unwrap_or(0);
                        let at_tail = header_tip >= expected_first
                            && header_tip < expected_first.saturating_add(VERIFICATION_MAX_BATCH as u64)
                            && available as u64 >= header_tip.saturating_sub(expected_first).saturating_add(1);
                        let timer_expired = fill_since.map(|t| t.elapsed() >= VERIFICATION_FILL_DELAY).unwrap_or(false);
                        let should_release = available == VERIFICATION_MAX_BATCH || at_tail || timer_expired;
                        if !should_release {
                            break;
                        }

                        let Some(blocks) = assembler.release_up_to(expected_first, VERIFICATION_MAX_BATCH) else { break };
                        let first_height = expected_first;
                        let last_height = blocks.last().map(|b| b.request.height).unwrap_or(first_height);
                        if let Some(reason) = batch_entry_error(&intake_state, first_height, &blocks) {
                            eprintln!("[INTAKE] verification chunk {}..{} refused: {}", first_height, last_height, reason);
                            intake_metrics.trace_head(
                                "continuous-intake",
                                "REFUSED",
                                first_height,
                                blocks.first().map(|b| b.request.hash),
                                format!("verification chunk {}..{} refused at entry: {}", first_height, last_height, reason),
                            );
                            for block in &blocks {
                                intake_registry.release(&block.request.hash);
                                saturating_dec(&intake_metrics.semantic_queue);
                            }
                            let tip = intake_state.tip_height().ok().flatten().unwrap_or(0);
                            let pause = intake_reset.request(tip.saturating_add(1));
                            intake_metrics.pipeline_retries.fetch_add(1, Ordering::Relaxed);
                            thread::sleep(pause);
                            expected_first = intake_reset.resume_from();
                            fill_since = None;
                            break;
                        }

                        expected_first = last_height.saturating_add(1);
                        fill_since = None;
                        intake_metrics.ready_batches.fetch_add(1, Ordering::AcqRel);
                        metrics_set_intake_frontier(&intake_metrics, expected_first);
                        intake_metrics.trace_head(
                            "continuous-intake",
                            "CHUNK_READY",
                            last_height,
                            blocks.first().map(|b| b.request.hash),
                            format!("released verification chunk {}..{} ({} blocks); atomic commit size remains {}", first_height, last_height, blocks.len(), crate::PIPELINE_BATCH_SIZE),
                        );
                        if dispatch_tx.send(IntakeBatch {
                            epoch,
                            first_height,
                            last_height,
                            blocks,
                        }).is_err() {
                            return;
                        }
                        if assembler.contiguous_len_up_to(expected_first, VERIFICATION_MAX_BATCH) > 0 {
                            fill_since = Some(Instant::now());
                        }
                    }

                    let held = assembler.len();
                    intake_metrics.dispatch_pending.store(held as u64, Ordering::Relaxed);
                    if let Ok(mut published) = intake_metrics.intake_held.lock() {
                        published.clear();
                        published.extend(assembler.held_heights());
                    }
                    intake_metrics.intake_heartbeat_unix_ms.store(now_unix_ms(), Ordering::Relaxed);
                    metrics_set_intake_frontier(&intake_metrics, expected_first);
                    let gap = if held == 0 { 0 } else { assembler.missing_heights(expected_first).first().copied().unwrap_or(0) };
                    intake_metrics.dispatch_gap_height.store(gap, Ordering::Relaxed);
                    if gap == 0 {
                        observed_gap = 0;
                        intake_metrics.dispatch_gap_since_unix_ms.store(0, Ordering::Relaxed);
                    } else if gap != observed_gap {
                        observed_gap = gap;
                        intake_metrics.dispatch_gap_since_unix_ms.store(now_unix_ms(), Ordering::Relaxed);
                    }

                    if gap == 0 || intake_registry.spare_capacity() > 0 {
                        starved_since = None;
                    } else {
                        let waiting = *starved_since.get_or_insert_with(Instant::now);
                        if waiting.elapsed() >= STARVATION_TIMEOUT {
                            starved_since = None;
                            let freed = assembler.drop_highest(VERIFICATION_MAX_BATCH);
                            for hash in &freed {
                                intake_registry.release(hash);
                                saturating_dec(&intake_metrics.semantic_queue);
                            }
                            eprintln!("[INTAKE] claim pressure at gap {}; released {} far-ahead block(s)", gap, freed.len());
                        }
                    }
                }
            })
            .map_err(|e| anyhow!("failed to start continuous intake: {e}"))?;

        // ── Stage 1: continuously fed cryptographic verification ────────────
        //
        // Every admitted chunk is immediately handed to the persistent Rayon
        // pool. The batch verifier still accumulates and batch-verifies Sapling
        // proofs across all blocks in the chunk, but no longer waits for a full
        // 16-block commit window. Verified chunks are buffered ahead of the state
        // connector in a bounded queue.
        let dispatch_state = Arc::clone(&chain);
        let dispatch_metrics = Arc::clone(&metrics);
        let dispatch_registry = Arc::clone(&registry);
        let dispatch_reset = Arc::clone(&reset);
        let dispatch_pool = verify_pool;
        thread::Builder::new()
            .name("yortal-continuous-verifier".into())
            .spawn(move || {
                let mut epoch = dispatch_reset.epoch();
                let mut expected_first = dispatch_reset.resume_from();
                loop {
                    let batch = match dispatch_rx.recv_timeout(Duration::from_millis(100)) {
                        Ok(batch) => batch,
                        Err(RecvTimeoutError::Timeout) => continue,
                        Err(RecvTimeoutError::Disconnected) => return,
                    };
                    dispatch_metrics.ready_batches.fetch_sub(1, Ordering::AcqRel);
                    // v0.45.22: diagnostic only, never a start barrier. v0.45.21
                    // stopped setting it and the dashboard showed "ready N/0".
                    let header_tip = dispatch_state.header_height().ok().flatten().unwrap_or(0);
                    dispatch_metrics.ready_batch_target.store(
                        ready_batch_target_for_tip(batch.first_height, header_tip) as u64,
                        Ordering::Release,
                    );

                    let current = dispatch_reset.epoch();
                    if current != epoch {
                        epoch = current;
                        expected_first = dispatch_reset.resume_from();
                    }
                    if batch.epoch != epoch {
                        for block in &batch.blocks {
                            dispatch_registry.release(&block.request.hash);
                            saturating_dec(&dispatch_metrics.semantic_queue);
                        }
                        continue;
                    }

                    let count = batch.blocks.len();
                    let shape_ok = count > 0
                        && count <= VERIFICATION_MAX_BATCH
                        && batch.first_height == expected_first
                        && batch.blocks.first().map(|b| b.request.height) == Some(batch.first_height)
                        && batch.blocks.last().map(|b| b.request.height) == Some(batch.last_height)
                        && batch.blocks.windows(2).all(|w| w[1].request.height == w[0].request.height.saturating_add(1));
                    if !shape_ok {
                        eprintln!("[VERIFY] rejecting malformed verification chunk {}..{} ({} blocks) at {}", batch.first_height, batch.last_height, count, expected_first);
                        for block in &batch.blocks {
                            dispatch_registry.release(&block.request.hash);
                            saturating_dec(&dispatch_metrics.semantic_queue);
                        }
                        let tip = dispatch_state.tip_height().ok().flatten().unwrap_or(0);
                        let pause = dispatch_reset.request(tip.saturating_add(1));
                        dispatch_metrics.pipeline_retries.fetch_add(1, Ordering::Relaxed);
                        thread::sleep(pause);
                        continue;
                    }

                    let batch_hashes: Vec<[u8; 32]> = batch.blocks.iter().map(|b| b.request.hash).collect();
                    dispatch_metrics.trace_head(
                        "crypto-batch",
                        "DISPATCH",
                        batch.last_height,
                        batch.blocks.first().map(|b| b.request.hash),
                        format!("continuous verifier admitted {}..{} ({} blocks); cross-block Sapling batch", batch.first_height, batch.last_height, count),
                    );
                    let started = Instant::now();
                    let verified_batch = verify_batch_in_order(
                        dispatch_pool,
                        &dispatch_metrics.semantic_active_workers,
                        batch.blocks,
                        assume_valid,
                    );
                    let sapling = verified_batch.sapling;
                    dispatch_metrics.sapling_batch_blocks.store(sapling.blocks, Ordering::Relaxed);
                    dispatch_metrics.sapling_batch_proofs.store(sapling.proofs, Ordering::Relaxed);
                    dispatch_metrics.sapling_batch_spend_proofs.store(sapling.spend_proofs, Ordering::Relaxed);
                    dispatch_metrics.sapling_batch_output_proofs.store(sapling.output_proofs, Ordering::Relaxed);
                    dispatch_metrics.sapling_batch_verify_us.store(sapling.verify_us, Ordering::Relaxed);
                    for _ in 0..count {
                        saturating_dec(&dispatch_metrics.semantic_queue);
                    }

                    let verify_us = started.elapsed().as_micros() as u64;
                    let verified: BTreeMap<u64, SemanticBlock> = verified_batch.blocks.into_iter().map(|b| (b.height, b)).collect();
                    let mut rejected = verified_batch.rejected;
                    if rejected.is_none() && verified.len() != count {
                        rejected = Some((batch.first_height, "duplicate heights inside one verification chunk".into()));
                    }
                    if let Some((height, reason)) = rejected {
                        dispatch_metrics.invalid_blocks.fetch_add(1, Ordering::Relaxed);
                        let tip = dispatch_state.tip_height().ok().flatten().unwrap_or(0);
                        eprintln!("[VERIFY] block {} rejected: {}", height, reason);
                        record_failure(&dispatch_metrics, tip, format!("block {height} rejected by verifier: {reason} (verification chunk {}..{} discarded)", batch.first_height, batch.last_height));
                        for hash in &batch_hashes {
                            dispatch_registry.release(hash);
                        }
                        let pause = dispatch_reset.request(tip.saturating_add(1));
                        dispatch_metrics.pipeline_retries.fetch_add(1, Ordering::Relaxed);
                        thread::sleep(pause);
                        continue;
                    }

                    let blocks: Vec<SemanticBlock> = verified.into_values().collect();
                    expected_first = batch.last_height.saturating_add(1);
                    dispatch_metrics.semantic_batches.fetch_add(1, Ordering::Relaxed);
                    dispatch_metrics.last_semantic_batch_blocks.store(count as u64, Ordering::Relaxed);
                    dispatch_metrics.semantic_verified_blocks.fetch_add(count as u64, Ordering::Relaxed);
                    dispatch_metrics.semantic_verify_total_us.fetch_add(verify_us, Ordering::Relaxed);
                    dispatch_metrics.semantic_verify_us.store(verify_us, Ordering::Relaxed);
                    dispatch_metrics.highest_semantically_verified_height.fetch_max(batch.last_height, Ordering::Relaxed);
                    dispatch_metrics.trace_head(
                        "crypto-batch",
                        "COMPLETE",
                        batch.last_height,
                        None,
                        format!("verified {}..{} ({} blocks) in {}us; ordered state connector is independent", batch.first_height, batch.last_height, count, verify_us),
                    );

                    if verified_tx.send(CryptoVerified {
                        epoch,
                        first_height: batch.first_height,
                        last_height: batch.last_height,
                        hashes: batch_hashes,
                        blocks,
                    }).is_err() {
                        return;
                    }
                }
            })
            .map_err(|e| anyhow!("failed to start continuous verifier: {e}"))?;

        // ── Stage 2: ordered state connector ─────────────────────────────────
        //
        // Verified chunks may be short and may accumulate ahead of state. This
        // stage is the sole ordering barrier after cryptographic verification: it
        // holds verified blocks by height, takes only the next contiguous prefix,
        // and prepares exact 16-block commit windows. A final shorter window is
        // permitted only when the validated header tip has been reached.
        let prepare_state = Arc::clone(&chain);
        let prepare_metrics = Arc::clone(&metrics);
        let prepare_registry = Arc::clone(&registry);
        let prepare_reset = Arc::clone(&reset);
        thread::Builder::new()
            .name("yortal-ordered-state-connector".into())
            .spawn(move || {
                let mut batch_id = 0u64;
                let mut pending: BTreeMap<u64, SemanticBlock> = BTreeMap::new();
                let mut pending_epoch = prepare_reset.epoch();
                loop {
                    let chunk = match verified_rx.recv() {
                        Ok(chunk) => chunk,
                        Err(_) => return,
                    };

                    let current = prepare_reset.epoch();
                    if current != pending_epoch {
                        pending_epoch = current;
                        prepare_state.clear_utxo_hint();
                        let old = std::mem::take(&mut pending);
                        for (_, block) in old {
                            prepare_registry.release(&block.commit.hash);
                        }
                    }
                    if chunk.epoch != pending_epoch {
                        for hash in &chunk.hashes {
                            prepare_registry.release(hash);
                        }
                        continue;
                    }

                    for block in chunk.blocks {
                        let height = block.height;
                        if let Some(old) = pending.insert(height, block) {
                            prepare_registry.release(&old.commit.hash);
                        }
                    }

                    loop {
                        let current_epoch = prepare_reset.epoch();
                        if current_epoch != pending_epoch {
                            pending_epoch = current_epoch;
                            prepare_state.clear_utxo_hint();
                            let old = std::mem::take(&mut pending);
                            for (_, block) in old {
                                prepare_registry.release(&block.commit.hash);
                            }
                            break;
                        }

                        let tip = prepare_state.tip_height().ok().flatten().unwrap_or(0);
                        let first_height = tip.saturating_add(1);
                        let contiguous = contiguous_verified_len(&pending, first_height, VERIFICATION_MAX_BATCH);
                        if contiguous == 0 {
                            break;
                        }

                        let header_tip = prepare_state.header_height().ok().flatten().unwrap_or(0);
                        let commit_len = ordered_commit_len(contiguous, first_height, header_tip);
                        if commit_len == 0 {
                            break;
                        }
                        let mut selected = Vec::with_capacity(commit_len);
                        for i in 0..commit_len {
                            let height = first_height.saturating_add(i as u64);
                            if let Some(block) = pending.remove(&height) {
                                selected.push(block);
                            }
                        }
                        if selected.len() != commit_len {
                            let old = std::mem::take(&mut pending);
                            for (_, block) in old {
                                prepare_registry.release(&block.commit.hash);
                            }
                            let tip_now = prepare_state.tip_height().ok().flatten().unwrap_or(0);
                            record_failure(&prepare_metrics, tip_now, format!("ordered state connector lost a verified block while selecting {}..{}", first_height, first_height + commit_len as u64 - 1));
                            let pause = prepare_reset.request(tip_now.saturating_add(1));
                            prepare_metrics.pipeline_retries.fetch_add(1, Ordering::Relaxed);
                            for block in selected {
                                prepare_registry.release(&block.commit.hash);
                            }
                            thread::sleep(pause);
                            pending_epoch = prepare_reset.epoch();
                            break;
                        }

                        let hashes: Vec<[u8; 32]> = selected.iter().map(|b| b.commit.hash).collect();
                        let commits: Vec<BlockCommit> = selected.into_iter().map(|b| b.commit).collect();
                        // Everything this window spends. Read-ahead for the next
                        // window must exclude these (see State::prefetch_utxo_hint).
                        // None = spend set unknown: no read-ahead this round.
                        let spent_here = State::spent_outpoints(&commits);
                        if let Some(reason) = publication_order_error(&prepare_state, &commits) {
                            let old = std::mem::take(&mut pending);
                            for (_, block) in old {
                                prepare_registry.release(&block.commit.hash);
                            }
                            for hash in &hashes {
                                prepare_registry.release(hash);
                            }
                            let tip_now = prepare_state.tip_height().ok().flatten().unwrap_or(0);
                            record_failure(&prepare_metrics, tip_now, format!("ordered state connector refused {}..{}: {reason}", first_height, first_height + commit_len as u64 - 1));
                            let pause = prepare_reset.request(tip_now.saturating_add(1));
                            prepare_metrics.pipeline_retries.fetch_add(1, Ordering::Relaxed);
                            thread::sleep(pause);
                            pending_epoch = prepare_reset.epoch();
                            break;
                        }

                        prepare_metrics.contextual_active_batches.fetch_add(1, Ordering::Relaxed);
                        let prepare_started = Instant::now();
                        let prepared_result: Result<ycash_state::PreparedCommit> = match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                            ycash_state::chainstate::shared_pool().install(|| prepare_state.prepare_commit_batch_owned(commits))
                        })) {
                            Ok(result) => result,
                            Err(payload) => Err(anyhow!("state preparation panicked: {}", panic_text(&*payload))),
                        };
                        prepare_metrics.contextual_active_batches.fetch_sub(1, Ordering::Relaxed);

                        let prepared = match prepared_result {
                            Ok(prepared) => prepared,
                            Err(e) => {
                                prepare_metrics.invalid_blocks.fetch_add(1, Ordering::Relaxed);
                                let old = std::mem::take(&mut pending);
                                for (_, block) in old {
                                    prepare_registry.release(&block.commit.hash);
                                }
                                for hash in &hashes {
                                    prepare_registry.release(hash);
                                }
                                let tip_now = prepare_state.tip_height().ok().flatten().unwrap_or(0);
                                record_failure(&prepare_metrics, tip_now, format!("state preparation rejected {}..{}: {e:#}", first_height, first_height + commit_len as u64 - 1));
                                let pause = prepare_reset.request(tip_now.saturating_add(1));
                                prepare_metrics.pipeline_retries.fetch_add(1, Ordering::Relaxed);
                                thread::sleep(pause);
                                pending_epoch = prepare_reset.epoch();
                                break;
                            }
                        };

                        let last_height = first_height + commit_len as u64 - 1;
                        let prepare_us = prepare_started.elapsed().as_micros() as u64;
                        prepare_metrics.contextual_prepare_us.store(prepare_us, Ordering::Relaxed);
                        prepare_metrics.highest_contextually_verified_height.fetch_max(last_height, Ordering::Relaxed);
                        prepare_metrics.trace_head(
                            "ordered-state",
                            "PREPARED",
                            last_height,
                            None,
                            format!("prepared ordered commit {}..{} ({} blocks) in {}us", first_height, last_height, commit_len, prepare_us),
                        );
                        if prepared_tx.send(PreparedBatch {
                            epoch: pending_epoch,
                            batch_id,
                            first_height,
                            last_height,
                            blocks: commit_len,
                            hashes,
                            prepared,
                        }).is_err() {
                            return;
                        }

                        // v0.45.22: restore the UTXO read-ahead lost in v0.45.21.
                        // While this window publishes, pull in any verified
                        // chunks already queued and read the coins the next
                        // window will spend, so its preparation starts warm.
                        // Never blocks: without queued work nothing happens.
                        while let Ok(chunk) = verified_rx.try_recv() {
                            if chunk.epoch != pending_epoch {
                                for hash in &chunk.hashes {
                                    prepare_registry.release(hash);
                                }
                                continue;
                            }
                            for block in chunk.blocks {
                                let height = block.height;
                                if let Some(old) = pending.insert(height, block) {
                                    prepare_registry.release(&old.commit.hash);
                                }
                            }
                        }
                        if let Some(spent) = spent_here.as_ref() {
                            let next_first = last_height.saturating_add(1);
                            let next_len = contiguous_verified_len(&pending, next_first, VERIFICATION_MAX_BATCH);
                            if next_len > 0 {
                                let next_commits: Vec<&BlockCommit> = (0..next_len as u64)
                                    .filter_map(|i| pending.get(&next_first.saturating_add(i)))
                                    .map(|b| &b.commit)
                                    .collect();
                                let readahead_started = Instant::now();
                                match prepare_state.prefetch_utxo_hint(&next_commits, spent) {
                                    Ok(n) => eprintln!(
                                        "[READAHEAD] read {} coin(s) for {}..{} during publication of {}..{} in {}us",
                                        n,
                                        next_first,
                                        next_first + next_len as u64 - 1,
                                        first_height,
                                        last_height,
                                        readahead_started.elapsed().as_micros()
                                    ),
                                    Err(e) => {
                                        prepare_state.clear_utxo_hint();
                                        eprintln!("[READAHEAD] skipped: {e:#}");
                                    }
                                }
                            }
                        }

                        match commit_ack_rx.recv() {
                            Ok(true) => {
                                prepare_reset.settled();
                                batch_id = batch_id.saturating_add(1);
                                continue;
                            }
                            Ok(false) => {
                                prepare_state.clear_utxo_hint();
                                let old = std::mem::take(&mut pending);
                                for (_, block) in old {
                                    prepare_registry.release(&block.commit.hash);
                                }
                                let tip_now = prepare_state.tip_height().ok().flatten().unwrap_or(0);
                                let pause = prepare_reset.request(tip_now.saturating_add(1));
                                prepare_metrics.pipeline_retries.fetch_add(1, Ordering::Relaxed);
                                thread::sleep(pause);
                                pending_epoch = prepare_reset.epoch();
                                break;
                            }
                            Err(_) => return,
                        }
                    }
                }
            })
            .map_err(|e| anyhow!("failed to start ordered state connector: {e}"))?;

        // ── Stage 3: one canonical commit worker ────────────────────────────
        //
        // Publication only: the writer also rejects stale pipeline epochs and
        // apply_prepared_commit rechecks the prepared
        // tip/parent and executes the atomic RocksDB write. No parsing, UTXO
        // discovery, script execution or proof verification happens here.
        let commit_state = Arc::clone(&chain);
        let commit_metrics = Arc::clone(&metrics);
        let commit_registry = Arc::clone(&registry);
        let commit_reset = Arc::clone(&reset);
        thread::Builder::new()
            .name("yortal-batch-commit".into())
            .spawn(move || {
                while let Ok(batch) = prepared_rx.recv() {
                    let PreparedBatch {
                        epoch,
                        batch_id,
                        first_height,
                        last_height,
                        blocks,
                        hashes,
                        prepared,
                    } = batch;
                    let started = Instant::now();
                    let blocks = blocks as u64;
                    // Last gate before canonical state: the batch must be in
                    // strict height order, linked block to block, and sit
                    // directly on the current canonical tip.
                    let result: Result<()> = if epoch != commit_reset.epoch() {
                        Err(anyhow!("prepared batch is stale: epoch {epoch} != current {}", commit_reset.epoch()))
                    } else if let Some(reason) = publication_order_error(&commit_state, &prepared.blocks) {
                        Err(anyhow!("batch not in order for publication: {reason}"))
                    } else {
                        match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                            commit_state.apply_prepared_commit(prepared)
                        })) {
                            Ok(result) => result,
                            Err(payload) => Err(anyhow!("canonical publication panicked: {}", panic_text(&*payload))),
                        }
                    };
                    let committed_ok = result.is_ok();
                    match result {
                        Ok(()) => {
                            let timing = commit_state.last_commit_timing();
                            commit_metrics.database_write_us.store(timing.db_write_us, Ordering::Relaxed);
                            commit_metrics.last_publication_blocks.store(blocks, Ordering::Relaxed);
                            commit_metrics.committed_blocks.fetch_add(blocks, Ordering::Relaxed);
                            commit_metrics.canonical_height.store(last_height, Ordering::Relaxed);
                            commit_metrics.commit_batches.fetch_add(1, Ordering::Relaxed);
                            commit_metrics.commit_total_us.fetch_add(timing.total_us, Ordering::Relaxed);
                            commit_metrics.last_commit_total_us.store(timing.total_us, Ordering::Relaxed);
                            commit_metrics.last_commit_unix.store(
                                std::time::SystemTime::now()
                                    .duration_since(std::time::UNIX_EPOCH)
                                    .map(|d| d.as_secs())
                                    .unwrap_or(0),
                                Ordering::Relaxed,
                            );
                            *commit_metrics.last_commit_timing.lock().unwrap() = timing;
                            commit_metrics.trace_head(
                                "ordered-commit",
                                "COMMITTED",
                                last_height,
                                hashes.last().copied(),
                                format!(
                                    "published {}..{} as one batch of {} in {}us; publication only",
                                    first_height,
                                    last_height,
                                    blocks,
                                    started.elapsed().as_micros()
                                ),
                            );
                            commit_metrics.clear_missing_parent();
                        }
                        Err(e) => {
                            eprintln!("[COMMIT] batch {batch_id} publication failed: {e:#}");
                            commit_metrics.semantic_batch_failures.fetch_add(1, Ordering::Relaxed);
                            let tip_now = commit_state.tip_height().ok().flatten().unwrap_or(0);
                            record_failure(
                                &commit_metrics,
                                tip_now,
                                format!(
                                    "batch {}..{} publication failed: {e:#}",
                                    first_height, last_height
                                ),
                            );
                        }
                    }

                    for hash in &hashes {
                        commit_registry.release(hash);
                    }
                    let _ = commit_ack_tx.send(committed_ok);
                }
            })
            .map_err(|e| anyhow!("failed to start canonical commit worker: {e}"))?;

        Ok(Self { tx: intake_tx, metrics })
    }

    /// Bounded producer backpressure. The download window is sized so the gate
    /// can keep its ready queue full; transport itself remains limited to 16
    /// blocks per peer.
    pub fn submit(&self, block: RawBlock) -> Result<()> {
        self.metrics.semantic_queue.fetch_add(1, Ordering::Relaxed);
        self.tx.send(block).map_err(|_| {
            self.metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
            anyhow!("cryptographic verifier stopped")
        })
    }
}

/// Owned hand-off between the single expensive preparation worker and the
/// single canonical commit worker. Keeping the prepared mutation plan owned is
/// what lets the stages communicate without copying raw block data.
struct PreparedBatch {
    /// Pipeline epoch at which this prepared mutation plan was created. The
    /// commit writer rejects stale epochs so a concurrent reset can never make
    /// an old prepared plan canonical.
    epoch: u64,
    batch_id: u64,
    first_height: u64,
    last_height: u64,
    blocks: usize,
    hashes: Vec<[u8; 32]>,
    prepared: ycash_state::PreparedCommit,
}


/// Count the next contiguous verified run without touching or removing entries.
/// This is intentionally generic so the ordering rule can be unit-tested
/// independently of consensus state construction.
fn contiguous_verified_len<T>(pending: &BTreeMap<u64, T>, first_height: u64, max: usize) -> usize {
    let mut len = 0usize;
    while len < max && pending.contains_key(&first_height.saturating_add(len as u64)) {
        len += 1;
    }
    len
}

/// Select an atomic state-commit size. Full 16-block windows are always
/// admitted. A shorter window is legal only when the selected header tip is
/// inside that same window, i.e. at the validated chain tail.
fn ordered_commit_len(contiguous: usize, first_height: u64, header_tip: u64) -> usize {
    if contiguous == 0 {
        return 0;
    }
    let full = contiguous.min(VERIFICATION_MAX_BATCH);
    if full == VERIFICATION_MAX_BATCH {
        return full;
    }
    let tail_len = header_tip.saturating_sub(first_height).saturating_add(1);
    if header_tip >= first_height && tail_len <= VERIFICATION_MAX_BATCH as u64 && contiguous as u64 >= tail_len {
        tail_len as usize
    } else {
        0
    }
}

/// Why a released batch may not enter the pipeline, if it may not.
fn batch_entry_error(state: &State, first_height: u64, blocks: &[RawBlock]) -> Option<String> {
    if blocks.is_empty() {
        return Some("empty batch".into());
    }
    let mut prev_hash: Option<[u8; 32]> = if first_height > 1 {
        match state.header_hash_by_height(first_height - 1) {
            Ok(Some(h)) if h.len() == 32 => {
                let mut out = [0u8; 32];
                out.copy_from_slice(&h);
                Some(out)
            }
            _ => return Some(format!("no validated header for parent height {}", first_height - 1)),
        }
    } else {
        None
    };
    for (i, block) in blocks.iter().enumerate() {
        let want = first_height + i as u64;
        if block.request.height != want {
            return Some(format!("position {i} holds height {} instead of {want}", block.request.height));
        }
        let parent = match header_prev(&block.raw) {
            Ok(p) => p,
            Err(e) => return Some(format!("height {want}: unreadable header: {e}")),
        };
        if let Some(expected) = prev_hash {
            if parent != expected {
                return Some(format!("height {want} does not build on height {}", want.saturating_sub(1)));
            }
        }
        prev_hash = Some(block.request.hash);
    }
    None
}

/// Why a prepared batch may not be published, if it may not.
fn publication_order_error(state: &State, blocks: &[BlockCommit]) -> Option<String> {
    let Some(first) = blocks.first() else { return Some("empty batch".into()) };
    let tip = match state.tip_height() {
        Ok(tip) => tip,
        Err(e) => return Some(format!("tip unreadable: {e}")),
    };
    let expected_first = tip.map(|t| t.saturating_add(1)).unwrap_or(1);
    if first.height != expected_first {
        return Some(format!("first height {} but canonical tip + 1 is {expected_first}", first.height));
    }
    if tip.is_some() {
        match state.tip_hash() {
            Ok(Some(hash)) if hash.as_slice() == first.prev.as_slice() => {}
            _ => return Some(format!("height {} does not build on the canonical tip", first.height)),
        }
    }
    for pair in blocks.windows(2) {
        if pair[1].height != pair[0].height.saturating_add(1) {
            return Some(format!("height {} follows {}", pair[1].height, pair[0].height));
        }
        if pair[1].prev != pair[0].hash {
            return Some(format!("height {} does not build on height {}", pair[1].height, pair[0].height));
        }
    }
    None
}

/// Default verifier width: leave one core for the ordered state engine and one
/// for the Android UI thread, and never drop below one worker.
pub fn default_verifier_workers() -> usize {
    std::thread::available_parallelism()
        .map(|n| n.get().saturating_sub(2).max(1))
        .unwrap_or(1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn failure_backoff_grows_then_caps() {
        assert_eq!(failure_backoff(1), Duration::ZERO);
        assert_eq!(failure_backoff(2), Duration::ZERO);
        assert_eq!(failure_backoff(3), Duration::from_millis(250));
        assert_eq!(failure_backoff(4), Duration::from_millis(500));
        assert_eq!(failure_backoff(100), Duration::from_secs(15));
    }

    #[test]
    fn queue_counter_never_wraps() {
        let counter = AtomicU64::new(1);
        saturating_dec(&counter);
        saturating_dec(&counter);
        assert_eq!(counter.load(Ordering::Relaxed), 0);
    }

    #[test]
    fn a_reset_moves_every_stage_to_the_same_height() {
        let reset = PipelineReset::new(100);
        assert_eq!(reset.epoch(), 1);
        assert_eq!(reset.resume_from(), 100);
        reset.request(64);
        assert_eq!(reset.epoch(), 2);
        assert_eq!(reset.resume_from(), 64);
        reset.settled();
        assert_eq!(reset.request(64), Duration::ZERO);
    }

    #[test]
    fn repeated_resets_back_off_but_a_publication_clears_the_streak() {
        let reset = PipelineReset::new(1);
        assert_eq!(reset.request(1), Duration::ZERO);
        assert_eq!(reset.request(1), Duration::ZERO);
        assert_eq!(reset.request(1), Duration::from_millis(250));
        reset.settled();
        assert_eq!(reset.request(1), Duration::ZERO);
    }

    #[test]
    fn ready_prefill_target_is_four_when_four_batches_are_possible() {
        assert_eq!(ready_batch_target_for_tip(1, 64), 4);
        assert_eq!(ready_batch_target_for_tip(1, 65), 4);
        assert_eq!(ready_batch_target_for_tip(17, 64), 3);
    }

    #[test]
    fn a_single_ready_batch_is_enough_to_start_progress() {
        // The four-batch value is a desired prefill depth only. The dispatcher
        // must never wait for the target before consuming a complete batch.
        assert_eq!(INTAKE_READY_BATCHES, 4);
        assert!(INTAKE_READY_BATCHES > 1);
    }

    #[test]
    fn ready_watermark_drops_only_at_chain_tip() {
        assert_eq!(ready_batch_target_for_tip(1, 16), 1);
        assert_eq!(ready_batch_target_for_tip(1, 20), 2);
        assert_eq!(ready_batch_target_for_tip(1, 48), 3);
        assert_eq!(ready_batch_target_for_tip(1, 49), 4);
        assert_eq!(ready_batch_target_for_tip(100, 99), 1);
    }

    #[test]
    fn continuous_verifier_uses_bounded_chunks_without_changing_commit_size() {
        assert_eq!(VERIFICATION_BATCH_SIZE, 16);
        assert_eq!(VERIFICATION_MAX_BATCH, 16);
        assert_eq!(INTAKE_READY_BATCHES, 4);
        assert_eq!(VERIFIED_CHUNK_QUEUE, 8);
        assert!(VERIFICATION_FILL_DELAY <= Duration::from_millis(100));
    }

    #[test]
    fn intake_sleeps_until_the_fill_timer_or_the_idle_poll() {
        assert_eq!(intake_wait(None), INTAKE_POLL);
        let fresh = intake_wait(Some(Instant::now()));
        assert!(fresh <= VERIFICATION_FILL_DELAY && fresh >= Duration::from_millis(1));
        let overdue = Instant::now() - Duration::from_secs(1);
        assert_eq!(intake_wait(Some(overdue)), Duration::from_millis(1));
    }

    #[test]
    fn ordered_connector_coalesces_short_verifier_chunks() {
        let mut pending = BTreeMap::new();
        for height in [17u64, 18, 19, 20, 21, 22, 23] {
            pending.insert(height, ());
        }
        assert_eq!(contiguous_verified_len(&pending, 17, 16), 7);
        assert_eq!(ordered_commit_len(7, 17, 22), 6);
        assert_eq!(ordered_commit_len(7, 17, 30), 0);
    }

    #[test]
    fn ordered_connector_prefers_full_atomic_windows() {
        assert_eq!(ordered_commit_len(16, 17, 200), 16);
        assert_eq!(ordered_commit_len(32, 17, 200), 16);
        assert_eq!(ordered_commit_len(15, 17, 31), 15);
    }

    #[test]
    fn diagnostic_prefill_target_is_not_a_start_barrier() {
        assert_eq!(ready_batch_target_for_tip(1, 16), 1);
        assert_eq!(ready_batch_target_for_tip(1, 64), 4);
        assert_eq!(crate::PIPELINE_BATCH_SIZE, 16);
    }
}
