# v0.45.22 — fixes on top of the v0.45.21 continuous verifier

Keeps the v0.45.21 architecture (continuous verification chunks, ordered state
connector, epoch-fenced commits) and fixes what the review found.

1. **Head watchdog vs. the connector (stall path).** Since v0.45.21 a verified
   head can wait in the ordered connector until its 16-block window completes.
   After 120s the watchdog treated it as lost, freed its claim and fetched it
   again; the copy landed on disk below the promoter's window and stayed there.
   The watchdog now skips any head the intake frontier has already passed.
2. **Prefetch pruning.** The promoter drops cached blocks below the frontier
   (duplicates of blocks already downstream or committed) instead of leaving
   them in read-ahead slots for the rest of the run. Counted as duplicates.
3. **UTXO read-ahead restored.** While a window publishes, the connector drains
   already-verified chunks and pre-reads the coins the next window spends
   (`State::prefetch_utxo_hint`, same safety rules as before: spent coins of
   the publishing window excluded, hint bound to the next parent). The hint is
   cleared on every epoch change.
4. **Intake sleep.** Waits exactly until the 40ms fill timer is due when a
   partial chunk is pending, 250ms otherwise (v0.45.21: fixed 10ms, ~100
   wake-ups/s idle). The heartbeat still refreshes well inside the reconciler's
   2s window.
5. **Dashboard.** `ready_batch_target` is set again (diagnostic only), so the
   pipeline line no longer shows "ready N/0". Removed unused `TAIL_FLUSH_DELAY`.

## Reviewed, no change
The fill timer was suspected of starting on the first out-of-order insert. It
does not: whenever no contiguous run exists the timer is cleared, so it starts
when a contiguous run forms. Small chunks under a slow network reduce Sapling
batching, but only while the network, not the CPU, is the limit.

## Tests
Prefetch pruning; intake wait computation. `tools/verify-continuous-verifier.sh`
now also checks each fix is wired. Not compiled in the authoring environment;
the host-tests workflow is the first compile.
