# v0.45.21 — Continuous verifier + ordered state connector

## Design change

The pipeline no longer treats 16 blocks as the unit that controls admission to
verification. The 16-block value remains the **atomic canonical state-commit
unit**.

The new flow is:

```text
network / disk read-ahead
        |
        v
ordered hot intake
        |
        +--> contiguous verification chunk (1..16)
                    |
                    v
             persistent Rayon pool
             (parallel block preparation)
                    |
                    v
             cross-block Sapling proof batch
                    |
                    v
             bounded verified queue
                    |
                    v
             ordered state connector
             (N -> N+1 -> ...)
                    |
                    +--> exact 16 blocks --> atomic RocksDB commit
                    |
                    +--> short tail only when validated header tip reached
```

## Why this is safer

* Verification no longer waits for a complete 16-block window at the chain tip.
* Four ready 16-block-equivalent chunks are still a prefill target, not a start
  barrier.
* The verified queue is bounded, so read-ahead cannot grow RAM without limit.
* Verified blocks are keyed by height and cannot be committed out of order.
* The state connector only prepares the next contiguous canonical prefix.
* Canonical publication remains single-writer and uses the existing atomic
  prepared-state RocksDB path.
* Every prepared commit carries the current pipeline epoch. A reset therefore
  cannot publish a prepared plan created on the old branch/state snapshot.
* Full verification chunks retain the existing cross-block Sapling `ProofBatch`
  path. A rejected batch falls back to individual verification so a batch-level
  failure is never mistaken for proof validity.

## Important boundary

`16` is a state publication boundary, not a consensus rule. The verifier may
produce smaller chunks and the connector may temporarily buffer more than one
chunk. Only the ordered connector decides when a commit window is ready.

At the chain tip, a final partial commit is allowed because there are no more
blocks currently advertised by the validated header chain. Once more headers
arrive, normal 16-block commits resume.

## Operational parameters

* Verification chunk maximum: 16 blocks.
* Partial-chunk fill delay: 40 ms.
* Verified chunk queue: 8 chunks (up to 128 blocks at 16/chunk).
* Read-ahead reservoir: 2048 blocks on disk by default.
* Canonical state commit: one atomic 16-block batch whenever 16 contiguous
  verified blocks are available.

These are transport/scheduling parameters; they do not change consensus.
