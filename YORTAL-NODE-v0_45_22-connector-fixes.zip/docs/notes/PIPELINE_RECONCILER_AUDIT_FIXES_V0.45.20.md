# v0.45.20 — audit fixes

Follows the v0.45.19 prefetch promoter fix. Goal: stalls of the v0.45.18 kind
repair themselves and, if they do not, say exactly why on the dashboard.

## Liveness
1. **Gap reconciler** (`SyncEngine::reconcile_gap_once`, watchdog thread, 1s).
   Collects where the gap block really is (registry claim + age, hand-off,
   prefetch disk, intake gate, gate heartbeat) into `GapFacts`; the pure
   `decide_gap_action` picks one of: nothing / reserve for best peer /
   release a claim with no block behind it. Grace: 5s for `Prefetched` not on
   disk and for an unclaimed gap, 30s for post-arrival states, and never while
   the gate is busy (its channel may legitimately hold the block).
2. **Hedge blind spot** closed by (1): the hedge still owns transport claims,
   the reconciler owns every other state.
3. **Head watchdog** no longer breaks the claim of a head the gate holds or that
   is staged on disk. The gate publishes its held heights each pass
   (`SyncMetrics::intake_held`).
4. **Priority overflow claims** (`PRIORITY_OVERFLOW_CLAIMS = 2`): the head/gap
   may exceed capacity by two via `claim_priority`, `claim_reserved` and
   `reserve_head`, so a full look-ahead window can no longer block the one
   block everything waits for.

## Speed
5. Header lead 2048/1024 -> 32768/16384 (the old high mark equalled the
   download window, so the hysteresis was dead code). Header batches per turn
   are adaptive: 8 while headers are the bottleneck, 2 while behind, else 1.
   Equihash checkpoints were **not** added: skipping PoW below a hard-coded
   height is a trust decision, left for the maintainer.
6. Prefetch promoter sleeps on a condvar woken by `put()` (50ms cap) instead of
   polling every 5ms.

## Dashboard
7. MEM = device memory in use (1 - MemAvailable/MemTotal), CPU = process CPU
   share from /proc/self/stat. Previously MEM copied DB pressure and CPU was 0.
   Header height shows the higher of DB tip and counter. "Verifier jobs"
   shows active / pool.
8. New bottleneck `STALLED / BATCH GAP` after 30s on one gap, with a
   `stall_detail` line (claim state, owner, disk, held, gate, hedges, repairs)
   shown on the dashboard and logged as `[STALL]` every 30s.

## Process
9. `.github/workflows/host-tests.yml`: `cargo test -p ycash-node --lib` and
   `cargo check -p ycash-android-node` on every push.
10. APK `versionName`/`versionCode` and every node version string (P2P user
    agent, RPC, lightwalletd, banner) now come from `BUILD_ID.txt`. Change notes
    moved to `docs/notes/`; `CHANGELOG.md` at the root.

## Tests added
Registry priority overflow and stale-release; reconciler decision table;
prefetch arrival wake-up; promoter regression from v0.45.19.

Not compiled in the authoring environment: the host-tests workflow is the
first compile.
