#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
V="$ROOT/crates/node/src/verifier.rs"
B="$ROOT/crates/node/src/batch.rs"
N="$ROOT/crates/node/src/lib.rs"

fail() { echo "ERROR: $*" >&2; exit 1; }

[[ -f "$V" && -f "$B" && -f "$N" ]] || fail "node pipeline sources missing"
grep -q 'pub const VERIFICATION_MAX_BATCH: usize = VERIFICATION_BATCH_SIZE;' "$V" || fail "verification chunk cap missing"
grep -q 'pub const VERIFICATION_FILL_DELAY: Duration = Duration::from_millis(40);' "$V" || fail "partial chunk fill timer missing"
grep -q 'pub const VERIFIED_CHUNK_QUEUE: usize = crate::INTAKE_READY_BATCHES \* 2;' "$V" || fail "bounded verified queue missing"
grep -q 'sync_channel::<IntakeBatch>(VERIFIED_CHUNK_QUEUE)' "$V" || fail "bounded dispatch queue missing"
grep -q 'sync_channel::<CryptoVerified>(VERIFIED_CHUNK_QUEUE)' "$V" || fail "bounded verified-result queue missing"
grep -q 'assembler.release_up_to(expected_first, VERIFICATION_MAX_BATCH)' "$V" || fail "continuous prefix release missing"
grep -q 'verify_batch_in_order(' "$V" || fail "batch verifier not connected"
grep -q 'ordered_commit_len' "$V" || fail "ordered commit selector missing"
grep -q 'apply_prepared_commit(prepared)' "$V" || fail "canonical publication path missing"
grep -q 'epoch != commit_reset.epoch()' "$V" || fail "stale prepared epoch protection missing"
grep -q 'pub fn contiguous_len_up_to' "$B" || fail "non-blocking assembler length helper missing"
grep -q 'pub fn release_up_to' "$B" || fail "non-blocking assembler release helper missing"
grep -q 'pub const PIPELINE_BATCH_SIZE: usize = 16;' "$N" || fail "16-block atomic commit constant missing"
! grep -q 'while dispatch_metrics.ready_batches.load(Ordering::Acquire) < target as u64' "$V" || fail "prefill target has become a hard start barrier"
! grep -q 'release_ready(expected_first)' "$V" || fail "intake still requires complete 16-block groups"

grep -q 'prefetch_utxo_hint(&next_commits, spent)' "$V" || fail "UTXO read-ahead during publication missing (v0.45.22)"
grep -q 'recv_timeout(intake_wait(fill_since))' "$V" || fail "intake idle poll regressed to fixed interval (v0.45.22)"
grep -q 'intake_expected_height.load(Ordering::Acquire) > next_height' "$N" || fail "head watchdog frontier guard missing (v0.45.22)"
grep -q 'prune_below(expected.max(1))' "$N" || fail "prefetch pruning below the frontier missing (v0.45.22)"
echo 'PASS: continuous verifier architecture is statically wired with bounded admission, batch verification, ordered connector, epoch fencing, and 16-block atomic commits'
