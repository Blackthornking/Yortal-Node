# v0.45.7 — active 16-block global Sapling proof batching

## What changed

The live verifier previously split a 16-block window across four workers and each
worker performed its own deferred Sapling Groth16 batch. That meant the active
cryptographic batching boundary was the worker slice, not the full 16-block
window.

The active path now:

1. assembles the complete contiguous 16-block window;
2. splits the window into four contiguous worker slices;
3. performs parsing, consensus decoding, point checks, RedJubjub checks and
   public-input preparation in parallel;
4. returns each worker's deferred Sapling proof queue to the coordinator;
5. merges all worker queues into one `ProofBatch`, rebasing transaction tags;
6. performs one global Sapling Spend batch and one global Sapling Output batch;
7. if the global batch rejects, re-runs the authoritative single-proof verifier
   on the window and rejects at the first actual invalid block.

No proof format or consensus equation is changed.

## Consensus safety

The randomized Groth16 batch remains an optimization only. The existing
single-proof verifier remains authoritative for batch failures. Worker-local
non-pairing failures are also preserved as ordinary block failures.

The transaction tags are rebased when worker batches are merged so a failed
proof can still be mapped back to its original transaction height.

## Verification

The source-level verification script now checks the active 16-block global
batch wiring and worker-queue merge invariants.

A full Cargo build could not be run in this environment because `cargo` is not
installed. The repository's static verification script passes:

`tools/verify-ordered-48-batch-v0.34.1.sh`

and reports the active 16-block global Sapling proof batching invariants.
