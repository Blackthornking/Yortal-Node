use sha2::{Digest, Sha256};
use std::io::{Read, Write};
use std::os::unix::fs::PermissionsExt;
use base64::Engine as _;
use std::net::{IpAddr, SocketAddr, TcpListener, TcpStream, ToSocketAddrs};
use std::path::{Path, PathBuf};
use std::sync::{atomic::{AtomicBool, Ordering}, Arc, RwLock};
use std::thread;
use std::time::{Duration, Instant};
use ycash_chain::{genesis_hash_internal, read_header_at, BlockHeader, YCASH_FORK_HEIGHT, MAX_HEADERS_RESULTS};
use ycash_consensus::{validate_header_opts, block_proof, add_work, minimum_chain_work};
use ycash_network::runtime::{connect_with_timeout, getheaders_payload, parse_addr_message, unix_time, version_payload};
use ycash_network::{decode_header, encode_message, Hash256, PROTOCOL_VERSION};
use ycash_state::State;

mod runtime;
use runtime::{LiveNodeState, SharedState};
mod sync_coordinator;
use sync_coordinator::SyncCoordinator;
use ycash_node::PeerDownloadSession;

struct DoubleSha;
impl Hash256 for DoubleSha { fn hash256(data: &[u8]) -> [u8;32] { let a=Sha256::digest(data); let b=Sha256::digest(a); let mut out=[0u8;32]; out.copy_from_slice(&b); out } }

fn esc(s:&str)->String{s.replace('\\',"\\\\").replace('"',"\\\"")}
fn json_u64_array(values: &[u64;32]) -> String {
    let mut out = String::from("[");
    for (i, v) in values.iter().enumerate() {
        if i != 0 { out.push(','); }
        out.push_str(&v.to_string());
    }
    out.push(']');
    out
}


fn rolling_json(s: &LiveNodeState) -> String {
    let n = s.rolling_commits.len() as u64;
    let sum = |f: fn(&crate::runtime::RollingCommitSample) -> u64| -> u64 {
        s.rolling_commits.iter().map(f).sum()
    };
    let blocks = sum(|x| x.blocks);
    let txs = sum(|x| x.txs);
    let per_block = |v: u64| -> u64 { if blocks == 0 { 0 } else { v / blocks } };
    let blocks_per_sec = if n == 0 {
        0
    } else {
        let total_us = sum(|x| x.total_us);
        if total_us == 0 { 0 } else { blocks.saturating_mul(1_000_000) / total_us }
    };
    format!(
        r#"{{"samples":{},"blocks":{},"txs":{},"blocks_per_sec":{},"avg_commit_us_per_block":{},"avg_state_validation_us_per_block":{},"avg_tx_connect_us_per_block":{},"avg_script_us_per_block":{},"avg_script_transaction_input_extraction_us_per_block":{},"avg_script_sig_construction_us_per_block":{},"avg_script_pubkey_retrieval_us_per_block":{},"avg_script_parsing_us_per_block":{},"avg_signature_hash_preparation_us_per_block":{},"avg_ecdsa_verification_us_per_block":{},"avg_script_interpreter_us_per_block":{},"avg_script_cache_lookup_us_per_block":{},"avg_script_synchronization_us_per_block":{},"avg_sqlite_commit_us_per_block":{},"avg_db_write_us_per_block":{}}}"#,
        n, blocks, txs, blocks_per_sec,
        per_block(sum(|x| x.total_us)),
        per_block(sum(|x| x.state_validation_us)),
        per_block(sum(|x| x.tx_connect_us)),
        per_block(sum(|x| x.script_us)),
        per_block(sum(|x| x.script_transaction_input_extraction_us)),
        per_block(sum(|x| x.script_sig_construction_us)),
        per_block(sum(|x| x.script_pubkey_retrieval_us)),
        per_block(sum(|x| x.script_parsing_us)),
        per_block(sum(|x| x.signature_hash_preparation_us)),
        per_block(sum(|x| x.ecdsa_verification_us)),
        per_block(sum(|x| x.script_interpreter_us)),
        per_block(sum(|x| x.script_cache_lookup_us)),
        per_block(sum(|x| x.script_synchronization_us)),
        per_block(sum(|x| x.sqlite_commit_us)),
        per_block(sum(|x| x.db_write_us)),
    )
}
fn json(s:&LiveNodeState)->String{let target_height=match s.target_height{Some(t)=>t.to_string(),None=>"null".into()};let uptime_seconds=(unix_time()-s.started_unix).max(0);format!(r#"{{"status":"{}","peers":{},"height":{},"target_height":{},"headers_height":{},"download_height":{},"semantic_verified_height":{},"contextual_verified_height":{},"sync":"{}","connection_source":"{}","connection_endpoint":"{}","connection_detail":"{}","handshake_stage":"{}","handshake_elapsed_ms":{},"message":"{}","tip_time":{},"uptime_seconds":{},"api_listening":{},"rpc_listening":{},"p2p_listening":{},"lightwallet_listening":{},"outbound_attempts":{},"outbound_handshakes":{},"inbound_connections":{},"last_error":"{}","pipeline_error":"{}","active_outbound":{},"known_peers":{},"blocks_received":{},"blocks_validated":{},"txs_indexed":{},"last_block_bytes":{},"last_block_height":{},"headers_validated":{},"header_bytes_received":{},"block_bytes_received":{},"db_commits":{},"blocks_committed":{},"reorgs":{},"duplicate_blocks":{},"evicted_prospective":{},"invalid_blocks":{},"expired_requests":{},"stalled_parent_waits":{},"parent_retries":{},"parent_retry_height":{},"parent_retry_unix_ms":{},"missing_parent_height":{},"missing_parent_hash":"{}","missing_parent_wait_ms":{},"missing_parent_retries":{},"missing_parent_in_flight":{},"missing_parent_candidate_present":{},"head_trace":"{}","blocks_in_flight":{},"validation_queue":{},"contextual_queue":{},"last_semantic_verify_us":{},"sapling_batch_blocks":{},"sapling_batch_proofs":{},"sapling_batch_spend_proofs":{},"sapling_batch_output_proofs":{},"sapling_batch_verify_us":{},"last_contextual_prepare_us":{},"batch_size":{},"current_window":{},"validation_ms_total":{},"db_commit_ms_total":{},"last_begin_ms":{},"last_state_validation_ms":{},"last_state_validation_us":{},"last_state_unattributed_us":{},"last_header_hash_us":{},"last_connector_new_us":{},"last_connector_other_us":{},"last_block_root_us":{},"last_block_root_level_us":{},"last_block_root_level_hashes":{},"last_block_root_empty_us":{},"last_block_root_empty_hashes":{},"last_block_root_hash_us":{},"last_block_root_hashes":{},"last_block_loop_other_us":{},"last_slowest_block_height":{},"last_slowest_block_us":{},"last_slowest_block_other_us":{},"last_slowest_tx_height":{},"last_slowest_tx_index":{},"last_slowest_tx_us":{},"last_slowest_tx_other_us":{},"last_commit_total_us":{},"last_tree_ms":{},"last_parent_state_load_ms":{},"last_parent_state_load_us":{},"last_block_parse_ms":{},"last_block_parse_us":{},"last_txid_us":{},"last_tx_parse_us":{},"last_tx_connect_ms":{},"last_tx_connect_us":{},"last_sigops_ms":{},"last_sigops_us":{},"last_bip30_ms":{},"last_bip30_us":{},"last_utxo_lookup_ms":{},"last_utxo_lookup_us":{},"last_sprout_requirements_ms":{},"last_sprout_requirements_us":{},"last_value_checks_ms":{},"last_value_checks_us":{},"last_script_ms":{},"last_script_us":{},"last_coin_state_update_ms":{},"last_coin_state_update_us":{},"last_sprout_apply_ms":{},"last_sprout_apply_us":{},"last_sapling_validate_ms":{},"last_sapling_validate_us":{},"last_sapling_anchor_lookup_ms":{},"last_sapling_anchor_lookup_us":{},"last_sapling_nullifier_lookup_ms":{},"last_sapling_nullifier_lookup_us":{},"last_sapling_tree_update_ms":{},"last_sapling_tree_update_us":{},"last_block_finalize_ms":{},"last_block_finalize_us":{},"last_tree_encode_us":{},"last_read_transaction_us":{},"last_read_transaction_commit_us":{},"last_parent_frontier_load_us":{},"last_sprout_state_load_us":{},"last_sapling_anchor_queries":{},"last_sapling_nullifier_queries":{},"last_sapling_empty_hashes_avoided":{},"last_sapling_root_cache_hits":{},"last_utxo_lookups":{},"last_bip30_checks":{},"last_script_checks":{},"last_script_parallel_workers":{},"last_script_parallel_us":{},"last_script_input_work_us":{},"last_script_slowest_input_index":{},"last_script_slowest_input_us":{},"last_script_slowest_input_tx_height":{},"last_script_slowest_input_tx_index":{},"last_script_transaction_input_extraction_us":{},"last_script_sig_construction_us":{},"last_script_pubkey_retrieval_us":{},"last_script_parsing_us":{},"last_signature_hash_preparation_us":{},"last_ecdsa_verification_us":{},"last_script_interpreter_us":{},"last_script_cache_lookup_us":{},"last_script_synchronization_us":{},"last_script_permit_wait_us":{},"last_script_active_peak":{},"last_script_scheduler_gap_us":{},"last_script_worker_wall_us":{},"last_script_worker_input_work_us":{},"last_script_worker_inputs":{},"last_script_spawn_us":{},"last_script_join_us":{},"last_script_pool_overhead_us":{},"last_script_pool_threads":{},"last_script_worker_max_us":{},"last_script_worker_min_us":{},"last_utxo_cache_hits":{},"last_utxo_cache_misses":{},"last_utxo_db_lookup_us":{},"last_utxo_db_lookup_keys":{},"last_utxo_cache_hit_rate_ppm":{},"last_parent_state_cache_hit":{},"last_sprout_state_cache_hit":{},"last_db_write_ms":{},"last_db_write_us":{},"last_sql_write_ms":{},"last_index_write_ms":{},"last_sqlite_commit_ms":{},"last_sqlite_commit_us":{},"last_rollback_ms":{},"verifying_jobs":{},"buffered_ranges":{},"active_block_workers":{},"completed_ranges":{},"retried_ranges":{},"quarantined_ranges":{},"last_commit_unix":{},"pipeline_inflight_ranges":{},"pipeline_pending_ranges":{},"pipeline_verify_threads":{},"pipeline_script_budget":{},"pipeline_script_pool_threads":{},"pipeline_max_validation_workers":{},"pipeline_max_inflight_ranges":{},"pipeline_lookahead":{},"pipeline_commit_batch":{},"pipeline_max_range_len":{},"pipeline_active_range_len":{},"pipeline_cfg_validation_workers":{},"pipeline_cfg_inflight_ranges":{},"pipeline_cfg_min_window":{},"pipeline_cfg_max_window":{},"pipeline_cfg_window_step":{},"pipeline_cpu_pressure":{},"pipeline_memory_pressure":{},"pipeline_db_pressure":{},"pipeline_network_pressure":{},"pipeline_validation_pressure":{},"pipeline_bottleneck":"{}","rolling_telemetry":{},"peer_table":"{}","batch_gap_height":{},"dispatch_pending":{}}}"#,if s.running{"running"}else{"stopped"},s.peers,s.local_height,target_height,s.headers_height,s.download_height,s.semantic_verified_height,s.contextual_verified_height,esc(&s.sync_text()),esc(&s.connection_source),esc(&s.connection_endpoint),esc(&s.connection_detail),esc(&s.handshake_stage),s.handshake_elapsed_ms,esc(&s.message),s.tip_time,uptime_seconds,s.api_listening,s.rpc_listening,s.p2p_listening,s.lightwallet_listening,s.outbound_attempts,s.outbound_handshakes,s.inbound_connections,esc(&s.last_error),esc(&s.pipeline_error),s.active_outbound,s.known_peers,s.blocks_received,s.blocks_validated,s.txs_indexed,s.last_block_bytes,s.last_block_height,s.headers_validated,s.header_bytes_received,s.block_bytes_received,s.db_commits,s.blocks_committed,s.reorgs,s.duplicate_blocks,s.evicted_prospective,s.invalid_blocks,s.expired_requests,s.stalled_parent_waits,s.parent_retries,s.parent_retry_height,s.parent_retry_unix_ms,s.missing_parent_height,esc(&s.missing_parent_hash),s.missing_parent_wait_ms,s.missing_parent_retries,s.missing_parent_in_flight,s.missing_parent_candidate_present,esc(&s.head_trace),s.blocks_in_flight,s.validation_queue,s.contextual_queue,s.last_semantic_verify_us,s.sapling_batch_blocks,s.sapling_batch_proofs,s.sapling_batch_spend_proofs,s.sapling_batch_output_proofs,s.sapling_batch_verify_us,s.last_contextual_prepare_us,s.batch_size,s.current_window,s.validation_ms_total,s.db_commit_ms_total,s.last_begin_ms,s.last_state_validation_ms,s.last_state_validation_us,s.last_state_unattributed_us,s.last_header_hash_us,s.last_connector_new_us,s.last_connector_other_us,s.last_block_root_us,json_u64_array(&s.last_block_root_level_us),json_u64_array(&s.last_block_root_level_hashes),json_u64_array(&s.last_block_root_empty_us),json_u64_array(&s.last_block_root_empty_hashes),json_u64_array(&s.last_block_root_hash_us),json_u64_array(&s.last_block_root_hashes),s.last_block_loop_other_us,s.last_slowest_block_height,s.last_slowest_block_us,s.last_slowest_block_other_us,s.last_slowest_tx_height,s.last_slowest_tx_index,s.last_slowest_tx_us,s.last_slowest_tx_other_us,s.last_commit_total_us,s.last_tree_ms,s.last_parent_state_load_ms,s.last_parent_state_load_us,s.last_block_parse_ms,s.last_block_parse_us,s.last_txid_us,s.last_tx_parse_us,s.last_tx_connect_ms,s.last_tx_connect_us,s.last_sigops_ms,s.last_sigops_us,s.last_bip30_ms,s.last_bip30_us,s.last_utxo_lookup_ms,s.last_utxo_lookup_us,s.last_sprout_requirements_ms,s.last_sprout_requirements_us,s.last_value_checks_ms,s.last_value_checks_us,s.last_script_ms,s.last_script_us,s.last_coin_state_update_ms,s.last_coin_state_update_us,s.last_sprout_apply_ms,s.last_sprout_apply_us,s.last_sapling_validate_ms,s.last_sapling_validate_us,s.last_sapling_anchor_lookup_ms,s.last_sapling_anchor_lookup_us,s.last_sapling_nullifier_lookup_ms,s.last_sapling_nullifier_lookup_us,s.last_sapling_tree_update_ms,s.last_sapling_tree_update_us,s.last_block_finalize_ms,s.last_block_finalize_us,s.last_tree_encode_us,s.last_read_transaction_us,s.last_read_transaction_commit_us,s.last_parent_frontier_load_us,s.last_sprout_state_load_us,s.last_sapling_anchor_queries,s.last_sapling_nullifier_queries,s.last_sapling_empty_hashes_avoided,s.last_sapling_root_cache_hits,s.last_utxo_lookups,s.last_bip30_checks,s.last_script_checks,s.last_script_parallel_workers,s.last_script_parallel_us,s.last_script_input_work_us,s.last_script_slowest_input_index,s.last_script_slowest_input_us,s.last_script_slowest_input_tx_height,s.last_script_slowest_input_tx_index,s.last_script_transaction_input_extraction_us,s.last_script_sig_construction_us,s.last_script_pubkey_retrieval_us,s.last_script_parsing_us,s.last_signature_hash_preparation_us,s.last_ecdsa_verification_us,s.last_script_interpreter_us,s.last_script_cache_lookup_us,s.last_script_synchronization_us,s.last_script_permit_wait_us,s.last_script_active_peak,s.last_script_scheduler_gap_us,json_u64_array(&s.last_script_worker_wall_us),json_u64_array(&s.last_script_worker_input_work_us),json_u64_array(&s.last_script_worker_inputs),s.last_script_spawn_us,s.last_script_join_us,s.last_script_pool_overhead_us,s.last_script_pool_threads,s.last_script_worker_max_us,s.last_script_worker_min_us,s.last_utxo_cache_hits,s.last_utxo_cache_misses,s.last_utxo_db_lookup_us,s.last_utxo_db_lookup_keys,s.last_utxo_cache_hit_rate_ppm,s.last_parent_state_cache_hit,s.last_sprout_state_cache_hit,s.last_db_write_ms,s.last_db_write_us,s.last_sql_write_ms,s.last_index_write_ms,s.last_sqlite_commit_ms,s.last_sqlite_commit_us,s.last_rollback_ms,s.verifying_jobs,s.buffered_ranges,s.active_block_workers,s.completed_ranges,s.retried_ranges,s.quarantined_ranges,s.last_commit_unix,s.pipeline_inflight_ranges,s.pipeline_pending_ranges,s.pipeline_verify_threads,s.pipeline_script_budget,s.pipeline_script_pool_threads,s.pipeline_max_validation_workers,s.pipeline_max_inflight_ranges,s.pipeline_lookahead,s.pipeline_commit_batch,s.pipeline_max_range_len,s.pipeline_active_range_len,s.pipeline_cfg_validation_workers,s.pipeline_cfg_inflight_ranges,s.pipeline_cfg_min_window,s.pipeline_cfg_max_window,s.pipeline_cfg_window_step,s.pipeline_cpu_pressure,s.pipeline_memory_pressure,s.pipeline_db_pressure,s.pipeline_network_pressure,s.pipeline_validation_pressure,esc(&s.pipeline_bottleneck),rolling_json(s),esc(&peer_table(s)),s.batch_gap_height,s.dispatch_pending)}
fn peer_table(s:&LiveNodeState)->String{let mut v:Vec<_>=s.peer_last.iter().collect();v.sort_by_key(|(_,x)|std::cmp::Reverse(x.0));v.iter().take(20).map(|(k,x)|format!("{} - {}",k,x.1)).collect::<Vec<_>>().join(" | ")}
fn serve(mut stream:TcpStream,state:SharedState,db:Arc<State>,export_dir:PathBuf){
    let mut b=[0u8;2048];let _=stream.read(&mut b);let req=String::from_utf8_lossy(&b);
    let line=req.lines().next().unwrap_or("");
    if line.starts_with("GET /export"){
        let height=state.read().unwrap().local_height;
        export_to_stream(&mut stream,&db,&export_dir,height);
        return;
    }
    let(code,body)=if line.starts_with("GET /status "){("200 OK",json(&state.read().unwrap()))}else{("404 Not Found",r#"{"error":"not found"}"#.into())};
    let r=format!("HTTP/1.1 {code}\r\nContent-Type: application/json\r\nCache-Control: no-store\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",body.len(),body);
    let _=stream.write_all(r.as_bytes());
}
/// Handles GET /export: writes a fresh VACUUM INTO snapshot of the whole chain database (headers,
/// blocks, transactions) to a temp file, then *streams* it to the client in 256 KiB chunks. The old
/// version read the whole snapshot into RAM first, which on a multi-GB chain gets the node killed.
/// The app compresses the stream into a .zip as it arrives. `X-Chain-Height` tells the app which
/// height the snapshot is at so it can name the file. The temp file is always removed.
fn export_to_stream(stream:&mut TcpStream,db:&State,export_dir:&Path,height:u64){
    let tmp=export_dir.join(format!(".ycash-chain-export-{}.tar",unix_time()));
    let _=std::fs::remove_file(&tmp);
    let opened=db.export_snapshot(&tmp).and_then(|_|{let f=std::fs::File::open(&tmp)?;let len=f.metadata()?.len();Ok((f,len))});
    match opened{
        Ok((mut f,len))=>{
            let _=stream.set_write_timeout(Some(Duration::from_secs(120)));
            let header=format!("HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Disposition: attachment; filename=\"ycash-chain-height-{}.tar\"\r\nX-Chain-Height: {}\r\nCache-Control: no-store\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",height,height,len);
            if stream.write_all(header.as_bytes()).is_ok(){
                let mut w=std::io::BufWriter::with_capacity(256*1024,&mut *stream);
                let _=std::io::copy(&mut f,&mut w).and_then(|_|w.flush());
            }
        }
        Err(e)=>{
            let body=format!(r#"{{"error":"export failed: {}"}}"#,esc(&e.to_string()));
            let _=stream.write_all(format!("HTTP/1.1 500 Internal Server Error\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",body.len(),body).as_bytes());
        }
    }
    let _=std::fs::remove_file(&tmp);
}
fn start_api(state:SharedState,db:Arc<State>,export_dir:PathBuf)->std::io::Result<()> {
    let bind=std::env::var("YCASH_STATUS_BIND").unwrap_or_else(|_|"127.0.0.1".into());
    let port=std::env::var("YCASH_STATUS_PORT").ok().and_then(|x|x.parse().ok()).unwrap_or(8834u16);
    let listener=TcpListener::bind((bind.as_str(),port))?;
    { let mut st=state.write().unwrap(); st.api_listening=true; st.message=format!("status API listening on {}:{}",bind,port); }
    thread::spawn(move||for s in listener.incoming(){if let Ok(s)=s{let st=state.clone();let db=db.clone();let dir=export_dir.clone();thread::spawn(move||serve(s,st,db,dir));}});
    Ok(())
}

fn rpc_config(base:&Path)->(String,String) {
    let user=std::env::var("YCASH_RPC_USER").unwrap_or_else(|_|"ycashrpc".into());
    let path=base.join("rpc_credentials.conf");
    if let Ok(text)=std::fs::read_to_string(&path) {
        let mut u=None; let mut p=None;
        for l in text.lines() {
            if let Some(v)=l.strip_prefix("rpcuser="){u=Some(v.trim().to_string());}
            if let Some(v)=l.strip_prefix("rpcpassword="){p=Some(v.trim().to_string());}
        }
        if let (Some(u),Some(p))=(u,p) { return (u,p); }
    }
    let mut bytes=[0u8;32];
    if let Ok(mut f)=std::fs::File::open("/dev/urandom") { let _=std::io::Read::read_exact(&mut f,&mut bytes); }
    let pass=hex::encode(bytes);
    let _=std::fs::write(&path,format!("rpcuser={}\nrpcpassword={}\nrpcport={}\n",user,pass,
        std::env::var("YCASH_RPC_PORT").unwrap_or_else(|_|"8832".into())));
    let _=std::fs::set_permissions(&path,std::fs::Permissions::from_mode(0o600));
    (user,pass)
}

fn http_basic_ok(req:&str,user:&str,pass:&str)->bool {
    let wanted=base64::engine::general_purpose::STANDARD.encode(format!("{}:{}",user,pass));
    req.lines().any(|l|l.trim().eq_ignore_ascii_case(&format!("Authorization: Basic {}",wanted)))
}
fn rpc_response(body:&str)->String {
    format!("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",body.len(),body)
}
fn serve_rpc(mut stream:TcpStream,state:SharedState,user:String,pass:String){
    let mut b=[0u8;16384]; let n=stream.read(&mut b).unwrap_or(0);
    let req=String::from_utf8_lossy(&b[..n]).to_string();
    if !http_basic_ok(&req,&user,&pass) {
        let r="HTTP/1.1 401 Unauthorized\r\nWWW-Authenticate: Basic realm=\"Ycash 4.5.0 reference implementation\"\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
        let _=stream.write_all(r.as_bytes()); return;
    }
    let body=req.split("\r\n\r\n").nth(1).unwrap_or("");
    let method=if body.contains("\"method\":\"getblockchaininfo\""){"getblockchaininfo"}
        else if body.contains("\"method\":\"getnetworkinfo\""){"getnetworkinfo"}
        else if body.contains("\"method\":\"getpeerinfo\""){"getpeerinfo"}
        else {"unknown"};
    let st=state.read().unwrap();
    let result=match method {
        "getblockchaininfo"=>format!(r#"{{"result":{{"chain":"main","blocks":{},"headers":{},"verificationprogress":0.0}},"error":null,"id":1}}"#,st.local_height,st.headers_height),
        "getnetworkinfo"=>format!(r#"{{"result":{{"version":280000,"subversion":"/YcashAndroid:0.30.4/","protocolversion":270013,"connections":{}}},"error":null,"id":1}}"#,st.peers),
        "getpeerinfo"=>r#"{"result":[],"error":null,"id":1}"#.into(),
        _=>r#"{"result":null,"error":{"code":-32601,"message":"method not implemented"},"id":1}"#.into()
    };
    let _=stream.write_all(rpc_response(&result).as_bytes());
}
fn start_rpc(state:SharedState,base:&Path)->std::io::Result<()> {
    let bind=std::env::var("YCASH_RPC_BIND").unwrap_or_else(|_|"127.0.0.1".into());
    let port=std::env::var("YCASH_RPC_PORT").ok().and_then(|x|x.parse().ok()).unwrap_or(8832u16);
    let (user,pass)=rpc_config(base);
    let listener=TcpListener::bind((bind.as_str(),port))?;
    eprintln!("Ycash JSON-RPC listening on {}:{} (credentials: {})",bind,port,base.join("rpc_credentials.conf").display());
    { let mut st=state.write().unwrap(); st.rpc_listening=true; st.message=format!("JSON-RPC listening on {}:{}",bind,port); }
    thread::spawn(move||for s in listener.incoming(){if let Ok(s)=s{let st=state.clone();let u=user.clone();let p=pass.clone();thread::spawn(move||serve_rpc(s,st,u,p));}}); Ok(())
}
fn start_p2p_listener(state:SharedState)->std::io::Result<()> {
    let bind=std::env::var("YCASH_P2P_BIND").unwrap_or_else(|_|"0.0.0.0".into());
    let port=std::env::var("YCASH_P2P_PORT").ok().and_then(|x|x.parse().ok()).unwrap_or(8833u16);
    let listener=TcpListener::bind((bind.as_str(),port))?;
    { let mut st=state.write().unwrap(); st.p2p_listening=true; st.message=format!("P2P listening on {}:{}",bind,port); }
    thread::spawn(move||for incoming in listener.incoming(){if let Ok(mut s)=incoming{
        let st=state.clone(); thread::spawn(move||{
            let peer=s.peer_addr().ok(); let local=s.local_addr().ok();
            let _=s.set_read_timeout(Some(Duration::from_secs(20))); let _=s.set_write_timeout(Some(Duration::from_secs(20)));
            let remote=match peer { Some(x)=>x, None=>return };
            let local_addr=local.unwrap_or_else(||"0.0.0.0:0".parse().unwrap());
            {
                let mut x=st.write().unwrap();
                x.connection_source="Inbound Peer".into();
                x.connection_endpoint=remote.to_string();
                x.connection_detail="TCP accepted; sending version".into();
                x.message=format!("inbound TCP connection accepted: {}",remote);
            }
            let start=st.read().unwrap().local_height.min(i32::MAX as u64) as i32;
            let nonce=unix_time() as u64 ^ std::process::id() as u64 ^ remote.port() as u64;
            let v=version_payload(ycash_network::runtime::NODE_NETWORK,remote,local_addr,nonce,"/YcashAndroid:0.30.4/",start);
            if let Err(e)=send(&mut s,"version",&v) {
                let mut x=st.write().unwrap(); x.connection_detail=format!("inbound VERSION send failed: {}",e); x.last_error=format!("{} VERSION send: {}",remote,e); return;
            }
            let mut got_version=false; let mut got_verack=false;
            let mut peer_height=None;
            for _ in 0..32 {
                match read_message(&mut s) {
                    Ok((cmd,p)) if cmd=="version" => {
                        if got_version { let mut x=st.write().unwrap(); x.connection_detail="duplicate VERSION received".into(); return; }
                        if p.len()<4 { let mut x=st.write().unwrap(); x.connection_detail=format!("invalid VERSION payload: {} bytes",p.len()); return; }
                        let pv=i32::from_le_bytes(p[0..4].try_into().unwrap());
                        peer_height=parse_version_height(&p);
                        if pv<PROTOCOL_VERSION { let mut x=st.write().unwrap(); x.connection_detail=format!("peer protocol {} below required {}",pv,PROTOCOL_VERSION); return; }
                        got_version=true;
                        if let Err(e)=send(&mut s,"verack",&[]) { let mut x=st.write().unwrap(); x.connection_detail=format!("VERACK send failed: {}",e); x.last_error=format!("{} VERACK send: {}",remote,e); return; }
                        let _=send(&mut s,"getaddr",&[]);
                        let mut x=st.write().unwrap();
                        x.target_height=peer_height;
                        x.connection_detail=format!("VERSION received (protocol {}, peer height {:?}); VERACK sent",pv,peer_height);
                    }
                    Ok((cmd,_)) if cmd=="verack" => {
                        got_verack=true;
                        let mut x=st.write().unwrap(); x.connection_detail="VERACK received; inbound handshake complete".into();
                    }
                    Ok((cmd,p)) if cmd=="ping" => { let _=send(&mut s,"pong",&p); }
                    Ok((cmd,p)) if cmd=="addr" => {
                        if let Ok(addrs)=parse_addr_message(&p,1000) { /* inbound path has no peers.dat here */ let mut x=st.write().unwrap(); x.message=format!("inbound handshake received {} peer addresses",addrs.len()); }
                    }
                    Ok((cmd,p)) if cmd=="reject" => { let mut x=st.write().unwrap(); x.connection_detail=format!("peer rejected inbound message: {}",String::from_utf8_lossy(&p)); }
                    Ok((_cmd,_p)) => {}
                    Err(e) => { let mut x=st.write().unwrap(); x.connection_detail=format!("inbound handshake/session failed: {}",describe_io_error(&e)); x.last_error=format!("{} inbound: {}",remote,e); return; }
                }
                if got_version && got_verack { break; }
            }
            if !(got_version && got_verack) { let mut x=st.write().unwrap(); x.connection_detail=format!("inbound handshake incomplete (version={}, verack={})",got_version,got_verack); return; }
            {
                let mut x=st.write().unwrap();
                x.peers=x.peers.saturating_add(1); x.inbound_connections=x.inbound_connections.saturating_add(1);
                x.connection_source="Inbound Peer".into(); x.connection_endpoint=remote.to_string();
                x.connection_detail=format!("Ycash P2P handshake PASS: {}",remote);
                x.message=format!("inbound peer ready: {} (height {:?})",remote,peer_height);
            }
            loop {
                match read_message(&mut s) {
                    Ok((cmd,p)) if cmd=="ping" => { if send(&mut s,"pong",&p).is_err(){break;} }
                    Ok((cmd,_)) if cmd=="verack" || cmd=="version" => {}
                    Ok((_cmd,_p)) => {}
                    Err(e) => { let mut x=st.write().unwrap(); x.connection_detail=format!("inbound peer {} disconnected: {}",remote,describe_io_error(&e)); break; }
                }
            }
            let mut x=st.write().unwrap(); x.peers=x.peers.saturating_sub(1);
        });
    }}); Ok(())
}

fn describe_io_error(e:&std::io::Error)->String{
    if e.raw_os_error()==Some(11){return "timed out: Android/Linux EAGAIN (os error 11)".into();}
    match e.kind(){std::io::ErrorKind::UnexpectedEof=>"EOF while reading a complete Ycash P2P message (peer closed mid-frame)".into(),std::io::ErrorKind::WouldBlock=>"timed out: peer sent nothing (Android reports read timeout as EAGAIN)".into(),std::io::ErrorKind::TimedOut=>"read timeout waiting for a complete P2P message".into(),std::io::ErrorKind::ConnectionReset=>"connection reset by peer".into(),std::io::ErrorKind::ConnectionAborted=>"connection aborted".into(),std::io::ErrorKind::BrokenPipe=>"broken pipe".into(),_=>format!("{} ({:?})",e,e.kind())}
}
fn is_timeout(e:&std::io::Error)->bool{matches!(e.kind(),std::io::ErrorKind::WouldBlock|std::io::ErrorKind::TimedOut)||e.raw_os_error()==Some(11)}
fn read_message(stream:&mut TcpStream)->std::io::Result<(String,Vec<u8>)>{
    let mut h=[0u8;24];
    // Wait for the first byte with the socket's normal (short) timeout. A timeout here means the
    // peer is idle and nothing was consumed. Once a message has started, finish it with a long
    // timeout: a short timeout mid-frame (large addr/headers/block messages on mobile data) used to
    // discard half a message, desync the stream and drop the peer.
    loop{match stream.read(&mut h[..1]){Ok(0)=>return Err(std::io::Error::new(std::io::ErrorKind::UnexpectedEof,"peer closed")),Ok(_)=>break,Err(e) if e.kind()==std::io::ErrorKind::Interrupted=>continue,Err(e)=>return Err(e)}}
    let prev=stream.read_timeout().ok().flatten();
    let _=stream.set_read_timeout(Some(Duration::from_secs(180)));
    let r=(||->std::io::Result<(String,Vec<u8>)>{
    stream.read_exact(&mut h[1..])?;
    let(cmd,len,checksum)=decode_header::<DoubleSha>(&h)?;
    if len as usize>2*1024*1024{return Err(std::io::Error::new(std::io::ErrorKind::InvalidData,"message exceeds Ycash 2 MiB limit"))}
    let mut p=vec![0u8;len as usize];
    stream.read_exact(&mut p)?;
    if DoubleSha::hash256(&p)[..4]!=checksum{return Err(std::io::Error::new(std::io::ErrorKind::InvalidData,format!("{} checksum mismatch",cmd)))}
    Ok((cmd,p))
    })();
    let _=stream.set_read_timeout(prev);
    r
}
fn send(stream:&mut TcpStream,cmd:&str,payload:&[u8])->std::io::Result<()>{stream.write_all(&encode_message::<DoubleSha>(cmd,payload)?)}

#[derive(Clone,Debug)]struct PeerCandidate{addr:SocketAddr,source:String}
#[derive(Clone,Debug)]struct PeerRecord{addr:SocketAddr,last_seen:u64,attempts:u32,tried:bool}
fn load_peer_records(path:&Path)->Vec<PeerRecord>{std::fs::read_to_string(path).ok().map(|s|s.lines().filter_map(|l|{let f:Vec<_>=l.split('\t').collect();if f.len()>=4{Some(PeerRecord{addr:f[0].parse().ok()?,last_seen:f[1].parse().unwrap_or(0),attempts:f[2].parse().unwrap_or(0),tried:f[3]=="1"})}else{Some(PeerRecord{addr:l.parse().ok()?,last_seen:0,attempts:0,tried:false})}}).collect()).unwrap_or_default()}
fn save_peer_records(path:&Path,records:&[PeerRecord]){let body=records.iter().take(512).map(|r|format!("{}\t{}\t{}\t{}",r.addr,r.last_seen,r.attempts,if r.tried{"1"}else{"0"})).collect::<Vec<_>>().join("\n");let _=std::fs::write(path,body);}
fn routable(a:&SocketAddr)->bool{if a.port()==0{return false}match a.ip(){IpAddr::V4(v)=>{let o=v.octets();!(v.is_private()||v.is_loopback()||v.is_link_local()||v.is_unspecified()||v.is_broadcast()||v.is_documentation()||(o[0]==100&&(o[1]&0xc0)==64))},IpAddr::V6(v)=>{let o=v.segments();!(v.is_loopback()||v.is_unspecified()||(o[0]&0xfe00)==0xfc00||(o[0]&0xffc0)==0xfe80)}}}
fn learn_peers(path:&Path,addrs:&[SocketAddr])->usize{let _g=PEERS_LOCK.lock().unwrap_or_else(|e|e.into_inner());let mut v=load_peer_records(path);let mut added=0;for a in addrs{if !routable(a){continue}if !v.iter().any(|r|r.addr==*a){v.push(PeerRecord{addr:*a,last_seen:0,attempts:0,tried:false});added+=1;}}v.sort_by_key(|r|std::cmp::Reverse((r.tried,r.last_seen)));save_peer_records(path,&v);added}
static PEERS_LOCK:std::sync::Mutex<()>=std::sync::Mutex::new(());
static PEER_FILE:std::sync::OnceLock<PathBuf>=std::sync::OnceLock::new();
/// Ycash 4.5.0 reference implementation answers our getaddr a moment after the handshake, i.e. while this peer is already inside
/// header/block sync. Those loops used to discard every non-sync message, so the address list was lost
/// and the node never learned any other peers to connect to.
fn learn_from_addr_payload(p:&[u8]){if let (Some(pf),Ok(addrs))=(PEER_FILE.get(),parse_addr_message(p,1000)){let n=learn_peers(pf,&addrs);if n>0{eprintln!("learned {} new peer addresses during sync",n);}}}
fn save_peer(path:&Path,addr:SocketAddr){let _g=PEERS_LOCK.lock().unwrap_or_else(|e|e.into_inner());let mut v=load_peer_records(path);if let Some(r)=v.iter_mut().find(|r|r.addr==addr){r.last_seen=unix_time() as u64;r.tried=true;}else{v.push(PeerRecord{addr,last_seen:unix_time() as u64,attempts:0,tried:true});}v.sort_by_key(|r|std::cmp::Reverse((r.tried,r.last_seen)));save_peer_records(path,&v)}
fn ban_peer(base:&Path,addr:SocketAddr){let p=base.join("banlist.dat");let mut v=std::fs::read_to_string(&p).unwrap_or_default();if !v.lines().any(|x|x.trim()==addr.to_string()){v.push_str(&format!("{}\t{}\n",addr,unix_time()+24*60*60));let _=std::fs::write(p,v);}}
fn is_banned(base:&Path,addr:SocketAddr)->bool{let p=base.join("banlist.dat");let now=unix_time();std::fs::read_to_string(p).ok().map(|s|s.lines().any(|l|{let f:Vec<_>=l.split('\t').collect();f.len()>=2&&f[0]==addr.to_string()&&f[1].parse::<i64>().unwrap_or(0)>now})).unwrap_or(false)}

fn mark_peer_attempt(path:&Path,addr:SocketAddr){let _g=PEERS_LOCK.lock().unwrap_or_else(|e|e.into_inner());let mut v=load_peer_records(path);if let Some(r)=v.iter_mut().find(|r|r.addr==addr){r.attempts=r.attempts.saturating_add(1);}else{v.push(PeerRecord{addr,last_seen:0,attempts:1,tried:false});}save_peer_records(path,&v)}

fn parse_version_height(version:&[u8])->Option<u64>{let mut i=4+8+8+26+26+8;let b=*version.get(i)?;let n=match b{0..=252=>{i+=1;b as usize},253=>{let x=version.get(i+1..i+3)?;i+=3;u16::from_le_bytes([x[0],x[1]]) as usize},254=>{let x=version.get(i+1..i+5)?;i+=5;u32::from_le_bytes(x.try_into().ok()?) as usize},255=>{let x=version.get(i+1..i+9)?;i+=9;u64::from_le_bytes(x.try_into().ok()?) as usize}};i=i.checked_add(n)?;if version.len()<i+4{return None}Some(i32::from_le_bytes(version[i..i+4].try_into().ok()?).max(0) as u64)}

fn header_from_raw(raw:&[u8],height:u64)->std::io::Result<BlockHeader>{let mut c=std::io::Cursor::new(raw);read_header_at(&mut c,height).map_err(|e|std::io::Error::new(std::io::ErrorKind::InvalidData,e.to_string()))}
#[allow(dead_code)]
fn mtp(state:&State,height:u64)->u32{
    // One query for the 11 previous timestamps (was 11 separate locked lookups + 11 full header decodes, per block and per header).
    let start=height.saturating_sub(11);let mut times=Vec::new();if start==0&&height>0{times.push(ycash_consensus::GENESIS_TIME);}
    if let Ok(rows)=state.header_times_range(start.max(1),height){for (_,t) in rows{times.push(t);}}
    if times.is_empty(){0}else{times.sort_unstable();times[times.len()/2]}
}

#[allow(dead_code)]
fn load_header_history(state:&State, next_height:u64)->std::io::Result<(u64,Vec<BlockHeader>)>{
    if next_height<=1{return Ok((1,Vec::new()));}
    let end=next_height-1;
    // 17-block window + 11-block median for pindexFirst = 28 headers, including genesis when needed.
    let start=end.saturating_sub(27);
    let mut out=Vec::new();
    for h in start..=end{
        if h==0{out.push(BlockHeader{version:4,prev:[0;32],merkle:[0;32],light_client_root:[0;32],time:ycash_consensus::GENESIS_TIME,bits:ycash_consensus::GENESIS_BITS,nonce:[0;32],solution:Vec::new()});continue;}
        let raw=state.header_by_height(h).map_err(|e|ioe(&e.to_string()))?.ok_or_else(||ioe(&format!("missing header {h}")))?;
        out.push(header_from_raw(&raw,h)?);
    }
    Ok((start,out))
}

fn parse_headers(payload:&[u8],start_height:u64)->std::io::Result<Vec<(u64,BlockHeader,Vec<u8>)>>{
    let mut i=0usize;let count=ycash_network::runtime::read_compact_size(payload,&mut i).map_err(|e|e)? as usize;if count>MAX_HEADERS_RESULTS{return Err(std::io::Error::new(std::io::ErrorKind::InvalidData,"too many headers"))}let mut out=Vec::with_capacity(count);for n in 0..count{let height=start_height+n as u64;let begin=i;let slice=&payload[i..];let mut c=std::io::Cursor::new(slice);let h=read_header_at(&mut c,height).map_err(|e|std::io::Error::new(std::io::ErrorKind::InvalidData,e.to_string()))?;i+=c.position() as usize;let _tx_count=ycash_network::runtime::read_compact_size(payload,&mut i).map_err(|e|e)?;out.push((height,h,payload[begin..i].to_vec()));}Ok(out)}

/// Synchronise headers, feeding any block that arrives to `blocks`.
///
/// The sink is what stops this from silently eating the block download. This
/// function owns the socket while it runs, and its inner read loop used to
/// discard every message that was not `headers` — including `block`. Blocks
/// already requested and already on the wire were read off the socket and
/// dropped on the floor, so their requests stayed outstanding until they timed
/// out, were re-requested, and were dropped again if header sync was still
/// running. With headers streaming and block bytes at zero, the node looked
/// exactly like a peer that had stopped serving blocks. It was us.
/// Pause before asking a peer for headers again after a turn that returned
/// nothing. Without it a caught-up node sends `getheaders` on every pass.
const HEADER_IDLE_BACKOFF:Duration=Duration::from_secs(2);

fn sync_headers(stream:&mut TcpStream,state:Arc<State>,live:&SharedState,source:&str,endpoint:&str,mut blocks:Option<(&SyncCoordinator,&mut PeerDownloadSession)>,max_batches:usize)->std::io::Result<u64>{
    let mut turns=0usize;
    let mut next=state.header_height().map_err(|e| ioe(&e.to_string()))?.unwrap_or(0)+1;
    if next==1 {
        eprintln!("[SYNC] GENESIS-FIRST: no persisted headers; first accepted header must have prev={}", hex::encode(genesis_hash_internal()));
    }
    loop{
        let locator=state.locator_hashes().map_err(|e| ioe(&e.to_string()))?;let stop=[0u8;32];send(stream,"getheaders",&getheaders_payload(&locator,&stop))?;
        // Previously every unrelated message (addr, inv, ping...) looped back and re-sent getheaders,
        // flooding the peer. Now: send once, then read until "headers", resending only after idle timeouts.
        let mut idle=0u32;
        let payload=loop{match read_message(stream){
            Ok((cmd,p)) if cmd=="headers"=>break p,
            Ok((cmd,p)) if cmd=="ping"=>{send(stream,"pong",&p)?;}
            Ok((cmd,p)) if cmd=="reject"=>return Err(std::io::Error::new(std::io::ErrorKind::ConnectionAborted,format!("peer rejected getheaders: {}",String::from_utf8_lossy(&p)))),
            Ok((cmd,p)) if cmd=="addr"=>{learn_from_addr_payload(&p);}
            Ok((cmd,p)) if cmd=="block"=>{if let Some((sink,session))=blocks.as_mut(){sink.on_block(&mut **session,p);}}
            Ok(_)=>{}
            Err(e) if is_timeout(&e)=>{idle+=1;if idle>=6{return Err(std::io::Error::new(std::io::ErrorKind::TimedOut,"peer did not answer getheaders"))}if idle%2==0{send(stream,"getheaders",&getheaders_payload(&locator,&stop))?;}}
            Err(e)=>return Err(e),
        }};
        // Peer answers from the fork point it found in our locator, not necessarily our tip.
        // Derive the start height from the first header's prev hash (Ycash 4.5.0 reference implementation does this via mapBlockIndex).
        let mut pi=0usize;let n_hdr=ycash_network::runtime::read_compact_size(&payload,&mut pi).unwrap_or(0);if n_hdr==0{break;}
        if payload.len()<pi+36{return Err(ioe("headers message truncated"));}
        let mut first_prev=[0u8;32];first_prev.copy_from_slice(&payload[pi+4..pi+36]);
        next=if first_prev==genesis_hash_internal(){
            if state.header_height().map_err(|e|ioe(&e.to_string()))?.unwrap_or(0)==0 {
                eprintln!("[SYNC] GENESIS-FIRST: accepting successor of Ycash genesis as height 1");
            }
            1
        }else{
            match state.header_height_by_hash(&first_prev).map_err(|e|ioe(&e.to_string()))?{
                Some(h)=>h+1,
                None=>return Err(ioe("headers do not connect to canonical chain (unknown/non-canonical prev hash)"))
            }
        };
        let batch=parse_headers(&payload,next)?;if batch.is_empty(){break;}
        { let mut ls=live.write().unwrap(); ls.header_bytes_received=ls.header_bytes_received.saturating_add(payload.len() as u64); }
        // v0.29.1 BATCHED header stage (Zebra-style: verify in parallel, apply
        // contextual rules in order against an in-memory window, commit once).
        //  0. Equihash for every header of this ≤160 batch on all cores.
        //  1. One range query seeds the 28-header context window below `next`.
        //  2. Contextual rules run strictly in order with ZERO DB reads -- the
        //     window answers exactly what header_hash/header_by_height/
        //     header_times_range/header_work used to answer per header.
        //  3. The whole batch is written in one SQLite transaction.
        // If header k fails (PoW or contextual), headers 0..k are still
        // committed first, exactly as the old one-at-a-time loop left them.
        let started=Instant::now();
        let (pow_ok_len,pow_err)=match first_bad_pow(&batch){Some((k,e))=>(k,Some(e)),None=>(batch.len(),None)};
        let mut win=HeaderWindow::seed(&state,next)?;
        let mut rows:Vec<ycash_state::HeaderRow>=Vec::with_capacity(batch.len());
        let mut ctx_err:Option<std::io::Error>=None;
        for (height,h,_raw) in batch[..pow_ok_len].iter(){
            match win.apply(h,*height){
                Ok(row)=>rows.push(row),
                Err(e)=>{ctx_err=Some(e);break;}
            }
        }
        let accepted=rows.len();
        if let Some(last)=rows.last(){
            let last_h=last.height;
            state.put_headers_batch(&rows).map_err(|e|ioe(&e.to_string()))?;
            let ms=started.elapsed().as_millis() as u64;
            eprintln!("[HEADERS] batch {}..{} n={} ms={} headers_per_sec={}",rows[0].height,last_h,accepted,ms,(accepted as u64)*1000/ms.max(1));
            let mut ls=live.write().unwrap();ls.headers_height=last_h;ls.headers_validated=ls.headers_validated.saturating_add(accepted as u64);ls.connection_source=source.into();ls.connection_endpoint=endpoint.into();ls.connection_detail=format!("validated Ycash headers {}..{} (Equihash {}, batched)",rows[0].height,last_h,if last_h>=YCASH_FORK_HEIGHT{"192,7"}else{"200,9"});ls.message=format!("header sync: height {}",last_h);
        }
        if let Some(e)=ctx_err{return Err(e);}
        if let Some(e)=pow_err{return Err(ioe(&e));}
        next+=batch.len() as u64;if batch.len()<MAX_HEADERS_RESULTS{break;}
        // Hand the socket back. One round trip returns at most MAX_HEADERS_RESULTS
        // headers whatever we do here, so yielding costs nothing but stops this
        // peer from being absent from the block pool for the whole header run.
        turns+=1;if max_batches!=0&&turns>=max_batches{break;}
    }
    let tip=next.saturating_sub(1);if let Some(w)=state.header_work_by_height(tip).map_err(|e|ioe(&e.to_string()))?{if w.len()==32{let mut x=[0u8;32];x.copy_from_slice(&w);if x.iter().cmp(minimum_chain_work().iter()).is_lt(){let mut ls=live.write().unwrap();ls.message=format!("header tip {tip} below Ycash minimum chain work");}}}Ok(tip)
}

// The old single-peer, post-headers-only download_blocks() was removed in
// favor of the streaming downloader, which lets every connected peer
// claim and validate disjoint height ranges concurrently, starting as soon
// as headers exist ahead of the local tip rather than waiting for header
// sync to fully finish. See peer_session()'s post-handshake loop and
// V0.23_CONCURRENT_PIPELINE.md.
/// Run `check_pow` (Equihash + target) for a header batch across all cores.
/// Returns the LOWEST failing index and its error text (same message the
/// sequential loop produced, so ban logic still matches), or None.
fn first_bad_pow(batch:&[(u64,BlockHeader,Vec<u8>)])->Option<(usize,String)>{
    if batch.is_empty(){return None;}
    let n=ycash_node::verifier::default_verifier_workers().min(batch.len()).max(1);
    let chunk=(batch.len()+n-1)/n;
    let per_chunk:Vec<Option<(usize,String)>>=thread::scope(|sc|{
        let handles:Vec<_>=batch.chunks(chunk).enumerate().map(|(ci,part)|sc.spawn(move||{
            for (k,(height,h,_)) in part.iter().enumerate(){
                if let Err(e)=ycash_consensus::check_pow(h,*height){
                    return Some((ci*chunk+k,format!("header validation failed at {height}: {e:?}")));
                }
            }
            None
        })).collect();
        handles.into_iter().enumerate().map(|(ci,j)|j.join().unwrap_or_else(|_|Some((ci*chunk,"header PoW worker panicked".to_string())))).collect()
    });
    per_chunk.into_iter().flatten().min_by_key(|(k,_)|*k)
}

/// In-memory stand-in for the header table during one batch. Holds the
/// canonical headers just below the batch (from one query) plus every header
/// accepted so far in this batch, and answers the same questions the old
/// per-header DB calls did, with the same "missing" semantics.
struct HeaderWindow{
    rows:std::collections::BTreeMap<u64,(BlockHeader,[u8;32],[u8;32])>, // header, hash, chain work
}
impl HeaderWindow{
    fn seed(state:&State,next:u64)->std::io::Result<Self>{
        let mut rows=std::collections::BTreeMap::new();
        if next>1{
            let from=next.saturating_sub(28).max(1);
            for (h,hash,work,raw) in state.header_rows_range(from,next-1).map_err(|e|ioe(&e.to_string()))?{
                rows.insert(h,(header_from_raw(&raw,h)?,hash,work));
            }
        }
        Ok(Self{rows})
    }
    /// Same arithmetic as `mtp()`: median of header times at heights
    /// [max(h-11,1), h), plus genesis time when h ≤ 11, index len/2.
    fn mtp(&self,height:u64)->u32{
        let start=height.saturating_sub(11);let mut times=Vec::new();if start==0&&height>0{times.push(ycash_consensus::GENESIS_TIME);}
        for x in start.max(1)..height{if let Some((hd,_,_))=self.rows.get(&x){times.push(hd.time);}}
        if times.is_empty(){0}else{times.sort_unstable();times[times.len()/2]}
    }
    /// Same window as `load_header_history()`.
    fn history(&self,next_height:u64)->std::io::Result<(u64,Vec<BlockHeader>)>{
        if next_height<=1{return Ok((1,Vec::new()));}
        let end=next_height-1;let start=end.saturating_sub(27);let mut out=Vec::with_capacity(28);
        for h in start..=end{
            if h==0{out.push(BlockHeader{version:4,prev:[0;32],merkle:[0;32],light_client_root:[0;32],time:ycash_consensus::GENESIS_TIME,bits:ycash_consensus::GENESIS_BITS,nonce:[0;32],solution:Vec::new()});continue;}
            let (hd,_,_)=self.rows.get(&h).ok_or_else(||ioe(&format!("missing header {h}")))?;
            out.push(hd.clone());
        }
        Ok((start,out))
    }
    /// Contextual header rules for one header (PoW already checked), in the
    /// exact order of the v0.28/v0.29.1 loop. On success the header joins the
    /// window and its DB row is returned.
    fn apply(&mut self,h:&BlockHeader,height:u64)->std::io::Result<ycash_state::HeaderRow>{
        let prev_hash=if height==1{genesis_hash_internal()}else{self.rows.get(&(height-1)).map(|r|r.1).ok_or_else(||ioe("missing previous header"))?};
        if h.prev!=prev_hash{return Err(ioe("header chain discontinuity"));}
        let mtp_time=self.mtp(height);
        if height>1{
            let prev=self.rows.get(&(height-1)).map(|r|r.0.clone()).ok_or_else(||ioe("missing previous header"))?;
            let (hist_start,hist)=self.history(height)?;
            validate_header_opts(h,height,&prev,mtp_time,hist_start,&hist,false).map_err(|e|ioe(&format!("header validation failed at {height}: {e:?}")))?;
        }else{
            if h.bits!=ycash_consensus::GENESIS_BITS{return Err(ioe("header validation failed at 1: nBits must be powLimit"));}
            if h.time<=ycash_consensus::GENESIS_TIME{return Err(ioe("header validation failed at 1: time-too-old"));}
            ycash_consensus::check_pow(h,height).map_err(|e|ioe(&format!("genesis successor PoW invalid: {e:?}")))?;
        }
        let hash=h.hash();
        let proof=block_proof(h.bits).map_err(|e|ioe(&format!("work calculation failed: {e:?}")))?;
        let prev_work=if height<=1{[0u8;32]}else{self.rows.get(&(height-1)).map(|r|r.2).ok_or_else(||ioe("missing previous chain work"))?};
        let chain_work=add_work(&prev_work,&proof);
        // Any window entry above this height came from an older branch; drop it.
        let stale:Vec<u64>=self.rows.range(height..).map(|(k,_)|*k).collect();for k in stale{self.rows.remove(&k);}
        self.rows.insert(height,(h.clone(),hash,chain_work));
        // Keep the window small (28 below the next header is all any rule reads).
        while self.rows.len()>64{let k=*self.rows.keys().next().unwrap();self.rows.remove(&k);}
        Ok(ycash_state::HeaderRow{height,hash,prev:h.prev,time:h.time,bits:h.bits,work:chain_work,raw:h.serialize()})
    }
}

fn inv_has_block(payload:&[u8])->bool{let mut i=0usize;let count=match ycash_network::runtime::read_compact_size(payload,&mut i){Ok(x)=>x as usize,Err(_)=>return false};if count>50000{return false}for _ in 0..count{if i+36>payload.len(){return false}let kind=u32::from_le_bytes(payload[i..i+4].try_into().unwrap());if kind==2{return true}i+=36;}false}

fn ioe(s:&str)->std::io::Error{std::io::Error::new(std::io::ErrorKind::InvalidData,s.to_string())}

fn peer_session(candidate:PeerCandidate,live:SharedState,peer_file:PathBuf,db:Arc<State>,sync_owner:Arc<AtomicBool>,coordinator:SyncCoordinator)->bool{
    let addr=candidate.addr; let source=candidate.source.clone(); if !source.starts_with("Fixed Seed"){mark_peer_attempt(&peer_file,addr);}
    { let mut st=live.write().unwrap(); st.outbound_attempts=st.outbound_attempts.saturating_add(1); st.connection_source=source.clone(); st.connection_endpoint=addr.to_string(); st.connection_detail="TCP CONNECT: starting".into();st.handshake_stage="TCP_CONNECT".into();st.handshake_elapsed_ms=0;st.note(&addr.to_string()); st.message=format!("connecting to {} via {}",addr,source); }
    let mut s=match connect_with_timeout(addr,Duration::from_secs(8)){Ok(x)=>{let mut st=live.write().unwrap();st.connection_detail="TCP CONNECT: PASS".into();st.handshake_stage="TCP_CONNECTED".into();st.handshake_elapsed_ms=0;st.note(&addr.to_string());x},Err(e)=>{let mut st=live.write().unwrap();st.handshake_stage="TCP_FAILED".into();st.connection_detail=format!("TCP CONNECT: FAIL — {}",describe_io_error(&e));st.note(&addr.to_string());st.last_error=format!("{} TCP: {}",addr,e);return false;}};
    let start_height=db.header_height().ok().flatten().unwrap_or(0).min(i32::MAX as u64) as i32;
    let local="0.0.0.0:0".parse().unwrap();
    let nonce=unix_time() as u64 ^ std::process::id() as u64 ^ addr.port() as u64;
    { let mut st=live.write().unwrap(); st.handshake_stage="VERSION_SEND".into(); st.handshake_elapsed_ms=0; }
    let hs_started=Instant::now();
    if let Err(e)=send(&mut s,"version",&version_payload(ycash_network::runtime::NODE_NETWORK,addr,local,nonce,"/YcashAndroid:0.30.4/",start_height)){let mut st=live.write().unwrap();st.handshake_stage="VERSION_SEND_FAILED".into();st.handshake_elapsed_ms=hs_started.elapsed().as_millis() as u64;st.connection_detail=format!("VERSION SEND: FAIL — {}",describe_io_error(&e));st.note(&addr.to_string());st.last_error=format!("{} VERSION send: {}",addr,e);return false;}
    {let mut st=live.write().unwrap();st.connection_detail="VERSION SEND: PASS; waiting for peer VERSION/VERACK".into();st.note(&addr.to_string());}
    let mut got_v=false; let mut got_a=false; let mut peer_height=None;
    // v0.29.2: a quiet read during the handshake (Android: EAGAIN / os error 11)
    // is not a failure. Keep waiting until 30s have passed since VERSION was sent.
    for _ in 0..64 {
        match read_message(&mut s) {
            Err(e) if is_timeout(&e) && hs_started.elapsed()<Duration::from_secs(30) => {let mut st=live.write().unwrap();st.handshake_stage="WAITING_FOR_PEER".into();st.handshake_elapsed_ms=hs_started.elapsed().as_millis() as u64;st.connection_detail=format!("HANDSHAKE: waiting for peer ({}s)",hs_started.elapsed().as_secs());st.note(&addr.to_string());continue;}
            Ok((cmd,p)) if cmd=="version" => {
                { let mut st=live.write().unwrap(); st.handshake_stage="VERSION_RECV".into(); st.handshake_elapsed_ms=hs_started.elapsed().as_millis() as u64; }
                if got_v {let mut st=live.write().unwrap();st.handshake_stage="VERSION_DUPLICATE".into();st.connection_detail="HANDSHAKE FAIL: duplicate VERSION".into();st.note(&addr.to_string());return false;}
                if p.len()<4 {let mut st=live.write().unwrap();st.handshake_stage="VERSION_INVALID".into();st.connection_detail=format!("HANDSHAKE FAIL: VERSION payload too short ({} bytes)",p.len());st.note(&addr.to_string());return false;}
                let peer_proto=i32::from_le_bytes(p[0..4].try_into().unwrap());
                if peer_proto<PROTOCOL_VERSION {let mut st=live.write().unwrap();st.handshake_stage="VERSION_REJECTED".into();st.connection_detail=format!("HANDSHAKE FAIL: peer protocol {} < {}",peer_proto,PROTOCOL_VERSION);st.note(&addr.to_string());return false;}
                got_v=true; peer_height=parse_version_height(&p);
                { let mut st=live.write().unwrap(); st.handshake_stage="VERACK_SEND".into(); st.handshake_elapsed_ms=hs_started.elapsed().as_millis() as u64; }
                if let Err(e)=send(&mut s,"verack",&[]){let mut st=live.write().unwrap();st.handshake_stage="VERACK_SEND_FAILED".into();st.handshake_elapsed_ms=hs_started.elapsed().as_millis() as u64;st.connection_detail=format!("VERACK SEND: FAIL — {}",describe_io_error(&e));st.note(&addr.to_string());st.last_error=format!("{} VERACK send: {}",addr,e);return false;}
                let _=send(&mut s,"getaddr",&[]);
                let mut st=live.write().unwrap();st.target_height=peer_height;st.connection_detail=format!("VERSION RECV: PASS (protocol {}, peer height {:?}); VERACK SEND: PASS",peer_proto,peer_height);st.note(&addr.to_string());
            }
            Ok((cmd,_)) if cmd=="verack" => {got_a=true;let mut st=live.write().unwrap();st.handshake_stage="VERACK_RECV".into();st.handshake_elapsed_ms=hs_started.elapsed().as_millis() as u64;st.connection_detail="VERACK RECV: PASS".into();st.note(&addr.to_string());}
            Ok((cmd,p)) if cmd=="ping" => {let _=send(&mut s,"pong",&p);}
            Ok((cmd,p)) if cmd=="addr" => {if let Ok(addrs)=parse_addr_message(&p,1000){let _=learn_peers(&peer_file,&addrs);let mut st=live.write().unwrap();st.message=format!("received {} addresses from {}",addrs.len(),addr);}}
            Ok((cmd,p)) if cmd=="reject" => {let mut st=live.write().unwrap();st.connection_detail=format!("PEER REJECT: {}",String::from_utf8_lossy(&p));st.note(&addr.to_string());}
            Ok((cmd,_)) => {let mut st=live.write().unwrap();st.connection_detail=format!("HANDSHAKE: received {}",cmd);st.note(&addr.to_string());}
            Err(e) => {let mut st=live.write().unwrap();st.handshake_stage="FAILED".into();st.handshake_elapsed_ms=hs_started.elapsed().as_millis() as u64;st.connection_detail=format!("HANDSHAKE/SESSION FAIL [{}]: {}",st.handshake_stage,describe_io_error(&e));st.note(&addr.to_string());st.last_error=format!("{} handshake [{}]: {}",addr,st.handshake_stage,e);return false;}
        }
        if got_v&&got_a {break;}
    }
    if !(got_v&&got_a){let mut st=live.write().unwrap();st.handshake_stage="INCOMPLETE".into();st.handshake_elapsed_ms=hs_started.elapsed().as_millis() as u64;st.connection_detail=format!("HANDSHAKE INCOMPLETE: version={}, verack={}",got_v,got_a);st.note(&addr.to_string());return false;}
    save_peer(&peer_file,addr);
    {let mut st=live.write().unwrap();st.peers=st.peers.saturating_add(1);st.outbound_handshakes=st.outbound_handshakes.saturating_add(1);st.connection_source=source.clone();st.connection_endpoint=addr.to_string();st.connection_detail="P2P HANDSHAKE PASS: VERSION + VERACK".into();st.handshake_stage="COMPLETE".into();st.handshake_elapsed_ms=hs_started.elapsed().as_millis() as u64;st.note(&addr.to_string());st.message=format!("outbound peer ready: {}",addr);}
    // Header sync is re-entered whenever the header chain is not ahead of the
    // committed tip. Previously one peer ran it once; if it returned early the
    // ownership flag was cleared but nothing asked again, so the header chain
    // could sit still while every peer waited for blocks it could not name.
    // Created before header sync so blocks arriving during it have somewhere to
    // go. Dropping it at the end of the session releases every claim.
    let mut download=coordinator.session(&addr.to_string());
    if sync_owner.compare_exchange(false,true,Ordering::AcqRel,Ordering::Acquire).is_ok(){
        // Headers stay a single canonical, strictly ordered stream owned by
        // one peer at a time. Blocks no longer wait for this to finish: as
        // soon as headers exist ahead of our validated tip, every other
        // connected peer's session loop below starts claiming and validating
        // blocks concurrently via the shared engine (see sync_coordinator.rs).
        let result=sync_headers(&mut s,db.clone(),&live,&source,&addr.to_string(),Some((&coordinator,&mut download)),sync_coordinator::HEADER_BATCHES_PER_TURN);
        sync_owner.store(false,Ordering::Release);
        match result {
            Ok(tip)=>{let _=tip;coordinator.headers_advanced();}
            Err(e)=>{let detail=e.to_string();if detail.contains("invalid Equihash")||detail.contains("header hash above target")||detail.contains("wrong Equihash solution length"){if let Some(base)=peer_file.parent(){ban_peer(base,addr);}}let mut st=live.write().unwrap();st.connection_detail=format!("SYNC FAIL: {}",detail);st.note(&addr.to_string());st.message=format!("sync peer {} dropped: {}",addr,detail);st.last_error=format!("{} sync: {}",addr,detail);}
        }
    }
    // 1s (was 5s): an idle worker re-checks for claimable ranges after at most 1s instead of 5s.
    let _=s.set_read_timeout(Some(Duration::from_secs(1)));let _=s.set_write_timeout(Some(Duration::from_secs(30)));
    let mut last_ping_sent=Instant::now(); let mut ping_deadline:Option<Instant>=None; let mut ping_nonce=unix_time() as u64 ^ addr.port() as u64;
    // Per-peer request window: at most 48 outstanding blocks, refilled the
    // moment one arrives (see sync_coordinator.rs). Dropping it at the end of
    // the session releases every claim, so another peer can fetch them.
    let mut last_telemetry=Instant::now();
    let mut last_header_tip=db.header_height().ok().flatten().unwrap_or(0);
    let mut next_header_attempt=Instant::now();
    loop{
        // Block-download worker: while headers are ahead of our validated
        // tip, this (and every other connected) peer claims and validates a
        // disjoint height range concurrently, independent of who currently
        // owns header sync. Falls through to normal ping/addr handling below
        // once nothing is left to claim.
        // Headers are the prerequisite for every block request: a height with
        // no validated header has no hash to ask for. Headers must therefore
        // stay ahead of the download window, but no further: see
        // `wants_headers`, which throttles the lead with hysteresis so the peer
        // that owns header sync spends most of its time fetching blocks.
        if Instant::now()>=next_header_attempt && coordinator.wants_headers() && sync_owner.compare_exchange(false,true,Ordering::AcqRel,Ordering::Acquire).is_ok(){
            let result=sync_headers(&mut s,db.clone(),&live,&source,&addr.to_string(),Some((&coordinator,&mut download)),sync_coordinator::HEADER_BATCHES_PER_TURN);
            sync_owner.store(false,Ordering::Release);
            match result{
                Ok(tip)=>{
                    // At the chain tip `wants_headers` is permanently true —
                    // headers equal the committed tip, which is below the
                    // window — so without this the peer would send `getheaders`
                    // on every pass and be answered with an empty list forever.
                    // A turn that made no progress waits before asking again.
                    if tip>last_header_tip{last_header_tip=tip;next_header_attempt=Instant::now();}
                    else{next_header_attempt=Instant::now()+HEADER_IDLE_BACKOFF;}
                    coordinator.headers_advanced();
                }
                Err(e)=>{next_header_attempt=Instant::now()+HEADER_IDLE_BACKOFF;let mut st=live.write().unwrap();st.message=format!("header resume failed: {}",e);}
            }
            // Deliberately NOT `continue`. Falling through alternates one
            // header batch with one block-service pass; restarting the loop
            // here would put us straight back into header sync and the yield
            // above would buy nothing.
        }
        {
            let (headers_height,local_height)={let st=live.read().unwrap();(st.headers_height,st.local_height)};
            if headers_height>local_height||download.in_flight()>0{
                match sync_coordinator::drive_peer(&coordinator,&mut s,&mut download,&live,&mut last_telemetry){
                    Ok(true)=>continue,
                    Ok(false)=>{},
                    Err(e)=>{let mut st=live.write().unwrap();st.connection_detail=format!("BLOCK DOWNLOAD FAIL: {}",describe_io_error(&e));st.note(&addr.to_string());st.last_error=format!("{} block download: {}",addr,e);break;}
                }
            }
        }
        match read_message(&mut s){
        Ok((cmd,p)) if cmd=="ping"=>{if send(&mut s,"pong",&p).is_err(){break}},
        Ok((cmd,p)) if cmd=="pong"=>{ping_deadline=None;let _=p;let mut st=live.write().unwrap();st.connection_detail="P2P SESSION: alive".into();st.note(&addr.to_string());},
        Ok((cmd,p)) if cmd=="addr"=>{if let Ok(addrs)=parse_addr_message(&p,1000){let _=learn_peers(&peer_file,&addrs);}},
        Ok((cmd,p)) if cmd=="inv"=>{if inv_has_block(&p)&&sync_owner.compare_exchange(false,true,Ordering::AcqRel,Ordering::Acquire).is_ok(){let result=sync_headers(&mut s,db.clone(),&live,&source,&addr.to_string(),Some((&coordinator,&mut download)),sync_coordinator::HEADER_BATCHES_PER_TURN);sync_owner.store(false,Ordering::Release);match result{Ok(_)=>{coordinator.headers_advanced();},Err(e)=>{let mut st=live.write().unwrap();st.message=format!("live chain update failed: {}",e);}}}},
        Ok((cmd,p)) if cmd=="block"=>{coordinator.on_block(&mut download,p);},
        Ok((cmd,p)) if cmd=="reject"=>{let mut st=live.write().unwrap();st.message=format!("peer reject: {}",String::from_utf8_lossy(&p));},
        Ok((cmd,_))=>{let mut st=live.write().unwrap();st.connection_detail=format!("P2P SESSION: received {}",cmd);st.note(&addr.to_string());},
        Err(e) if is_timeout(&e)=>{if let Some(deadline)=ping_deadline{if deadline.elapsed()>=Duration::from_secs(30){let mut st=live.write().unwrap();st.connection_detail="P2P SESSION FAIL: ping timeout".into();st.note(&addr.to_string());break}}if ping_deadline.is_none()&&last_ping_sent.elapsed()>=Duration::from_secs(120){ping_nonce=ping_nonce.wrapping_add(1);if send(&mut s,"ping",&ping_nonce.to_le_bytes()).is_err(){break}last_ping_sent=Instant::now();ping_deadline=Some(Instant::now());}},
        Err(e)=>{let mut st=live.write().unwrap();st.connection_detail=format!("P2P SESSION END: {}",describe_io_error(&e));st.note(&addr.to_string());break;}
    }}
    // Handshake succeeded earlier: tell the supervisor this is a healthy peer
    // worth reconnecting to quickly.
    let mut st=live.write().unwrap();st.peers=st.peers.saturating_sub(1);true
}

fn peer_candidates(peer_file:&Path)->Vec<PeerCandidate>{
    // Ycash 4.5.0 defines seed.ycash.xyz as the mainnet DNS seed and the two
    // historical fixed seeds below. Prefer DNS discovery and successful peers;
    // keep fixed seeds as an opt-in diagnostic fallback so dead historical
    // addresses cannot starve discovery.
    let mut out=Vec::new();
    if let Ok(v)=std::env::var("YCASH_PEER"){for x in v.split([',',';']).map(str::trim).filter(|x|!x.is_empty()){if let Ok(a)=x.to_socket_addrs(){for addr in a{out.push(PeerCandidate{addr,source:"Manual Peer".into()})}}}}
    if let Ok(v)=std::env::var("YCASH_AUTO_PEER"){for x in v.split([',',';']).map(str::trim).filter(|x|!x.is_empty()){if let Ok(addr)=x.parse::<SocketAddr>(){out.push(PeerCandidate{addr,source:"Auto-discovered".into()})}}}
    match "seed.ycash.xyz:8833".to_socket_addrs(){Ok(a)=>{for addr in a{out.push(PeerCandidate{addr,source:"DNS Seed (seed.ycash.xyz)".into()})}},Err(e)=>{eprintln!("DNS seed seed.ycash.xyz failed: {e}");}}
    let mut peers=load_peer_records(peer_file); peers.sort_by_key(|p|std::cmp::Reverse((p.tried,p.last_seen))); for p in peers{out.push(PeerCandidate{addr:p.addr,source:"peers.dat".into()});}
    // Ycash 4.5.0 reference implementation 4.5.0 falls back to vFixedSeeds (chainparamsseeds.h) when DNS gives nothing.
    // Always keep them at the END of the list so DNS/peers.dat are preferred, but discovery
    // can never be left with zero candidates. Set YCASH_NO_FIXED_SEEDS=1 to disable.
    if std::env::var("YCASH_NO_FIXED_SEEDS").ok().as_deref()!=Some("1"){
        for(label,s)in [("Fixed Seed #1","3.130.144.65:8833"),("Fixed Seed #2","13.126.58.237:8833")]{if let Ok(addr)=s.parse::<SocketAddr>(){out.push(PeerCandidate{addr,source:format!("{} (fallback)",label)})}}
    }
    let base=peer_file.parent().unwrap_or(Path::new("."));let mut unique=Vec::new();for c in out{if is_banned(base,c.addr){continue}if !unique.iter().any(|x:&PeerCandidate|x.addr==c.addr){unique.push(c)}}unique
}
fn peer_supervisor(live:SharedState,db:Arc<State>){
    let base=std::env::var("YCASH_DATA_DIR").map(PathBuf::from).unwrap_or_else(|_|std::env::var("YCASH_NODE_DB").ok().and_then(|p|Path::new(&p).parent().map(Path::to_path_buf)).unwrap_or_else(||std::env::temp_dir().join("ycash-android-node")));
    let _=std::fs::create_dir_all(&base);let peer_file=base.join("peers.dat");let _=PEER_FILE.set(peer_file.clone());let sync_owner=Arc::new(AtomicBool::new(false));
    // Ycash 4.5.0 reference implementation-compatible peer management is retained, while YORTAL allows up to 12 outbound connections for faster peer redundancy. The old supervisor ran
    // one session at a time, so the peer count could never stay above 1. Each session now runs in
    // its own thread; one peer owns header/block sync at a time (sync_owner).
    const MAX_OUTBOUND:usize=12;
    let active=Arc::new(std::sync::Mutex::new(std::collections::HashSet::<SocketAddr>::new()));
    let mut retry_after=std::collections::HashMap::<SocketAddr,Instant>::new();
    // v0.29.2: peers whose session completed a handshake and then ended are
    // retried after RECONNECT_HEALTHY instead of the 5-minute dead-peer backoff.
    const RECONNECT_HEALTHY:Duration=Duration::from_secs(15);
    let healthy_ended=Arc::new(std::sync::Mutex::new(Vec::<SocketAddr>::new()));
    // Shared across every peer connection so height ranges are claimed and
    // committed exactly once, in order, no matter which of the up-to-12
    // connected peers happens to fetch them (see sync_coordinator.rs).
    // One ordered state gate, one canonical writer and one verifier pool for
    // the whole process (see sync_coordinator.rs). Every peer thread below
    // feeds them; none of them mutates canonical state itself.
    let coordinator=match SyncCoordinator::start(db.clone()){Ok(c)=>c,Err(e)=>{eprintln!("sync engine failed to start: {e}");return}};
    loop{
        for a in healthy_ended.lock().unwrap().drain(..){retry_after.insert(a,Instant::now()+RECONNECT_HEALTHY);}
        let candidates=peer_candidates(&peer_file);
        if candidates.is_empty(){let mut st=live.write().unwrap();st.connection_source="DNS Seed".into();st.connection_endpoint="seed.ycash.xyz:8833".into();st.connection_detail="peer discovery: no candidates (DNS failed, peers.dat empty, fixed seeds disabled or banned); retrying".into();drop(st);thread::sleep(Duration::from_secs(5));continue;}
        {let known=load_peer_records(&peer_file).len() as u32;let act=active.lock().unwrap().len() as u32;let mut st=live.write().unwrap();st.known_peers=known;st.active_outbound=act;}
        for c in candidates{
            if active.lock().unwrap().len()>=MAX_OUTBOUND{break}
            if active.lock().unwrap().contains(&c.addr){continue}
            if let Some(t)=retry_after.get(&c.addr){if Instant::now()<*t{continue}}
            // back off 5 minutes before retrying the same address, so dead peers aren't hammered
            retry_after.insert(c.addr,Instant::now()+Duration::from_secs(300));
            active.lock().unwrap().insert(c.addr);
            let (l,pf,d,so,act,pl,he)=(live.clone(),peer_file.clone(),db.clone(),sync_owner.clone(),active.clone(),coordinator.clone(),healthy_ended.clone());
            thread::spawn(move||{let addr=c.addr;let healthy=peer_session(c,l,pf,d,so,pl);if healthy{he.lock().unwrap().push(addr);}act.lock().unwrap().remove(&addr);});
            thread::sleep(Duration::from_millis(300));
        }
        thread::sleep(Duration::from_secs(5));
    }
}


pub mod walletrpc { tonic::include_proto!("cash.z.wallet.sdk.rpc"); }

use walletrpc::compact_tx_streamer_server::{CompactTxStreamer, CompactTxStreamerServer};
use walletrpc::{BlockId, BlockRange, ChainSpec, CompactBlock, Empty, LightdInfo};
use tonic::{Request, Response, Status};
use tonic::transport::Server;
use std::pin::Pin;
use tokio_stream::Stream;
use tokio_stream::wrappers::ReceiverStream;

#[derive(Clone)]
struct LightwalletService { db: Arc<State> }

fn compact_block_from_header(raw: Vec<u8>, height: u64) -> Result<CompactBlock, Status> {
    let header = read_header_at(&mut std::io::Cursor::new(raw.as_slice()), height)
        .map_err(|e| Status::internal(format!("invalid stored header: {e}")))?;
    let hash = header.hash().to_vec();
    Ok(CompactBlock {
        height,
        hash,
        prev_hash: header.prev.to_vec(),
        time: header.time,
        header: raw,
        vtx: Vec::new(),
        chain_metadata: None,
    })
}

#[tonic::async_trait]
impl CompactTxStreamer for LightwalletService {
    async fn get_latest_block(&self, _req: Request<ChainSpec>) -> Result<Response<BlockId>, Status> {
        let height = self.db.header_height().map_err(|e| Status::internal(e.to_string()))?.unwrap_or(0);
        let hash = if let Some(h) = self.db.header_hash_by_height(height).map_err(|e| Status::internal(e.to_string()))? {
            h
        } else {
            genesis_hash_internal().to_vec()
        };
        Ok(Response::new(BlockId { height, hash }))
    }

    async fn get_block(&self, req: Request<BlockId>) -> Result<Response<CompactBlock>, Status> {
        let id = req.into_inner();
        if id.hash.len() != 0 {
            return Err(Status::invalid_argument("hash selection is not supported; use height"));
        }
        let raw = self.db.header_by_height(id.height).map_err(|e| Status::internal(e.to_string()))?
            .ok_or_else(|| Status::not_found(format!("header {} not found", id.height)))?;
        Ok(Response::new(compact_block_from_header(raw, id.height)?))
    }

    type GetBlockRangeStream = ReceiverStream<Result<CompactBlock, Status>>;
    async fn get_block_range(&self, req: Request<BlockRange>) -> Result<Response<Self::GetBlockRangeStream>, Status> {
        let r = req.into_inner();
        let start = r.start.map(|x| x.height).unwrap_or(0);
        let end = r.end.map(|x| x.height).unwrap_or(start);
        let (tx, rx) = tokio::sync::mpsc::channel(8);
        let db = self.db.clone();
        tokio::spawn(async move {
            let step_up = start <= end;
            let mut h = start;
            loop {
                match db.header_by_height(h) {
                    Ok(Some(raw)) => {
                        match compact_block_from_header(raw, h) {
                            Ok(block) => { if tx.send(Ok(block)).await.is_err() { break; } }
                            Err(e) => { let _ = tx.send(Err(e)).await; break; }
                        }
                    }
                    Ok(None) => {
                        let _ = tx.send(Err(Status::not_found(format!("header {} not found", h)))).await;
                        break;
                    }
                    Err(e) => { let _ = tx.send(Err(Status::internal(e.to_string()))).await; break; }
                }
                if h == end { break; }
                if step_up { h = h.saturating_add(1); } else { if h == 0 { break; } h -= 1; }
            }
        });
        Ok(Response::new(ReceiverStream::new(rx)))
    }

    async fn get_lightd_info(&self, _req: Request<Empty>) -> Result<Response<LightdInfo>, Status> {
        let height = self.db.header_height().map_err(|e| Status::internal(e.to_string()))?.unwrap_or(0);
        Ok(Response::new(LightdInfo {
            version: "0.30.4".into(),
            vendor: "Ycash".into(),
            taddr_support: true,
            chain_name: "main".into(),
            sapling_activation_height: 0,
            consensus_branch_id: "".into(),
            block_height: height,
            git_commit: "".into(),
            branch: "".into(),
            build_date: "".into(),
            build_user: "".into(),
            estimated_height: height,
            node_build: "".into(),
            node_subversion: "/YcashAndroid:0.30.4/".into(),
            donation_address: "".into(),
            upgrade_name: "".into(),
            upgrade_height: 0,
            lightwallet_protocol_version: "0.5.0".into(),
        }))
    }
}

fn start_lightwalletd(state: SharedState, db: Arc<State>) {
    let bind = std::env::var("YCASH_LIGHTWALLET_BIND").unwrap_or_else(|_| "127.0.0.1".into());
    let port = std::env::var("YCASH_LIGHTWALLET_PORT")
        .ok()
        .and_then(|x| x.parse().ok())
        .unwrap_or(9067u16);

    let addr: SocketAddr = match format!("{}:{}", bind, port).parse() {
        Ok(a) => a,
        Err(e) => {
            state.write().unwrap().last_error =
                format!("Lightwalletd address invalid: {e}");
            return;
        }
    };

    thread::spawn(move || {
        let rt = match tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .build()
        {
            Ok(rt) => rt,
            Err(e) => {
                state.write().unwrap().last_error =
                    format!("Lightwalletd runtime failed: {e}");
                return;
            }
        };

        rt.block_on(async move {
            // IMPORTANT: bind once and give the already-bound listener to tonic.
            // The previous implementation bound 9067, dropped that socket, and then
            // asked tonic to bind the address again. That created a race/window where
            // the diagnostic could see a listening HTTP/2 endpoint while the actual
            // gRPC server was not yet attached to the socket.
            match tokio::net::TcpListener::bind(addr).await {
                Ok(listener) => {
                    state.write().unwrap().lightwallet_listening = true;
                    state.write().unwrap().message =
                        format!("YWallet gRPC listening on {}:{}", bind, port);

                    let incoming = tokio_stream::wrappers::TcpListenerStream::new(listener);
                    if let Err(e) = Server::builder()
                        .add_service(CompactTxStreamerServer::new(LightwalletService { db }))
                        .serve_with_incoming(incoming)
                        .await
                    {
                        let mut st = state.write().unwrap();
                        st.lightwallet_listening = false;
                        st.last_error = format!("YWallet gRPC failed: {e}");
                    }
                }
                Err(e) => {
                    state.write().unwrap().last_error =
                        format!("YWallet gRPC bind {}:{} failed: {e}", bind, port);
                }
            }
        });
    });
}

/// Load Sapling (and, if present, Sprout Groth16) verifying parameters before
/// block sync starts. Files are looked up in $YCASH_PARAMS_DIR, else
/// <data dir>/params. Sapling blocks (height >= 419200) and post-checkpoint
/// Groth16 JoinSplits halt sync with a clear message if their files are
/// missing; nothing panics. A corrupt parameter file aborts at load time
/// (librustzcash checks the file hash), so replace it if that happens.
fn load_shielded_params(live:&SharedState,base:&Path){
    let dir=std::env::var("YCASH_PARAMS_DIR").map(PathBuf::from).unwrap_or_else(|_|base.join("params"));
    let spend=dir.join("sapling-spend.params");let output=dir.join("sapling-output.params");let sprout=dir.join("sprout-groth16.params");
    if !(spend.is_file()&&output.is_file()){let mut st=live.write().unwrap();st.message=format!("Sapling params not found in {} -- sync will stop at the first Sapling transaction",dir.display());return;}
    {let mut st=live.write().unwrap();st.message="loading shielded verification parameters...".into();}
    let sprout_opt=if sprout.is_file(){Some(sprout.as_path())}else{None};
    let r=ycash_consensus::initialize_shielded_verifier(&spend,&output,sprout_opt);
    let mut st=live.write().unwrap();
    st.message=match r{Ok(())=>format!("shielded params loaded (Sprout Groth16: {})",if sprout_opt.is_some(){"yes"}else{"no"}),Err(e)=>format!("shielded params failed to load: {e:?}")};
}
fn main(){let state=Arc::new(RwLock::new(LiveNodeState{running:true,..Default::default()}));let db_path=std::env::var("YCASH_NODE_DB").map(PathBuf::from).unwrap_or_else(|_|std::env::var("YCASH_DATA_DIR").map(|p|PathBuf::from(p).join("ycash-node.rocksdb")).unwrap_or_else(|_|PathBuf::from("ycash-node.rocksdb")));if let Some(p)=db_path.parent(){let _=std::fs::create_dir_all(p);}let db=match State::open(&db_path){Ok(x)=>Arc::new(x),Err(e)=>{eprintln!("database open failed: {e}");return}};if let Ok(h)=db.header_height(){let mut s=state.write().unwrap();s.headers_height=h.unwrap_or(0);s.local_height=db.tip_height().ok().flatten().unwrap_or(0);}if let Err(e)=start_api(state.clone(),db.clone(),db_path.parent().map(|p|p.to_path_buf()).unwrap_or_else(||PathBuf::from("."))){eprintln!("Status API failed: {e}");return}if let Some(base)=db_path.parent(){if let Err(e)=start_rpc(state.clone(),base){eprintln!("RPC failed: {e}");return}}start_lightwalletd(state.clone(), db.clone());load_shielded_params(&state,db_path.parent().unwrap_or(Path::new(".")));if let Err(e)=start_p2p_listener(state.clone()){eprintln!("P2P listener failed: {e}");return}println!("Ycash Android Rust full P2P node v0.30.4");println!("Ycash mainnet magic 24e92764, port 8833, protocol 270013");let st=state.clone();let d=db.clone();thread::spawn(move||peer_supervisor(st,d));loop{thread::park()}}
