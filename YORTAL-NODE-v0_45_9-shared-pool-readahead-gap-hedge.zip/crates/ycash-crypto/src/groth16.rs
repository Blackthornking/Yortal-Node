//! Yodel One verify-only Groth16 over BLS12-381.
//!
//! A node never needs R1CS synthesis, circuit gadgets, evaluation domains, or
//! proving-key query vectors. This module owns the consensus verification layer:
//! proof and verifying-key decoding with subgroup checks, the Groth16 pairing
//! equation, public-input packing, and randomized batch verification.
//!
//! Field and curve arithmetic is deliberately NOT reimplemented here. Fp/Fp2
//! for BLS12-381 is where both the speed and the correctness risk live, and it
//! wants audited assembly. This module owns the protocol layer and calls the
//! curve crate underneath, so the arithmetic backend can be swapped (for
//! example to blst's aarch64 assembly) without touching consensus logic.
//!
//! # The batch identity
//!
//! For proofs (A_i, B_i, C_i) with public inputs x_i, each valid proof satisfies
//!
//! ```text
//!   e(A_i, B_i) = e(alpha, beta) · e(L_i, gamma) · e(C_i, delta)
//!   L_i = IC_0 + Σ_j x_ij · IC_{j+1}
//! ```
//!
//! With secret random 128-bit scalars r_i, the batch checks
//!
//! ```text
//!   Π_i e(r_i·A_i, B_i) · e(Σ r_i·L_i, -gamma) · e(Σ r_i·C_i, -delta)
//!     == e(alpha, beta)^(Σ r_i)
//! ```
//!
//! # Batch construction
//!
//! A per-proof API would build `L_i` independently and then combine it:
//! N·(k+1) scalar multiplications. Expanding the sum instead:
//!
//! ```text
//!   Σ_i r_i·L_i = (Σ_i r_i)·IC_0 + Σ_j (Σ_i r_i·x_ij)·IC_{j+1}
//! ```
//!
//! The IC points are fixed in the verifying key. So the whole batch costs k+1
//! scalar multiplications regardless of how many proofs it holds: for a Sapling
//! spend, 8 instead of 8N. The scalar accumulation that replaces them is field
//! arithmetic, which is orders of magnitude cheaper than group arithmetic.
//!
//! This is exact algebra, not an approximation. The group element fed to the
//! pairing is identical to the one the per-proof form produces, so the equation
//! and its ~2^-128 soundness bound are unchanged.
//!
//! # Safety properties this module must keep
//!
//! * A batch failure is a hint, never a verdict: it says something in the set
//!   is bad, not which. Callers must re-check individually and treat the
//!   single-proof result as final.
//! * The r_i must be unpredictable and fresh per batch, from the OS RNG. They
//!   must never be derived from block or transaction data: a peer able to
//!   influence them could craft proofs that cancel.

use bls12_381::{multi_miller_loop, pairing, G1Affine, G1Projective, G2Affine, G2Prepared, Gt, Scalar};
use group::{Curve, Group};
use rand_core::{OsRng, RngCore};
use rayon::prelude::*;
// This crate is edition 2018: TryInto is not in the prelude.
use std::convert::TryInto;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Groth16Error {
    /// A point failed decompression, the curve equation, or the prime-order
    /// subgroup check. Accepting such a point would accept proofs the
    /// reference implementation rejects.
    InvalidPoint,
    /// The encoding was truncated or the input count did not match the key.
    MalformedEncoding,
    /// The pairing equation did not hold.
    VerificationFailed,
}

/// A Groth16 proof: three group elements, 192 bytes compressed.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Proof {
    pub a: G1Affine,
    pub b: G2Affine,
    pub c: G1Affine,
}

impl Proof {
    pub const BYTES: usize = 192;

    /// Decode the compressed proof wire format used by the Zcash Groth16 proofs on
    /// chain: compressed A ‖ B ‖ C.
    ///
    /// `from_compressed` performs the on-curve and prime-order subgroup checks.
    /// Neither may be skipped: a point of small order in the wrong subgroup can
    /// make the pairing equation hold for a proof that is not valid.
    pub fn read(bytes: &[u8]) -> Result<Self, Groth16Error> {
        if bytes.len() < Self::BYTES {
            return Err(Groth16Error::MalformedEncoding);
        }
        let a = read_g1(&bytes[0..48])?;
        let b = read_g2(&bytes[48..144])?;
        let c = read_g1(&bytes[144..192])?;
        if bool::from(a.is_identity()) || bool::from(b.is_identity()) || bool::from(c.is_identity()) {
            return Err(Groth16Error::InvalidPoint);
        }
        Ok(Self { a, b, c })
    }

    pub fn write(&self) -> [u8; Self::BYTES] {
        let mut out = [0u8; Self::BYTES];
        out[0..48].copy_from_slice(&self.a.to_compressed());
        out[48..144].copy_from_slice(&self.b.to_compressed());
        out[144..192].copy_from_slice(&self.c.to_compressed());
        out
    }
}

/// Verifying keys on disk use the *uncompressed* encoding (96/192 bytes),
/// unlike proofs on the wire, which are compressed (48/96). `from_uncompressed`
/// still performs the on-curve and prime-order subgroup checks.
fn read_g1_uncompressed(bytes: &[u8]) -> Result<G1Affine, Groth16Error> {
    let raw: [u8; 96] = bytes.try_into().map_err(|_| Groth16Error::MalformedEncoding)?;
    Option::from(G1Affine::from_uncompressed(&raw)).ok_or(Groth16Error::InvalidPoint)
}

fn read_g2_uncompressed(bytes: &[u8]) -> Result<G2Affine, Groth16Error> {
    let raw: [u8; 192] = bytes.try_into().map_err(|_| Groth16Error::MalformedEncoding)?;
    Option::from(G2Affine::from_uncompressed(&raw)).ok_or(Groth16Error::InvalidPoint)
}

fn read_g1(bytes: &[u8]) -> Result<G1Affine, Groth16Error> {
    let raw: [u8; 48] = bytes.try_into().map_err(|_| Groth16Error::MalformedEncoding)?;
    Option::from(G1Affine::from_compressed(&raw)).ok_or(Groth16Error::InvalidPoint)
}

fn read_g2(bytes: &[u8]) -> Result<G2Affine, Groth16Error> {
    let raw: [u8; 96] = bytes.try_into().map_err(|_| Groth16Error::MalformedEncoding)?;
    Option::from(G2Affine::from_compressed(&raw)).ok_or(Groth16Error::InvalidPoint)
}

/// A Groth16 verifying key.
///
/// `beta_g1` and `delta_g1` appear in the legacy parameter encoding because
/// the same file also contains proving material; verification does not use them, so they are parsed
/// (and subgroup-checked, since a malformed key must not silently load) and
/// then dropped.
#[derive(Debug, Clone)]
pub struct VerifyingKey {
    pub alpha_g1: G1Affine,
    pub beta_g2: G2Affine,
    pub gamma_g2: G2Affine,
    pub delta_g2: G2Affine,
    /// IC_0 followed by one point per public input.
    pub ic: Vec<G1Affine>,
}

impl VerifyingKey {
    /// Fixed part of the encoding, before the IC length and points:
    /// alpha_g1 ‖ beta_g1 ‖ beta_g2 ‖ gamma_g2 ‖ delta_g1 ‖ delta_g2,
    /// uncompressed.
    pub const HEADER_BYTES: usize = 96 + 96 + 192 + 192 + 96 + 192;

    /// Decode a verifying key from the head of a legacy Groth16 parameter file.
    ///
    /// The key is a *prefix*: the proving key's h, l, a, b_g1 and b_g2 query
    /// vectors follow it and are not read. For `sapling-spend.params` the key
    /// is 1,636 bytes of a 47,958,396-byte file, so a node that only verifies
    /// never needs the rest — on disk or in memory.
    pub fn read(bytes: &[u8]) -> Result<Self, Groth16Error> {
        if bytes.len() < Self::HEADER_BYTES + 4 {
            return Err(Groth16Error::MalformedEncoding);
        }
        let alpha_g1 = read_g1_uncompressed(&bytes[0..96])?;
        let _beta_g1 = read_g1_uncompressed(&bytes[96..192])?;
        let beta_g2 = read_g2_uncompressed(&bytes[192..384])?;
        let gamma_g2 = read_g2_uncompressed(&bytes[384..576])?;
        let _delta_g1 = read_g1_uncompressed(&bytes[576..672])?;
        let delta_g2 = read_g2_uncompressed(&bytes[672..864])?;

        let count = u32::from_be_bytes(
            bytes[864..868].try_into().map_err(|_| Groth16Error::MalformedEncoding)?,
        ) as usize;
        // A key with no IC_0 cannot describe any statement. Sapling spend has
        // 8 points (7 public inputs); output has 6 (5 inputs).
        if count == 0 || count > 1024 {
            return Err(Groth16Error::MalformedEncoding);
        }
        let end = 868 + count * 96;
        if bytes.len() < end {
            return Err(Groth16Error::MalformedEncoding);
        }
        let mut ic = Vec::with_capacity(count);
        for i in 0..count {
            let offset = 868 + i * 96;
            ic.push(read_g1_uncompressed(&bytes[offset..offset + 96])?);
        }
        Ok(Self { alpha_g1, beta_g2, gamma_g2, delta_g2, ic })
    }

    /// Byte length of the key at the head of `bytes`, without decoding it.
    /// Lets a loader read the prefix and stop.
    pub fn encoded_len(bytes: &[u8]) -> Result<usize, Groth16Error> {
        if bytes.len() < Self::HEADER_BYTES + 4 {
            return Err(Groth16Error::MalformedEncoding);
        }
        let count = u32::from_be_bytes(
            bytes[864..868].try_into().map_err(|_| Groth16Error::MalformedEncoding)?,
        ) as usize;
        if count == 0 || count > 1024 {
            return Err(Groth16Error::MalformedEncoding);
        }
        Ok(868 + count * 96)
    }

    /// Number of public inputs this key expects.
    pub fn public_inputs(&self) -> usize {
        self.ic.len() - 1
    }
}

/// Load a verifying key from a legacy Groth16 parameter file, reading only its
/// verification-key prefix.
///
/// Parameter files may contain proof-generation query vectors after the
/// verifying-key prefix. The verifier reads only the prefix and never loads
/// those query vectors into memory.
pub fn read_verifying_key_file(path: &std::path::Path) -> std::io::Result<VerifyingKey> {
    use std::io::{Error, ErrorKind, Read};
    let mut file = std::fs::File::open(path)?;
    let mut head = vec![0u8; VerifyingKey::HEADER_BYTES + 4];
    file.read_exact(&mut head)?;
    let total = VerifyingKey::encoded_len(&head)
        .map_err(|e| Error::new(ErrorKind::InvalidData, format!("{e:?} in {}", path.display())))?;
    head.resize(total, 0);
    file.read_exact(&mut head[VerifyingKey::HEADER_BYTES + 4..])?;
    VerifyingKey::read(&head)
        .map_err(|e| Error::new(ErrorKind::InvalidData, format!("{e:?} in {}", path.display())))
}

/// Convert bytes into the exact bit ordering used by the legacy Groth16
/// multipack helper: bits are consumed most-significant-bit first within each
/// byte, then packed little-endian into 254-bit scalar chunks.
///
/// This is intentionally separate from Sapling's field-element decoding. Sprout
/// proofs expose byte strings through `bytes_to_bits`, while Sapling public
/// inputs are already encoded as field elements by the circuit.
pub fn bytes_to_multipacking(bytes: &[u8]) -> Result<Vec<Scalar>, Groth16Error> {
    const CAPACITY: usize = 254; // BLS12-381 Fr capacity.
    let total_bits = bytes.len().checked_mul(8).ok_or(Groth16Error::MalformedEncoding)?;
    if total_bits == 0 {
        return Ok(Vec::new());
    }

    let chunks = (total_bits + CAPACITY - 1) / CAPACITY;
    let mut result = Vec::with_capacity(chunks);
    for chunk_index in 0..chunks {
        let start_bit = chunk_index * CAPACITY;
        let bit_count = (total_bits - start_bit).min(CAPACITY);
        let mut repr = [0u8; 32];
        for local_bit in 0..bit_count {
            let global_bit = start_bit + local_bit;
            let byte = bytes[global_bit / 8];
            let bit_in_byte = 7 - (global_bit % 8); // legacy `bytes_to_bits`
            if ((byte >> bit_in_byte) & 1) != 0 {
                repr[local_bit / 8] |= 1u8 << (local_bit % 8);
            }
        }
        let scalar = Option::from(Scalar::from_bytes(&repr))
            .ok_or(Groth16Error::MalformedEncoding)?;
        result.push(scalar);
    }
    Ok(result)
}

/// A block-chain link used by the Yodel One batch barrier.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ChainLink {
    pub height: u64,
    pub hash: [u8; 32],
    pub prev_hash: [u8; 32],
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ChainLinkError {
    Empty,
    WrongStartHeight { expected: u64, actual: u64 },
    FirstParentMismatch,
    HeightGap { previous: u64, current: u64 },
    ParentMismatch { height: u64 },
}

/// Deterministic ancestry barrier for a verification batch.
///
/// Groth16 proves a statement chosen by its circuit; it cannot by itself infer
/// that a network batch contains the canonical chain's missing parent. Yodel
/// therefore treats canonical `(tip + 1, tip_hash)` as part of the verifier
/// protocol and refuses to enter the proof-verification stage unless every
/// link in the proposed window is present and ordered.
pub fn validate_chain_links(
    expected_height: u64,
    expected_parent: [u8; 32],
    links: &[ChainLink],
) -> Result<(), ChainLinkError> {
    let first = links.first().ok_or(ChainLinkError::Empty)?;
    if first.height != expected_height {
        return Err(ChainLinkError::WrongStartHeight {
            expected: expected_height,
            actual: first.height,
        });
    }
    if first.prev_hash != expected_parent {
        return Err(ChainLinkError::FirstParentMismatch);
    }
    for pair in links.windows(2) {
        let previous = pair[0];
        let current = pair[1];
        if previous.height.checked_add(1) != Some(current.height) {
            return Err(ChainLinkError::HeightGap {
                previous: previous.height,
                current: current.height,
            });
        }
        if current.prev_hash != previous.hash {
            return Err(ChainLinkError::ParentMismatch {
                height: current.height,
            });
        }
    }
    Ok(())
}

/// A verifying key with the per-verification-invariant work done once.
///
/// `alpha_beta` is a full pairing, and the prepared G2 points carry the Miller
/// loop line functions for gamma and delta. Both are fixed for the lifetime of
/// the key, so neither belongs in a per-proof or per-batch path.
pub struct PreparedVerifyingKey {
    pub alpha_beta: Gt,
    neg_gamma: G2Prepared,
    neg_delta: G2Prepared,
    ic: Vec<G1Affine>,
}

impl PreparedVerifyingKey {
    pub fn new(vk: &VerifyingKey) -> Self {
        Self {
            alpha_beta: pairing(&vk.alpha_g1, &vk.beta_g2),
            neg_gamma: G2Prepared::from(-vk.gamma_g2),
            neg_delta: G2Prepared::from(-vk.delta_g2),
            ic: vk.ic.clone(),
        }
    }

    pub fn public_inputs(&self) -> usize {
        self.ic.len() - 1
    }

    /// L = IC_0 + Σ_j x_j · IC_{j+1} for one proof.
    fn public_input_commitment(&self, inputs: &[Scalar]) -> Result<G1Projective, Groth16Error> {
        if inputs.len() + 1 != self.ic.len() {
            return Err(Groth16Error::MalformedEncoding);
        }
        let mut scalars = Vec::with_capacity(self.ic.len());
        scalars.push(Scalar::one());
        scalars.extend_from_slice(inputs);
        Ok(pippenger_msm(&self.ic, &scalars))
    }

    /// Verify one proof. This is the reference path: the batch is an
    /// optimisation over it, and any batch rejection is resolved by coming
    /// back here.
    pub fn verify(&self, proof: &Proof, inputs: &[Scalar]) -> Result<(), Groth16Error> {
        let l = self.public_input_commitment(inputs)?.to_affine();
        let proof_b = G2Prepared::from(proof.b);
        let terms: [(&G1Affine, &G2Prepared); 3] = [
            (&proof.a, &proof_b),
            (&l, &self.neg_gamma),
            (&proof.c, &self.neg_delta),
        ];
        // e(A,B) · e(L,-gamma) · e(C,-delta) == e(alpha,beta)
        if multi_miller_loop(&terms).final_exponentiation() == self.alpha_beta {
            Ok(())
        } else {
            Err(Groth16Error::VerificationFailed)
        }
    }
}

/// One queued proof and its public inputs.
pub struct BatchItem {
    pub proof: Proof,
    pub inputs: Vec<Scalar>,
}

/// A batch of proofs against one verifying key.
///
/// Correctness note for callers: `verify` returns a single verdict for the
/// whole set. On failure the caller must fall back to per-item verification;
/// the batch cannot say which item was bad, and treating a batch failure as a
/// per-item verdict would reject valid proofs.
#[derive(Default)]
pub struct Batch {
    items: Vec<BatchItem>,
}

impl Batch {
    pub fn new() -> Self {
        Self { items: Vec::new() }
    }

    pub fn push(&mut self, proof: Proof, inputs: Vec<Scalar>) {
        self.items.push(BatchItem { proof, inputs });
    }

    pub fn len(&self) -> usize {
        self.items.len()
    }

    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    pub fn items(&self) -> &[BatchItem] {
        &self.items
    }

    pub fn take(&mut self) -> Vec<BatchItem> {
        std::mem::take(&mut self.items)
    }

    /// Prepare the complete randomized batch for one verifying key.
    ///
    /// Proof preparation is CPU-parallel: each item gets its fresh randomizer,
    /// its `r*A` point, its prepared `B`, and its weighted public-input scalars
    /// independently. The two variable-base MSMs (the C accumulator and the
    /// public-input/IC accumulator) are then accumulated concurrently.
    fn prepare(&self, key: &PreparedVerifyingKey) -> Result<PreparedBatch, Groth16Error> {
        if self.items.is_empty() {
            return Ok(PreparedBatch::empty());
        }
        let expected_inputs = key.public_inputs();
        if self.items.iter().any(|item| item.inputs.len() != expected_inputs) {
            return Err(Groth16Error::MalformedEncoding);
        }

        let prepared: Vec<PreparedItem> = self
            .items
            .par_iter()
            .map(|item| {
                // A singleton is exact; multi-item sets use fresh OS randomness.
                let r = if self.items.len() == 1 { Scalar::one() } else { random_scalar() };
                let weighted_inputs = item.inputs.iter().map(|x| r * x).collect();
                PreparedItem {
                    r,
                    a: G1Affine::from(G1Projective::from(item.proof.a) * r),
                    b: G2Prepared::from(item.proof.b),
                    c: item.proof.c,
                    weighted_inputs,
                }
            })
            .collect();

        let r_sum = prepared
            .par_iter()
            .map(|item| item.r)
            .reduce(Scalar::zero, |a, b| a + b);

        let (l_acc, c_acc) = rayon::join(
            || {
                // L = (Σr_i)·IC_0 + Σ_j(Σ_i r_i·x_ij)·IC_{j+1}.
                // This is a single public-input MSM over the fixed IC bases;
                // unlike the old Bellman-style loop it does not perform one
                // independent scalar multiplication per public input.
                let mut scalars = vec![r_sum; key.ic.len()];
                for item in &prepared {
                    for (j, scalar) in item.weighted_inputs.iter().enumerate() {
                        scalars[j + 1] += *scalar;
                    }
                }
                pippenger_msm(&key.ic, &scalars)
            },
            || {
                let points: Vec<G1Affine> = prepared.iter().map(|item| item.c).collect();
                let scalars: Vec<Scalar> = prepared.iter().map(|item| item.r).collect();
                pippenger_msm(&points, &scalars)
            },
        );

        let a_terms = prepared.into_iter().map(|item| (item.a, item.b)).collect();
        Ok(PreparedBatch {
            r_sum,
            a_terms,
            l_acc: l_acc.to_affine(),
            c_acc: c_acc.to_affine(),
        })
    }

    /// Verify every queued proof in one pairing check.
    ///
    /// This keeps the existing public API while routing the expensive path
    /// through the adaptive MSM/preparation implementation above.
    pub fn verify(&self, key: &PreparedVerifyingKey) -> Result<(), Groth16Error> {
        let prepared = self.prepare(key)?;
        verify_prepared(key, &prepared)
    }

    /// Verify two proof sets, each against its own verifying key, in a single
    /// multi-Miller loop and final exponentiation.
    ///
    /// Spend and Output keep independent `L`/`C` accumulators because their
    /// verifying keys differ, but their prepared A/B terms are merged into one
    /// pairing product. The only final exponentiation is therefore shared
    /// across the two Sapling verifying keys.
    pub fn verify_pair(
        spend: &Batch,
        spend_key: &PreparedVerifyingKey,
        output: &Batch,
        output_key: &PreparedVerifyingKey,
    ) -> Result<(), Groth16Error> {
        if spend.items.is_empty() && output.items.is_empty() {
            return Ok(());
        }

        // Independent Spend/Output proof preparation is safe because all key
        // data is immutable. Rayon keeps the two verification-key accumulators
        // separate while overlapping their work.
        let (spend_prepared, output_prepared) = rayon::join(
            || spend.prepare(spend_key),
            || output.prepare(output_key),
        );
        let spend_prepared = spend_prepared?;
        let output_prepared = output_prepared?;

        let mut terms: Vec<(&G1Affine, &G2Prepared)> = Vec::with_capacity(
            spend_prepared.a_terms.len() + output_prepared.a_terms.len() + 4,
        );
        for (a, b) in &spend_prepared.a_terms {
            terms.push((a, b));
        }
        for (a, b) in &output_prepared.a_terms {
            terms.push((a, b));
        }
        terms.push((&spend_prepared.l_acc, &spend_key.neg_gamma));
        terms.push((&spend_prepared.c_acc, &spend_key.neg_delta));
        terms.push((&output_prepared.l_acc, &output_key.neg_gamma));
        terms.push((&output_prepared.c_acc, &output_key.neg_delta));

        let lhs = multi_miller_loop(&terms).final_exponentiation();
        let rhs = (spend_key.alpha_beta * spend_prepared.r_sum)
            * (output_key.alpha_beta * output_prepared.r_sum);
        if lhs == rhs {
            Ok(())
        } else {
            Err(Groth16Error::VerificationFailed)
        }
    }

    /// Verify each item on its own and return the indices that failed. Used to
    /// resolve a batch rejection into per-proof verdicts.
    pub fn verify_individually(&self, key: &PreparedVerifyingKey) -> Vec<usize> {
        self.items
            .iter()
            .enumerate()
            .filter_map(|(i, item)| key.verify(&item.proof, &item.inputs).err().map(|_| i))
            .collect()
    }
}

/// A fresh 128-bit randomiser. Wider than needed for the soundness bound and
/// cheaper to multiply by than a full-width scalar.
fn random_scalar() -> Scalar {
    loop {
        let mut bytes = [0u8; 64];
        OsRng.fill_bytes(&mut bytes[..16]);
        let scalar = Scalar::from_bytes_wide(&bytes);
        if scalar != Scalar::zero() {
            return scalar;
        }
    }
}

/// One proof after parallel preparation.
struct PreparedItem {
    r: Scalar,
    a: G1Affine,
    b: G2Prepared,
    c: G1Affine,
    weighted_inputs: Vec<Scalar>,
}

/// The complete randomized equation for one verifying key after preparation.
struct PreparedBatch {
    r_sum: Scalar,
    a_terms: Vec<(G1Affine, G2Prepared)>,
    l_acc: G1Affine,
    c_acc: G1Affine,
}

impl PreparedBatch {
    fn empty() -> Self {
        Self {
            r_sum: Scalar::zero(),
            a_terms: Vec::new(),
            l_acc: G1Affine::identity(),
            c_acc: G1Affine::identity(),
        }
    }
}

fn verify_prepared(key: &PreparedVerifyingKey, prepared: &PreparedBatch) -> Result<(), Groth16Error> {
    if prepared.a_terms.is_empty() {
        return Ok(());
    }
    let mut terms: Vec<(&G1Affine, &G2Prepared)> = Vec::with_capacity(prepared.a_terms.len() + 2);
    for (a, b) in &prepared.a_terms {
        terms.push((a, b));
    }
    terms.push((&prepared.l_acc, &key.neg_gamma));
    terms.push((&prepared.c_acc, &key.neg_delta));

    if multi_miller_loop(&terms).final_exponentiation() == key.alpha_beta * prepared.r_sum {
        Ok(())
    } else {
        Err(Groth16Error::VerificationFailed)
    }
}

/// Σ scalars_i · points_i, using an adaptive Pippenger window.
///
/// The window is selected from the actual point count. Small MSMs use the
/// smallest useful window (or direct scalar multiplication), while larger MSMs
/// increase the window to amortise bucket construction. The bit width is taken
/// from the scalars themselves, so 128-bit randomisers do not pay for 255 bits.
fn pippenger_msm(points: &[G1Affine], scalars: &[Scalar]) -> G1Projective {
    debug_assert_eq!(points.len(), scalars.len());
    if points.is_empty() {
        return G1Projective::identity();
    }
    if points.len() < 4 {
        let mut acc = G1Projective::identity();
        for (point, scalar) in points.iter().zip(scalars.iter()) {
            acc += G1Projective::from(*point) * scalar;
        }
        return acc;
    }

    let window = adaptive_window(points.len());
    let bucket_count = 1usize << window;
    let mask = bucket_count - 1;

    let scalar_bytes: Vec<[u8; 32]> = scalars.iter().map(|s| s.to_bytes()).collect();
    let bits = scalar_bytes.iter().map(scalar_bit_length).max().unwrap_or(0);
    if bits == 0 {
        return G1Projective::identity();
    }
    let mut acc = G1Projective::identity();

    // Process high windows first: each pass shifts the accumulator by exactly
    // `window` bits before adding that window's bucket sum.
    let windows = (bits + window - 1) / window;
    for window_index in (0..windows).rev() {
        for _ in 0..window {
            acc = acc.double();
        }

        let mut buckets = vec![G1Projective::identity(); bucket_count];
        let bit_offset = window_index * window;
        for (point, bytes) in points.iter().zip(scalar_bytes.iter()) {
            let digit = scalar_window(bytes, bit_offset, window) & mask;
            if digit != 0 {
                buckets[digit] += G1Projective::from(*point);
            }
        }

        let mut running = G1Projective::identity();
        let mut window_sum = G1Projective::identity();
        for bucket in buckets.iter().skip(1).rev() {
            running += bucket;
            window_sum += running;
        }
        acc += window_sum;
    }
    acc
}

fn adaptive_window(points: usize) -> usize {
    match points {
        0..=7 => 3,
        8..=15 => 4,
        16..=31 => 5,
        32..=63 => 6,
        64..=127 => 7,
        128..=255 => 8,
        256..=511 => 9,
        _ => 10,
    }
}

fn scalar_bit_length(bytes: &[u8; 32]) -> usize {
    for i in (0..bytes.len()).rev() {
        let byte = bytes[i];
        if byte != 0 {
            return i * 8 + (8 - byte.leading_zeros() as usize);
        }
    }
    0
}

fn scalar_window(bytes: &[u8; 32], bit_offset: usize, width: usize) -> usize {
    if bit_offset >= 256 {
        return 0;
    }
    let mut word = 0u32;
    let byte_offset = bit_offset / 8;
    let shift = bit_offset % 8;
    for i in 0..4 {
        let idx = byte_offset + i;
        if idx < bytes.len() {
            word |= (bytes[idx] as u32) << (8 * i);
        }
    }
    ((word >> shift) & ((1u32 << width.min(16)) - 1)) as usize
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_truncated_proof_is_rejected() {
        assert_eq!(Proof::read(&[0u8; 100]).unwrap_err(), Groth16Error::MalformedEncoding);
    }

    #[test]
    fn an_uncompressable_point_is_rejected() {
        // All-zero compressed bytes have no compression flag set, so this is
        // not a valid encoding of any point.
        assert_eq!(Proof::read(&[0u8; Proof::BYTES]).unwrap_err(), Groth16Error::InvalidPoint);
    }

    #[test]
    fn a_truncated_verifying_key_is_rejected() {
        assert_eq!(VerifyingKey::read(&[0u8; 64]).unwrap_err(), Groth16Error::MalformedEncoding);
    }

    #[test]
    fn the_sapling_key_lengths_match_the_published_parameters() {
        // sapling-spend.params: 8 IC points -> 1636 bytes.
        let mut spend = vec![0u8; 868];
        spend[864..868].copy_from_slice(&8u32.to_be_bytes());
        spend.extend(std::iter::repeat(0u8).take(8 * 96));
        assert_eq!(VerifyingKey::encoded_len(&spend).unwrap(), 1636);

        // sapling-output.params: 6 IC points -> 1444 bytes.
        let mut output = vec![0u8; 868];
        output[864..868].copy_from_slice(&6u32.to_be_bytes());
        output.extend(std::iter::repeat(0u8).take(6 * 96));
        assert_eq!(VerifyingKey::encoded_len(&output).unwrap(), 1444);
    }

    #[test]
    fn pippenger_msm_matches_naive_across_adaptive_sizes() {
        for &count in &[4usize, 6, 8, 16, 31, 64] {
            let points: Vec<G1Affine> = (0..count)
                .map(|i| G1Affine::from(G1Projective::generator() * Scalar::from((i as u64) + 1)))
                .collect();
            let scalars: Vec<Scalar> = (0..count)
                .map(|i| Scalar::from((i as u64 + 3) * 17))
                .collect();

            let got = pippenger_msm(&points, &scalars);
            let mut expected = G1Projective::identity();
            for (point, scalar) in points.iter().zip(scalars.iter()) {
                expected += G1Projective::from(*point) * scalar;
            }
            assert_eq!(got.to_affine(), expected.to_affine());
        }
    }

    #[test]
    fn pippenger_reads_high_scalar_windows() {
        let generator = G1Projective::generator();
        let points: Vec<G1Affine> = (1..=4)
            .map(|i| G1Affine::from(generator * Scalar::from(i as u64)))
            .collect();
        let mut wide = [0u8; 64];
        wide[25] = 0x80; // exercises a bit well above the 128-bit randomizer range.
        let high = Scalar::from_bytes_wide(&wide);
        let scalars = vec![high, Scalar::from(3u64), high, Scalar::from(9u64)];
        let got = pippenger_msm(&points, &scalars);
        let mut expected = G1Projective::identity();
        for (point, scalar) in points.iter().zip(scalars.iter()) {
            expected += G1Projective::from(*point) * scalar;
        }
        assert_eq!(got.to_affine(), expected.to_affine());
    }

    #[test]
    fn sprout_byte_packing_uses_legacy_msb_byte_order() {
        let packed = bytes_to_multipacking(&[0b1000_0001]).unwrap();
        assert_eq!(packed.len(), 1);
        // Bit sequence is [1,0,0,0,0,0,0,1], so the scalar is 1 + 2^7.
        assert_eq!(packed[0], Scalar::from(129u64));
    }

    #[test]
    fn chain_barrier_rejects_a_batch_with_a_missing_first_parent() {
        let links = [
            ChainLink { height: 2, hash: [2u8; 32], prev_hash: [1u8; 32] },
            ChainLink { height: 3, hash: [3u8; 32], prev_hash: [2u8; 32] },
        ];
        assert_eq!(
            validate_chain_links(1, [0u8; 32], &links),
            Err(ChainLinkError::WrongStartHeight { expected: 1, actual: 2 })
        );
    }

    #[test]
    fn chain_barrier_rejects_parent_hash_mismatch() {
        let links = [
            ChainLink { height: 10, hash: [10u8; 32], prev_hash: [9u8; 32] },
            ChainLink { height: 11, hash: [11u8; 32], prev_hash: [8u8; 32] },
        ];
        assert_eq!(
            validate_chain_links(10, [9u8; 32], &links),
            Err(ChainLinkError::ParentMismatch { height: 11 })
        );
    }

    #[test]
    fn multi_scalar_mul_matches_the_naive_sum() {
        let points: Vec<G1Projective> = (1u64..=12).map(|i| G1Projective::generator() * Scalar::from(i)).collect();
        let scalars: Vec<Scalar> = (1u64..=12).map(|i| Scalar::from(i * 7 + 1)).collect();
        let mut expected = G1Projective::identity();
        for (p, s) in points.iter().zip(scalars.iter()) {
            expected += p * s;
        }
        assert_eq!(multi_scalar_mul(&points, &scalars), expected);
    }

    #[test]
    fn randomisers_are_fresh_per_call() {
        assert_ne!(random_scalar(), random_scalar());
    }
}
