#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
V="$ROOT/crates/node/src/verifier.rs"
S="$ROOT/crates/state/src/state_service.rs"
D="$ROOT/crates/node/src/downloader.rs"
L="$ROOT/crates/state/src/lib.rs"

fail(){ echo "[FAIL] $*" >&2; exit 1; }

grep -q 'pub const MAX_BLOCKS_PER_PROOF_BATCH: usize = crate::PIPELINE_BATCH_SIZE;' "$V" || fail "global 16-block proof batch cap missing"
grep -q 'verify_batch_in_order(raw_blocks, workers, assume_valid)' "$V" || fail "active 16-block verifier wiring missing"
grep -q 'global Sapling proof batch' "$V" || fail "global proof-batch dispatch telemetry missing"
grep -q 'pub fn verify_batch_in_order' "$ROOT/crates/node/src/batch.rs" || fail "global batch verifier missing"
grep -q 'proof_batches' "$ROOT/crates/node/src/batch.rs" || fail "worker proof-batch merge missing"
grep -q 'pub fn append(&mut self, mut other: ProofBatch)' "$ROOT/crates/consensus/src/lib.rs" || fail "cross-worker proof batch merge missing"
grep -q 'pub struct VerifiedBatch' "$ROOT/crates/node/src/batch.rs" || fail "verified batch result missing"
grep -q 'pub fn append_with_offset' "$ROOT/crates/ycash-crypto/src/batch.rs" || fail "crypto batch append missing"
grep -q 'pub const MAX_BLOCKS_IN_FLIGHT: usize = 16;' "$D" || fail "global 16-block lifecycle bound missing"
grep -q 'pub fn apply_prepared_commit' "$L" || fail "single canonical prepared commit path missing"

if grep -q 'state.offer(verified)' "$V"; then
  fail "old per-block semantic handoff still present"
fi

python3 - <<'PY'
def partition(n, workers):
    w=max(1,min(workers,max(1,n)))
    base=n//w
    rem=n%w
    out=[]
    start=0
    for i in range(w):
        length=base+(1 if i<rem else 0)
        out.append(range(start,start+length))
        start += length
    return out

ranges=partition(16,4)
assert [len(x) for x in ranges] == [4,4,4,4]
assert list(x for r in ranges for x in r) == list(range(16))
ranges=partition(16,3)
assert [len(x) for x in ranges] == [6,5,5]
assert list(x for r in ranges for x in r) == list(range(16))
print('[PASS] 16-block partition invariants')
PY

grep -q 'pub fn verify_batch_in_order' "$ROOT/crates/node/src/batch.rs" || fail "active global batch verifier missing"
grep -q 'proof_batches.sort_by_key' "$ROOT/crates/node/src/batch.rs" || fail "worker proof batches are not deterministically merged"
grep -q 'ProofBatch::append' "$ROOT/crates/node/src/batch.rs" || true
grep -q 'proof batch rejected' "$ROOT/crates/node/src/batch.rs" || fail "global batch failure isolation missing"

echo '[PASS] active 16-block global Sapling proof batching invariants'
